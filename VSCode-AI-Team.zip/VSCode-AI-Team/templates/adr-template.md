# ADR-[NNN]: [Decision Title]

**Date:** [YYYY-MM-DD]
**Status:** [Proposed | Accepted | Deprecated | Superseded by ADR-XXX]
**Deciders:** [Names or agent roles]
**DRB Reviewed:** [Yes | No | N/A — scope below threshold]

---

## Context

[Describe the situation and the problem being solved. What forces are at play? What constraints exist? Keep this factual and objective. Explain why this decision needs to be made now.]

### Problem Statement
[1-2 sentences: exactly what are we deciding?]

### Driving Requirements
- [Requirement 1]
- [Requirement 2]
- [Non-functional requirement]

### Constraints
- [Constraint 1: e.g., must integrate with existing system X]
- [Constraint 2: e.g., team has no expertise in Y]
- [Constraint 3: e.g., budget limit]

---

## Decision

[State the decision clearly in one or two sentences.]

> **We will [decision] because [primary reason].**

---

## Rationale

[Explain the reasoning behind this decision. Why is this option preferred over the alternatives?]

### Key Factors
1. [Factor 1 and how it supports this decision]
2. [Factor 2]
3. [Factor 3]

---

## Alternatives Considered

| Option | Description | Why Not Selected |
|--------|-------------|-----------------|
| [Option A — the chosen option] | [Brief description] | Selected |
| [Option B] | [Brief description] | [Reason: e.g., higher complexity, security concern, cost] |
| [Option C] | [Brief description] | [Reason] |

---

## Consequences

### Positive
- [Benefit 1]
- [Benefit 2]
- [Benefit 3]

### Negative
- [Drawback or constraint introduced]
- [Technical debt incurred]
- [Operational complexity added]

### Risks
| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| [Risk 1] | H/M/L | H/M/L | [How mitigated] |
| [Risk 2] | H/M/L | H/M/L | [How mitigated] |

### Technical Debt
[Any technical debt this decision introduces and the plan to address it]

---

## DRB Review Summary

*(Complete this section if DRB was convened)*

| Reviewer | Position | Notes |
|----------|---------|-------|
| Enterprise Architect | [Approve / Approve with conditions / Dissent] | [Key point] |
| DevSecOps | [Approve / Approve with conditions / Dissent] | [Key point] |
| Risk & Privacy | [Approve / Approve with conditions / Dissent] | [Key point] |

### Dissenting Opinions
[Record any dissenting positions with their full reasoning — do not suppress]

---

## Implementation Notes

[Any important notes about how this decision should be implemented]

### Dependencies
- [What must be true or in place before this can be implemented]

### Migration Path
[If this supersedes a previous approach, how do we transition?]

---

## Review

**Review Date:** [Date — typically 6-12 months or when context changes significantly]
**Review Trigger:** [What event would cause this decision to be revisited?]

---

*ADR format based on Michael Nygard's original format, extended for enterprise DRB process.*
