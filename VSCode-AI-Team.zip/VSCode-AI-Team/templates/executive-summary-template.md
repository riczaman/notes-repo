# Executive Summary Template

**Title:** [Topic — Executive Brief]
**Date:** [YYYY-MM-DD]
**Classification:** [Internal | Confidential | Restricted]
**Prepared for:** [Audience: CEO / Board / Steering Committee / VP]
**Prepared by:** [Team/Agent]
**Version:** [1.0]

---

## 🎯 Bottom Line

> [1-2 sentences. The single most important thing this audience needs to know. Written for someone who reads only this section.]

---

## Situation

[2-3 sentences. Context and current state. No jargon. What is happening and why does the audience care?]

---

## Decision / Action Required

> **[What specific decision or action is required from this audience?]**
>
> **Decision Deadline:** [Date — and consequence of missing it]

*(If information-only and no decision is required, replace this section with "For Information Only" and remove the options table below.)*

---

## Options Considered

| Option | Summary | Key Benefit | Key Risk | Recommended |
|--------|---------|-------------|---------|-------------|
| A — [Name] | [1 line] | [Primary benefit] | [Primary risk] | ✅ Yes |
| B — [Name] | [1 line] | [Primary benefit] | [Primary risk] | |
| C — Do Nothing | [Maintain status quo] | [None / describe] | [Cost of inaction] | |

---

## Key Metrics

| Metric | Target | Actual / Forecast | Trend | Status |
|--------|--------|------------------|-------|--------|
| [Metric 1] | [X] | [Y] | ↑ / ↓ / → | 🟢 / 🟡 / 🔴 |
| [Metric 2] | [X] | [Y] | ↑ / ↓ / → | 🟢 / 🟡 / 🔴 |

---

## Risks

| Risk | Likelihood | Impact | Mitigation | Owner |
|------|-----------|--------|-----------|-------|
| [Risk 1] | H/M/L | H/M/L | [Mitigation] | [Name] |
| [Risk 2] | H/M/L | H/M/L | [Mitigation] | [Name] |

---

## Financial Summary

| Item | Amount | Notes |
|------|--------|-------|
| One-time investment | $[X] | [Context] |
| Ongoing cost / savings | $[X]/[period] | [Context] |
| 3-year net impact | $[X] | [Context] |

---

## Timeline

| Milestone | Date | Owner | Status |
|-----------|------|-------|--------|
| [Milestone 1] | [Date] | [Owner] | [Not Started / In Progress / Complete] |
| [Milestone 2] | [Date] | [Owner] | |
| Decision needed by | [Date] | [This audience] | ⚠️ |

---

## Recommended Next Steps

1. **[Action 1]** — Owner: [Name] — By: [Date]
2. **[Action 2]** — Owner: [Name] — By: [Date]
3. **[Decision requested from this audience]** — By: [Date]

---

## Appendix

*(Available on request — do not include in executive brief unless specifically requested)*

- Technical Architecture Details
- Full Risk Register
- Security Assessment
- Detailed Financial Model
- Vendor Analysis

---

*Questions? Contact [Name] at [contact].*
