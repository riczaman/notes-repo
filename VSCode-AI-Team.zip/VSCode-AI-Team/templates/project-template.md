# Project Template

**Project Name:** [Name]
**Project Code:** [Code]
**Date:** [YYYY-MM-DD]
**Status:** [Initiating | Planning | In Execution | Completed | On Hold | Cancelled]
**Project Owner:** [Name]
**Chief of Staff Lead:** Chief of Staff Agent

---

## 1. Project Charter

### Problem Statement
[What problem are we solving? Who is affected? What is the cost of not solving it?]

### Proposed Solution
[High-level description of what we are building or changing]

### Business Objectives
| Objective | Success Metric | Target | Measurement Approach |
|-----------|--------------|--------|---------------------|
| [Objective] | [KPI] | [Value by date] | [How measured] |

### Target Users / Beneficiaries
[Who will use or benefit from this? Persona descriptions.]

### Scope

**In Scope:**
- [Item 1]
- [Item 2]

**Out of Scope:**
- [Item 1]
- [Item 2]

---

## 2. Constraints and Assumptions

### Constraints
| Constraint | Type | Impact |
|-----------|------|--------|
| [e.g., Must go live by Q2] | Timeline | [Impact on scope/quality] |
| [e.g., Budget: $X] | Financial | [Impact on technology choices] |
| [e.g., Must use existing auth system] | Technical | [Integration requirements] |

### Assumptions
[Document assumptions — these are items that, if proven false, would require re-scoping]
- [Assumption 1]
- [Assumption 2]

---

## 3. Stakeholders

| Stakeholder | Role | Interest | Communication | Engagement Level |
|-------------|------|---------|---------------|-----------------|
| [Name] | [Sponsor / Decision Maker / User / Advisor] | [What they care about] | [How/frequency] | High/Medium/Low |

---

## 4. Team

| Role | Name | Responsibility | Allocation |
|------|------|---------------|-----------|
| Project Owner | [Name] | Backlog, acceptance | 100% |
| Lead Engineer | [Name] | Technical lead | 100% |
| [Role] | [Name] | [Responsibility] | [%] |

---

## 5. Architecture Summary

**Architecture Type:** [Monolith / Microservices / Serverless / Hybrid]
**Cloud Platform:** [Azure / AWS / GCP / Multi-cloud / On-prem]
**Key Technologies:** [List]
**Architecture Document:** [Link]
**Key ADRs:** [Links]

---

## 6. Milestones and Timeline

| Milestone | Description | Target Date | Owner | Status |
|-----------|-------------|------------|-------|--------|
| M1: Project Kickoff | Team aligned, environment ready | [Date] | [Owner] | ☐ |
| M2: Architecture Approved | DRB sign-off on architecture | [Date] | [Owner] | ☐ |
| M3: MVP Complete | Core features delivered to staging | [Date] | [Owner] | ☐ |
| M4: Security Review | Security sign-off obtained | [Date] | [Owner] | ☐ |
| M5: Production Launch | Go-live | [Date] | [Owner] | ☐ |
| M6: Post-Launch Review | 30-day health review | [Date] | [Owner] | ☐ |

---

## 7. Risks

| ID | Risk | Rating | Owner | Mitigation | Status |
|----|------|--------|-------|-----------|--------|
| R-001 | [Risk] | Critical/High/Medium/Low | [Owner] | [Plan] | Open |

*Full risk register: [Link to risk-template.md]*

---

## 8. Non-Functional Requirements

| NFR | Requirement | Measurement |
|-----|-------------|-------------|
| Availability | [e.g., 99.9%] | [How measured] |
| Performance | [e.g., P95 < 200ms] | [How measured] |
| Security | [e.g., SOC2 controls] | [How assessed] |
| Scalability | [e.g., supports 10K concurrent users] | [Load test] |
| Disaster Recovery | [RTO: X hours, RPO: Y hours] | [DR test] |
| Privacy | [e.g., PIPEDA compliant] | [PIA] |

---

## 9. Definition of Done (Project Level)

- [ ] All user stories meet sprint-level DoD
- [ ] Security review passed (no unmitigated Critical/High findings)
- [ ] Performance targets met (load test evidence)
- [ ] DR runbook written and tested
- [ ] All documentation complete (architecture, runbooks, API docs, onboarding)
- [ ] PIA completed and approved (if personal data)
- [ ] Risk register reviewed — no unacceptable open risks
- [ ] Monitoring and alerting configured
- [ ] Rollback procedure documented
- [ ] Product Owner has signed off on all acceptance criteria
- [ ] Go-Live approval from Chief of Staff (DRB completed)

---

## 10. Budget

| Category | Estimated | Actual | Variance |
|----------|-----------|--------|---------|
| Engineering (hours × rate) | $[X] | $[X] | $[X] |
| Cloud infrastructure | $[X]/month | $[X]/month | $[X] |
| Third-party tools/licenses | $[X] | $[X] | $[X] |
| **Total** | **$[X]** | **$[X]** | **$[X]** |

---

## 11. Open Items / Decisions Required

| Item | Type | Owner | Due Date | Status |
|------|------|-------|---------|--------|
| [Open item] | Decision / Action / Risk | [Owner] | [Date] | Open |
