# Architecture Document Template

**System Name:** [Name]
**Version:** [X.X]
**Date:** [YYYY-MM-DD]
**Author:** Enterprise Architect Agent
**Status:** [Draft | Review | Approved | Deprecated]
**DRB Status:** [Pending | Approved | Not Required]

---

## 1. Executive Summary

[3-5 sentences. What this system does, the key architectural decisions, and why this approach was chosen. Written for a technical lead who hasn't seen this system before.]

---

## 2. Goals and Non-Goals

### Goals
- [What this architecture is designed to achieve]
- [Non-functional outcomes: availability, latency, throughput, security posture]

### Non-Goals
- [What is explicitly out of scope — important for setting expectations]
- [What future versions might address]

### Non-Functional Requirements (NFRs)
| Attribute | Requirement | Measurement |
|-----------|-------------|-------------|
| Availability | [e.g., 99.9%] | [Uptime over rolling 30 days] |
| Latency | [e.g., P95 < 200ms] | [API response time] |
| Throughput | [e.g., 1,000 RPS] | [Requests per second] |
| RTO | [e.g., < 4 hours] | [Recovery time from major failure] |
| RPO | [e.g., < 1 hour] | [Data loss tolerance] |
| Data Residency | [e.g., Canada only] | [Data location confirmed] |

---

## 3. System Context (C4 Level 1)

[Describe the system boundary and its relationships with users and external systems]

```
[System Context Diagram — Mermaid notation]

graph TB
    User([User]) --> System[This System]
    System --> ExternalAPI([External API])
    System --> Database[(Database)]
    Admin([Admin]) --> System
```

### External Dependencies
| Dependency | Purpose | Owner | Availability SLA | Fallback |
|-----------|---------|-------|-----------------|---------|
| [System] | [Why needed] | [Team] | [SLA] | [What happens if unavailable] |

---

## 4. Container Architecture (C4 Level 2)

[Describe the major containers (applications, services, databases) within the system]

```
[Container Diagram — Mermaid notation]

graph TB
    subgraph System Boundary
        API[API Service\nNode.js/Express]
        Worker[Background Worker\nNode.js]
        DB[(PostgreSQL)]
        Cache[(Redis)]
    end
    Client([Client]) --> API
    API --> DB
    API --> Cache
    Worker --> DB
```

### Container Descriptions
| Container | Technology | Responsibility | Scale |
|-----------|-----------|---------------|-------|
| [Name] | [Tech] | [What it does] | [Instances/scaling approach] |

---

## 5. Key Architecture Decisions

| Decision | Choice | ADR Reference |
|----------|--------|--------------|
| [Decision 1] | [Choice made] | [ADR-001] |
| [Decision 2] | [Choice made] | [ADR-002] |

---

## 6. Data Architecture

### Data Classification
| Data Type | Classification | Storage | Encryption | Retention |
|-----------|---------------|---------|-----------|----------|
| [e.g., User PII] | Restricted | [Where] | [At rest + in transit] | [Period] |

### Data Flows
[Describe how data moves through the system, particularly sensitive data]

---

## 7. Security Architecture

### Authentication & Authorization
[How users and services authenticate. RBAC / ABAC model.]

### Network Security
[Network segmentation, private endpoints, WAF, ingress controls]

### Secrets Management
[How secrets are stored and rotated]

### Encryption
| Data State | Encryption | Key Management |
|-----------|-----------|---------------|
| At rest | [Algorithm] | [Key vault/service] |
| In transit | TLS 1.3 | [Certificate management] |
| In use | [If applicable] | |

---

## 8. Reliability & Resilience

### Availability Design
[How the system achieves its availability target]

### Failure Modes
| Failure | Impact | Detection | Recovery |
|---------|--------|----------|---------|
| [Dependency X unavailable] | [Impact] | [How detected] | [Circuit breaker/fallback] |
| [Database failure] | [Impact] | [Alert] | [DR runbook reference] |

### Disaster Recovery
- **DR Tier:** [0-4]
- **RTO Target:** [X hours]
- **RPO Target:** [X hours]
- **DR Runbook:** [Link]

---

## 9. Observability

### Metrics
[What is measured and what dashboards exist]

### Logging
[Logging strategy, PII in logs policy, retention]

### Tracing
[Distributed tracing approach]

### Alerting
| Alert | Condition | Severity | Runbook |
|-------|-----------|---------|--------|
| [Alert name] | [Condition] | [P1/P2/P3] | [Link] |

---

## 10. Known Risks and Trade-offs

| Risk | Trade-off | Mitigation |
|------|----------|-----------|
| [Risk 1] | [What was traded off to accept this] | [Mitigation] |

---

## 11. Future Considerations

[What known limitations exist? What will need to change as the system grows?]

---

## 12. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | [Date] | [Author] | Initial version |
