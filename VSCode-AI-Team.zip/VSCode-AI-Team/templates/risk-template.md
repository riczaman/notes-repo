# Risk Assessment Template

**Project/System:** [Name]
**Assessment Date:** [YYYY-MM-DD]
**Assessor:** Risk & Privacy Agent
**Review Cycle:** [Quarterly / On change]
**Status:** [Draft | Active | Closed]

---

## Risk Rating Matrix

| | **Low Impact** | **Medium Impact** | **High Impact** |
|---|--------------|-----------------|----------------|
| **High Likelihood** | 🟡 Medium | 🔴 High | 🔴 Critical |
| **Medium Likelihood** | 🟢 Low | 🟡 Medium | 🔴 High |
| **Low Likelihood** | 🟢 Low | 🟢 Low | 🟡 Medium |

**Rating Scale:**
- 🔴 **Critical**: Immediate action required. Escalate to Chief of Staff.
- 🔴 **High**: Must be mitigated before production or have named risk acceptance.
- 🟡 **Medium**: Mitigation plan required within current quarter.
- 🟢 **Low**: Monitor and address in backlog.

---

## Risk Register

| ID | Risk Description | Category | Likelihood | Impact | Rating | Owner | Mitigation | Residual Risk | Status | Review Date |
|----|----------------|----------|-----------|--------|--------|-------|-----------|--------------|--------|------------|
| R-001 | [Description] | [Tech/Ops/Privacy/Compliance/Vendor] | H/M/L | H/M/L | Critical/High/Medium/Low | [Owner] | [Mitigation action] | [After mitigation] | Open/Mitigated/Accepted/Closed | [Date] |

---

## Risk Detail Cards

*(Complete one card per Critical or High risk)*

---

### Risk R-001: [Short Risk Name]

**Category:** [Technology / Operational / Privacy / Compliance / Vendor / Financial]
**Rating:** 🔴 Critical / 🔴 High / 🟡 Medium / 🟢 Low
**Owner:** [Named individual — must be a person, not a team]
**Identified Date:** [Date]

#### Description
[Detailed description of the risk. What could go wrong? What triggers this risk?]

#### Likelihood Assessment
**Rating:** High / Medium / Low
**Rationale:** [Why this likelihood rating? What evidence supports it?]

#### Impact Assessment
**Rating:** High / Medium / Low
**Potential Impact:**
- Business: [e.g., revenue loss, customer impact]
- Operational: [e.g., outage, manual workaround]
- Regulatory: [e.g., breach notification, fine]
- Reputational: [e.g., customer trust, media]

**Estimated Cost of Risk Materializing:** $[Range]

#### Current Controls
[What is already in place that reduces this risk?]
- [Control 1]
- [Control 2]

#### Mitigation Plan
| Action | Owner | Due Date | Status |
|--------|-------|---------|--------|
| [Action] | [Name] | [Date] | [Not started / In progress / Complete] |

#### Residual Risk (After Mitigation)
**Rating:** [Rating after mitigations implemented]
**Acceptable:** [Yes / No — if No, escalate]

#### Risk Acceptance (if applicable)
**Accepted By:** [Name and title — must be authorized]
**Date:** [Date]
**Conditions:** [Any conditions on the acceptance]
**Expiry:** [Date when acceptance must be renewed]

---

## Privacy Impact Assessment Summary

*(Complete if personal data is in scope)*

| Personal Data Type | Classification | Volume | Purpose | Retention | Risk Level |
|-------------------|---------------|--------|---------|-----------|-----------|
| [e.g., Email address] | PII | [Approx #] | [Purpose] | [Period] | H/M/L |

**PIA Status:** [Not Required / Completed / In Progress / Required - Not Started]
**PIA Decision:** [Approved / Conditional / Not Approved]

---

## Third-Party Risk Summary

| Vendor | Service | Data Shared | SOC2 | Last Review | Risk Rating |
|--------|---------|-----------|------|------------|-------------|
| [Vendor] | [Service] | [Data types] | [Yes/No/Pending] | [Date] | H/M/L |

---

## Compliance Obligations

| Regulation | Applicability | Status | Gap | Owner |
|-----------|--------------|--------|-----|-------|
| PIPEDA | [Applies if: Canadian user PII] | Compliant / Gap | [Gap description] | [Owner] |
| GDPR | [Applies if: EU user data] | Compliant / Gap | [Gap description] | [Owner] |
| PCI-DSS | [Applies if: payment card data] | Compliant / Gap | [Gap description] | [Owner] |
| SOC 2 | [Applies if: customer data, SaaS] | Compliant / Gap | [Gap description] | [Owner] |

---

## Risk Summary

**Total Risks:** [N]
**Critical:** [N] | **High:** [N] | **Medium:** [N] | **Low:** [N]

**Unmitigated Critical/High Risks:** [N] ← Must be zero for production approval

**Overall Risk Posture:** 🟢 Acceptable / 🟡 Elevated / 🔴 Unacceptable

**Recommendation:** [Proceed / Proceed with conditions / Do not proceed]
