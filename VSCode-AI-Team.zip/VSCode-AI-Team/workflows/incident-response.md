# Workflow: Incident Response

## Purpose
Coordinate a structured, rapid response to production incidents — minimizing impact, driving to resolution, and ensuring thorough post-incident learning.

## Severity Levels
| Level | Definition | Response Time | Commander |
|-------|-----------|--------------|----------|
| SEV-1 | Complete service outage or data breach | Immediate | Senior Engineer + Manager |
| SEV-2 | Major feature down, significant user impact | <15 min | Senior Engineer |
| SEV-3 | Degraded performance, workaround available | <1 hour | On-call Engineer |
| SEV-4 | Minor issue, low user impact | Next business day | Ticket |

## Primary Agents
- **Disaster Recovery**: Leads recovery execution
- **DevSecOps**: Leads security incident analysis
- **Chief of Staff**: Coordinates and manages executive communications
- **Executive Communications**: Manages stakeholder communications
- **Enterprise Architect**: Provides system knowledge for diagnosis
- **Technical Writer**: Documents timeline and actions in real-time

---

## Phase 1: Detection & Declaration (Minutes 0-5)

```
1. Incident detected via: [ ] Monitoring alert  [ ] Customer report  [ ] Team discovery
2. Incident Commander assigned
3. Severity level declared
4. Incident channel created (#incident-[YYYY-MM-DD]-[name])
5. Initial notification sent:
   - Engineering team
   - On-call engineers
   - Manager (SEV-1/2)
   - Executive (SEV-1 only)
```

**Initial Notification Template:**
```
🚨 INCIDENT DECLARED — SEV-[X]
Time: [HH:MM UTC]
System: [Affected system]
Impact: [Who/what is affected]
Commander: [Name]
Channel: #incident-[name]
Bridge: [Link]
```

---

## Phase 2: Triage & Assessment (Minutes 5-20)

```
Incident Commander drives:
1. What is broken? (symptoms, not causes)
2. What is the user impact? (scope and severity)
3. When did it start? (timeline correlation)
4. What changed recently? (deployments, config changes, infra)
5. Which systems are affected? (blast radius)
6. Is this a security incident? → If yes, DevSecOps leads
7. Is data loss involved? → Escalate Risk & Privacy immediately
```

**Assessment Output:**
```
Impact Statement: "[X] users are unable to [Y] since [time]"
Scope: [Affected regions/services/users]
Root Cause Hypothesis: [Top 3 theories]
Changes in last 24h: [List]
Data Impact: [ ] None  [ ] Possible  [ ] Confirmed
Security Impact: [ ] None  [ ] Possible  [ ] Confirmed
```

---

## Phase 3: Response & Recovery (Minutes 20+)

### Technical Response
```
1. Form sub-teams if large incident:
   - Mitigations team: reduce user impact now
   - Investigation team: find root cause
   - Communications team: manage updates

2. Apply mitigations in order:
   a. Traffic routing (shift away from affected zone)
   b. Feature flags (disable affected feature)
   c. Rollback (revert recent deployment)
   d. Failover (activate DR runbook)
   e. Scaling (if capacity issue)

3. Update incident channel every 15 minutes:
   "UPDATE [HH:MM]: [What we're doing] — [Current status]"
```

### Disaster Recovery Agent Actions
```
1. Retrieve DR runbook for affected system
2. Assess if DR activation criteria are met
3. If failover needed: execute DR runbook
4. Monitor RTO against target
5. Validate recovery completeness
```

### Security Incident Additional Steps (DevSecOps)
```
1. Preserve evidence (logs, snapshots) BEFORE remediation
2. Isolate affected systems if breach suspected
3. Assess data exfiltration risk
4. Identify attack vector
5. Regulatory notification obligations (breach = 72h GDPR, provincial requirements)
6. Engage Risk & Privacy for breach assessment
```

---

## Phase 4: Communications

### Internal Updates (Chief of Staff)
```
Cadence:
- SEV-1: every 15 minutes to executive channel
- SEV-2: every 30 minutes to leadership
- SEV-3: hourly update in incident channel
```

### Executive Communication Template (Executive Comms)
```
INCIDENT UPDATE — [HH:MM UTC]
Severity: SEV-[X]
Status: [Investigating / Mitigating / Recovering / Resolved]

WHAT HAPPENED:
[1-2 sentences]

IMPACT:
[Users affected, duration, business impact]

CURRENT ACTIONS:
[What we're doing right now]

NEXT UPDATE:
[Time of next update]

ETA TO RESOLUTION:
[If known]
```

### Customer Communication Criteria
- SEV-1 impacting >5% customers: Customer notification required
- Data breach: Customer notification required (with Risk & Privacy approval)
- SLA breach: Customer notification per contract terms

---

## Phase 5: Resolution & Closure

```
1. Confirm service fully restored
2. Validate all health checks passing
3. Monitor for 30 minutes post-recovery
4. Send all-clear notification
5. Close incident channel
6. Schedule postmortem (within 48h for SEV-1/2, within 1 week for SEV-3)
```

**All-Clear Template:**
```
✅ INCIDENT RESOLVED — [HH:MM UTC]
Duration: [X hours Y minutes]
Root Cause: [Brief summary]
Customer Impact: [Estimated affected users / duration]
Postmortem: Scheduled for [date]
```

---

## Phase 6: Postmortem (Technical Writer + All Agents)

```markdown
# Incident Postmortem: [Incident Name]
**Date of Incident:** [Date]
**Duration:** [HH:MM — HH:MM]
**Severity:** SEV-[X]
**Postmortem Date:** [Date]
**Author:** [Names]

## Summary
[2-3 sentences: what happened, why, and what was done]

## Timeline
| Time (UTC) | Event |
|-----------|-------|
| [HH:MM] | [Event] |

## Root Cause
[Specific technical root cause — not symptoms]

## Contributing Factors
[What conditions allowed this to happen?]

## Impact
- Users affected: [number/percentage]
- Duration: [minutes/hours]
- Data impact: [None / Confirmed — description]
- Revenue impact: [If known]
- SLA impact: [If applicable]

## What Went Well
[Genuine positives — detection, response speed, teamwork]

## What Went Poorly
[Honest assessment — detection gaps, response delays, communication failures]

## Action Items
| Action | Owner | Priority | Due Date | Status |
|--------|-------|---------|---------|--------|

## Blameless Principle
This postmortem is blameless. We identify system and process failures, not personal failures.
```
