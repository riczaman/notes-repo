# Workflow: Executive Briefing

## Purpose
Produce a concise, accurate, and decision-oriented executive communication from technical content — ensuring leadership has what they need to make informed decisions.

## Trigger Conditions
- Quarterly business review preparation
- Major initiative status update
- Incident requiring executive visibility
- Major architecture or technology decision
- Budget or resourcing request
- Risk or compliance escalation
- Board or steering committee presentation

## Lead Agent: Executive Communications
## Supporting: Chief of Staff, Technical Writer, all relevant domain agents
## Orchestrator: Chief of Staff

---

## Phase 1: Audience & Purpose Alignment (Chief of Staff)

```
Before producing any content, define:

1. Audience: Who is receiving this?
   [ ] CEO / C-Suite
   [ ] Board of Directors
   [ ] Steering Committee
   [ ] VP / Director level
   [ ] External (Regulator, Auditor, Customer)

2. Purpose: What outcome do we need?
   [ ] Decision required → clearly state the ask
   [ ] Information only → what do they need to know?
   [ ] Approval sought → what are we requesting?
   [ ] Risk disclosure → what risk are we communicating?

3. Format:
   [ ] Written brief (<2 pages)
   [ ] Slide deck (<10 slides)
   [ ] Verbal talking points
   [ ] Dashboard / status report
```

---

## Phase 2: Content Collection (Domain Agents)

### From Technical Agents
```
Enterprise Architect: key architecture facts, technology decisions, risks
DevSecOps: security posture, outstanding findings, compliance status
Full Stack Engineer: delivery status, quality metrics, technical debt
AI Engineer: AI system status, risks, costs
```

### From Operational Agents
```
Product Owner: roadmap status, key milestones, user impact metrics
Senior Manager: team health, capacity, hiring status
Disaster Recovery: DR status, upcoming test dates, gaps
Risk & Privacy: risk register summary, open PIAs, compliance status
```

---

## Phase 3: Executive Brief Production (Executive Communications)

### Pyramid Principle Application
```
Step 1: Define the CONCLUSION first
  → What is the single most important thing this audience needs to know?

Step 2: Structure supporting arguments (max 3)
  → Why is that the conclusion?

Step 3: Relegate evidence to appendix
  → Data, charts, full analyses — available but not in the brief
```

### Translation Rules
```
Technical → Executive language:
"SAST scan found 3 critical vulnerabilities" → "We identified and resolved 3 security issues before release"
"P95 latency is 450ms" → "System response time meets our performance targets"
"We have 73% test coverage" → "Our automated testing covers the majority of business-critical code paths"
"Technical debt backlog" → "Engineering investments needed to maintain delivery velocity"

NEVER use: SAST, DAST, CVE, ADR, CQRS, K8s, or other internal jargon without translation
```

---

## Standard Executive Briefing Format

```markdown
# [Topic] — Executive Brief
**Date:** [Date]
**Classification:** [Internal / Confidential]
**Prepared for:** [Audience]
**Prepared by:** [Team]

---

## 🎯 Bottom Line
[1-2 sentences: the most important thing this audience needs to know]

## Situation
[2-3 sentences: context and current state — no jargon]

## Decision / Action Required
> [Specific ask or decision needed from this audience]
> **Deadline:** [Date]

## Key Metrics
| Metric | Target | Actual | Trend |
|--------|--------|--------|-------|
| [Metric] | [X] | [Y] | ↑↓→ |

## Status
| Initiative | Status | Notes |
|-----------|--------|-------|
| [Name] | 🟢 On Track / 🟡 At Risk / 🔴 Off Track | [1 line] |

## Risks
| Risk | Impact | Mitigation | Owner |
|------|--------|-----------|-------|
| [Risk] | H/M/L | [Plan] | [Name] |

## Options (if decision required)
| Option | Benefit | Risk | Recommended |
|--------|---------|------|-------------|
| A | ... | ... | ✓ |
| B | ... | ... | |

## Recommended Next Steps
1. [Action] — Owner: [Name] — By: [Date]
2. [Action] — Owner: [Name] — By: [Date]

---
*Appendix: Supporting detail available on request*
```

---

## Board-Level Additional Requirements

For board-level communications:
```
✓ Risk disclosure is explicit — no softening of material risks
✓ Financial figures verified against finance team
✓ Legal review for any regulatory or liability statements
✓ No internal jargon — written for a non-technical board member
✓ Forward-looking statements appropriately caveated
✓ Approved by Chief of Staff before distribution
```

---

## Quality Gate

Before delivering executive content:
```
[ ] BLUF is in the first paragraph
[ ] Decision or action requested is explicit
[ ] No technical jargon without translation
[ ] All data points are verified (not estimates presented as facts)
[ ] Risks are not buried in appendices — they are in the body
[ ] Length is appropriate: brief = <2 pages, deck = <10 slides
[ ] Reviewed by Chief of Staff
[ ] Reviewed by relevant domain agents for accuracy
```
