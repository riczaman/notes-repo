# Workflow: Release Readiness

## Purpose
Ensure that every production release meets engineering, security, operational, and business quality standards before deployment. No release proceeds with unresolved blocking criteria.

## Participants
| Agent | Role in Release |
|-------|----------------|
| Chief of Staff | Go/No-Go decision authority, coordinates DRB |
| Enterprise Architect | Architecture and integration sign-off |
| DevSecOps | Security sign-off |
| Risk & Privacy | Risk and compliance sign-off |
| Full Stack Engineer | Code quality and testing sign-off |
| Product Owner | Acceptance criteria sign-off |
| Technical Writer | Documentation sign-off |
| Disaster Recovery | DR readiness sign-off |
| Senior Manager | Team readiness and capacity sign-off |

---

## Release Readiness Checklist

### 1. Product Readiness ✓ (Product Owner)
```
[ ] All committed user stories meet Definition of Done
[ ] Acceptance criteria verified and signed off by Product Owner
[ ] Edge cases and error states tested
[ ] Feature flags configured correctly (on/off state verified)
[ ] Product documentation updated
[ ] Release notes drafted
[ ] No known P1/P2 bugs open against release scope
```

### 2. Code Quality ✓ (Full Stack Engineer)
```
[ ] All code reviewed and approved (no outstanding review comments)
[ ] Test coverage meets threshold (defined per project)
[ ] Unit tests passing
[ ] Integration tests passing
[ ] E2E tests passing (critical paths)
[ ] Performance tests run — no regressions >10%
[ ] No dead code or debug statements in release
[ ] Dependencies up to date (no known Critical CVEs)
[ ] TypeScript compilation: zero errors
[ ] Linting: zero errors
```

### 3. Security ✓ (DevSecOps) — BLOCKING
```
[ ] SAST scan: no Critical or High findings unmitigated
[ ] SCA scan: no Critical CVEs in dependencies
[ ] Secrets scan: no secrets in codebase
[ ] Threat model reviewed for any new attack surface
[ ] Authentication/authorization tested
[ ] DAST run on staging (if qualifying release)
[ ] Container image scan: no Critical findings
[ ] Security regression tests passing
```

### 4. Architecture ✓ (Enterprise Architect)
```
[ ] Architecture review completed for scope
[ ] ADRs updated for any new decisions
[ ] Integration contracts verified (API contracts, event schemas)
[ ] Database migrations reviewed and rollback available
[ ] No breaking API changes without versioning strategy
[ ] Observability confirmed: metrics, logs, traces in place
[ ] Load/performance characteristics acceptable
```

### 5. Risk & Compliance ✓ (Risk & Privacy) — BLOCKING
```
[ ] Risk register reviewed — no unmitigated Critical/High risks
[ ] PIA completed (if personal data involved)
[ ] Regulatory requirements met
[ ] Data retention and deletion verified
[ ] Audit logging confirmed for regulated operations
```

### 6. Operational Readiness ✓ (DevSecOps + Enterprise Architect)
```
[ ] Monitoring and alerting configured for new features
[ ] Runbooks updated for new operational procedures
[ ] On-call team briefed on changes
[ ] Rollback procedure documented and tested
[ ] Feature flags in place for high-risk changes
[ ] Deployment procedure documented
[ ] Health check endpoints verified
[ ] Scaling tested (if applicable)
```

### 7. Disaster Recovery ✓ (Disaster Recovery)
```
[ ] DR runbook updated for any changes
[ ] RTO/RPO targets still achievable with new release
[ ] Backup procedure verified
[ ] No new single points of failure introduced (or documented exceptions)
```

### 8. Documentation ✓ (Technical Writer)
```
[ ] API documentation updated
[ ] User-facing documentation updated
[ ] Architecture documentation updated
[ ] Runbooks updated
[ ] Onboarding documentation updated (if applicable)
[ ] Release notes complete
```

### 9. Team Readiness ✓ (Senior Manager)
```
[ ] On-call rotation staffed for release window
[ ] Team has been briefed on changes
[ ] Escalation path confirmed
[ ] Rollback decision authority identified
```

---

## Go / No-Go Decision

### Blocking Criteria (No-Go if ANY are open)
- Unmitigated Critical or High security findings
- Unmitigated Critical or High risks
- Missing PIA for new personal data processing
- Failing tests (unit, integration, E2E critical paths)
- No rollback procedure
- No monitoring/alerting for new features
- Product Owner has not signed off acceptance criteria

### Non-Blocking (Document and Track)
- Medium or Low security findings (tracked in backlog)
- Minor documentation gaps (tracked with owner)
- Performance improvements identified (tracked)
- Technical debt identified (tracked)

---

## Go/No-Go Meeting Template

```markdown
## Release Go/No-Go: [Release Name/Version]
**Date:** [Date]
**Release Window:** [Date/Time]
**Chief of Staff Decision:** [ ] GO  [ ] NO-GO  [ ] CONDITIONAL GO

### Blocking Items
| Item | Owner | Resolution |
|------|-------|-----------|

### Conditions (if Conditional GO)
[List conditions that must be met before deployment proceeds]

### Non-Blocking Items (Track Post-Release)
| Item | Owner | Sprint Target |
|------|-------|--------------|

### DRB Recommendation
[If DRB was required for this release]

### Decision
**Decision:** [GO / NO-GO / CONDITIONAL GO]
**Authorized by:** Chief of Staff
**Rollback Trigger:** [Define: what conditions cause a rollback]
**Rollback Owner:** [Named person]
```
