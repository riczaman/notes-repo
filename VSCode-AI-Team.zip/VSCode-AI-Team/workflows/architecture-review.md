# Workflow: Architecture Review

## Purpose
Provide a structured, multi-perspective review of any architectural proposal, change, or existing system design. All architecture reviews of qualifying scope trigger the Decision Review Board process.

## Trigger Conditions
Initiate this workflow for:
- New system or service design
- Significant changes to existing architecture
- Technology selection decisions (new vendor, platform, language)
- Integration with new external systems
- Infrastructure platform changes
- Data architecture changes
- AI/ML system design

## Participants
| Role | Participation |
|------|--------------|
| Chief of Staff | Orchestrator, DRB consolidator |
| Enterprise Architect | Lead reviewer, ADR author |
| DevSecOps | Security review, threat modeling |
| Risk & Privacy | Risk and compliance review |
| Full Stack Engineer | Implementation feasibility |
| AI Engineer | If AI/ML components present |
| Disaster Recovery | If availability/recovery requirements implicated |

---

## Phase 1: Request Intake (Chief of Staff)

**Input:** Architecture proposal, design document, or description
**Time:** 15 minutes

```
1. Classify the scope: Is this a DRB-required decision?
2. Identify which specialist agents are required
3. Request documentation from requestor (if missing):
   - Problem statement
   - Proposed solution
   - Constraints (time, cost, existing systems)
   - Non-functional requirements
4. Assign review responsibilities to agents
5. Set review deadline
```

---

## Phase 2: Specialist Reviews (Parallel)

### Enterprise Architect Review
```
✓ Alignment with enterprise architecture patterns
✓ Scalability assessment (10x load analysis)
✓ Integration complexity and dependency risks
✓ Technology selection rationale
✓ Alternatives considered
✓ Technical debt implications
✓ Observability and operability
✓ ADR drafted
```

### DevSecOps Review
```
✓ Threat model (STRIDE analysis)
✓ Attack surface assessment
✓ Authentication and authorization design
✓ Secrets management approach
✓ Data encryption (at rest and in transit)
✓ Supply chain security (dependencies)
✓ Compliance requirements (OWASP, PCI, SOC2)
✓ Security findings logged with severity
```

### Risk & Privacy Review
```
✓ Risk register updated
✓ Privacy Impact Assessment (if personal data)
✓ Regulatory compliance check
✓ Third-party risk assessment (if new vendors)
✓ Operational risk identification
✓ Risk ratings assigned (Critical/High/Medium/Low)
```

---

## Phase 3: Cross-Agent Synthesis (Chief of Staff)

```
1. Collect all specialist findings
2. Identify conflicts between specialist views
3. Identify areas of unanimous concern (amplify these)
4. Identify risks with no proposed mitigation
5. Generate question list for architecture team
6. Request clarification if needed
7. Prepare DRB consolidation
```

---

## Phase 4: Decision Review Board

**Trigger:** Any architecture review flagged as DRB-required

```
DRB Review Agenda:
1. Enterprise Architect presents recommendation
2. DevSecOps presents security finding summary
3. Risk & Privacy presents risk and compliance summary
4. Open discussion: conflicts and trade-offs
5. Dissenting opinions formally recorded
6. Chief of Staff consolidates final recommendation
7. DRB output generated (all 10 fields required)
```

---

## Phase 5: Output Delivery

### Outputs Produced
- ADR (Architecture Decision Record)
- DRB Recommendation document (all 10 fields)
- Threat Model document
- Risk Register entries
- Action items with owners and due dates
- PIA (if applicable)

### Quality Gate
Before closing the workflow, verify:
```
✓ ADR written and status set (Proposed/Accepted)
✓ DRB output includes all 10 mandatory fields
✓ All Critical and High findings have mitigations
✓ Dissenting opinions recorded
✓ Action items have named owners
✓ Review date set for the decision
```

---

## Escalation Path
| Situation | Escalation |
|-----------|-----------|
| Unresolved conflict between agents | Chief of Staff → Human principal |
| Critical security finding with no mitigation | DevSecOps blocks → Chief of Staff escalates |
| Critical privacy risk | Risk & Privacy blocks → Chief of Staff escalates |
| Irreconcilable trade-offs | Chief of Staff presents options to human for decision |
