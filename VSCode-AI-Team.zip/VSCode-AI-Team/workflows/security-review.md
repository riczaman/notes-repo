# Workflow: Security Review

## Purpose
Perform a comprehensive security review of a system, feature, code change, or infrastructure configuration. Produces a prioritized findings report with mitigations.

## Trigger Conditions
- Pre-production security review
- New feature with security implications
- Third-party integration
- Infrastructure change
- Scheduled periodic review
- Post-incident security audit
- Compliance-driven review

## Lead Agent: DevSecOps
## Supporting Agents: Enterprise Architect, Risk & Privacy
## Orchestrator: Chief of Staff

---

## Phase 1: Scope Definition

```
Inputs:
- System / feature / change description
- Code repository (if available)
- Architecture diagram (if available)
- Compliance context (PCI, SOC2, GDPR, etc.)
- Previous findings (if re-review)

Scope Definition Output:
- Review type: [ ] Code  [ ] Architecture  [ ] Infrastructure  [ ] API  [ ] Full
- Regulatory context identified
- Review depth: [ ] Express  [ ] Standard  [ ] Deep Dive
```

---

## Phase 2: Threat Modeling (DevSecOps)

```
1. Create/update Data Flow Diagram (DFD)
2. Identify trust boundaries
3. Apply STRIDE methodology per component:
   - Spoofing: Can identity be faked?
   - Tampering: Can data be modified in transit or at rest?
   - Repudiation: Can actions be denied without audit?
   - Information Disclosure: Can data be exposed to unauthorized parties?
   - Denial of Service: Can availability be impacted?
   - Elevation of Privilege: Can attackers gain higher access?
4. Rate each identified threat: Critical / High / Medium / Low
5. Document existing controls vs. needed controls
```

---

## Phase 3: Technical Security Review (DevSecOps)

### Code Review (if applicable)
```
Authentication & Authorization
✓ Authentication required on all protected endpoints
✓ Authorization at function level (not just route level)
✓ JWT validation: algorithm, expiry, audience, issuer
✓ Session management: secure cookies, CSRF protection
✓ No broken access control patterns

Input Validation
✓ All external inputs validated and sanitized
✓ Parameterized queries (no string concatenation in SQL)
✓ File upload restrictions enforced
✓ Request size limits configured

Cryptography
✓ Approved algorithms only (AES-256, RSA-2048+, SHA-256+)
✓ No MD5, SHA1 for security purposes
✓ Keys properly managed (not hardcoded)
✓ TLS 1.2+ enforced, TLS 1.0/1.1 disabled

Secrets & Configuration
✓ No hardcoded secrets, API keys, passwords
✓ No secrets in environment variables without vault backing
✓ Sensitive config not logged
✓ .env files not committed

Dependencies
✓ No known Critical CVEs in dependencies
✓ Dependency versions pinned
✓ Outdated dependencies flagged for update
```

### Infrastructure Review (if applicable)
```
Network
✓ Principle of least access on security groups/NSGs
✓ No unnecessary public exposure
✓ Private endpoints used where available
✓ WAF configured for public-facing endpoints

Identity
✓ Managed identities used (no static credentials)
✓ Service accounts have minimal required permissions
✓ MFA enforced for all human access
✓ Privileged access reviewed

Data
✓ Encryption at rest confirmed
✓ Encryption in transit confirmed
✓ Backup encryption confirmed
✓ Data residency requirements met
```

---

## Phase 4: Risk & Compliance Cross-Check (Risk & Privacy)

```
1. Map findings to applicable compliance frameworks
2. Identify any regulatory violations
3. Assess aggregate risk posture
4. Flag PII/PHI/PCI in scope
5. Confirm findings align with risk register
```

---

## Phase 5: Findings Report (DevSecOps + Chief of Staff)

### Findings Report Template
```markdown
# Security Review Report: [System/Feature]
**Date:** [Date]
**Scope:** [What was reviewed]
**Reviewer:** DevSecOps Agent
**Risk & Privacy:** [Findings incorporated: Yes/No]

## Executive Summary
[2-3 sentences: overall security posture, number of findings by severity]

## Findings Summary
| ID | Severity | Category | Finding | Status |
|----|----------|---------|---------|--------|
| S-001 | Critical | Auth | [Description] | Open |

## Critical Findings (Block Release)
### S-001: [Title]
**Severity:** Critical
**CVSS Score:** [If applicable]
**Description:** [What the vulnerability is]
**Evidence:** [Where found]
**Impact:** [What an attacker could do]
**Remediation:** [Specific fix required]
**Timeline:** Immediate — must fix before production

## High Findings (Fix Before Release)
...

## Medium Findings (Fix Within Sprint)
...

## Low / Informational Findings
...

## Positive Observations
[What is done well — not just issues]

## Recommendations
[Strategic improvements beyond specific findings]

## Verdict
[ ] PASS — cleared for production
[ ] CONDITIONAL PASS — proceed with listed conditions
[ ] FAIL — blocking issues must be resolved before production
```

---

## Escalation Path
| Condition | Action |
|-----------|--------|
| Critical finding discovered | DevSecOps blocks release, notifies Chief of Staff immediately |
| Compliance violation | Risk & Privacy escalates to Chief of Staff for legal review |
| Finding cannot be mitigated | Formal risk acceptance required from named business owner |
| Finding indicates active exploit | Incident Response workflow activated |
