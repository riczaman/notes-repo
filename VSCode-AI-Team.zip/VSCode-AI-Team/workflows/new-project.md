# Workflow: New Project Initialization

## Purpose
Establish a complete, production-ready foundation for a new software project — covering architecture, security, product definition, documentation, and team readiness.

## Trigger
Starting a new project, product, or significant new service.

## Participants
All agents participate. Chief of Staff orchestrates.

---

## Phase 1: Project Charter (Chief of Staff + Product Owner)

```
Inputs Needed:
- Project name and description
- Business objective (what problem are we solving?)
- Target users
- Success metrics
- Key constraints: timeline, budget, team size
- Regulatory or compliance context

Output:
- Project Charter document
- Stakeholder map
- Initial risk assumptions
```

---

## Phase 2: Architecture Foundation (Enterprise Architect)

```
Activities:
1. Define non-functional requirements (scalability, availability, latency)
2. Select cloud platform and core services
3. Design initial system architecture
4. Define integration points
5. Create C4 Level 1 and Level 2 diagrams
6. Document technology choices in ADRs
7. Identify architectural risks

Output:
- System architecture document
- ADRs for key technology decisions
- Architecture diagrams
- Non-functional requirements specification
```

---

## Phase 3: Security Baseline (DevSecOps)

```
Activities:
1. Threat model the initial architecture
2. Define security requirements
3. Set up security toolchain (SAST, SCA, secrets scanning)
4. Configure branch protection and CODEOWNERS
5. Define secrets management approach
6. Establish security review gates in CI/CD
7. Create initial threat model document

Output:
- Threat model
- Security requirements list
- Pipeline security configuration
- Secrets management design
```

---

## Phase 4: Risk & Privacy Assessment (Risk & Privacy)

```
Activities:
1. Initial risk register creation
2. PIA (if personal data processed)
3. Compliance requirements identification
4. Third-party risk assessment (if applicable)
5. Data classification for all data types

Output:
- Initial risk register
- PIA (if required)
- Compliance requirements checklist
- Data classification matrix
```

---

## Phase 5: Product Backlog (Product Owner)

```
Activities:
1. Define initial epics
2. Write MVP feature list
3. Create first sprint backlog
4. Define acceptance criteria for first stories
5. Set up Definition of Ready and Definition of Done

Output:
- Epic map
- Sprint 1 backlog
- Product roadmap (rough)
- DoR and DoD documents
```

---

## Phase 6: Project Documentation (Technical Writer)

```
Activities:
1. Create project README
2. Set up documentation structure (Confluence or docs-as-code)
3. Create onboarding guide template
4. Define runbook templates
5. Create ADR index

Output:
- README.md
- docs/ folder structure
- Onboarding guide (stub)
- Runbook template
- CONTRIBUTING.md
```

---

## Phase 7: DR Baseline (Disaster Recovery)

```
Activities:
1. Define RTO/RPO targets with business owner
2. Design backup strategy
3. Identify DR tier for the system
4. Create DR plan stub (to be completed before production)

Output:
- RTO/RPO definition document
- DR tier assignment
- DR plan stub
```

---

## Phase 8: DRB Sign-off (Chief of Staff)

```
Activities:
1. Collect all phase outputs
2. Run DRB for the initial architecture decision
3. Confirm no blocking issues
4. Issue project green light or conditions

Output:
- DRB Recommendation (all 10 fields)
- Project Green Light document
- Open action items log
```

---

## Project Setup Checklist

```
Repository
✓ Repository created with branch protection
✓ CODEOWNERS configured
✓ .gitignore and .gitattributes configured
✓ README.md complete
✓ CONTRIBUTING.md created
✓ License file present

CI/CD
✓ Pipeline created (GitHub Actions / ADO / GitLab)
✓ SAST scanning enabled
✓ SCA / dependency scanning enabled
✓ Secrets scanning enabled
✓ Code quality gate configured
✓ Test coverage gate configured

Documentation
✓ Architecture document created
✓ ADR index initialized
✓ Onboarding guide stub created
✓ Runbook template in place

Product
✓ Backlog created
✓ Definition of Ready documented
✓ Definition of Done documented
✓ Sprint 1 planned

Security
✓ Threat model completed
✓ Secrets management approach defined
✓ No secrets in code

Compliance
✓ Risk register initialized
✓ PIA completed (if applicable)
✓ Compliance requirements listed

DR
✓ RTO/RPO defined
✓ Backup strategy documented
✓ DR plan stub created
```
