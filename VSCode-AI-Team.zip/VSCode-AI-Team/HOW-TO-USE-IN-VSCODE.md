# How to Use the VS Code AI Team — Step-by-Step Instructions

This guide is your quick-start reference. Follow each step in order the first time, then use the Quick Actions section as your daily reference.

---

## Part 1: One-Time Setup (Do This Once)

---

### Step 1: Unzip and Place the Framework

After downloading the ZIP file:

1. Unzip `VSCode-AI-Team.zip`
2. Open your terminal and run:

```bash
# macOS / Linux
mkdir -p ~/.vscode-ai-team
cp -r VSCode-AI-Team/* ~/.vscode-ai-team/
```

```powershell
# Windows (PowerShell)
New-Item -ItemType Directory -Force "$env:USERPROFILE\.vscode-ai-team"
Copy-Item -Recurse "VSCode-AI-Team\*" "$env:USERPROFILE\.vscode-ai-team\"
```

✅ **Verification:** Run `ls ~/.vscode-ai-team/agents/` — you should see 11 `.md` files.

---

### Step 2: Install Required VS Code Extensions

1. Open VS Code
2. Press `Ctrl+Shift+X` (Windows) or `Cmd+Shift+X` (Mac) to open Extensions
3. Search for and install:
   - **GitHub Copilot** (`GitHub.copilot`)
   - **GitHub Copilot Chat** (`GitHub.copilot-chat`)
4. Sign in to GitHub Copilot when prompted

---

### Step 3: Set Up Global Custom Instructions

This makes the Chief of Staff agent active in every project you open.

1. Press `Ctrl+Shift+P` (Windows) or `Cmd+Shift+P` (Mac)
2. Type: **Open User Settings (JSON)** and press Enter
3. Inside the JSON object `{}`, add:

```json
"github.copilot.chat.codeGeneration.instructions": [
  {
    "file": "~/.vscode-ai-team/agents/chief-of-staff.md"
  }
]
```

**Full example if your settings file is currently empty:**
```json
{
  "github.copilot.chat.codeGeneration.instructions": [
    {
      "file": "~/.vscode-ai-team/agents/chief-of-staff.md"
    }
  ]
}
```

✅ **Verification:** Open Copilot Chat and ask: *"What role do you play in this workspace?"* — it should respond as the Chief of Staff.

---

### Step 4: (Optional) Set Up Per-Project Instructions

For projects where you want the full team active, add a `.github/copilot-instructions.md` file to the project root.

Run this from inside your project directory:

```bash
mkdir -p .github
cat > .github/copilot-instructions.md << 'EOF'
# AI Team Active

This project uses the VS Code AI Team framework.

## Agents Active
- Chief of Staff (orchestrator)
- Enterprise Architect
- DevSecOps
- Full Stack Engineer
- Risk & Privacy

## Project Context
Stack: [Fill in: e.g., Next.js, Node.js, PostgreSQL, Azure]
Compliance: [Fill in: e.g., PIPEDA, SOC2, none]
DRB Policy: Required for all architecture and technology decisions.

## Behavior
When answering any technical question, apply the Decision Review Board process
if the question involves architecture, security, technology selection, or 
production system changes.
EOF
```

Edit the file to add your actual project context.

---

### Step 5: (Optional) Enable Agent Mode in VS Code

1. Press `Ctrl+Shift+P` → type **Open User Settings (JSON)**
2. Add this setting:

```json
"github.copilot.chat.agent.enabled": true
```

---

## Part 2: Daily Usage

---

### Opening Copilot Chat

Press `Ctrl+Shift+I` (Windows/Linux) or `Cmd+Shift+I` (Mac)

Or click the **Copilot icon** in the left Activity Bar.

---

### How to Invoke the Chief of Staff (Standard Entry Point)

**Use this for anything complex, multi-domain, or requiring a decision.**

In Copilot Chat, type:

```
@workspace #file:~/.vscode-ai-team/agents/chief-of-staff.md

[Describe your request here]
```

**Example — Architecture Decision:**
```
@workspace #file:~/.vscode-ai-team/agents/chief-of-staff.md

I need to choose between PostgreSQL and MongoDB for our new document 
management system. Expected 500GB of documents. Complex queries needed.
Team has strong SQL skills. Please run a DRB recommendation.
```

**Example — New Feature Design:**
```
@workspace #file:~/.vscode-ai-team/agents/chief-of-staff.md

We want to add AI-powered document summarization to our product.
Users upload PDFs, we summarize using an LLM, store results.
~50,000 documents per day at peak. Must be PIPEDA compliant.
Please orchestrate the right agents and provide a full analysis.
```

---

### How to Invoke a Specific Specialist Agent

**Use this when you know exactly which domain you need.**

```
@workspace #file:~/.vscode-ai-team/agents/[agent-file].md
           #file:~/.vscode-ai-team/commands/[commands-file].md

/[command-name]
[Your request or code]
```

**Example — Security Review:**
```
@workspace #file:~/.vscode-ai-team/agents/devsecops.md
           #file:~/.vscode-ai-team/commands/security.commands.md

/security-review

Here is the authentication code for review:
[paste your code]
```

**Example — Code Review:**
```
@workspace #file:~/.vscode-ai-team/agents/full-stack-engineer.md
           #file:~/.vscode-ai-team/commands/development.commands.md

/code-review

Context: This is a payment processing controller in Node.js/Express.
[paste your code]
```

**Example — Generate ADR:**
```
@workspace #file:~/.vscode-ai-team/agents/enterprise-architect.md
           #file:~/.vscode-ai-team/commands/architecture.commands.md

/generate-adr

Decision: Whether to use Redis or Memcached for our caching layer
Context: We need distributed session caching for our Node.js app cluster.
Options: Redis, Memcached, in-process (Keyv)
Preferred: Redis (team familiarity, pub/sub capability needed)
```

---

### How to Run a Full Decision Review Board (DRB)

**Use this for any significant decision. Takes 3-5 minutes but saves hours of back-and-forth.**

```
@workspace 
  #file:~/.vscode-ai-team/agents/chief-of-staff.md
  #file:~/.vscode-ai-team/agents/enterprise-architect.md
  #file:~/.vscode-ai-team/agents/devsecops.md
  #file:~/.vscode-ai-team/agents/risk-privacy.md

Please convene a Decision Review Board for:

DECISION TITLE: [e.g., Selecting our AI Provider for Production]

CONTEXT:
[Describe the situation — what are you deciding and why?]

PROPOSED RECOMMENDATION:
[What do you currently think you should do?]

CONSTRAINTS:
[Budget, timeline, compliance requirements, team skills]

Please provide:
1. Enterprise Architect's architectural analysis
2. DevSecOps security and supply chain risk analysis  
3. Risk & Privacy compliance and risk analysis
4. Chief of Staff consolidation with all 10 DRB fields
5. All dissenting opinions recorded
```

---

### How to Run a Workflow

**Use workflows for structured multi-phase processes.**

```
@workspace
  #file:~/.vscode-ai-team/agents/chief-of-staff.md
  #file:~/.vscode-ai-team/workflows/[workflow-name].md

Please execute the [Workflow Name] workflow for:
[Your project/system description]
```

**Available Workflows:**
| Workflow File | Use When |
|--------------|---------|
| `architecture-review.md` | Reviewing any system design |
| `new-project.md` | Starting a new project |
| `security-review.md` | Pre-production security audit |
| `incident-response.md` | Responding to production incidents |
| `release-readiness.md` | Pre-release go/no-go check |
| `executive-briefing.md` | Creating executive communications |

---

### How to Use Templates

Templates are best used with the appropriate specialist agent:

**Example — Generate Architecture Document:**
```
@workspace
  #file:~/.vscode-ai-team/agents/enterprise-architect.md
  #file:~/.vscode-ai-team/templates/architecture-template.md

Please complete the architecture template for the following system:

System: Customer Portal API
Stack: Node.js, PostgreSQL, Redis, deployed on Azure AKS
Purpose: REST API serving our web and mobile customers
Key NFRs: 99.9% availability, P95 latency <200ms, 10K concurrent users
Compliance: PIPEDA, SOC2
```

**Example — Generate Risk Register:**
```
@workspace
  #file:~/.vscode-ai-team/agents/risk-privacy.md
  #file:~/.vscode-ai-team/templates/risk-template.md

Please create a risk assessment for:

System: AI-powered customer support chatbot
Personal data processed: Customer names, account history, conversation logs
Third parties: OpenAI API, Zendesk
Jurisdiction: Canada (PIPEDA applies)
Compliance context: SOC2 being pursued
```

---

## Part 3: Common Scenarios

---

### Scenario 1: "I want to add a new feature"

1. Invoke the **Chief of Staff** with your feature description
2. Ask it to invoke the **Product Owner** for user stories
3. Ask it to invoke the **Enterprise Architect** for design options
4. If personal data or significant changes: run a **DRB**

---

### Scenario 2: "I need to review this code before merging"

1. Invoke the **Full Stack Engineer** with `/code-review`
2. For auth/payment/sensitive code: also invoke **DevSecOps**
3. Blockers must be fixed; major issues should be addressed

---

### Scenario 3: "We had a production incident"

1. Invoke the **Disaster Recovery** agent with the incident details
2. Reference the **incident-response.md** workflow
3. After resolution: use the **Technical Writer** to produce the postmortem

---

### Scenario 4: "We need to present to leadership"

1. Provide your technical content to the **Executive Communications** agent
2. Reference the **executive-summary-template.md**
3. Ask: "Translate this for a non-technical VP audience with a decision recommendation"

---

### Scenario 5: "We're picking a new technology"

1. Invoke the **Chief of Staff** with the technology choice description
2. Request a `/evaluate-technology` DRB
3. The Chief of Staff will invoke Architect + DevSecOps + Risk & Privacy
4. You'll get a scored evaluation with a final recommendation

---

### Scenario 6: "We're building an AI feature"

1. Invoke the **Chief of Staff** + **AI Engineer** + **DevSecOps** + **Risk & Privacy**
2. Use `/design-agent` or `/rag-design` as appropriate
3. DRB is required for all AI production systems
4. Ensure PIA is completed if personal data is processed

---

## Part 4: Tips for Best Results

---

### Tip 1: Always Provide Context
The more context you provide, the better the output. Include:
- What you're building
- The technology stack
- The team's skill level
- Budget and timeline constraints
- Compliance requirements

### Tip 2: Use the DRB for Real Decisions
The DRB isn't just a checkbox — it surfaces risks you haven't thought of. Run it for anything consequential.

### Tip 3: Push Back on Overly Positive Output
If an agent seems too agreeable, prompt: *"What are the top 3 risks with this approach that we might be underestimating?"*

### Tip 4: Ask for Confidence Scores
Add to any request: *"Please include a confidence score (X/10) for this recommendation and list the top unknowns that could change it."*

### Tip 5: Request Dissenting Opinions
Add: *"What would the Enterprise Architect object to in this plan? What about DevSecOps?"*

### Tip 6: Use Commands for Structured Output
The slash commands (`/code-review`, `/threat-model`, etc.) produce consistently structured output that's easier to act on than free-form answers.

### Tip 7: Reference Workflows for Complex Tasks
Workflows break complex processes into phases and ensure nothing important is skipped. Use them for releases, new projects, and incident response.

---

## Part 5: Cheat Sheet

```
ORCHESTRATION
Chief of Staff = entry point for everything complex

DRB TRIGGER = any architecture, technology, or security decision that matters

DAILY COMMANDS
/code-review          → Full Stack + DevSecOps
/security-review      → DevSecOps + Risk & Privacy
/review-architecture  → Enterprise Architect + DRB
/generate-adr         → Enterprise Architect
/design-agent         → AI Engineer + DRB
/threat-model         → DevSecOps
/risk-assessment      → Risk & Privacy
/create-user-story    → Product Owner
/generate-executive-summary → Executive Communications
/create-drrunbook     → Disaster Recovery + TW

FILE LOCATIONS
Agents:    ~/.vscode-ai-team/agents/
Workflows: ~/.vscode-ai-team/workflows/
Commands:  ~/.vscode-ai-team/commands/
Templates: ~/.vscode-ai-team/templates/

INVOCATION PATTERN
@workspace #file:~/.vscode-ai-team/agents/[agent].md
           #file:~/.vscode-ai-team/commands/[commands].md
/[command]
[your request]
```
