# VS Code AI Team — Setup Guide

**Version:** 1.0
**Last Updated:** 2025

This guide explains how to install, configure, and use the VS Code AI Team framework across all your projects using GitHub Copilot Agent Mode and Claude's custom instructions.

---

## Table of Contents

1. [Overview](#1-overview)
2. [Prerequisites](#2-prerequisites)
3. [Installation](#3-installation)
4. [GitHub Copilot Agent Mode Setup](#4-github-copilot-agent-mode-setup)
5. [Custom Instructions Setup](#5-custom-instructions-setup)
6. [Workspace Settings](#6-workspace-settings)
7. [Global User Profile Setup](#7-global-user-profile-setup)
8. [Making Agents Available Across All Projects](#8-making-agents-available-across-all-projects)
9. [How to Invoke Agents](#9-how-to-invoke-agents)
10. [How Agents Collaborate](#10-how-agents-collaborate)
11. [Decision Review Board Usage](#11-decision-review-board-usage)
12. [Quick Reference — All Commands](#12-quick-reference-all-commands)
13. [Adding Future Agents](#13-adding-future-agents)
14. [Troubleshooting](#14-troubleshooting)

---

## 1. Overview

The VS Code AI Team is a multi-agent framework that gives you a virtual engineering leadership team inside VS Code. Each agent is a markdown instruction file that you reference in GitHub Copilot or Claude.

**What you get:**
- 11 specialist AI agents (Architect, Security, AI Engineer, etc.)
- A Chief of Staff orchestrator that coordinates all agents
- A Decision Review Board (DRB) process for major decisions
- 6 workflow playbooks
- 5 command sets with 20+ slash commands
- 5 reusable templates

---

## 2. Prerequisites

You need at least one of:

| Tool | What it enables |
|------|----------------|
| GitHub Copilot (Chat + Agent Mode) | Full agent invocation via `@workspace` in VS Code |
| Claude.ai (Pro or higher) | Use agents via Custom Instructions or pasting agent files |
| Any AI assistant supporting system prompts | Use agent markdown as system prompt content |

**Required VS Code Extensions:**
- GitHub Copilot (`GitHub.copilot`)
- GitHub Copilot Chat (`GitHub.copilot-chat`)

**Optional but Recommended:**
- GitLens
- Markdown All in One
- Error Lens

---

## 3. Installation

### Step 1: Copy the Framework to Your Global Location

Create a permanent home for the framework that is accessible from any project:

```bash
# On macOS/Linux
mkdir -p ~/.vscode-ai-team
cp -r VSCode-AI-Team/* ~/.vscode-ai-team/

# On Windows (PowerShell)
New-Item -ItemType Directory -Force "$env:USERPROFILE\.vscode-ai-team"
Copy-Item -Recurse "VSCode-AI-Team\*" "$env:USERPROFILE\.vscode-ai-team\"
```

Your directory structure should look like:
```
~/.vscode-ai-team/
├── agents/
│   ├── chief-of-staff.md
│   ├── enterprise-architect.md
│   ├── full-stack-engineer.md
│   ├── ai-engineer.md
│   ├── devsecops.md
│   ├── product-owner.md
│   ├── technical-writer.md
│   ├── senior-manager.md
│   ├── executive-communications.md
│   ├── disaster-recovery.md
│   └── risk-privacy.md
├── workflows/
├── commands/
├── templates/
└── setup-guide.md
```

### Step 2: (Optional) Per-Project Copy

For projects that use the framework heavily, you may want to copy it into the project:

```bash
# From within your project directory:
cp -r ~/.vscode-ai-team ./.ai-team
echo ".ai-team/" >> .gitignore  # Or commit it — your choice
```

---

## 4. GitHub Copilot Agent Mode Setup

GitHub Copilot Agent Mode (`@workspace`) allows you to include files from your workspace in Copilot's context. This is the primary way to invoke agents.

### Step 1: Enable Agent Mode in VS Code

1. Open VS Code Settings (`Cmd/Ctrl + ,`)
2. Search for: `github.copilot.chat.agent`
3. Ensure **GitHub Copilot Chat: Agent Mode** is enabled

### Step 2: Open Copilot Chat

- Press `Ctrl+Shift+I` (Windows/Linux) or `Cmd+Shift+I` (Mac)
- Or click the Copilot icon in the Activity Bar

### Step 3: Switch to Agent Mode

In the Copilot Chat panel, click the dropdown that says **"Ask"** and switch to **"Agent"** mode (or use `@workspace`).

### Step 4: Reference an Agent File

To invoke the Chief of Staff:
```
@workspace #file:~/.vscode-ai-team/agents/chief-of-staff.md

I need to design a new microservices architecture for our payment processing system. 
Budget is $50K/year for cloud costs. Team of 5 engineers. Must be PCI compliant.
```

To invoke specific agents with context:
```
@workspace #file:~/.vscode-ai-team/agents/devsecops.md
                #file:~/.vscode-ai-team/commands/security.commands.md

/security-review [paste code here]
```

### Step 5: Multi-Agent Invocation

You can reference multiple agents simultaneously:
```
@workspace 
  #file:~/.vscode-ai-team/agents/chief-of-staff.md
  #file:~/.vscode-ai-team/agents/enterprise-architect.md
  #file:~/.vscode-ai-team/agents/devsecops.md
  #file:~/.vscode-ai-team/workflows/architecture-review.md

Please run an architecture review on the attached design document.
[paste design here]
```

---

## 5. Custom Instructions Setup

Custom Instructions embed agent behavior permanently into every Copilot conversation — no need to reference files each time.

### Setting Up Global Custom Instructions

1. Open VS Code
2. Press `Cmd/Ctrl + Shift + P` → type **"Open User Settings (JSON)"**
3. Add the following:

```json
{
  "github.copilot.chat.codeGeneration.instructions": [
    {
      "file": "~/.vscode-ai-team/agents/chief-of-staff.md"
    }
  ]
}
```

> **Tip:** You can include multiple files. The Chief of Staff is recommended as the always-on orchestrator.

### Setting Up Workspace-Level Custom Instructions

Create a `.github/copilot-instructions.md` file in your project root. This is automatically picked up by GitHub Copilot:

```markdown
# Project AI Team Instructions

This project uses the VS Code AI Team framework.

## Active Agents
The following agents are active for this project:
- Chief of Staff (orchestrator)
- Enterprise Architect
- DevSecOps
- Full Stack Engineer

## Project Context
- **Stack**: [Your stack, e.g., Next.js, Node.js, PostgreSQL, Azure]
- **Compliance**: [e.g., SOC2, PCI, PIPEDA]
- **Team Size**: [N engineers]
- **Non-Functional Requirements**: [Availability target, latency targets]

## DRB Policy
All architecture decisions and technology changes require DRB review.
Invoke the Chief of Staff agent for any qualifying decision.

## Agent Instructions
[Paste the Chief of Staff agent markdown here, or reference the file]
```

---

## 6. Workspace Settings

Create a `.vscode/settings.json` in your project to configure workspace-level Copilot behavior:

```json
{
  "github.copilot.chat.codeGeneration.instructions": [
    {
      "file": ".ai-team/agents/chief-of-staff.md"
    },
    {
      "text": "Always apply the Decision Review Board process for architectural decisions."
    }
  ],
  "github.copilot.chat.testGeneration.instructions": [
    {
      "file": ".ai-team/agents/full-stack-engineer.md"
    },
    {
      "text": "Follow the testing standards in the Full Stack Engineering agent. Cover happy path and at least 2 failure modes."
    }
  ],
  "github.copilot.chat.reviewSelection.instructions": [
    {
      "file": ".ai-team/agents/devsecops.md"
    },
    {
      "text": "Perform a security-focused review. Rate findings as BLOCKER, MAJOR, MINOR, or NIT."
    }
  ]
}
```

---

## 7. Global User Profile Setup

To make agents available in **every** VS Code project without per-project configuration:

### Option A: VS Code User Settings

1. Press `Cmd/Ctrl + Shift + P` → **"Open User Settings (JSON)"**
2. Add:

```json
{
  "github.copilot.chat.codeGeneration.instructions": [
    {
      "file": "~/.vscode-ai-team/agents/chief-of-staff.md"
    }
  ]
}
```

### Option B: VS Code Profile

1. Go to **File → Preferences → Profiles → Create Profile**
2. Name it **"AI Team"**
3. In the profile's settings, add the custom instructions above
4. Switch to this profile when doing AI-assisted development

### Option C: Shell Alias for Quick Reference

Add to your `~/.zshrc` or `~/.bashrc`:

```bash
# AI Team aliases
alias ai-chief="cat ~/.vscode-ai-team/agents/chief-of-staff.md | pbcopy"
alias ai-architect="cat ~/.vscode-ai-team/agents/enterprise-architect.md | pbcopy"
alias ai-security="cat ~/.vscode-ai-team/agents/devsecops.md | pbcopy"
# Usage: run alias, then paste into any AI chat
```

---

## 8. Making Agents Available Across All Projects

### Method 1: Global Copilot Instructions (Recommended)

Add to VS Code User Settings JSON (applies to every project):

```json
{
  "github.copilot.chat.codeGeneration.instructions": [
    {
      "file": "~/.vscode-ai-team/agents/chief-of-staff.md"
    }
  ]
}
```

### Method 2: copilot-instructions.md in Every Project

Use a script to add the instructions file to new projects:

```bash
# ~/.scripts/init-ai-team.sh
#!/bin/bash
mkdir -p .github
cat ~/.vscode-ai-team/agents/chief-of-staff.md > .github/copilot-instructions.md
echo "✅ AI Team initialized for this project"
```

Then run `init-ai-team.sh` in any new project.

### Method 3: Git Template Directory

Any files in your git template directory are added to every new repository:

```bash
# Set up git template
mkdir -p ~/.git-template/.github
cp ~/.vscode-ai-team/agents/chief-of-staff.md ~/.git-template/.github/copilot-instructions.md
git config --global init.templateDir ~/.git-template

# Now every `git init` will include the AI Team instructions
```

---

## 9. How to Invoke Agents

### Pattern 1: Chief of Staff First (Recommended for Complex Requests)

The Chief of Staff is always your entry point for anything complex. It will invoke the right specialist agents:

```
I need to [describe what you need].

Context:
- [Relevant technical context]
- [Constraints]
- [Compliance requirements if any]

Please orchestrate the appropriate agents and provide a DRB recommendation if applicable.
```

### Pattern 2: Direct Specialist Invocation

When you know exactly which specialist you need:

```
[Include the specialist agent markdown or reference the file]

/[command-name]

[Your specific request or code]
```

**Examples:**

```
[enterprise-architect.md content]
/review-architecture
[paste your architecture description]
```

```
[devsecops.md content]  
/threat-model
System: Payment API
Components: React frontend, Node.js API, PostgreSQL, Stripe integration
Trust boundaries: Public internet → API, API → Stripe, API → Database
Data: Credit card tokens, user PII
```

```
[full-stack-engineer.md content]
/code-review
[paste your code]
```

### Pattern 3: Workflow Invocation

For end-to-end workflows:

```
[chief-of-staff.md content]
[architecture-review.md workflow content]

Please run the Architecture Review workflow for:
[Your architecture description]
```

### Pattern 4: Template Generation

```
[technical-writer.md content]

Please generate an ADR using the ADR template for:
Decision: Whether to use PostgreSQL or MongoDB for our document store
Context: [your context]
Options considered: PostgreSQL, MongoDB, DynamoDB
Recommendation: PostgreSQL
```

---

## 10. How Agents Collaborate

The collaboration model is:

```
You
 └── Chief of Staff (always the orchestrator)
      ├── Enterprise Architect (architecture decisions)
      │    └── collaborates with DevSecOps, Full Stack
      ├── DevSecOps (security — reviews all qualifying decisions)
      │    └── collaborates with Risk & Privacy, Disaster Recovery
      ├── Risk & Privacy (risk/compliance — reviews all qualifying decisions)
      │    └── collaborates with DevSecOps, Enterprise Architect
      ├── Full Stack Engineer (implementation)
      │    └── collaborates with Enterprise Architect, DevSecOps
      ├── AI Engineer (AI systems)
      │    └── collaborates with all agents
      ├── Product Owner (requirements and acceptance)
      ├── Technical Writer (documentation)
      ├── Senior Manager (team and org)
      ├── Executive Communications (stakeholder comms)
      └── Disaster Recovery (resilience and recovery)
```

**The DRB is always chaired by the Chief of Staff and requires:**
- Enterprise Architect sign-off
- DevSecOps sign-off
- Risk & Privacy sign-off

**To simulate multi-agent collaboration**, include multiple agent files in your request:

```
[chief-of-staff.md]
[enterprise-architect.md]
[devsecops.md]
[risk-privacy.md]

Please run a DRB review on this proposal:
[Your proposal]

Each agent should provide their independent assessment, then the Chief of Staff
should consolidate into a DRB recommendation with all 10 required fields.
```

---

## 11. Decision Review Board Usage

The DRB is the most powerful feature of this framework. Use it whenever you are making a decision that matters.

### When to Trigger a DRB

Trigger the DRB for:
- ✅ Selecting a new technology or vendor
- ✅ Designing a new system or service
- ✅ Making a significant architecture change
- ✅ Processing personal data in a new way
- ✅ Changes with cost implications >$5,000/year
- ✅ Any production system change affecting availability

### How to Run a DRB

**Prompt template:**

```
Chief of Staff, please convene the Decision Review Board for the following:

**Decision Under Review:** [Clear title]
**Requested by:** [Your name/team]
**Context:** [Background and problem]
**Proposed Recommendation:** [What you're proposing]
**Constraints:** [Budget, timeline, existing systems]

Please ensure:
1. Enterprise Architect provides architectural review
2. DevSecOps provides security review
3. Risk & Privacy provides risk and compliance review
4. All dissenting opinions are recorded
5. Final output includes all 10 DRB fields
```

### DRB Output Verification

Check your DRB output contains all 10 fields:
1. ✅ Recommended Option
2. ✅ Alternative Options
3. ✅ Risks
4. ✅ Cost Impact
5. ✅ Operational Impact
6. ✅ Security Impact
7. ✅ Implementation Complexity
8. ✅ Confidence Score
9. ✅ Dissenting Opinions
10. ✅ Final Decision

---

## 12. Quick Reference — All Commands

| Command | Agent | Description |
|---------|-------|-------------|
| `/review-architecture` | Chief of Staff + Architect | Full architecture review with DRB |
| `/generate-adr` | Enterprise Architect | Create an Architecture Decision Record |
| `/design-solution` | Chief of Staff + all | Design a solution with full multi-agent input |
| `/evaluate-technology` | Enterprise Architect + DRB | Technology/vendor evaluation |
| `/create-migration-plan` | Enterprise Architect | Phased migration planning |
| `/code-review` | Full Stack + DevSecOps | Multi-perspective code review |
| `/refactor` | Full Stack Engineer | Refactoring plan and implementation |
| `/generate-tests` | Full Stack Engineer | Full test suite generation |
| `/design-api` | Full Stack + Architect | API specification design |
| `/performance-review` | Full Stack + Architect | Performance analysis and optimization |
| `/security-review` | DevSecOps + Risk | Full security review |
| `/threat-model` | DevSecOps | STRIDE threat modeling |
| `/risk-assessment` | Risk & Privacy | Risk register and assessment |
| `/privacy-review` | Risk & Privacy | PIA for personal data |
| `/secrets-audit` | DevSecOps | Secrets and credentials audit |
| `/create-user-story` | Product Owner | User story with acceptance criteria |
| `/create-roadmap` | Product Owner + Manager | Product/technical roadmap |
| `/generate-executive-summary` | Executive Comms | Executive brief from technical content |
| `/create-drrunbook` | Disaster Recovery + TW | DR runbook creation |
| `/performance-review-person` | Senior Manager | Performance review document |
| `/design-agent` | AI Engineer + DRB | AI agent design and specification |
| `/evaluate-llm` | AI Engineer + DRB | LLM evaluation and selection |
| `/prompt-engineer` | AI Engineer | Production prompt design |
| `/ai-risk-review` | AI Engineer + Risk | AI system risk assessment |
| `/rag-design` | AI Engineer + Architect | RAG system architecture |
| `/agent-orchestration` | AI Engineer + Architect | Multi-agent system design |
| `/ai-eval-framework` | AI Engineer | AI evaluation framework design |

---

## 13. Adding Future Agents

To add a new agent to the framework:

### Step 1: Create the Agent File

Create `~/.vscode-ai-team/agents/[agent-name].md` following this structure:

```markdown
# [Agent Name] Agent

## Identity
| Field | Value |
|-------|-------|
| **Role** | [Role] |
| **Level** | [Level] |
| **Mission** | [Mission] |
| **Scope** | [Scope] |
| **Authority** | [Authority] |
| **Escalation** | [Escalation path] |

## Domain Expertise (15+ Years Equivalent)
[Expertise areas]

## Mandatory Analysis Framework
[What the agent must always evaluate]

## Decision Review Board Role
[Agent's DRB responsibilities]

## Adversarial Challenge Questions
[Questions agent must ask]

## Collaboration Triggers
[When to engage other agents]

## Behavioral Controls
[What the agent MUST NOT do]

## Success Metrics
[How quality is measured]
```

### Step 2: Register the Agent

Add the new agent to the Chief of Staff's Delegation Matrix in `agents/chief-of-staff.md`.

### Step 3: Add Commands (Optional)

Add a new section to the relevant commands file or create a new `[domain].commands.md`.

### Step 4: Update This Guide

Document the new agent in the Quick Reference table above.

---

## 14. Troubleshooting

### Agent not behaving as expected
- Ensure the full agent markdown is included in the context (not just the filename)
- For complex tasks, include both the agent file AND the relevant workflow file
- Explicitly mention the DRB when you need the full review process

### Copilot ignoring agent instructions
- Check that `github.copilot.chat.codeGeneration.instructions` is set correctly in settings
- Try using `@workspace #file:` syntax to explicitly include the file
- Ensure Agent Mode (not Ask mode) is selected in Copilot Chat

### DRB output missing fields
- Prompt: "Please ensure all 10 DRB fields are included: Recommended Option, Alternative Options, Risks, Cost Impact, Operational Impact, Security Impact, Implementation Complexity, Confidence Score, Dissenting Opinions, Final Decision"

### Context length issues
- For very large systems, break the review into phases
- Use the workflow files to structure the conversation across multiple turns
- Consider using the templates to collect structured input before the AI review

### Using with Claude (claude.ai)
1. Open a new conversation
2. Paste the contents of the agent file(s) you want to use as the first message
3. Follow with "Understood — please proceed as the above agent(s)"
4. Then begin your actual request
5. For the DRB process, include the Chief of Staff + three reviewer agents

---

*This framework is designed to grow with your team. The agents are opinionated, adversarial where needed, and built to produce production-grade outputs — not just suggestions.*
