# Development Commands

---

## /code-review

**Purpose:** Perform a comprehensive, multi-perspective code review with security and quality analysis.

**Inputs Required:**
- Code to review (paste, file, or PR link)
- Language and framework
- Context (what does this code do?)
- Review focus (optional): `security` | `quality` | `performance` | `all`

**Workflow:**
1. Full Stack Engineer performs primary code review
2. DevSecOps performs security-focused review
3. Findings consolidated with severity ratings

**Severity Ratings:**
- `[BLOCKER]` — Must fix before merge (security, correctness)
- `[MAJOR]` — Should fix before merge (quality, maintainability)
- `[MINOR]` — Fix in this sprint (style, improvement)
- `[NIT]` — Optional (preference, minor polish)

**Output Template:**
```markdown
## Code Review: [filename/PR]
**Verdict:** [ ] APPROVE  [ ] APPROVE WITH CONDITIONS  [ ] REQUEST CHANGES

### Blockers
- [BLOCKER] Line X: [Issue and specific fix]

### Major Issues
- [MAJOR] [Issue and recommendation]

### Minor Issues
- [MINOR] [Issue]

### Security Observations (DevSecOps)
- [Findings]

### Positive Observations
- [What is well done]

### Summary
[2-3 sentence overall assessment]
```

**Success Criteria:**
- All Blockers explicitly called out
- At least one positive observation (good review culture)
- Security review included for any auth/data handling code

---

## /refactor

**Purpose:** Produce a refactoring plan and implementation for a code section.

**Inputs Required:**
- Code to refactor
- Goals: `readability` | `performance` | `maintainability` | `testability` | `security`
- Constraints (cannot change public API, must maintain backward compatibility, etc.)

**Workflow:**
1. Full Stack Engineer analyzes current code quality issues
2. Refactoring plan produced with specific improvements
3. Refactored code produced
4. Test strategy updated
5. DevSecOps reviews if security-sensitive

**Output:**
- Analysis of current issues
- Refactoring plan (what will change and why)
- Refactored code
- Before/after comparison
- Updated or new tests

**Validation Rules:**
- Refactored code must be functionally equivalent (unless behavior change is specified)
- Tests must cover the same or more scenarios post-refactor
- Public interfaces preserved unless explicitly requested to change

---

## /generate-tests

**Purpose:** Generate a comprehensive test suite for a given code module.

**Inputs Required:**
- Code to test
- Test framework (Vitest, Jest, Playwright, etc.)
- Coverage goals: `unit` | `integration` | `e2e` | `all`
- Known edge cases (optional)

**Workflow:**
1. Full Stack Engineer analyzes code paths
2. Test scenarios generated (happy path + failure modes + edge cases)
3. Tests written with meaningful assertions
4. Test coverage analysis provided

**Test Quality Standards:**
```
✓ Each test has a single, clear assertion
✓ Test names describe behavior: "should [do X] when [condition Y]"
✓ Setup is minimal and explicit
✓ No test logic in production code
✓ Failure modes tested, not just success
✓ Mocks clearly documented
✓ No flaky tests (time-dependent, network-dependent without mocking)
```

**Output:**
- Test file(s) with full test suite
- Coverage analysis: what is and isn't covered
- Recommendations for additional test scenarios

---

## /design-api

**Purpose:** Design a RESTful or GraphQL API with full specification.

**Inputs Required:**
- API purpose and domain
- Resources/operations needed
- Consumer types (web, mobile, third-party)
- Authentication requirements
- Scale requirements

**Workflow:**
1. Full Stack Engineer designs API structure
2. Enterprise Architect validates against API standards
3. DevSecOps reviews authentication, authorization, rate limiting
4. Risk & Privacy reviews data exposure

**Output:**
- OpenAPI 3.0 specification (for REST)
- Schema definition (for GraphQL)
- Authentication design
- Error response contract
- Versioning strategy
- Rate limiting design
- API documentation

**Validation Rules:**
- All endpoints documented
- Error responses include meaningful codes and messages
- Authentication documented
- Pagination specified for list endpoints
- Versioning strategy defined

---

## /performance-review

**Purpose:** Analyze and optimize the performance of a system or code.

**Inputs Required:**
- System/code description or code
- Current performance metrics (if available)
- Performance targets
- Environment details

**Workflow:**
1. Full Stack Engineer profiles bottlenecks
2. Enterprise Architect reviews architectural performance patterns
3. Recommendations prioritized by impact and effort

**Analysis Areas:**
- Database query patterns (N+1, missing indexes, over-fetching)
- Caching opportunities (CDN, application, database)
- Bundle size and frontend loading (if frontend)
- API response times and payload sizes
- Memory usage and garbage collection
- Concurrency and throughput limits

**Output:**
- Performance analysis report
- Prioritized optimization recommendations (Impact / Effort matrix)
- Implementation guidance for top 3 improvements
- Performance testing approach
