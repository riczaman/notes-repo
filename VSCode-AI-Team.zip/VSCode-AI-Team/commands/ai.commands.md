# AI Engineering Commands

> See also: `/design-agent`, `/evaluate-llm`, `/prompt-engineer`, `/ai-risk-review` in `management.commands.md`

---

## /rag-design

**Purpose:** Design a production-quality Retrieval-Augmented Generation (RAG) system.

**Inputs Required:**
- Use case and data domain
- Data sources (documents, databases, APIs)
- Query characteristics (question types, frequency)
- Latency requirements
- Quality requirements (accuracy, citation)
- Scale (document count, query volume)

**Workflow:**
1. AI Engineer designs full RAG architecture
2. Enterprise Architect reviews infrastructure and integration
3. DevSecOps reviews PII handling in embeddings
4. Risk & Privacy reviews data governance for document ingestion
5. DRB convened for production systems

**Design Decisions Addressed:**
- Chunking strategy (fixed / semantic / recursive / hierarchical)
- Embedding model selection with benchmark rationale
- Vector database selection
- Hybrid search (dense + sparse) recommendation
- Re-ranking strategy
- Context window management
- Hallucination mitigation approach
- Evaluation framework (RAGAS metrics)
- Observability and trace logging

**Output:**
- RAG Architecture document
- Technology selection with rationale
- Evaluation framework
- DRB Recommendation
- Implementation roadmap

---

## /agent-orchestration

**Purpose:** Design a multi-agent orchestration system.

**Inputs Required:**
- Overall goal of the agent system
- Individual agent roles needed
- Coordination pattern: `sequential` | `parallel` | `hierarchical` | `mixed`
- Human-in-the-loop requirements
- Tool inventory
- Termination criteria

**Workflow:**
1. AI Engineer designs orchestration architecture
2. Enterprise Architect validates integration patterns
3. DevSecOps reviews tool permissions and data flows
4. Risk & Privacy reviews data handling across agents

**Output:**
- Multi-agent architecture document
- Agent interaction diagram
- Tool manifest (all tools, permissions, rationale)
- Failure mode analysis
- Observability design
- Cost model per workflow run
- Human-in-the-loop trigger conditions

---

## /ai-eval-framework

**Purpose:** Design an evaluation framework for an AI system before production deployment.

**Inputs Required:**
- AI system description and outputs
- Quality definition (what does "good" look like?)
- Failure modes to catch
- Volume of evaluations feasible

**Workflow:**
1. AI Engineer designs evaluation approach
2. Evaluation dataset strategy created
3. Metrics defined (automatic + human)
4. CI/CD integration plan produced

**Evaluation Framework Components:**
```markdown
## Automatic Metrics
- [Task-specific metrics: RAGAS, BLEU, exact match, etc.]
- Latency P50/P95/P99
- Token cost per operation

## LLM-as-Judge Metrics
- Correctness: [Rubric]
- Relevance: [Rubric]
- Safety: [Rubric]
- Groundedness (for RAG): [Rubric]

## Human Evaluation
- Sampling strategy
- Annotation guidelines
- Agreement measurement

## Regression Testing
- Golden dataset: [Size, diversity]
- CI gate: [Threshold for blocking deployment]
- Drift detection: [How production quality is monitored]
```

**Output:**
- Evaluation Framework document
- Golden dataset strategy
- CI/CD integration specification
- Dashboard design for ongoing monitoring
