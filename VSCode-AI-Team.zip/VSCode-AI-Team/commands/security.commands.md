# Security Commands

---

## /security-review

**Purpose:** Perform a comprehensive security review with findings report and remediation guidance.

**Inputs Required:**
- Scope: `code` | `architecture` | `infrastructure` | `api` | `full`
- Code/system description or content
- Compliance context (PCI, SOC2, GDPR, etc.)
- Previous findings (if re-review)

**Workflow:**
1. DevSecOps performs STRIDE threat modeling
2. Code/infrastructure security checklist applied
3. Risk & Privacy performs compliance cross-check
4. Enterprise Architect reviews architectural security controls
5. Findings report produced with severity ratings and remediation guidance
6. Chief of Staff issues go/no-go recommendation for qualifying decisions

**Outputs:**
- Security Review Report
- Threat Model
- Findings list with severity (Critical / High / Medium / Low)
- Remediation guidance for each finding
- Overall security posture verdict: PASS / CONDITIONAL PASS / FAIL

**Success Criteria:**
- All Critical and High findings have specific remediation steps
- Compliance requirements addressed
- No false assurance: if risks remain open, they are documented

---

## /threat-model

**Purpose:** Create a formal threat model for a system using STRIDE methodology.

**Inputs Required:**
- System name and description
- System components
- Data flows (what data moves where)
- Trust boundaries (external users, APIs, services)
- Sensitivity of data involved

**Workflow:**
1. DevSecOps creates Data Flow Diagram
2. STRIDE analysis per component and data flow
3. Threats rated by likelihood and impact
4. Mitigations proposed for all High and Critical threats
5. Security requirements derived from threat model

**Output Template:**
```markdown
# Threat Model: [System Name]
## Data Flow Diagram
[Component descriptions with trust boundaries]

## Assets Being Protected
[List of sensitive assets]

## Trust Boundaries
[Where authorization/authentication is required]

## STRIDE Analysis
| ID | Component | Threat | Category | Likelihood | Impact | Rating | Mitigation |
|----|-----------|--------|----------|-----------|--------|--------|-----------|

## Attack Surface
[All external entry points]

## Security Requirements
[Controls derived from threats]

## Open Threats (No Mitigation Yet)
[If any — must be risk-accepted by named owner]
```

**Success Criteria:**
- All data flows mapped
- Every trust boundary identified
- All Critical and High threats have mitigations or documented risk acceptance

---

## /risk-assessment

**Purpose:** Produce a risk assessment for a project, system, or decision.

**Inputs Required:**
- Subject of assessment
- Scope (technical, operational, compliance, privacy, or all)
- Business context
- Known concerns

**Workflow:**
1. Risk & Privacy leads risk identification
2. DevSecOps contributes technical and security risks
3. Enterprise Architect contributes architectural and operational risks
4. Disaster Recovery contributes availability and recovery risks
5. Risks rated and prioritized
6. Mitigation options proposed

**Output:**
- Risk Register (probability × impact matrix)
- Top 5 risks with detailed analysis
- Mitigation recommendations per risk
- Residual risk summary
- Risks requiring formal acceptance

---

## /privacy-review

**Purpose:** Conduct a Privacy Impact Assessment (PIA) for a system or feature involving personal data.

**Inputs Required:**
- System/feature description
- Personal data types involved (name, email, location, financial, health, etc.)
- Data sources and flows
- Applicable jurisdictions (Canada, EU, US, etc.)
- Third parties receiving data

**Workflow:**
1. Risk & Privacy leads PIA
2. Enterprise Architect reviews data architecture
3. DevSecOps reviews technical privacy controls
4. Full Stack Engineer validates implementation feasibility of privacy controls

**Output:**
- Full Privacy Impact Assessment document
- Data inventory with classification
- Legal basis for processing
- Risk findings
- Required controls and recommendations
- PIA decision: Approved / Conditional / Not Approved

**Validation Rules:**
- Personal data cannot be processed without completed PIA
- Cross-border transfers require documented legal basis
- Third-party data sharing requires DPA review

---

## /secrets-audit

**Purpose:** Audit a codebase or configuration for exposed secrets and remediation guidance.

**Inputs Required:**
- Repository or code to audit

**Workflow:**
1. DevSecOps performs pattern-based secrets analysis
2. Infrastructure configuration reviewed
3. Pipeline configuration reviewed
4. Historical commits flagged (if pattern-match found)

**Checks:**
```
✓ Hardcoded API keys
✓ Database connection strings with credentials
✓ Private keys and certificates
✓ OAuth tokens
✓ Cloud provider credentials
✓ Passwords in config files
✓ Secrets in environment variable names (suggesting inline values)
✓ Secrets in logs or test files
```

**Output:**
- Findings with file locations
- Severity (any exposed secret is Critical)
- Remediation steps:
  1. Rotate the exposed credential immediately
  2. Remove from codebase and history (git-filter-repo)
  3. Replace with vault/secret manager reference
  4. Add to secrets scanning rules to prevent recurrence
