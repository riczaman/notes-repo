# Architecture Commands

---

## /review-architecture

**Purpose:** Perform a full multi-agent architecture review with DRB output.

**Inputs Required:**
- System/feature name
- Description of what is being built or changed
- Current architecture (if applicable)
- Constraints (budget, timeline, team)
- Non-functional requirements (availability, latency, scale)

**Workflow:**
1. Chief of Staff receives request and classifies scope
2. Enterprise Architect performs primary architectural analysis
3. DevSecOps performs threat modeling
4. Risk & Privacy performs risk/compliance review
5. DRB convened — all three reviewers provide sign-off or dissent
6. Chief of Staff consolidates findings

**Validation Rules:**
- Must include at least one NFR (performance, availability, or security)
- Must identify the technology choices being made
- Must identify integration dependencies

**Outputs:**
- DRB Recommendation (all 10 fields)
- Architecture Decision Record (ADR)
- Threat Model
- Risk Register entries

**Escalation Paths:**
- Critical security finding → DevSecOps blocks, Chief of Staff escalates
- Unresolvable trade-off → Human principal decision

**Success Criteria:**
- ADR produced with status Proposed or Accepted
- All 10 DRB fields completed
- No unmitigated Critical/High findings

---

## /generate-adr

**Purpose:** Generate a structured Architecture Decision Record for a specific technology or design decision.

**Inputs Required:**
- Decision title
- Context (what problem are we solving?)
- Options considered (minimum 2)
- Preferred option
- Key constraints

**Workflow:**
1. Enterprise Architect drafts ADR
2. DevSecOps reviews security implications
3. Full Stack Engineer reviews implementation feasibility
4. Chief of Staff issues for team review

**Outputs:**
```markdown
# ADR-[NNN]: [Title]
Status / Context / Decision / Rationale / Consequences / Alternatives / Review Date
```

**Success Criteria:**
- All ADR sections completed
- Minimum 2 alternatives documented
- Consequences include both positive and negative
- Review date set

---

## /design-solution

**Purpose:** Design a technical solution for a given problem with full multi-agent input.

**Inputs Required:**
- Problem statement
- Business requirements
- Technical constraints
- Scale requirements
- Timeline

**Workflow:**
1. Chief of Staff decomposes the problem into domains
2. Enterprise Architect proposes solution architecture
3. Full Stack Engineer proposes implementation approach
4. AI Engineer (if AI components) proposes AI architecture
5. DevSecOps reviews security
6. Risk & Privacy reviews compliance
7. Chief of Staff consolidates into solution design document

**Outputs:**
- Solution design document
- Architecture diagram (Mermaid notation)
- Technology recommendations
- ADRs for key decisions
- DRB output (if qualifying scope)
- Implementation approach
- Risk register

**Validation Rules:**
- Must include non-functional requirements
- Must include at least one alternative approach
- Must include a risk assessment
- Must include a cost estimate

**Success Criteria:**
- All domains addressed
- Solution is implementable by the team
- Security and compliance addressed

---

## /evaluate-technology

**Purpose:** Evaluate a specific technology, vendor, or tool for fit within the enterprise stack.

**Inputs Required:**
- Technology/vendor name
- Use case being considered
- Current alternatives in use
- Evaluation criteria

**Workflow:**
1. Enterprise Architect leads evaluation against enterprise standards
2. DevSecOps evaluates security posture, CVE history, security certifications
3. Risk & Privacy evaluates vendor risk, data handling, licensing
4. Full Stack Engineer evaluates developer experience and integration complexity
5. Chief of Staff produces DRB Recommendation

**Evaluation Criteria Template:**
| Criterion | Weight | Score (1-10) | Notes |
|-----------|--------|-------------|-------|
| Technical fit | 25% | | |
| Security posture | 20% | | |
| Vendor maturity | 15% | | |
| Total cost of ownership | 15% | | |
| Developer experience | 10% | | |
| Community / ecosystem | 10% | | |
| Enterprise compliance | 5% | | |

**Outputs:**
- Technology Evaluation Report
- DRB Recommendation
- ADR (if adoption approved)

---

## /create-migration-plan

**Purpose:** Create a phased migration plan from one technology or architecture to another.

**Inputs Required:**
- Current state (what we're migrating from)
- Target state (what we're migrating to)
- Business drivers for migration
- Constraints (downtime tolerance, team capacity, timeline)

**Workflow:**
1. Enterprise Architect designs phased migration approach
2. DevSecOps reviews security implications at each phase
3. Disaster Recovery reviews continuity approach
4. Risk & Privacy reviews data migration compliance
5. Full Stack Engineer validates implementation feasibility
6. Product Owner validates business impact of each phase
7. Chief of Staff produces migration plan with DRB sign-off

**Outputs:**
- Phased Migration Plan document
- Risk register for migration
- Rollback strategy per phase
- DRB Recommendation
- Communication plan

**Success Criteria:**
- Each phase is independently deployable
- Rollback is possible at each phase
- No phase introduces extended downtime above tolerance
- Data integrity plan for each phase
