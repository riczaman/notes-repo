# Management Commands

---

## /create-user-story

**Purpose:** Generate well-formed user stories with acceptance criteria from a feature description.

**Inputs Required:**
- Feature or capability description
- Target user persona
- Business outcome expected
- Known constraints or dependencies

**Workflow:**
1. Product Owner drafts user story using Gherkin acceptance criteria
2. Full Stack Engineer reviews technical feasibility
3. DevSecOps adds security acceptance criteria if applicable
4. Risk & Privacy adds compliance acceptance criteria if applicable

**Output:** Complete user story with all sections including:
- User story statement (As a / I want / So that)
- Acceptance criteria (Given / When / Then)
- Non-functional requirements
- Out of scope definition
- Dependencies
- Definition of Done

---

## /create-roadmap

**Purpose:** Build a product or technical roadmap for a given scope and timeframe.

**Inputs Required:**
- Goals and objectives
- Current state
- Timeline (quarters)
- Constraints (budget, team, dependencies)
- Priorities

**Workflow:**
1. Product Owner defines business priorities
2. Enterprise Architect contributes technical foundation items
3. DevSecOps contributes security roadmap items
4. Senior Manager validates capacity assumptions
5. Chief of Staff consolidates and sequences

**Output:**
- Roadmap by quarter (Now / Next / Later)
- Dependencies identified
- Risks to roadmap delivery
- Resource assumptions

---

## /generate-executive-summary

**Purpose:** Produce an executive summary from technical content.

**Inputs Required:**
- Technical content, report, or project status
- Target audience level
- Decision or action needed (if any)

**Workflow:**
1. Executive Communications leads translation
2. Technical accuracy reviewed by domain agents
3. Chief of Staff reviews final output

**Output:**
- Executive Brief (1-2 pages max)
- BLUF (Bottom Line Up Front) opening
- Options table (if decision required)
- Recommended next steps with owners

---

## /create-drrunbook

**Purpose:** Generate a Disaster Recovery runbook for a specific system and failure scenario.

**Inputs Required:**
- System name and description
- Failure scenario
- Current architecture (failover options available)
- RTO/RPO targets
- On-call contacts

**Workflow:**
1. Disaster Recovery leads runbook design
2. Enterprise Architect validates technical recovery steps
3. DevSecOps validates security of recovery procedure
4. Technical Writer produces final formatted runbook

**Output:** Complete DR runbook with:
- Activation criteria
- Pre-activation checklist
- Step-by-step recovery with verification checkpoints
- Rollback procedure
- Post-incident actions

---

## /performance-review-person

**Purpose:** Generate a structured performance review for a team member.

**Inputs Required:**
- Role and level
- Review period
- Accomplishments (bullet points accepted)
- Development areas (if known)
- Goals for next period

**Workflow:**
1. Senior Manager structures and frames the review
2. Calibration against level expectations
3. Development plan generated

**Output:**
- Formatted performance summary
- Strengths with evidence
- Development areas with specific actions
- Goals for next period with metrics
- Overall assessment and promotion readiness

---

# AI Commands

---

## /design-agent

**Purpose:** Design an AI agent with full specification including tools, memory, safety controls, and evaluation strategy.

**Inputs Required:**
- Agent purpose (1 sentence)
- Inputs the agent receives
- Outputs the agent produces
- Tools/systems it needs access to
- Constraints (latency, cost, safety)

**Workflow:**
1. AI Engineer designs agent architecture
2. Enterprise Architect reviews system integration
3. DevSecOps reviews tool permissions and data access
4. Risk & Privacy reviews data handling
5. Chief of Staff produces DRB recommendation if qualifying scope

**Output:**
- Agent Design Document (full specification)
- Tool inventory with least-privilege rationale
- Prompt templates
- Evaluation framework
- Observability plan
- Cost model

---

## /evaluate-llm

**Purpose:** Evaluate and compare language models for a specific use case.

**Inputs Required:**
- Use case description
- Key requirements: quality, latency, cost, privacy, data residency
- Models to compare (or request recommendation)
- Sample inputs/outputs (optional but improves quality)

**Workflow:**
1. AI Engineer structures evaluation framework
2. Models scored against weighted criteria
3. DevSecOps reviews security and data handling of each model
4. Risk & Privacy reviews data residency and compliance
5. Cost model built for expected volume
6. DRB Recommendation produced

**Evaluation Matrix:**
| Criterion | Weight | Model A | Model B | Model C |
|-----------|--------|---------|---------|---------|
| Quality / Accuracy | 30% | | | |
| Latency (P95) | 20% | | | |
| Cost at volume | 20% | | | |
| Data privacy/residency | 15% | | | |
| Reliability/uptime | 10% | | | |
| Ease of integration | 5% | | | |

**Output:**
- LLM Evaluation Report
- Recommendation with rationale
- DRB Recommendation
- Cost model at 3 volume tiers

---

## /prompt-engineer

**Purpose:** Design, test, and document a production-quality prompt for a specific AI task.

**Inputs Required:**
- Task description
- Target model
- Expected input format
- Expected output format
- Quality criteria (how is a good output defined?)
- Known failure modes (optional)

**Workflow:**
1. AI Engineer designs system prompt
2. Few-shot examples created
3. Output format specified
4. Adversarial test cases designed
5. Prompt library entry created

**Output:**
- System prompt (versioned)
- Few-shot examples
- Output schema
- Known failure modes documented
- Eval criteria
- Prompt Library entry

---

## /ai-risk-review

**Purpose:** Assess AI-specific risks for an AI system or feature in development or production.

**Inputs Required:**
- AI system description
- Data inputs (including any personal data)
- Decision type (informational, advisory, automated action)
- User population and vulnerability considerations
- Current safeguards

**Workflow:**
1. AI Engineer identifies AI-specific risks (hallucination, bias, prompt injection, model drift)
2. Risk & Privacy assesses privacy and regulatory implications
3. DevSecOps assesses security (prompt injection, model abuse, data exfiltration)
4. Chief of Staff consolidates with DRB recommendation

**AI Risk Categories:**
- Accuracy / Hallucination risk
- Bias and fairness risk
- Prompt injection / adversarial risk
- Data privacy risk (PII in inputs/outputs)
- Model drift and staleness risk
- Dependency / vendor concentration risk
- Explainability risk (for regulated decisions)
- Cost overrun risk

**Output:**
- AI Risk Assessment
- Risk register entries
- Mitigation recommendations
- Monitoring requirements
- DRB Recommendation
