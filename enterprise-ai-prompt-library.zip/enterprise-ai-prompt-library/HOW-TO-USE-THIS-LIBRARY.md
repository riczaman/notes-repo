# 📖 How to Use This Library — Plain English Guide

## What Is This?

This is an **AI Prompt Library** — a toolkit that makes every person on your tech team
dramatically faster and better at their job by giving them the exact words to use
when talking to AI tools like Claude, GitHub Copilot, or ChatGPT.

---

## The Library Has 3 Parts

### PART 1 — PROMPTS (most important, start here)
These are the copy-paste instructions you give to AI.

| File | Who Uses It | What's In It |
|------|-------------|--------------|
| `prompts/senior-developer/prompts.md` | Developers | Code review, API design, bug diagnosis, deployments |
| `prompts/senior-architect/prompts.md` | Architects | HLD creation, ADRs, migration strategy, risk assessment |
| `prompts/devsecops-analyst/prompts.md` | DevSecOps | Pipeline design, security scans, threat modelling |
| `prompts/executive-avp/prompts.md` | AVP/VP/Directors | Steering updates, board reports, business cases |
| `prompts/pm-ba-em-qe-comms-support-prompts.md` | PM, BA, EM, QE, Comms, Support | Everything for those 6 roles |

**How to use a prompt:**
1. Open the file for your role
2. Find the prompt for your task (e.g., SD-03 for a bug RCA)
3. Copy the template
4. Replace everything in `{{DOUBLE_BRACKETS}}` with your real info
5. Paste into Claude, Copilot Chat, or ChatGPT
6. Get a professional-grade output in seconds

---

### PART 2 — TEMPLATES (blank documents your team fills in)
These are the professionally structured documents that prompts help you create.

| File | What It Is | When You Use It |
|------|------------|-----------------|
| `templates/brd/BRD-TEMPLATE.md` | Business Requirements Document | Starting a new project |
| `templates/hld/HLD-TEMPLATE.md` | High-Level Design document | Designing a new system |
| `templates/runbook/RUNBOOK-TEMPLATE.md` | Operations runbook | Documenting how to run a service |
| `templates/incident-report/INCIDENT-REPORT-TEMPLATE.md` | Incident + RCA form | After any production incident |
| `templates/operational-readiness/OPERATIONAL-READINESS-CHECKLIST.md` | Go-live checklist | Before any production release |

**How to use a template:**
1. Copy the file and rename it (e.g., `BRD-2026-001-Payment-Notifications.md`)
2. Use the matching prompt (e.g., BA-01) to ask AI to fill it in for your project
3. Review, edit, and get sign-off from your team

---

### PART 3 — READY-TO-USE FILES (drop into your projects)
These work right now without modification (minor config changes only).

| File | What It Does | Drop It Into |
|------|--------------|--------------|
| `pipelines/github-actions/secure-cicd-java.yaml` | Full secure CI/CD for Java | `.github/workflows/` in your repo |
| `pipelines/azure-devops/azure-pipeline.yaml` | Full Azure DevOps pipeline | Your ADO pipeline config |
| `pipelines/terraform/terraform-pipeline.yaml` | Terraform IaC pipeline | `.github/workflows/` in your infra repo |
| `communications/EXECUTIVE-COMMUNICATIONS-LIBRARY.md` | 9 executive email templates | Use directly — copy, fill 3 blanks, send |
| `config/vscode-setup.md` | VS Code + AI setup guide | Follow step by step once |

---

## Quick Start for Each Role

### 👨‍💻 I'm a Developer
1. Open `prompts/senior-developer/prompts.md`
2. Use **SD-01** to review your next PR with AI
3. Use **SD-03** next time you hit a production bug
4. Set up VS Code using `config/vscode-setup.md`

### 🏗️ I'm an Architect
1. Open `prompts/senior-architect/prompts.md`
2. Use **SA-01** to generate your next ADR in minutes
3. Use **SA-02** to generate a full HLD — fill in `{{BRACKETS}}`, paste, done
4. Use the `templates/hld/HLD-TEMPLATE.md` as the output document

### 👔 I'm an AVP/VP/Director
1. Open `prompts/executive-avp/prompts.md`
2. Use **AVP-01** for your next steering committee package
3. Use **AVP-07** when a production incident needs an executive brief
4. Use `communications/EXECUTIVE-COMMUNICATIONS-LIBRARY.md` for emails — find the right template, fill 3 blanks, send

### 🔐 I'm in DevSecOps
1. Open `prompts/devsecops-analyst/prompts.md`
2. Drop `pipelines/github-actions/secure-cicd-java.yaml` into your repo NOW
3. Use **DSO-02** to review any Terraform before it goes to production
4. Use **DSO-08** when a security incident happens

### 📋 I'm a BA or PM
1. Open `prompts/pm-ba-em-qe-comms-support-prompts.md`
2. BA section: use **BA-01** to generate a full BRD from your notes
3. PM section: use **PM-01** for PRDs, **PM-02** for roadmap prioritization
4. Use `templates/brd/BRD-TEMPLATE.md` as your output document

### 🎧 I'm in Support
1. Open `prompts/pm-ba-em-qe-comms-support-prompts.md`
2. Use **SUP-01** to triage your next complex ticket
3. Use **SUP-02** to generate a full ITIL RCA report
4. Use `templates/incident-report/INCIDENT-REPORT-TEMPLATE.md` as your RCA document

---

## How the Files Work Together (Example)

**Scenario**: New service going to production next week.

```
Step 1: Architect uses SA-02 prompt → AI generates HLD → saved as HLD-TEMPLATE filled in
Step 2: DevSecOps uses DSO-01 prompt → AI generates secure pipeline → drop secure-cicd-java.yaml into repo
Step 3: QE uses QE-01 prompt → AI generates test strategy → team builds tests
Step 4: EM uses OPERATIONAL-READINESS-CHECKLIST.md → team works through 80 items
Step 5: AVP uses AVP-01 prompt → AI generates steering committee update
Step 6: Comms uses COMM-07 → AI fills release notice template → sent to stakeholders
```

**Total AI-assisted time saved**: ~40 hours of manual writing → ~4 hours with prompts.

---

## Tips for Best Results

1. **Fill in ALL the `{{BRACKETS}}`** — the more context you give, the better the output
2. **Be specific** — "payment processing microservice" beats "my service"
3. **Iterate** — use the output as a first draft, ask AI to "refine section 3"
4. **Save your filled prompts** — build a personal library of prompts that worked well
5. **Share what works** — if you improve a prompt, submit a PR back to this repo

