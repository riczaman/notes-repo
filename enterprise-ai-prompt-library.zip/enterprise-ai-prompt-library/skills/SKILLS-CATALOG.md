# 📚 Skills Catalog — Enterprise AI Engineering Skills System

## Metadata Schema

All skills follow this YAML front-matter schema:

```yaml
---
skill_id: SKL-XXX
name: Skill Name
version: 1.0.0
category: [engineering | architecture | security | operations | communications | testing]
domain: [general | financial-services | azure | kubernetes | java]
maturity: [foundational | developing | proficient | advanced | expert]
owner: [role responsible for maintaining this skill]
last_reviewed: YYYY-MM-DD
next_review: YYYY-MM-DD
dependencies:
  - SKL-XXX (other skills this one depends on)
tags:
  - tag1
  - tag2
compliance:
  - SOC2
  - PCI-DSS
tools:
  - tool1
  - tool2
---
```

---

# SKL-001 — API Design

```yaml
---
skill_id: SKL-001
name: API Design
version: 2.1.0
category: engineering
domain: general
maturity: proficient
owner: senior-architect
last_reviewed: 2026-01-15
next_review: 2026-07-15
dependencies: []
tags: [api, rest, openapi, design, contracts]
compliance: [SOC2, PCI-DSS]
tools: [Swagger, Stoplight, Postman, Azure APIM]
---
```

## Overview
Design production-grade REST and event-driven APIs following OpenAPI 3.1 standards, Azure APIM patterns, and financial services compliance requirements.

## Core Competencies

### REST API Design Principles
- **Resource modeling**: Noun-based URLs, plural collection names (`/payments`, `/accounts`)
- **HTTP verbs**: GET (idempotent retrieval), POST (create), PUT (full replace), PATCH (partial update), DELETE
- **Status codes**: Use semantically correct codes (201 Created, 202 Accepted, 204 No Content, 422 Unprocessable Entity)
- **Pagination**: Cursor-based for large datasets; include `next_cursor`, `total_count` in response
- **Versioning**: URI versioning (`/v1/`) with semantic versioning policy and 12-month deprecation notice

### OpenAPI 3.1 Specification
```yaml
openapi: 3.1.0
info:
  title: Payment Processing API
  version: 1.0.0
  description: Processes payment transactions for financial services platform
  contact:
    name: Payments Team
    email: payments-team@org.com

servers:
  - url: https://api.org.com/v1
    description: Production
  - url: https://api-staging.org.com/v1
    description: Staging

security:
  - BearerAuth: []

components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT

  schemas:
    PaymentRequest:
      type: object
      required: [amount, currency, merchant_id]
      properties:
        amount:
          type: integer
          description: Amount in cents
          minimum: 1
          example: 1000
        currency:
          type: string
          pattern: '^[A-Z]{3}$'
          example: CAD
        merchant_id:
          type: string
          format: uuid
        idempotency_key:
          type: string
          maxLength: 64

    Problem:
      type: object
      description: RFC 7807 Problem Details
      properties:
        type:
          type: string
          format: uri
        title:
          type: string
        status:
          type: integer
        detail:
          type: string
        instance:
          type: string
          format: uri
```

### Security Requirements
- OAuth2 / OIDC bearer tokens (Azure AD)
- Rate limiting headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`
- Idempotency keys on mutating operations
- No PAN, CVV, or account numbers in URLs or logs

### Breaking vs Non-Breaking Changes
| Change Type | Breaking | Required Notice |
|-------------|----------|-----------------|
| Remove endpoint | Yes | 12 months |
| Remove required field | Yes | 12 months |
| Add required field | Yes | 12 months |
| Add optional field | No | Release notes |
| Change field type | Yes | 12 months |
| Add new endpoint | No | Release notes |

---

# SKL-002 — CI/CD Pipeline Engineering

```yaml
---
skill_id: SKL-002
name: CI/CD Pipeline Engineering
version: 1.3.0
category: engineering
domain: azure
maturity: proficient
owner: devsecops-analyst
last_reviewed: 2026-02-01
next_review: 2026-08-01
dependencies: [SKL-003, SKL-006]
tags: [cicd, github-actions, pipeline, automation, devops]
compliance: [SOC2, PCI-DSS]
tools: [GitHub Actions, Azure DevOps, Helm, ACR, AKS]
---
```

## Overview
Design, build, and maintain enterprise-grade CI/CD pipelines with embedded security gates for financial services workloads.

## Pipeline Stages

### Standard Pipeline Architecture
```
Source → Build → Test → Scan → Package → Deploy-Dev → Deploy-Staging → Approve → Deploy-Prod
```

### GitHub Actions Template
```yaml
name: Secure Service Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

permissions:
  contents: read
  id-token: write        # OIDC for Azure
  security-events: write # CodeQL

env:
  JAVA_VERSION: '17'
  ACR_NAME: ${{ vars.ACR_NAME }}
  AKS_CLUSTER: ${{ vars.AKS_CLUSTER }}
  RESOURCE_GROUP: ${{ vars.RESOURCE_GROUP }}

jobs:
  build-and-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11  # v4 pinned

      - name: Set up Java
        uses: actions/setup-java@387ac29b308b003ca37ba93a6cab5eb57c8f5f93  # v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: temurin
          cache: maven

      - name: Build and Test
        run: mvn -B verify --no-transfer-progress

      - name: Check Coverage
        run: |
          COVERAGE=$(mvn jacoco:report | grep -oP 'Total.*?(\d+)%' | tail -1 | grep -oP '\d+')
          if [ "$COVERAGE" -lt 80 ]; then
            echo "Coverage $COVERAGE% below threshold of 80%"
            exit 1
          fi

  security-scan:
    runs-on: ubuntu-latest
    needs: build-and-test
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11

      - name: Run CodeQL
        uses: github/codeql-action/analyze@v3
        with:
          languages: java

      - name: Run Gitleaks
        uses: gitleaks/gitleaks-action@v2

      - name: OWASP Dependency Check
        run: |
          mvn org.owasp:dependency-check-maven:check \
            -DfailBuildOnCVSS=9 \
            -DsuppressionsLocation=.owasp-suppressions.xml

  container-build:
    runs-on: ubuntu-latest
    needs: security-scan
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11

      - name: Azure Login (OIDC)
        uses: azure/login@v2
        with:
          client-id: ${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: ${{ secrets.AZURE_TENANT_ID }}
          subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Build Container
        run: |
          docker build -t ${{ env.ACR_NAME }}.azurecr.io/service:${{ github.sha }} .

      - name: Trivy Scan
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: ${{ env.ACR_NAME }}.azurecr.io/service:${{ github.sha }}
          exit-code: '1'
          severity: 'CRITICAL,HIGH'

      - name: Push to ACR
        run: |
          az acr login --name ${{ env.ACR_NAME }}
          docker push ${{ env.ACR_NAME }}.azurecr.io/service:${{ github.sha }}
```

---

# SKL-003 — Kubernetes Engineering

```yaml
---
skill_id: SKL-003
name: Kubernetes Engineering
version: 1.5.0
category: engineering
domain: azure
maturity: proficient
owner: devsecops-analyst
last_reviewed: 2026-03-01
next_review: 2026-09-01
dependencies: []
tags: [kubernetes, aks, helm, containers, orchestration]
compliance: [SOC2, PCI-DSS]
tools: [kubectl, Helm, AKS, Kustomize, OPA Gatekeeper]
---
```

## Production Kubernetes Manifest — Secure Defaults

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: payment-service
  namespace: payments
  labels:
    app: payment-service
    version: "1.0.0"
    environment: production
    data-classification: pci-scope
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  selector:
    matchLabels:
      app: payment-service
  template:
    metadata:
      labels:
        app: payment-service
        version: "1.0.0"
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8080"
        prometheus.io/path: "/actuator/prometheus"
    spec:
      serviceAccountName: payment-service-sa
      automountServiceAccountToken: false
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
        fsGroup: 2000
        seccompProfile:
          type: RuntimeDefault
      containers:
        - name: payment-service
          image: myacr.azurecr.io/payment-service:SHA_PINNED
          ports:
            - containerPort: 8080
              name: http
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: true
            capabilities:
              drop: ["ALL"]
          resources:
            requests:
              memory: "512Mi"
              cpu: "250m"
            limits:
              memory: "1Gi"
              cpu: "500m"
          livenessProbe:
            httpGet:
              path: /actuator/health/liveness
              port: 8080
            initialDelaySeconds: 30
            periodSeconds: 10
            failureThreshold: 3
          readinessProbe:
            httpGet:
              path: /actuator/health/readiness
              port: 8080
            initialDelaySeconds: 15
            periodSeconds: 5
          env:
            - name: SPRING_PROFILES_ACTIVE
              value: "production"
          envFrom:
            - secretRef:
                name: payment-service-secrets
          volumeMounts:
            - name: tmp
              mountPath: /tmp
            - name: secrets-store
              mountPath: /mnt/secrets
              readOnly: true
      volumes:
        - name: tmp
          emptyDir: {}
        - name: secrets-store
          csi:
            driver: secrets-store.csi.k8s.io
            readOnly: true
            volumeAttributes:
              secretProviderClass: payment-service-kv
      topologySpreadConstraints:
        - maxSkew: 1
          topologyKey: kubernetes.io/hostname
          whenUnsatisfiable: DoNotSchedule
          labelSelector:
            matchLabels:
              app: payment-service
---
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: payment-service-pdb
  namespace: payments
spec:
  minAvailable: 2
  selector:
    matchLabels:
      app: payment-service
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: payment-service-hpa
  namespace: payments
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: payment-service
  minReplicas: 3
  maxReplicas: 20
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80
```

---

# SKL-004 — Terraform Infrastructure as Code

```yaml
---
skill_id: SKL-004
name: Terraform IaC
version: 1.2.0
category: engineering
domain: azure
maturity: proficient
owner: devsecops-analyst
tags: [terraform, iac, azure, infra]
compliance: [SOC2, PCI-DSS]
tools: [Terraform, AzureRM, Terragrunt, Checkov]
---
```

## Standard AKS Cluster — Terraform

```hcl
terraform {
  required_version = ">= 1.6.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90"
    }
  }
  backend "azurerm" {
    resource_group_name  = "tfstate-rg"
    storage_account_name = "tfstatestorage"
    container_name       = "tfstate"
    key                  = "aks/terraform.tfstate"
  }
}

resource "azurerm_kubernetes_cluster" "main" {
  name                = "${var.cluster_name}-${var.environment}"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  dns_prefix          = "${var.cluster_name}-${var.environment}"

  default_node_pool {
    name                        = "system"
    vm_size                     = "Standard_D4s_v5"
    node_count                  = 3
    zones                       = [1, 2, 3]
    enable_auto_scaling         = true
    min_count                   = 3
    max_count                   = 10
    os_disk_type                = "Ephemeral"
    only_critical_addons_enabled = true
  }

  identity {
    type = "SystemAssigned"
  }

  network_profile {
    network_plugin    = "azure"
    network_policy    = "calico"
    load_balancer_sku = "standard"
    outbound_type     = "userAssignedNATGateway"
  }

  azure_active_directory_role_based_access_control {
    managed            = true
    azure_rbac_enabled = true
  }

  oms_agent {
    log_analytics_workspace_id = azurerm_log_analytics_workspace.main.id
  }

  microsoft_defender {
    log_analytics_workspace_id = azurerm_log_analytics_workspace.main.id
  }

  key_vault_secrets_provider {
    secret_rotation_enabled = true
  }

  tags = local.required_tags
}
```

---

# SKL-005 — Incident Management

```yaml
---
skill_id: SKL-005
name: Incident Management
version: 1.0.0
category: operations
domain: financial-services
maturity: proficient
owner: support-analyst
tags: [incident, itil, sev1, sev2, rca, oncall]
compliance: [SOC2, PCI-DSS, ITIL]
tools: [ServiceNow, PagerDuty, Microsoft Teams, Azure Monitor]
---
```

## Severity Classification

| Severity | Definition | Response Time | Update Cadence |
|----------|-----------|---------------|----------------|
| SEV1 | Complete service outage or data breach | 5 min page | Every 30 min |
| SEV2 | Partial outage or significant degradation | 15 min page | Every 60 min |
| SEV3 | Minor degradation, workaround available | Next business day | Daily |
| SEV4 | Minimal impact, cosmetic | Best effort | Weekly |

## SEV1 Response Timeline
```
T+0:00  Detection (alert fires or customer reports)
T+0:05  L1 declares SEV1, creates incident ticket
T+0:10  Incident Commander (IC) assigned and on bridge
T+0:15  First stakeholder notification sent
T+0:30  Technical leads engaged, hypothesis list formed
T+1:00  First customer-facing status update
T+1:00  Executive notification if > 1 hour unresolved
T+2:00  Escalate to VP if no resolution path identified
RESOLVED Post-incident review scheduled (within 24h)
```

## RCA Template
```markdown
# Root Cause Analysis Report

**Incident ID**: [INC-XXXXX]
**Severity**: SEV1/SEV2
**Date of Incident**: YYYY-MM-DD
**Date of RCA**: YYYY-MM-DD
**RCA Author**: [Name, Role]
**Reviewed By**: [Engineering Manager, Architect]

## Executive Summary
[2-3 sentences: what failed, impact, root cause, key action]

## Impact
- Duration: X hours Y minutes
- Customers Affected: [count or %]
- Transactions Impacted: [count]
- SLA Breach: Yes/No
- Regulatory Reporting Required: Yes/No

## Timeline
| Time (UTC) | Event |
|------------|-------|
| HH:MM | [Event] |

## Root Cause
[Clear, factual statement of root cause]

## 5-Why Analysis
1. Why did the service fail? → [Answer]
2. Why did [answer 1] happen? → [Answer]
3. Why did [answer 2] happen? → [Answer]
4. Why did [answer 3] happen? → [Answer]
5. Why did [answer 4] happen? → [Root cause]

## Contributing Factors
- [Factor 1]
- [Factor 2]

## Why Did Controls Fail?
[Explain what monitoring/alerting/process should have caught this]

## Action Items
| Action | Owner | Due Date | Priority |
|--------|-------|----------|----------|
| [Immediate fix] | [Name] | [Date] | P1 |
| [Short-term fix] | [Name] | [Date] | P2 |
| [Long-term fix] | [Name] | [Date] | P3 |
```

---

# SKL-006 — Security Hardening

```yaml
---
skill_id: SKL-006
name: Security Hardening
version: 1.1.0
category: security
domain: financial-services
maturity: advanced
owner: devsecops-analyst
tags: [security, hardening, owasp, pci-dss, soc2, zero-trust]
compliance: [SOC2, PCI-DSS, NIST]
tools: [Microsoft Defender, Trivy, CodeQL, Snyk, Azure Policy]
---
```

## Security Hardening Checklist

### Application Layer
- [ ] Input validation on all external inputs
- [ ] Parameterized queries (no string concatenation SQL)
- [ ] Output encoding (prevent XSS)
- [ ] Authentication: OAuth2/OIDC, no custom auth
- [ ] Authorization: RBAC, principle of least privilege
- [ ] Secrets: Azure Key Vault only, no env vars for secrets
- [ ] Logging: no PII, PAN, credentials in logs
- [ ] Dependencies: Dependabot enabled, CRITICAL CVEs blocked

### Infrastructure Layer
- [ ] Private endpoints on all Azure PaaS services
- [ ] No public IP on AKS nodes
- [ ] Network policies (default deny)
- [ ] Encryption at rest (CMK for PCI-DSS scope)
- [ ] Encryption in transit (TLS 1.2+)
- [ ] Azure DDoS Protection Standard
- [ ] Microsoft Defender for Cloud enabled

### Container Layer
- [ ] Non-root user
- [ ] Read-only root filesystem
- [ ] No privileged containers
- [ ] Drop all Linux capabilities
- [ ] Distroless or minimal base image
- [ ] Image signing (Cosign)
- [ ] Image scan (Trivy) — no CRITICAL/HIGH CVEs

---

# SKL-007 — Observability Engineering

```yaml
---
skill_id: SKL-007
name: Observability Engineering
version: 1.0.0
category: operations
domain: azure
maturity: developing
owner: senior-developer
tags: [observability, logging, metrics, tracing, sli, slo]
compliance: [SOC2]
tools: [OpenTelemetry, Azure Monitor, Application Insights, Grafana, Prometheus]
---
```

## Three Pillars of Observability

### 1. Logging (Structured)
```java
// Spring Boot + SLF4J + structured logging
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.logstash.logback.marker.Markers;

@Service
public class PaymentService {
    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    public Payment processPayment(PaymentRequest request) {
        log.info(Markers.append("payment_id", request.getId())
                       .and(Markers.append("merchant_id", request.getMerchantId()))
                       .and(Markers.append("amount_cents", request.getAmount())),
            "Processing payment");
        // NEVER log: PAN, CVV, full account numbers
    }
}
```

### 2. Metrics (SLI/SLO)
```yaml
# SLO Definitions
slos:
  payment_availability:
    target: 99.95%
    measurement_window: 30d
    
  payment_latency_p99:
    target: 500ms
    measurement_window: 7d
    
  payment_error_rate:
    target: 0.1%
    measurement_window: 1d
```

### 3. Tracing (OpenTelemetry)
```yaml
# application.yaml
management:
  tracing:
    sampling:
      probability: 0.1  # 10% sampling in prod
  otlp:
    tracing:
      endpoint: ${OTEL_EXPORTER_OTLP_ENDPOINT}
```

---

# Skills Maturity Model

| Level | Name | Description |
|-------|------|-------------|
| 1 | Foundational | Basic awareness; follows templates with guidance |
| 2 | Developing | Can apply independently on standard tasks |
| 3 | Proficient | Adapts to complex situations; mentors others |
| 4 | Advanced | Creates new patterns; improves standards |
| 5 | Expert | Industry-level expertise; defines strategy |

## Skill Dependency Map

```
SKL-001 (API Design)
    └── SKL-002 (CI/CD) ── SKL-003 (Kubernetes)
                              └── SKL-004 (Terraform)
                                     └── SKL-006 (Security Hardening)
                                            └── SKL-007 (Observability)
                                                   └── SKL-005 (Incident Mgmt)
```
