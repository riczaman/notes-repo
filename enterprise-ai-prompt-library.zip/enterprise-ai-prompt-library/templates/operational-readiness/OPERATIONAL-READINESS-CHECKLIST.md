# RFC — Request for Comments
<!-- Template Version: 1.1.0 | Owner: Architecture Practice -->

---

**RFC Header**

| Field | Value |
|-------|-------|
| RFC ID | RFC-[YYYY]-[NNN] |
| Title | [Descriptive title of the proposal] |
| Status | DRAFT / REVIEW / ACCEPTED / REJECTED / WITHDRAWN |
| Author(s) | [Names] |
| Reviewers | [Names — assigned by Architecture Guild] |
| Created | YYYY-MM-DD |
| Last Updated | YYYY-MM-DD |
| Review Deadline | YYYY-MM-DD |
| Decision Date | YYYY-MM-DD |
| Implemented In | [ADR-XXX / Version / Release] |

---

## Summary

> *1–3 sentences. What are you proposing and why? Should be understandable by someone who won't read the full document.*

---

## Motivation

### Problem Statement

[What problem are we solving? Why does it need solving now? What's the cost of the status quo?]

### Evidence

- [Data point 1 — e.g., latency metrics, error rates, developer survey results]
- [Data point 2]
- [Customer/stakeholder feedback]

### Goals

- [ ] [Goal 1 — specific and measurable]
- [ ] [Goal 2]
- [ ] [Goal 3]

### Non-Goals

- [Explicitly out of scope — prevents scope creep in discussion]
- [What this RFC is NOT trying to solve]

---

## Detailed Design

### Proposed Solution

[Detailed description of the proposed solution. Use diagrams (Mermaid), code examples, and tables as needed.]

```mermaid
flowchart LR
    A[Current State] --> B[Proposed Change]
    B --> C[Expected Outcome]
```

### API / Interface Changes

[If applicable — show before/after for any API, interface, or contract changes]

**Before:**
```yaml
# Current API
...
```

**After:**
```yaml
# Proposed API
...
```

### Implementation Plan

| Phase | Description | Effort | Timeline |
|-------|-------------|--------|----------|
| Phase 1 | [Description] | [S/M/L] | [Date] |
| Phase 2 | [Description] | [S/M/L] | [Date] |

### Migration Strategy

[How will existing users/systems migrate? Is there a compatibility period?]

---

## Alternatives Considered

### Alternative 1: [Name]

**Description**: [What this alternative does]

**Pros**:
- [Pro 1]
- [Pro 2]

**Cons**:
- [Con 1 — why we rejected this]

### Alternative 2: [Name]

**Description**: [What this alternative does]

**Pros / Cons**: [Brief analysis]

### Why We Chose the Proposed Solution

[Explicit comparison and rationale for the chosen approach over alternatives]

---

## Drawbacks

> *Every proposal has trade-offs. Honest acknowledgment builds trust.*

- [Drawback 1]
- [Drawback 2]
- [Complexity introduced]
- [Risk introduced]

---

## Security & Compliance Considerations

| Consideration | Analysis | Mitigation |
|--------------|---------|-----------|
| Data exposure | [Analysis] | [Mitigation] |
| Authentication changes | [Analysis] | [Mitigation] |
| PCI-DSS impact | [Analysis] | [Mitigation] |
| SOC2 control changes | [Analysis] | [Mitigation] |

---

## Operational Considerations

| Area | Impact | Required Actions |
|------|--------|-----------------|
| Deployment | [Impact] | [Actions] |
| Monitoring | [New metrics/alerts needed] | [Actions] |
| Runbook updates | [Required] | [Who/When] |
| On-call training | [Required] | [Who/When] |

---

## Open Questions

| # | Question | Owner | Resolution |
|---|---------|-------|-----------|
| 1 | [Question] | [Name] | [Answer or TBD] |

---

## Review Comments

> *Reviewers: Add your name, date, and feedback below.*

| Reviewer | Date | Status | Comments |
|----------|------|--------|----------|
| [Name] | YYYY-MM-DD | Approved / Approved with Conditions / Rejected | [Comments] |

---

## Decision

**Decision**: [Accepted / Rejected / Accepted with Modifications]
**Date**: YYYY-MM-DD
**Decided By**: Architecture Review Board
**Conditions** (if any):
- [Condition 1]

**Resulting ADR**: [ADR-XXX]

---

# 📋 Operational Readiness Checklist

**Purpose**: Gate for all production deployments of new services or major changes.
**Owner**: Engineering Manager
**Required for**: All Tier 1 and Tier 2 services; recommended for Tier 3.

---

## Service Information

| Field | Value |
|-------|-------|
| Service Name | |
| Version | |
| Release Date | |
| Team | |
| Engineering Manager | |
| Architect | |
| Tier | 1 / 2 / 3 |

---

## Section 1: Architecture & Design ✅

- [ ] **ARB-01** Architecture Review Board approved HLD
- [ ] **ARB-02** All Architecture Decision Records (ADRs) approved
- [ ] **ARB-03** API contracts reviewed and versioned (OpenAPI 3.1)
- [ ] **ARB-04** Data model reviewed by Data Architecture
- [ ] **ARB-05** Integration patterns reviewed and approved
- [ ] **ARB-06** No single points of failure in critical path
- [ ] **ARB-07** Disaster recovery design documented and tested

---

## Section 2: Security 🔒

- [ ] **SEC-01** Security Architecture Review completed by InfoSec
- [ ] **SEC-02** Threat model (STRIDE) completed and signed off
- [ ] **SEC-03** SAST (CodeQL) — 0 Critical, 0 High findings unmitigated
- [ ] **SEC-04** SCA (Dependency Check) — 0 Critical CVEs unmitigated
- [ ] **SEC-05** Container scan (Trivy) — 0 Critical/High CVEs
- [ ] **SEC-06** DAST (OWASP ZAP) scan completed — 0 High findings
- [ ] **SEC-07** Penetration test scheduled (Tier 1: required before go-live)
- [ ] **SEC-08** Secrets management — no hardcoded credentials (Gitleaks passed)
- [ ] **SEC-09** Authentication implemented (OAuth2/OIDC via Azure AD)
- [ ] **SEC-10** Authorization implemented (RBAC, least privilege)
- [ ] **SEC-11** PCI-DSS scope assessed and documented
- [ ] **SEC-12** No PII or PAN in logs (verified by log review)
- [ ] **SEC-13** Encryption at rest (CMK for PCI scope)
- [ ] **SEC-14** Encryption in transit (TLS 1.2+ enforced)

---

## Section 3: Quality Engineering 🧪

- [ ] **QE-01** Test Strategy documented and approved by QE Lead
- [ ] **QE-02** Unit test coverage ≥ 80% (JaCoCo report attached)
- [ ] **QE-03** Integration tests passing in CI/CD
- [ ] **QE-04** Contract tests (Pact) passing for all API consumers
- [ ] **QE-05** Performance test results meet SLA thresholds (k6 report attached)
- [ ] **QE-06** Security test cases executed (OWASP test cases)
- [ ] **QE-07** Regression suite passing
- [ ] **QE-08** UAT sign-off obtained from Business Sponsor
- [ ] **QE-09** Accessibility testing completed (WCAG 2.1 AA) [if UI]
- [ ] **QE-10** Test data management — no real PII in test environments

---

## Section 4: Observability 📊

- [ ] **OBS-01** Structured logging implemented (JSON, SLF4J)
- [ ] **OBS-02** OpenTelemetry tracing instrumented
- [ ] **OBS-03** Prometheus metrics exposed (/actuator/prometheus)
- [ ] **OBS-04** Azure Monitor dashboards created and reviewed
- [ ] **OBS-05** Grafana dashboard created and published
- [ ] **OBS-06** Alerts configured in Azure Monitor (latency, errors, availability)
- [ ] **OBS-07** Alerts tested — confirmed they fire and route to PagerDuty
- [ ] **OBS-08** SLO dashboards published (availability, latency, error rate)
- [ ] **OBS-09** Log retention policy configured (90 days hot, 2 years archive)
- [ ] **OBS-10** Correlation IDs propagated across all service calls

---

## Section 5: Infrastructure & Deployment 🚀

- [ ] **INF-01** Terraform IaC reviewed and approved (Checkov, tfsec)
- [ ] **INF-02** Kubernetes manifests reviewed (Pod Security Standards: Restricted)
- [ ] **INF-03** Resource requests and limits set (no unbounded containers)
- [ ] **INF-04** Horizontal Pod Autoscaler configured
- [ ] **INF-05** Pod Disruption Budget configured (minAvailable ≥ 2 for Tier 1)
- [ ] **INF-06** Liveness and readiness probes tested
- [ ] **INF-07** Network Policies applied (default deny)
- [ ] **INF-08** Deployment strategy configured (blue-green or canary for Tier 1)
- [ ] **INF-09** Rollback procedure tested in staging
- [ ] **INF-10** Azure Key Vault CSI driver configured (no K8s secrets for sensitive data)
- [ ] **INF-11** Container image signed (Cosign/Notation)
- [ ] **INF-12** SBOM generated and attested

---

## Section 6: CI/CD Pipeline 🔄

- [ ] **PIPE-01** Full CI/CD pipeline operational (build → test → scan → deploy)
- [ ] **PIPE-02** All pipeline action versions pinned (SHA or version tag)
- [ ] **PIPE-03** Security gates passing (SAST, SCA, container scan, secret scan)
- [ ] **PIPE-04** No static credentials in pipeline (OIDC used for Azure auth)
- [ ] **PIPE-05** Production deployment requires manual approval
- [ ] **PIPE-06** Canary deployment configured and tested
- [ ] **PIPE-07** Auto-rollback on health check failure configured
- [ ] **PIPE-08** Change record (ServiceNow) integrated with deployment gate

---

## Section 7: Operations & Support 📞

- [ ] **OPS-01** Operational Runbook authored and reviewed
- [ ] **OPS-02** Runbook tested in a game day exercise
- [ ] **OPS-03** On-call rotation configured in PagerDuty
- [ ] **OPS-04** On-call team trained on runbook
- [ ] **OPS-05** Escalation path documented (L1 → L2 → L3 → EM → AVP)
- [ ] **OPS-06** Incident response procedure documented
- [ ] **OPS-07** Support team briefed on new service
- [ ] **OPS-08** Known issues / FAQ documented for L1 support
- [ ] **OPS-09** ServiceNow CMDB record created
- [ ] **OPS-10** Dependency map updated (what does this service depend on/affect?)
- [ ] **OPS-11** Capacity plan reviewed (normal + peak load)
- [ ] **OPS-12** Disaster recovery tested (RTO/RPO validation)

---

## Section 8: Compliance & Governance 📜

- [ ] **COM-01** Compliance review completed (SOC2 / PCI-DSS as applicable)
- [ ] **COM-02** Data classification documented for all data handled
- [ ] **COM-03** Data retention policy implemented
- [ ] **COM-04** Privacy impact assessment completed (if PII involved)
- [ ] **COM-05** GDPR/PIPEDA compliance reviewed (if personal data)
- [ ] **COM-06** Change Advisory Board (CAB) approval obtained
- [ ] **COM-07** Audit trail logging validated (SOC2 CC7.2)
- [ ] **COM-08** Access review completed — minimum necessary access granted

---

## Section 9: Documentation 📚

- [ ] **DOC-01** API documentation published (developer portal)
- [ ] **DOC-02** High-Level Design (HLD) finalized and stored
- [ ] **DOC-03** Low-Level Design (LLD) finalized and stored
- [ ] **DOC-04** README.md complete in service repository
- [ ] **DOC-05** Architecture Decision Records (ADRs) committed to repo
- [ ] **DOC-06** Deployment guide documented
- [ ] **DOC-07** Configuration reference documented
- [ ] **DOC-08** Troubleshooting guide in runbook

---

## Sign-Off

| Role | Name | Decision | Date | Notes |
|------|------|----------|------|-------|
| Engineering Manager | | ✅ / ❌ | | |
| QE Lead | | ✅ / ❌ | | |
| Security (InfoSec) | | ✅ / ❌ | | |
| Solution Architect | | ✅ / ❌ | | |
| Operations / SRE | | ✅ / ❌ | | |
| Compliance | | ✅ / ❌ | | |
| **Business Sponsor** | | ✅ Go-Live / ❌ Hold | | |

---

**Overall Readiness**: ☐ READY FOR PRODUCTION &nbsp;&nbsp; ☐ CONDITIONAL (conditions listed below) &nbsp;&nbsp; ☐ NOT READY

**Conditions / Outstanding Items**:
1. 
2. 

*Checklist Version: 2.1 | Mandatory for all Tier 1/2 services | Stored in ServiceNow + GitHub*
