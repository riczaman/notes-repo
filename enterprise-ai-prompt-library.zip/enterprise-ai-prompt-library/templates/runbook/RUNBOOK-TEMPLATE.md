# Operational Runbook — [Service Name]
<!-- 
Template Version: 1.2.0
Owner: [Team Name]
Classification: INTERNAL
Last Tested: YYYY-MM-DD
Next Review: YYYY-MM-DD
-->

---

## Runbook Header

| Field | Value |
|-------|-------|
| Runbook ID | RB-[SERVICE]-[NNN] |
| Service | [Service Name] |
| Version | 1.0 |
| Owner | [Team Name] |
| On-Call Contact | [PagerDuty rotation name] |
| Last Updated | YYYY-MM-DD |
| Last Tested | YYYY-MM-DD |
| Criticality | Tier 1 / Tier 2 / Tier 3 |
| Azure Dashboard | [Link to Azure Monitor Dashboard] |
| Grafana Dashboard | [Link] |
| Source Code | [GitHub Repo Link] |
| ServiceNow CI | [CMDB Item Link] |

---

## 1. Service Overview

### Purpose
[1–2 sentences describing what this service does and its business importance.]

### Architecture Quick Reference
```
Internet → Azure APIM → [Service Name] → Azure SQL
                             ↑
                     Azure Key Vault (secrets)
                     Azure Service Bus (events)
                     Azure Cache for Redis (cache)
```

### Service Tier & SLAs

| Metric | SLA Target | Alert Threshold |
|--------|-----------|----------------|
| Availability | 99.9% | < 99.5% → PagerDuty |
| Latency p99 | < 500ms | > 800ms → PagerDuty |
| Error Rate | < 1% | > 2% → PagerDuty |
| Throughput | 200 TPS normal | < 50 TPS → investigate |

---

## 2. Environments

| Environment | Namespace | Azure Subscription | URL |
|-------------|-----------|-------------------|-----|
| Production | `[service]-prod` | prod-subscription | https://api.org.com/v1 |
| Staging | `[service]-staging` | nonprod-subscription | https://api-staging.org.com/v1 |
| Dev | `[service]-dev` | nonprod-subscription | https://api-dev.org.com/v1 |

---

## 3. Access Requirements

> ⚠️ All production access requires MFA and is logged for SOC2 audit.

| Access Type | How to Obtain | Justification Required |
|-------------|--------------|------------------------|
| Azure Portal (read) | Azure AD role: Reader | No |
| Kubernetes (read) | `az aks get-credentials --name prod-aks` | Yes — ticket required |
| Production DB (read) | Break-glass procedure (Section 9) | Yes — manager approval |
| Key Vault | Managed Identity only — no human access to secrets | N/A |

---

## 4. Standard Operations

### 4.1 Health Check

```bash
# Check pod status
kubectl get pods -n [service]-prod -l app=[service-name]

# Expected output: all pods Running, 2/2 READY (or 1/1)
# If pods are CrashLoopBackOff or Pending → Section 5.1

# Check application health endpoint
curl -sf https://api.org.com/actuator/health | jq .

# Expected: {"status": "UP", "components": {...}}

# Check recent error rate (Azure Monitor KQL)
# Run in Log Analytics:
# requests
# | where timestamp > ago(15m)
# | summarize error_rate = countif(resultCode >= 500) / count() * 100
# | where error_rate > 1
```

### 4.2 View Logs

```bash
# Tail live logs for a pod
kubectl logs -f -n [service]-prod \
  -l app=[service-name] \
  --all-containers \
  --prefix

# Search logs for errors (last 100 lines)
kubectl logs -n [service]-prod \
  -l app=[service-name] \
  --tail=100 | grep -i "error\|exception\|fatal"

# Azure Monitor — structured log query
# Log Analytics KQL:
# AppTraces
# | where AppRoleName == "[service-name]"
# | where TimeGenerated > ago(1h)
# | where SeverityLevel >= 3
# | project TimeGenerated, Message, Properties
# | order by TimeGenerated desc
# | take 100
```

### 4.3 Restart a Pod

```bash
# Rolling restart (zero-downtime)
kubectl rollout restart deployment/[service-name] -n [service]-prod

# Monitor the rollout
kubectl rollout status deployment/[service-name] -n [service]-prod --timeout=5m

# If rollout stuck > 3 minutes → Section 5.2
```

### 4.4 Scale the Service

```bash
# Scale up manually (e.g., during incident or peak event)
kubectl scale deployment/[service-name] \
  -n [service]-prod \
  --replicas=10

# View current HPA status
kubectl get hpa [service-name]-hpa -n [service]-prod

# HPA will auto-scale based on CPU/memory; manual scale overrides temporarily
# HPA will reassert control within ~5 minutes
```

### 4.5 Check Database Connectivity

```bash
# From a debug pod in the same namespace
kubectl run db-debug \
  --image=mcr.microsoft.com/azure-sql-edge \
  -it --rm \
  -n [service]-prod \
  -- /bin/bash

# Inside the pod (connection string from Key Vault — do not hardcode)
# sqlcmd -S $DB_HOST -U $DB_USER -P $DB_PASS -Q "SELECT 1"

# Check connection pool metrics in Grafana: [Dashboard Link]
```

---

## 5. Troubleshooting Guides

### 5.1 Pod Not Starting / CrashLoopBackOff

**Symptoms**: `kubectl get pods` shows CrashLoopBackOff or Error state

```bash
# Step 1: Describe the pod for events
kubectl describe pod [pod-name] -n [service]-prod

# Look for:
# - OOMKilled → increase memory limits (Section 5.3)
# - ImagePullBackOff → check ACR access or image tag
# - Liveness probe failed → check /actuator/health endpoint
# - CreateContainerConfigError → missing secret or configmap

# Step 2: Get the last crash logs
kubectl logs [pod-name] -n [service]-prod --previous

# Step 3: Check events in namespace
kubectl get events -n [service]-prod --sort-by='.lastTimestamp'
```

**Common Causes & Fixes**:

| Error | Cause | Fix |
|-------|-------|-----|
| OOMKilled | Memory limit too low | Increase `resources.limits.memory` in Helm values |
| ImagePullBackOff | Image not found in ACR | Verify image tag exists: `az acr repository show-tags --name [ACR] --repository [service-name]` |
| Liveness probe failed | App not starting within `initialDelaySeconds` | Increase `initialDelaySeconds` or fix app startup issue |
| Secret not found | Key Vault secret missing | Check Key Vault: `az keyvault secret list --vault-name [kv-name]` |
| CrashLoopBackOff | Application exception at startup | Check logs with `--previous` flag |

---

### 5.2 High Latency / Slow Response

**Alert**: p99 latency > 800ms

```bash
# Step 1: Check pod resource utilization
kubectl top pods -n [service]-prod -l app=[service-name]

# High CPU (>80%) → HPA should scale; if not, check HPA events
kubectl describe hpa [service-name]-hpa -n [service]-prod

# Step 2: Check database connection pool (Grafana → DB Dashboard)
# Metric: hikari.connections.active / hikari.connections.max
# If pool exhausted → Step 3

# Step 3: Check for slow queries
# Azure SQL Query Performance Insight: [Portal Link]
# Look for queries > 1000ms

# Step 4: Check Redis cache hit rate
# Grafana → Redis Dashboard → cache_hit_rate metric
# If < 80% → cache may be cold; check TTL config

# Step 5: Check downstream dependency latency
# Application Insights → Dependency calls view
# Filter by timestamp of issue
```

---

### 5.3 High Error Rate / 5xx Responses

**Alert**: Error rate > 2%

```bash
# Step 1: Identify which endpoint is erroring
# KQL in Log Analytics:
# requests
# | where timestamp > ago(30m)
# | where resultCode >= 500
# | summarize count() by name, resultCode
# | order by count_ desc

# Step 2: Get exception details
# exceptions
# | where timestamp > ago(30m)
# | project timestamp, type, outerMessage, details
# | order by timestamp desc

# Step 3: Check if correlated with recent deployment
kubectl rollout history deployment/[service-name] -n [service]-prod

# Step 4: If recent deployment → evaluate rollback (Section 6.1)
```

---

### 5.4 Database Issues

```bash
# Check Azure SQL service health
az sql server show --name [sql-server-name] --resource-group [rg]

# Check DTU/vCore utilization in Azure Portal
# Azure SQL → [Database] → Query Performance Insight

# Check for blocking queries
# Run in Azure SQL:
# SELECT * FROM sys.dm_exec_requests WHERE blocking_session_id != 0

# Emergency: Failover to secondary (only with EM approval)
az sql db failover \
  --name [database-name] \
  --server [server-name] \
  --resource-group [rg]
  # ⚠️ This causes ~20-30 seconds of connectivity interruption
```

---

## 6. Rollback Procedures

### 6.1 Application Rollback (Helm)

```bash
# View Helm release history
helm history [service-name] -n [service]-prod

# Rollback to previous version (revision 0 = previous)
helm rollback [service-name] 0 \
  -n [service]-prod \
  --wait \
  --timeout 5m0s

# Verify rollback successful
kubectl rollout status deployment/[service-name] -n [service]-prod

# Confirm health
curl -sf https://api.org.com/actuator/health | jq .status
```

**Rollback Decision Criteria**:
- Error rate > 5% for > 2 minutes after deployment → automatic rollback
- p99 latency > 2x baseline for > 5 minutes → evaluate rollback
- Any SEV1 alert firing within 15 minutes of deployment → rollback

---

### 6.2 Infrastructure Rollback (Terraform)

```bash
# View Terraform state versions
az storage blob list \
  --container-name tfstate \
  --account-name [storage-account] \
  --query "[].{name:name, lastModified:properties.lastModified}" \
  -o table

# Restore previous state version via Azure Portal or:
# terraform plan -target=[resource] and revert specific resources
# ⚠️ Never run terraform destroy in production without Director approval
```

---

## 7. Scaling Procedures

### 7.1 Pre-Planned Peak Event (e.g., month-end, Black Friday)

```bash
# 1 hour before event: Pre-scale pods
kubectl scale deployment/[service-name] \
  -n [service]-prod \
  --replicas=15

# Temporarily increase HPA max
kubectl patch hpa [service-name]-hpa \
  -n [service]-prod \
  --patch '{"spec":{"maxReplicas":30}}'

# Monitor during event
watch kubectl get pods -n [service]-prod

# Post-event: Return to normal
kubectl patch hpa [service-name]-hpa \
  -n [service]-prod \
  --patch '{"spec":{"maxReplicas":20}}'
# HPA will scale down naturally
```

---

## 8. Maintenance Procedures

### 8.1 Planned Maintenance Window

**Notification Requirements**:
- Internal: 5 business days notice via ServiceNow Change Record
- Customer-facing (if applicable): 48 hours via status page

```bash
# Enable maintenance mode (return 503 from APIM)
az apim api operation update \
  --api-id [api-id] \
  --operation-id [op-id] \
  --resource-group [rg] \
  --service-name [apim-name] \
  --set policies='...'
  # See APIM policy templates in /pipelines/azure-devops/

# Drain pods gracefully
kubectl drain [node-name] \
  --ignore-daemonsets \
  --delete-emptydir-data \
  --grace-period=30

# Restore after maintenance
kubectl uncordon [node-name]
```

---

## 9. Break-Glass Procedures

> ⚠️ Break-glass access is for emergency only. ALL access is logged and reviewed.

### 9.1 Emergency Production Database Access

1. Open ServiceNow ticket with justification
2. Get manager verbal approval (documented in ticket)
3. Request temporary access: `az keyvault secret show --name db-admin-creds --vault-name [kv-break-glass]`
4. Access is time-limited (4 hours) and automatically revoked
5. Post-incident: ticket closed with access review

### 9.2 Emergency Secrets Rotation

```bash
# Rotate a secret immediately (e.g., suspected compromise)
az keyvault secret set \
  --vault-name [kv-name] \
  --name [secret-name] \
  --value "[new-value]"

# Trigger pod restart to pick up new secret (CSI driver auto-refreshes within 2 min)
kubectl rollout restart deployment/[service-name] -n [service]-prod
```

---

## 10. Monitoring & Alerting Reference

| Alert Name | Condition | Severity | Runbook Section |
|------------|-----------|----------|----------------|
| HighErrorRate | error_rate > 2% for 5m | SEV2 | Section 5.3 |
| HighLatency | p99 > 800ms for 5m | SEV2 | Section 5.2 |
| PodCrashLoop | CrashLoopBackOff > 3 times | SEV2 | Section 5.1 |
| DatabaseDown | DB connectivity failed | SEV1 | Section 5.4 |
| ServiceDown | All pods unhealthy | SEV1 | Section 5.1 + 6.1 |
| SecurityAlert | Microsoft Defender alert | SEV1 | Security Runbook |

---

## 11. Contacts & Escalation

| Level | Contact | When |
|-------|---------|------|
| L1 Support | PagerDuty: [rotation-name] | First contact |
| L2 Engineering | [Team Slack channel] | Not resolving within 30 min |
| Engineering Manager | [Name] — [Phone] | SEV1 or SLA breach |
| Architect | [Name] — [Phone] | Architectural decision needed |
| AVP Technology | [Name] — [Phone] | SEV1 > 60 min unresolved |
| Azure Support | Priority: Unified Support — Case via Azure Portal | Azure platform issues |

---

*Runbook Owner: [Team Name]*
*Review Cadence: Quarterly or after every SEV1*
*Tested: YYYY-MM-DD (Game Day exercise)*
