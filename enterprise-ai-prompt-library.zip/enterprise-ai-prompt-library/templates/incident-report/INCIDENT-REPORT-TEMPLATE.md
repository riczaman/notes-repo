# 🚨 Incident Report & Post-Incident Review Template
<!-- Template Version: 1.5.0 | Owner: Site Reliability Engineering | ITIL Aligned -->

---

## PART A — INCIDENT RECORD

**Incident Header**

| Field | Value |
|-------|-------|
| Incident ID | INC-[YYYY]-[NNNN] |
| Severity | SEV1 / SEV2 / SEV3 |
| Title | [Short description of incident] |
| Service Affected | [Service name] |
| Declared By | [Name, Role] |
| Detection Source | Azure Monitor Alert / PagerDuty / Customer Report / Manual |
| Declaration Time | YYYY-MM-DD HH:MM UTC |
| Resolution Time | YYYY-MM-DD HH:MM UTC |
| Total Duration | [X hours Y minutes] |
| Customer-Facing? | Yes / No |
| SLA Breach? | Yes / No |
| Regulatory Reporting Required? | Yes / No — [Regulation / Deadline] |

---

## PART B — INCIDENT TIMELINE

> Record all significant events, actions, and decisions with UTC timestamps.

| Time (UTC) | Actor | Event / Action | Evidence |
|------------|-------|----------------|----------|
| HH:MM | Monitoring | Azure Monitor alert fired — [Alert Name] | Alert ID: |
| HH:MM | [L1 Analyst] | Incident declared SEV[X], bridge created | INC-YYYY-NNNN created |
| HH:MM | [IC] | Incident Commander assumed bridge | Bridge: [Teams/Zoom link] |
| HH:MM | [Engineer] | [Action taken] | [Evidence/ticket] |
| HH:MM | [IC] | First stakeholder notification sent | [Notification ID] |
| HH:MM | [Engineer] | [Root cause hypothesis confirmed] | [Log evidence] |
| HH:MM | [Engineer] | [Fix applied — describe] | PR/Change: |
| HH:MM | [IC] | Service restored, monitoring period started | |
| HH:MM | [IC] | Incident declared resolved | |
| HH:MM | [IC] | All-clear notification sent | |

---

## PART C — IMPACT ASSESSMENT

### Customer Impact

| Dimension | Value |
|-----------|-------|
| Customers Affected | [Count / Percentage] |
| Geographic Scope | [Region/Global] |
| Transactions Impacted | [Count / Value] |
| Revenue at Risk | $[Amount] |
| Customer Complaints Received | [Count] |
| NPS / CSAT Impact | [If measurable] |

### Technical Impact

| Service | Impact Type | Duration |
|---------|-------------|----------|
| [Service A] | Full outage / Degraded / Intermittent | HH:MM |
| [Service B] | Dependency failure | HH:MM |

### SLA Impact

| SLA | Threshold | Actual | Status |
|----|-----------|--------|--------|
| Availability | 99.9% | [Actual %] | Breached / Met |
| Latency p99 | 500ms | [Actual ms] | Breached / Met |
| Error Rate | < 1% | [Actual %] | Breached / Met |

---

## PART D — ROOT CAUSE ANALYSIS

### D.1 Root Cause Statement

> *State the root cause in 1–2 clear, non-blaming sentences. This is what we will fix.*

[ROOT CAUSE STATEMENT]

### D.2 5-Why Analysis

| Why # | Question | Answer |
|-------|----------|--------|
| Why 1 | Why did the service fail? | [Answer] |
| Why 2 | Why did [Answer 1] occur? | [Answer] |
| Why 3 | Why did [Answer 2] occur? | [Answer] |
| Why 4 | Why did [Answer 3] occur? | [Answer] |
| Why 5 | Why did [Answer 4] occur? | **Root Cause** |

### D.3 Fishbone (Ishikawa) Analysis

```
                    INCIDENT: [Title]
                          |
    ┌─────────────────────┼─────────────────────┐
    │                     │                     │
  CODE                INFRA                PROCESS
    │                     │                     │
 [Issue A]           [Issue B]            [Issue C]
    │                     │                     │
    └─────────────────────┴─────────────────────┘
    │                     │                     │
  DATA               CONFIG               PEOPLE
    │                     │                     │
 [Issue D]           [Issue E]            [Issue F]
```

### D.4 Contributing Factors

| Factor | Category | Contribution to Incident |
|--------|----------|--------------------------|
| [Factor 1] | Code / Infra / Process / People | [How it contributed] |
| [Factor 2] | Code / Infra / Process / People | [How it contributed] |

### D.5 Why Did Controls Fail?

| Control | Expected Behavior | Actual Behavior | Gap |
|---------|-------------------|-----------------|-----|
| [Alert X] | Should have fired at threshold Y | Did not fire | Threshold too high |
| [Runbook Z] | Should guide resolution | Incomplete | Gap in procedure |
| [Test type] | Should have caught defect | Did not | Missing test scenario |

---

## PART E — ACTION ITEMS

> Every action item must have a single owner, a due date, and a tracking reference.

### Immediate Actions (Completed During Incident)

| # | Action | Owner | Completed |
|---|--------|-------|-----------|
| I-01 | [Action taken to restore service] | [Name] | YYYY-MM-DD HH:MM |

### Short-Term Actions (< 2 Weeks)

| # | Action | Owner | Due Date | Ticket | Priority |
|---|--------|-------|----------|--------|----------|
| S-01 | [Fix the root cause defect] | [Engineer] | YYYY-MM-DD | JIRA-XXXX | P1 |
| S-02 | [Improve the alerting threshold] | [SRE] | YYYY-MM-DD | JIRA-XXXX | P1 |
| S-03 | [Update runbook with gap identified] | [Support] | YYYY-MM-DD | JIRA-XXXX | P2 |

### Long-Term Actions (> 2 Weeks)

| # | Action | Owner | Due Date | Ticket | Priority |
|---|--------|-------|----------|--------|----------|
| L-01 | [Architectural improvement] | [Architect] | YYYY-MM-DD | JIRA-XXXX | P2 |
| L-02 | [Process change] | [EM] | YYYY-MM-DD | JIRA-XXXX | P3 |

---

## PART F — LESSONS LEARNED

### What Went Well

- [Positive 1 — e.g., detection was fast because of alert X]
- [Positive 2 — e.g., team communication was effective on the bridge]
- [Positive 3 — e.g., rollback procedure worked as designed]

### What Could Be Improved

- [Improvement 1 — e.g., runbook was missing a critical step]
- [Improvement 2 — e.g., escalation took too long]
- [Improvement 3 — e.g., monitoring gap allowed issue to exist undetected]

### Systemic Observations

[Any patterns across multiple incidents? Is this a symptom of a larger systemic issue?]

---

## PART G — STAKEHOLDER COMMUNICATIONS LOG

| Time (UTC) | Channel | Audience | Message Summary | Sent By |
|------------|---------|---------|-----------------|---------|
| HH:MM | Status Page | Public | Investigating issue | IC |
| HH:MM | Teams | Internal | [Update] | IC |
| HH:MM | Email | Executives | [Executive briefing] | [AVP] |
| HH:MM | Status Page | Public | Resolved | IC |

---

## PART H — SIGN-OFF

| Role | Name | Date | Notes |
|------|------|------|-------|
| Incident Commander | | | |
| Engineering Manager | | | |
| Service Owner | | | |
| Security (if applicable) | | | |
| Compliance (if regulatory impact) | | | |

---

## PART I — REGULATORY REPORTING (if applicable)

| Regulation | Reporting Requirement | Deadline | Reported By | Submission Ref |
|------------|----------------------|----------|-------------|----------------|
| PIPEDA | Breach of security safeguards report | 72 hours from confirmation | Privacy Officer | |
| PCI-DSS | Report to card brands and acquiring bank | As per PFI protocol | CISO | |

---

*Classification: INTERNAL — CONFIDENTIAL*
*Retention: 7 years (regulatory requirement)*
*Related Problem Record: PRB-[YYYY]-[NNNN]*
