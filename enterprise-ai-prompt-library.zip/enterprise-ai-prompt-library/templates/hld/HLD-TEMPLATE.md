# High-Level Design (HLD)
<!-- Template Version: 2.0.0 | Owner: Architecture Practice -->

**Document Control**

| Field | Value |
|-------|-------|
| Document ID | HLD-[YYYY]-[NNN] |
| System Name | [System Name] |
| Version | 1.0 |
| Status | DRAFT / PEER REVIEW / ARB APPROVED |
| Classification | INTERNAL — CONFIDENTIAL |
| Lead Architect | [Name] |
| Reviewed By | [Architecture Review Board] |
| Date | YYYY-MM-DD |

---

## 1. Executive Summary

[1–2 paragraphs. What is this system, what problem does it solve, and what architectural approach was chosen? Written for a VP or CTO audience. Include the most critical design decision and its rationale.]

---

## 2. Business Context

### 2.1 Business Drivers
[Why is this system being built or changed?]

### 2.2 Business Capabilities Enabled
- [Capability 1]
- [Capability 2]

### 2.3 Key Constraints
- **Timeline**: [Delivery target]
- **Budget**: [$Amount]
- **Regulatory**: [Applicable regulations]

---

## 3. Architecture Principles Applied

| Principle | Application in This Design |
|-----------|---------------------------|
| Security by Design | [How applied] |
| Cloud Native | [How applied] |
| Domain-Driven Design | [How applied] |
| Observability First | [How applied] |
| Compliance by Architecture | [How applied] |

---

## 4. System Context (C4 Level 1)

```mermaid
C4Context
    title System Context — [System Name]

    Person(customer, "Customer", "End user of the platform")
    Person(operator, "Operations Team", "Manages and monitors the system")

    System(targetSystem, "[System Name]", "Description of what the system does")

    System_Ext(extSystem1, "External System 1", "e.g., Payment Network")
    System_Ext(extSystem2, "External System 2", "e.g., Core Banking")
    System_Ext(idp, "Azure AD", "Identity Provider")

    Rel(customer, targetSystem, "Uses", "HTTPS")
    Rel(targetSystem, extSystem1, "Processes payments via", "ISO 8583 / REST")
    Rel(targetSystem, extSystem2, "Retrieves account data from", "REST API")
    Rel(targetSystem, idp, "Authenticates users via", "OIDC")
    Rel(operator, targetSystem, "Monitors and operates", "Azure Portal / Grafana")
```

---

## 5. Container Architecture (C4 Level 2)

```mermaid
C4Container
    title Container Diagram — [System Name]

    Person(user, "User")

    System_Boundary(system, "[System Name]") {
        Container(apiGateway, "API Gateway", "Azure APIM", "Routing, auth, rate limiting")
        Container(serviceA, "Service A", "Java/Spring Boot", "Domain capability A")
        Container(serviceB, "Service B", "Java/Spring Boot", "Domain capability B")
        Container(db, "Database", "Azure SQL", "Transactional data store")
        Container(cache, "Cache", "Azure Cache for Redis", "Session & hot data")
        Container(bus, "Message Bus", "Azure Service Bus", "Async event processing")
    }

    System_Ext(ext, "External System")

    Rel(user, apiGateway, "API calls", "HTTPS/TLS 1.3")
    Rel(apiGateway, serviceA, "Routes to", "HTTP (internal)")
    Rel(apiGateway, serviceB, "Routes to", "HTTP (internal)")
    Rel(serviceA, db, "Reads/Writes", "JDBC over TLS")
    Rel(serviceA, cache, "Caches", "Redis protocol/TLS")
    Rel(serviceA, bus, "Publishes events", "AMQP")
    Rel(serviceB, bus, "Subscribes to events", "AMQP")
    Rel(serviceB, ext, "Integrates with", "REST/HTTPS")
```

---

## 6. Key Architecture Decisions

| Decision | Options Considered | Chosen | Rationale | ADR Ref |
|----------|-------------------|--------|-----------|---------|
| [Decision 1] | Option A, B, C | Option B | [Rationale] | ADR-001 |
| [Decision 2] | Option A, B | Option A | [Rationale] | ADR-002 |

---

## 7. Data Architecture

### 7.1 Data Domain Ownership

| Data Entity | Owning Service | Data Store | Classification |
|-------------|---------------|------------|----------------|
| [Entity 1] | [Service] | [Store type] | PCI / PII / Internal |

### 7.2 Data Flow

```mermaid
flowchart LR
    A[Source System] -->|Event published| B[Azure Service Bus]
    B -->|Consumed by| C[Processing Service]
    C -->|Persists to| D[(Azure SQL)]
    C -->|Caches in| E[(Redis)]
    C -->|Emits event| F[Azure Service Bus]
    F -->|Consumed by| G[Downstream Service]
```

### 7.3 Data Residency & Sovereignty
- **Primary Region**: Canada Central (all PII and PCI-scoped data)
- **DR Region**: Canada East (replica)
- **Cross-border transfers**: None (compliant with PIPEDA)

---

## 8. Security Architecture

### 8.1 Authentication & Authorization

```
User → Azure AD (OIDC) → Access Token → Azure APIM (JWT Validation)
                                              ↓
                                        Microservices (scope-based RBAC)
```

- **Identity Provider**: Azure AD (OIDC / OAuth2)
- **Token Validation**: Azure APIM policy + Spring Security
- **Service-to-Service**: Azure Managed Identity (no credentials)
- **Authorization**: Role-Based Access Control (RBAC) + attribute-based policies

### 8.2 Network Security

```mermaid
flowchart TB
    Internet -->|"TLS 1.3"| WAF[Azure WAF / Front Door]
    WAF -->|"Private Link"| APIM[Azure APIM - Internal]
    APIM -->|"Private Subnet"| Services[AKS - Private Node Pool]
    Services -->|"Private Endpoint"| Data[Azure SQL / Redis / Storage]
    Services -->|"Private Endpoint"| KV[Azure Key Vault]
    Services -->|"Private Endpoint"| ACR[Azure Container Registry]
```

### 8.3 Encryption

| Layer | Encryption | Key Management |
|-------|-----------|----------------|
| Data in transit | TLS 1.2+ (1.3 preferred) | Azure-managed |
| Data at rest | AES-256 | Customer-managed key (CMK) for PCI scope |
| Application secrets | Azure Key Vault | RBAC-controlled |

### 8.4 Compliance Mapping

| Control Area | PCI-DSS Requirement | Implementation |
|-------------|---------------------|----------------|
| Network Segmentation | Req 1 | Azure NSGs + Private Endpoints |
| Access Control | Req 7 & 8 | Azure AD + RBAC + MFA |
| Encryption | Req 3 & 4 | TLS + CMK |
| Logging | Req 10 | Azure Monitor + Log Analytics |
| Vulnerability Mgmt | Req 6 | Trivy + CodeQL + Dependabot |

---

## 9. Infrastructure Architecture

### 9.1 Azure Services

| Service | Purpose | SKU / Config | Region |
|---------|---------|-------------|--------|
| Azure Kubernetes Service | Container orchestration | Standard D4s_v5 nodes | Canada Central |
| Azure SQL | Transactional DB | Business Critical, zone redundant | Canada Central |
| Azure Cache for Redis | Session/hot data cache | Premium P2, zone redundant | Canada Central |
| Azure Service Bus | Async messaging | Premium tier | Canada Central |
| Azure APIM | API Gateway | Premium, zone redundant | Canada Central |
| Azure Key Vault | Secrets management | Premium | Canada Central |
| Azure Container Registry | Container image store | Premium, geo-replicated | Canada Central |
| Azure Monitor | Observability | Log Analytics workspace | Canada Central |

### 9.2 AKS Topology

```
AKS Cluster (Canada Central — 3 Availability Zones)
├── System Node Pool (Standard_D4s_v5 × 3) — critical addons only
├── Payment Node Pool (Standard_D8s_v5 × 3–20) — payment services, autoscaling
└── General Node Pool (Standard_D4s_v5 × 3–10) — other services, autoscaling

Namespaces:
├── payments-prod          — payment processing services (PCI scope)
├── notifications-prod     — notification services
├── shared-prod            — shared utilities
└── monitoring             — observability stack
```

---

## 10. Observability Architecture

### 10.1 Three Pillars

| Pillar | Tool | Destination | Retention |
|--------|------|-------------|-----------|
| Logs | OpenTelemetry → App Insights | Log Analytics | 90 days hot, 2 years archive |
| Metrics | Prometheus → Azure Monitor | Grafana | 13 months |
| Traces | OpenTelemetry → App Insights | Application Insights | 90 days |

### 10.2 SLO Definitions

| SLO | Target | Measurement Window |
|-----|--------|-------------------|
| Payment API availability | 99.95% | 30 days rolling |
| Payment API p99 latency | < 500ms | 7 days rolling |
| Payment error rate | < 0.1% | 1 day rolling |

---

## 11. Disaster Recovery

| Metric | Target | Implementation |
|--------|--------|---------------|
| RTO | 4 hours | AKS cluster in DR region (Canada East), hot standby |
| RPO | 1 hour | Azure SQL geo-replication, 1-hour log backup |
| DR Test Cadence | Quarterly | Automated DR runbook |

---

## 12. Capacity Planning

| Workload | Current | 12-Month Target | Peak |
|---------|---------|----------------|------|
| Transactions/second | 100 TPS | 500 TPS | 2,000 TPS |
| Active users | 10,000 | 100,000 | 500,000 |
| Data volume | 500 GB | 5 TB | — |

---

## 13. Open Questions & Risks

| # | Question / Risk | Owner | Resolution Date | Status |
|---|----------------|-------|----------------|--------|
| 1 | [Question/Risk] | [Name] | YYYY-MM-DD | Open |

---

## 14. Related Documents

| Document | Location | Relationship |
|----------|---------|-------------|
| BRD | [Link] | Parent requirements |
| ADR-001 | [Link] | Architecture decision |
| LLD — [Service] | [Link] | Child design |
| Security Assessment | [Link] | Security review |
| Test Strategy | [Link] | Quality plan |

---

## 15. Architecture Review Board Sign-Off

| Reviewer | Role | Decision | Date | Notes |
|----------|------|----------|------|-------|
| [Name] | Chief Architect | Approved / Approved with Conditions / Rejected | | |
| [Name] | Security Architect | | | |
| [Name] | Platform Engineering | | | |
| [Name] | Data Architect | | | |
