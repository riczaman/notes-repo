# 🧪 Enterprise Testing Framework
**Stack**: Java/Spring Boot | JUnit 5 | TestContainers | REST Assured | k6 | OWASP ZAP

---

## Test Strategy Overview

### Testing Pyramid

```
                    ┌──────────────────┐
                    │   E2E Tests      │  ← 5% — Playwright/Selenium
                    │   (Slow, costly) │
                  ┌─┴──────────────────┴─┐
                  │  Integration Tests   │  ← 20% — Spring Boot Test + TestContainers
                  │                      │
                ┌─┴──────────────────────┴─┐
                │    Contract Tests         │  ← 10% — Pact (consumer-driven)
                │                           │
              ┌─┴───────────────────────────┴─┐
              │        Unit Tests              │  ← 65% — JUnit 5 + Mockito
              │   (Fast, isolated, numerous)   │
              └─────────────────────────────────┘
```

### Coverage Requirements

| Layer | Tool | Coverage Target | Gate |
|-------|------|----------------|------|
| Unit | JaCoCo | ≥ 80% line | Pipeline block |
| Integration | Spring Test | Key flows covered | Pipeline block |
| Contract | Pact | All API contracts | Pipeline block |
| Performance | k6 | p99 < 500ms | Pipeline block |
| Security | OWASP ZAP | 0 High/Critical | Pipeline block |
| Accessibility | axe-core | WCAG 2.1 AA | Pipeline warn |

---

## Unit Test Template (JUnit 5 + Mockito)

```java
package com.org.payments.service;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("PaymentService")
class PaymentServiceTest {

    @Mock
    private PaymentRepository paymentRepository;

    @Mock
    private FraudDetectionClient fraudDetectionClient;

    @Mock
    private AuditEventPublisher auditEventPublisher;

    @InjectMocks
    private PaymentService paymentService;

    @Nested
    @DisplayName("processPayment")
    class ProcessPayment {

        private PaymentRequest validRequest;

        @BeforeEach
        void setUp() {
            validRequest = PaymentRequest.builder()
                .amount(1000L)
                .currency("CAD")
                .merchantId("merchant-123")
                .idempotencyKey("idem-key-abc")
                .build();
        }

        @Test
        @DisplayName("should successfully process a valid payment")
        void shouldSuccessfullyProcessValidPayment() {
            // Arrange
            Payment expectedPayment = Payment.builder()
                .id("payment-789")
                .status(PaymentStatus.APPROVED)
                .amount(1000L)
                .build();
            when(fraudDetectionClient.assess(any())).thenReturn(FraudRiskLevel.LOW);
            when(paymentRepository.save(any())).thenReturn(expectedPayment);

            // Act
            Payment result = paymentService.processPayment(validRequest);

            // Assert
            assertThat(result).isNotNull();
            assertThat(result.getStatus()).isEqualTo(PaymentStatus.APPROVED);
            assertThat(result.getAmount()).isEqualTo(1000L);

            // Verify side effects
            verify(auditEventPublisher, times(1)).publish(any(PaymentProcessedEvent.class));
            verify(paymentRepository, times(1)).save(any(Payment.class));
        }

        @Test
        @DisplayName("should reject payment flagged as high fraud risk")
        void shouldRejectHighFraudRiskPayment() {
            // Arrange
            when(fraudDetectionClient.assess(any())).thenReturn(FraudRiskLevel.HIGH);

            // Act & Assert
            assertThatThrownBy(() -> paymentService.processPayment(validRequest))
                .isInstanceOf(FraudDetectedException.class)
                .hasMessageContaining("High fraud risk detected");

            verify(paymentRepository, never()).save(any());
            verify(auditEventPublisher, times(1)).publish(any(FraudRejectionEvent.class));
        }

        @Test
        @DisplayName("should be idempotent for duplicate idempotency key")
        void shouldReturnExistingPaymentForDuplicateIdempotencyKey() {
            // Arrange
            Payment existingPayment = Payment.builder()
                .id("existing-789")
                .status(PaymentStatus.APPROVED)
                .idempotencyKey("idem-key-abc")
                .build();
            when(paymentRepository.findByIdempotencyKey("idem-key-abc"))
                .thenReturn(Optional.of(existingPayment));

            // Act
            Payment result = paymentService.processPayment(validRequest);

            // Assert — should return existing, not create new
            assertThat(result.getId()).isEqualTo("existing-789");
            verify(fraudDetectionClient, never()).assess(any());
            verify(paymentRepository, never()).save(any());
        }

        @ParameterizedTest
        @DisplayName("should reject invalid amounts")
        @ValueSource(longs = {0L, -1L, -100L})
        void shouldRejectInvalidAmount(long invalidAmount) {
            // Arrange
            PaymentRequest invalidRequest = validRequest.toBuilder()
                .amount(invalidAmount)
                .build();

            // Act & Assert
            assertThatThrownBy(() -> paymentService.processPayment(invalidRequest))
                .isInstanceOf(InvalidPaymentRequestException.class)
                .hasMessageContaining("Amount must be positive");
        }

        @ParameterizedTest
        @DisplayName("should reject invalid currency codes")
        @ValueSource(strings = {"", "USDD", "123", "usd"})
        void shouldRejectInvalidCurrencyCode(String invalidCurrency) {
            PaymentRequest invalidRequest = validRequest.toBuilder()
                .currency(invalidCurrency)
                .build();

            assertThatThrownBy(() -> paymentService.processPayment(invalidRequest))
                .isInstanceOf(InvalidPaymentRequestException.class);
        }

        @Test
        @DisplayName("should handle repository failure gracefully")
        void shouldHandleRepositoryFailureGracefully() {
            // Arrange
            when(fraudDetectionClient.assess(any())).thenReturn(FraudRiskLevel.LOW);
            when(paymentRepository.save(any()))
                .thenThrow(new DataAccessException("DB connection failed") {});

            // Act & Assert
            assertThatThrownBy(() -> paymentService.processPayment(validRequest))
                .isInstanceOf(PaymentProcessingException.class)
                .hasMessageContaining("Temporary processing error");
        }
    }
}
```

---

## Integration Test Template (Spring Boot Test + TestContainers)

```java
package com.org.payments.integration;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.*;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.junit.jupiter.*;
import static org.assertj.core.api.Assertions.*;

@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class PaymentApiIntegrationTest {

    @Container
    static MSSQLServerContainer<?> sqlServer = new MSSQLServerContainer<>(
        "mcr.microsoft.com/mssql/server:2022-latest"
    )
    .acceptLicense()
    .withPassword("Integration_Test_P@ss1");

    @Container
    static GenericContainer<?> azureServiceBus = new GenericContainer<>(
        "mcr.microsoft.com/azure-messaging/servicebus-emulator:latest"
    )
    .withExposedPorts(5671)
    .waitingFor(Wait.forListeningPort());

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", sqlServer::getJdbcUrl);
        registry.add("spring.datasource.username", sqlServer::getUsername);
        registry.add("spring.datasource.password", sqlServer::getPassword);
        registry.add("spring.servicebus.connection-string",
            () -> "Endpoint=sb://localhost:" + azureServiceBus.getMappedPort(5671) + "/");
    }

    @Autowired
    private TestRestTemplate restTemplate;

    private HttpHeaders authHeaders;

    @BeforeEach
    void setUpAuth() {
        authHeaders = new HttpHeaders();
        authHeaders.setBearerAuth(TestJwtUtil.generateTestToken("test-user", "payments:write"));
        authHeaders.setContentType(MediaType.APPLICATION_JSON);
    }

    @Test
    @Order(1)
    @DisplayName("POST /v1/payments → 201 Created with valid request")
    void shouldCreatePaymentSuccessfully() {
        // Arrange
        var requestBody = """
            {
                "amount": 5000,
                "currency": "CAD",
                "merchant_id": "merchant-test-001",
                "idempotency_key": "integration-test-001"
            }
            """;

        var request = new HttpEntity<>(requestBody, authHeaders);

        // Act
        var response = restTemplate.postForEntity("/v1/payments", request, String.class);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getHeaders().getLocation()).isNotNull();

        var body = response.getBody();
        assertThat(body).contains("\"status\":\"APPROVED\"");
        assertThat(body).contains("\"amount\":5000");
        assertThat(body).doesNotContain("password", "secret", "key");
    }

    @Test
    @Order(2)
    @DisplayName("POST /v1/payments → 422 for invalid currency")
    void shouldReturn422ForInvalidCurrency() {
        var requestBody = """
            {
                "amount": 1000,
                "currency": "INVALID",
                "merchant_id": "merchant-001",
                "idempotency_key": "test-002"
            }
            """;

        var response = restTemplate.postForEntity(
            "/v1/payments",
            new HttpEntity<>(requestBody, authHeaders),
            String.class
        );

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY);
        assertThat(response.getBody()).contains("\"type\":");  // RFC 7807
        assertThat(response.getBody()).contains("\"status\":422");
    }

    @Test
    @DisplayName("POST /v1/payments → 401 without auth token")
    void shouldReturn401WithoutAuthToken() {
        var headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        var response = restTemplate.postForEntity(
            "/v1/payments",
            new HttpEntity<>("{}", headers),
            String.class
        );

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
    }
}
```

---

## Performance Test Template (k6)

```javascript
// k6 Performance Test — Payment API
// Usage: k6 run --env BASE_URL=https://api-staging.org.com performance/payment-api.js

import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Rate, Trend, Counter } from 'k6/metrics';
import { SharedArray } from 'k6/data';

// ── Custom Metrics ──────────────────────────────────────────────
const errorRate = new Rate('payment_error_rate');
const paymentLatency = new Trend('payment_latency', true);
const successfulPayments = new Counter('successful_payments');

// ── Test Configuration ──────────────────────────────────────────
export const options = {
  scenarios: {
    // Smoke test — verify baseline
    smoke: {
      executor: 'constant-vus',
      vus: 1,
      duration: '1m',
      tags: { scenario: 'smoke' },
    },
    // Load test — normal traffic
    load: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '2m', target: 50 },   // Ramp up
        { duration: '10m', target: 50 },  // Sustain
        { duration: '2m', target: 0 },    // Ramp down
      ],
      tags: { scenario: 'load' },
    },
    // Spike test — sudden traffic surge
    spike: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '30s', target: 200 }, // Spike
        { duration: '1m', target: 200 },  // Hold
        { duration: '30s', target: 0 },   // Drop
      ],
      tags: { scenario: 'spike' },
    },
  },

  // ── Pass/Fail Thresholds ──────────────────────────────────────
  thresholds: {
    // API response time
    'http_req_duration{endpoint:POST /v1/payments}': [
      'p(50) < 100',  // 50th percentile under 100ms
      'p(95) < 300',  // 95th percentile under 300ms
      'p(99) < 500',  // 99th percentile under 500ms
    ],
    // Error rate
    'payment_error_rate': ['rate < 0.01'],  // Less than 1% errors
    // HTTP failures
    'http_req_failed': ['rate < 0.005'],    // Less than 0.5% HTTP failures
  },
};

// ── Test Auth Setup ─────────────────────────────────────────────
const BASE_URL = __ENV.BASE_URL || 'https://api-staging.org.com';
const AUTH_TOKEN = __ENV.AUTH_TOKEN; // Injected from CI/CD secret

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${AUTH_TOKEN}`,
  'X-Correlation-ID': `k6-${Date.now()}`,
};

// ── Test Scenarios ──────────────────────────────────────────────
export default function () {
  group('Payment Processing', () => {
    // Generate unique idempotency key per VU per iteration
    const idempotencyKey = `k6-${__VU}-${__ITER}-${Date.now()}`;

    const payload = JSON.stringify({
      amount: Math.floor(Math.random() * 10000) + 100,
      currency: 'CAD',
      merchant_id: 'perf-test-merchant-001',
      idempotency_key: idempotencyKey,
    });

    const startTime = Date.now();
    const response = http.post(`${BASE_URL}/v1/payments`, payload, {
      headers,
      tags: { endpoint: 'POST /v1/payments' },
    });
    const duration = Date.now() - startTime;

    // Record custom metrics
    paymentLatency.add(duration);

    const success = check(response, {
      'status is 201': (r) => r.status === 201,
      'response has payment id': (r) => r.json('id') !== undefined,
      'response has status APPROVED': (r) => r.json('status') === 'APPROVED',
      'response time < 500ms': (r) => r.timings.duration < 500,
      'no PII in response': (r) => !r.body.includes('password') && !r.body.includes('secret'),
    });

    errorRate.add(!success);
    if (success) successfulPayments.add(1);

    sleep(1); // Think time between requests
  });

  group('Payment Retrieval', () => {
    // GET is lighter — test at higher rate
    const response = http.get(`${BASE_URL}/v1/payments?page_size=10`, {
      headers,
      tags: { endpoint: 'GET /v1/payments' },
    });

    check(response, {
      'status is 200': (r) => r.status === 200,
      'returns array': (r) => Array.isArray(r.json('data')),
      'includes pagination': (r) => r.json('next_cursor') !== undefined || r.json('data').length < 10,
    });

    sleep(0.5);
  });
}

export function handleSummary(data) {
  return {
    'performance/results/summary.json': JSON.stringify(data, null, 2),
    stdout: buildSummaryText(data),
  };
}

function buildSummaryText(data) {
  const thresholdsPassed = Object.values(data.metrics)
    .filter(m => m.thresholds)
    .every(m => Object.values(m.thresholds).every(t => !t.ok === false));

  return `
=== Performance Test Results ===
Status: ${thresholdsPassed ? '✅ PASSED' : '❌ FAILED'}
Duration: ${data.state.testRunDurationMs / 1000}s
Iterations: ${data.metrics.iterations?.values?.count}
Error Rate: ${(data.metrics.payment_error_rate?.values?.rate * 100).toFixed(2)}%
p50: ${data.metrics['http_req_duration']?.values?.['p(50)']?.toFixed(0)}ms
p99: ${data.metrics['http_req_duration']?.values?.['p(99)']?.toFixed(0)}ms
  `;
}
```

---

## SEV1 / SEV2 Incident Playbook

### SEV1 Response Playbook

```
TRIGGER: Alert fires OR customer reports complete service outage

T+00:00 ─── DETECTION & DECLARATION
│ ✅ L1 analyst receives alert / ticket
│ ✅ Verify: is the service truly down? (curl health endpoint)
│ ✅ Declare SEV1 in ServiceNow: INC record created
│ ✅ Page Incident Commander (PagerDuty: [rotation-name])
│ ✅ Open Teams Bridge: [Bridge Link]
│ ✅ Post in #incidents Slack channel: "SEV1 declared — [service] — bridge open"

T+00:05 ─── BRIDGE ESTABLISHMENT
│ ✅ Incident Commander (IC) opens bridge, does roll call
│ ✅ IC assigns roles: Technical Lead, Communications Lead, Scribe
│ ✅ Scribe starts timeline in INC record
│ ✅ Technical Lead begins triage (kubectl, logs, metrics)
│ ✅ Comms Lead sends INITIAL NOTIFICATION (template: COMM-01)

T+00:15 ─── TRIAGE
│ ✅ Check: pod health → kubectl get pods -n [svc]-prod
│ ✅ Check: error rate → Azure Monitor / Grafana
│ ✅ Check: recent deployments → helm history [svc] -n [svc]-prod
│ ✅ Check: Azure service health → portal.azure.com → Service Health
│ ✅ Check: database connectivity → Grafana → DB dashboard
│ ✅ Hypotheses formed, ranked by probability
│ ✅ IC communicates hypotheses on bridge

T+00:30 ─── STAKEHOLDER UPDATE #1
│ ✅ Comms Lead sends STATUS UPDATE (template: COMM-02)
│ ✅ Status page updated: "Identified" or "Investigating"
│ ✅ IC checks: do we have a resolution path?
│   ├── YES → execute fix, continue monitoring
│   └── NO  → escalate to Engineering Manager + Architect

T+01:00 ─── ESCALATION GATE
│ ✅ If not resolved at 60 minutes:
│   ├── Page Engineering Manager: [Name/PD Policy]
│   ├── Page Solution Architect: [Name/PD Policy]
│   └── Consider: is customer data at risk? → Security Lead
│ ✅ Comms Lead sends UPDATE #2

T+02:00 ─── EXECUTIVE ESCALATION
│ ✅ If not resolved at 2 hours:
│   ├── AVP Technology notified: [Name/Mobile]
│   └── Consider regulatory notification timeline assessment

RESOLUTION ─── CLOSE OUT
│ ✅ Verify service restored: all health checks green
│ ✅ Verify error rate < 1% for 10+ minutes
│ ✅ Comms Lead sends RESOLUTION notification (template: COMM-03)
│ ✅ Status page updated: "Resolved"
│ ✅ IC declares incident closed on bridge
│ ✅ Bridge closed, but scribe stays to complete INC record
│ ✅ Post-incident review scheduled: within 48 hours
│ ✅ RCA assigned to Technical Lead: due within 5 business days
```

---

## Governance Framework

```yaml
# governance/GOVERNANCE-MODEL.yaml
governance:
  
  prompt_library:
    ownership:
      overall: AI Engineering Guild
      per_role: Each role's designated senior lead
    
    review_cadence:
      strategic_review: Quarterly (full library)
      content_review: Bi-annual (per prompt)
      emergency_review: Ad-hoc (security issues, compliance changes)
    
    change_process:
      minor: PR with 1 peer reviewer approval
      major: PR with role lead + AI Guild lead approval
      breaking: ARB review + AI Guild + Compliance approval
    
    quality_gates:
      - prompt must have objective, context, constraints, examples
      - compliance mapping required for all security/data prompts
      - tested against 3 real scenarios before merge
      - reviewed for bias or hallucination risk
  
  agent_system:
    behavior_audits:
      frequency: Monthly
      owner: AI Governance Committee
      scope:
        - Output quality sampling (10% of interactions)
        - Compliance boundary enforcement
        - Escalation logic correctness
        - Hallucination rate tracking
    
    incident_response:
      trigger: Agent produces harmful, biased, or non-compliant output
      process:
        - Immediate: disable affected agent capability
        - 24h: root cause investigation
        - 48h: remediation applied
        - 72h: re-enable with monitoring
  
  skills_catalog:
    owner: Architecture Chapter
    review_cadence: Monthly
    maturity_assessment: Quarterly
    deprecation_process:
      notice_period: 90 days
      migration_guide: Required
      sunset_approval: Architecture Chapter lead
  
  compliance:
    regulatory_review:
      frequency: Quarterly
      scope: All prompts in SOC2/PCI-DSS scope
      reviewer: InfoSec + Legal
      output: Compliance attestation document
    
    data_handling:
      pii_in_prompts: PROHIBITED
      pan_in_prompts: PROHIBITED  
      internal_confidential: PERMITTED with classification label
      public: PERMITTED
```
