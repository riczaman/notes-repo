# 🖥️ VS Code Setup Guide — Enterprise AI Engineering Workflow
**Platform**: VS Code 1.90+ | **AI Tools**: GitHub Copilot + Claude + Cursor

---

## Step 1 — Install VS Code

Download from [code.visualstudio.com](https://code.visualstudio.com/)

Required version: **1.90+** (for full MCP + Copilot Chat support)

---

## Step 2 — Recommended Extensions

Install all extensions by opening VS Code and running:
```
Ctrl+Shift+P → Extensions: Install Extensions
```

### AI & Productivity Extensions

| Extension | ID | Purpose |
|-----------|-----|---------|
| GitHub Copilot | `GitHub.copilot` | AI code completion |
| GitHub Copilot Chat | `GitHub.copilot-chat` | AI chat in editor |
| Continue | `Continue.continue` | Multi-model AI (Claude, GPT-4, local LLMs) |
| Codeium | `Codeium.codeium` | Backup AI completions |

### Java / Spring Boot

| Extension | ID | Purpose |
|-----------|-----|---------|
| Extension Pack for Java | `vscjava.vscode-java-pack` | Full Java IDE experience |
| Spring Boot Extension Pack | `vmware.vscode-boot-dev-pack` | Spring Boot tooling |
| Lombok Annotations | `vscjava.vscode-lombok` | Lombok support |
| Maven for Java | `vscjava.vscode-maven` | Maven integration |
| SonarLint | `SonarSource.sonarlint-vscode` | Local SAST |

### Cloud & DevOps

| Extension | ID | Purpose |
|-----------|-----|---------|
| Azure Tools | `ms-vscode.vscode-node-azure-pack` | Full Azure toolset |
| Kubernetes | `ms-kubernetes-tools.vscode-kubernetes-tools` | K8s cluster management |
| Helm Intellisense | `Tim-Koehler.helm-intellisense` | Helm chart authoring |
| HashiCorp Terraform | `HashiCorp.terraform` | Terraform HCL editing |
| GitHub Actions | `github.vscode-github-actions` | Pipeline editing & debugging |
| Docker | `ms-azuretools.vscode-docker` | Container management |

### Code Quality

| Extension | ID | Purpose |
|-----------|-----|---------|
| ESLint | `dbaeumer.vscode-eslint` | JS/TS linting |
| Prettier | `esbenp.prettier-vscode` | Code formatting |
| Error Lens | `usernamehw.errorlens` | Inline error display |
| GitLens | `eamodio.gitlens` | Git supercharged |
| Git Graph | `mhutchie.git-graph` | Visual git history |

### Documentation & Markdown

| Extension | ID | Purpose |
|-----------|-----|---------|
| Markdown All in One | `yzhang.markdown-all-in-one` | Markdown editing |
| Mermaid Preview | `bierner.markdown-mermaid` | Diagram preview in MD |
| YAML | `redhat.vscode-yaml` | YAML validation |
| OpenAPI (Swagger) Editor | `42Crunch.vscode-openapi` | OpenAPI spec authoring |

### Prompt Engineering

| Extension | ID | Purpose |
|-----------|-----|---------|
| Prompt Flow | `prompt-flow.prompt-flow` | Prompt orchestration |
| .env | `mikestead.dotenv` | Environment file support |

---

## Step 3 — Workspace Settings

Create `.vscode/settings.json` in your project root:

```json
{
  // ── Editor ──────────────────────────────────────────────
  "editor.fontSize": 14,
  "editor.tabSize": 4,
  "editor.insertSpaces": true,
  "editor.formatOnSave": true,
  "editor.codeActionsOnSave": {
    "source.organizeImports": "explicit",
    "source.fixAll": "explicit"
  },
  "editor.rulers": [120],
  "editor.bracketPairColorization.enabled": true,
  "editor.inlayHints.enabled": "on",
  "editor.suggest.preview": true,

  // ── GitHub Copilot ───────────────────────────────────────
  "github.copilot.enable": {
    "*": true,
    "plaintext": false,
    "markdown": true,
    "scminput": false
  },
  "github.copilot.chat.localeOverride": "en",
  "github.copilot.editor.enableAutoCompletions": true,

  // ── Files ────────────────────────────────────────────────
  "files.autoSave": "onFocusChange",
  "files.trimTrailingWhitespace": true,
  "files.insertFinalNewline": true,
  "files.exclude": {
    "**/.git": true,
    "**/target": true,
    "**/.mvn": true,
    "**/node_modules": true
  },

  // ── Java ─────────────────────────────────────────────────
  "java.compile.nullAnalysis.mode": "automatic",
  "java.configuration.updateBuildConfiguration": "automatic",
  "java.debug.settings.hotCodeReplace": "auto",
  "java.format.settings.url": ".vscode/eclipse-formatter.xml",
  "java.test.defaultConfig": "junit5",
  "spring-boot.ls.java.home": "/usr/lib/jvm/java-17-openjdk",

  // ── Maven ────────────────────────────────────────────────
  "maven.executable.preferMavenWrapper": true,
  "maven.terminal.useJavaHome": true,

  // ── Kubernetes ────────────────────────────────────────────
  "vs-kubernetes": {
    "vs-kubernetes.namespace": "payments-dev",
    "vs-kubernetes.kubectl-path": "/usr/local/bin/kubectl"
  },

  // ── Terraform ────────────────────────────────────────────
  "terraform.experimentalFeatures.validateOnSave": true,
  "terraform.languageServer.enabled": true,

  // ── YAML ─────────────────────────────────────────────────
  "yaml.validate": true,
  "yaml.schemas": {
    "https://json.schemastore.org/github-workflow.json": ".github/workflows/*.yaml",
    "https://json.schemastore.org/helm-chart.json": "helm/Chart.yaml"
  },

  // ── OpenAPI ──────────────────────────────────────────────
  "openapi.defaultServer": "0",

  // ── Markdown ─────────────────────────────────────────────
  "markdown.preview.breaks": true,
  "[markdown]": {
    "editor.wordWrap": "on",
    "editor.quickSuggestions": {
      "comments": "off",
      "strings": "off",
      "other": "off"
    }
  },

  // ── Git ──────────────────────────────────────────────────
  "git.autofetch": true,
  "git.confirmSync": false,
  "gitlens.currentLine.enabled": true,
  "gitlens.hovers.currentLine.over": "line",

  // ── Terminal ─────────────────────────────────────────────
  "terminal.integrated.defaultProfile.linux": "bash",
  "terminal.integrated.fontSize": 13,
  "terminal.integrated.env.linux": {
    "KUBECONFIG": "${env:HOME}/.kube/config"
  },

  // ── SonarLint ────────────────────────────────────────────
  "sonarlint.connectedMode.project": {
    "connectionId": "org-sonarqube",
    "projectKey": "${workspaceFolderBasename}"
  }
}
```

---

## Step 4 — GitHub Copilot Configuration

### Configure Copilot Instructions (`.github/copilot-instructions.md`)

```markdown
# Copilot Instructions — [Organization Name] Engineering

## Technology Context
- Language: Java 17, Spring Boot 3.x
- Cloud: Microsoft Azure (AKS, Azure SQL, Key Vault, Service Bus)
- Compliance: SOC2 Type II, PCI-DSS Level 1

## Coding Standards
- Follow SOLID principles and Clean Architecture
- Use constructor injection (never field injection)
- Use @Slf4j for logging — never System.out.println
- Never hardcode secrets — always reference Spring Cloud Azure / Key Vault
- All public methods require Javadoc
- Unit test every new method with JUnit 5 + Mockito

## Security Rules
- Never log PAN, CVV, account numbers, or personal identifiers
- Always validate and sanitize external inputs
- Use parameterized queries — never string concatenation for SQL
- All API endpoints require OAuth2 authentication

## Code Style
- Max method length: 30 lines
- Max class length: 300 lines
- Package naming: com.org.[domain].[service].[layer]
- Exception handling: never swallow exceptions silently

## When generating tests
- Use JUnit 5 (@ExtendWith(MockitoExtension.class))
- Test class naming: [ClassName]Test
- Test method naming: should[ExpectedBehavior]When[Condition]
- Include at least one negative/error case per method

## When generating API code
- Follow OpenAPI 3.1 naming conventions
- Include request/response validation (@Valid annotations)
- Use RFC 7807 Problem Details for error responses
- Include correlation ID propagation
```

### VS Code Copilot Chat Participants

Use these built-in Copilot chat participants:
- `@workspace` — Ask about your entire codebase
- `@terminal` — Get help with shell commands
- `@vscode` — VS Code settings and features
- `/explain` — Explain selected code
- `/fix` — Fix selected code issue
- `/tests` — Generate tests for selected code
- `/doc` — Generate documentation for selected code

---

## Step 5 — Claude / Cursor Integration

### Option A: Cursor IDE (Recommended for Claude-first workflow)

1. Download Cursor from [cursor.sh](https://cursor.sh)
2. Open Settings → Models → Add `claude-sonnet-4-6` or `claude-opus-4-6`
3. Use your Anthropic API key
4. Open the repo: `cursor enterprise-ai-prompt-library/`

**Cursor Rules** (`.cursorrules` in project root):
```
You are an expert Java/Spring Boot developer for a financial services company on Azure.

Rules:
1. Always generate production-ready code — no TODOs in non-obvious places
2. Include error handling, logging (SLF4J), and OpenTelemetry tracing
3. Never hardcode secrets — use Azure Key Vault references
4. Security: follow OWASP Top 10, no SQL injection, no XSS vectors
5. Tests: generate JUnit 5 tests for every significant class
6. Compliance: flag any PCI-DSS or SOC2 concerns explicitly
7. Performance: flag any N+1 queries or blocking I/O
8. Use @Valid for all request body validation
9. Use RFC 7807 Problem Details for all error responses
10. Include correlation ID in all log statements
```

### Option B: Continue Extension (Multi-model)

Install Continue extension and configure `.continue/config.json`:
```json
{
  "models": [
    {
      "title": "Claude Sonnet 4.6",
      "provider": "anthropic",
      "model": "claude-sonnet-4-6",
      "apiKey": "${env:ANTHROPIC_API_KEY}"
    },
    {
      "title": "GitHub Copilot",
      "provider": "openai",
      "model": "gpt-4o",
      "apiBase": "https://api.githubcopilot.com"
    }
  ],
  "slashCommands": [
    {
      "name": "review",
      "description": "Security and quality code review",
      "prompt": "Review this code for: 1) Security (OWASP Top 10, PCI-DSS) 2) Performance 3) Maintainability 4) Test coverage gaps. Rate each finding BLOCKER/MAJOR/MINOR/SUGGESTION."
    },
    {
      "name": "hld",
      "description": "Generate HLD for selected component",
      "prompt": "Generate a High-Level Design document for this component using the organization's HLD template. Include C4 diagrams as Mermaid."
    },
    {
      "name": "rca",
      "description": "Root cause analysis",
      "prompt": "Perform a 5-Why root cause analysis on the following issue. Identify contributing factors and recommend remediation actions."
    }
  ],
  "contextProviders": [
    {
      "name": "file",
      "params": {}
    },
    {
      "name": "code",
      "params": {}
    },
    {
      "name": "docs",
      "params": {
        "urls": [
          "https://docs.spring.io/spring-boot/docs/current/reference/html/",
          "https://learn.microsoft.com/en-us/azure/aks/"
        ]
      }
    }
  ]
}
```

---

## Step 6 — Workspace Task Automation

Create `.vscode/tasks.json`:

```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "Maven: Build & Test",
      "type": "shell",
      "command": "mvn clean verify --no-transfer-progress",
      "group": { "kind": "build", "isDefault": true },
      "presentation": { "reveal": "always", "panel": "shared" },
      "problemMatcher": "$java"
    },
    {
      "label": "Maven: Run App",
      "type": "shell",
      "command": "mvn spring-boot:run -Dspring-boot.run.profiles=local",
      "group": "build",
      "presentation": { "reveal": "always", "panel": "shared" }
    },
    {
      "label": "Docker: Build Image",
      "type": "shell",
      "command": "docker build -t ${workspaceFolderBasename}:local .",
      "group": "build"
    },
    {
      "label": "K8s: Apply Dev",
      "type": "shell",
      "command": "kubectl apply -f k8s/dev/ -n ${workspaceFolderBasename}-dev",
      "group": "none"
    },
    {
      "label": "K8s: Port Forward",
      "type": "shell",
      "command": "kubectl port-forward svc/${workspaceFolderBasename} 8080:8080 -n ${workspaceFolderBasename}-dev",
      "group": "none"
    },
    {
      "label": "Terraform: Plan Dev",
      "type": "shell",
      "command": "cd terraform/environments/dev && terraform plan -var-file=terraform.tfvars",
      "group": "none"
    },
    {
      "label": "Security: Trivy Scan",
      "type": "shell",
      "command": "trivy image ${workspaceFolderBasename}:local --severity HIGH,CRITICAL",
      "group": "test"
    },
    {
      "label": "Security: Gitleaks",
      "type": "shell",
      "command": "gitleaks detect --source . --verbose",
      "group": "test"
    },
    {
      "label": "Prompt: Load Role Prompts",
      "type": "shell",
      "command": "code ${workspaceFolder}/prompts/${input:role}/prompts.md",
      "group": "none"
    }
  ],
  "inputs": [
    {
      "id": "role",
      "type": "pickString",
      "description": "Select your role",
      "options": [
        "senior-developer",
        "senior-architect",
        "business-analyst",
        "product-manager",
        "engineering-manager",
        "executive-avp",
        "qe-test-engineer",
        "communications-analyst",
        "devsecops-analyst",
        "support-analyst"
      ]
    }
  ]
}
```

---

## Step 7 — MCP Server Configuration (Claude Desktop)

Configure Claude Desktop's MCP servers (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/enterprise-ai-prompt-library"]
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"
      }
    },
    "azure-devops": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-azure-devops"],
      "env": {
        "AZURE_DEVOPS_ORG": "${ADO_ORG}",
        "AZURE_DEVOPS_TOKEN": "${ADO_PAT}"
      }
    }
  }
}
```

---

## Step 8 — Keyboard Shortcuts

Add to `.vscode/keybindings.json`:

```json
[
  {
    "key": "ctrl+shift+a",
    "command": "github.copilot.openChat",
    "when": "editorTextFocus"
  },
  {
    "key": "ctrl+shift+p",
    "command": "workbench.action.tasks.runTask"
  },
  {
    "key": "ctrl+k ctrl+r",
    "command": "workbench.action.tasks.runTask",
    "args": "Security: Gitleaks"
  }
]
```

---

## Step 9 — Local LLM Support (Optional / Air-Gap)

For air-gapped or on-premises AI workflows using Ollama:

```bash
# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Pull a capable model
ollama pull deepseek-coder-v2:16b
ollama pull llama3.1:8b

# Start server
ollama serve
```

Configure Continue extension to use local Ollama:
```json
{
  "models": [
    {
      "title": "DeepSeek Coder (Local)",
      "provider": "ollama",
      "model": "deepseek-coder-v2:16b",
      "apiBase": "http://localhost:11434"
    }
  ]
}
```

---

## Quick Reference — AI Workflow Commands

| Task | Command / Shortcut |
|------|-------------------|
| Open Copilot Chat | `Ctrl+Shift+I` |
| Inline Copilot suggest | `Alt+\` |
| Accept suggestion | `Tab` |
| Reject suggestion | `Esc` |
| Open Continue chat | `Ctrl+Shift+J` |
| Run build task | `Ctrl+Shift+B` |
| Run all tasks menu | `Ctrl+Shift+P → Tasks: Run Task` |
| Load role prompts | `Ctrl+Shift+P → Tasks: Run Task → Prompt: Load Role Prompts` |
| Open terminal | `Ctrl+\`` |
