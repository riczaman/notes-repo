# 🏗️ Senior Architect Prompt Library
**Role**: Senior Architect | **Domain**: Financial Services | **Cloud**: Azure | **Methodology**: SAFe Agile

---

## Index

| # | Prompt Name | Category |
|---|-------------|----------|
| SA-01 | Architecture Decision Record (ADR) | Documentation |
| SA-02 | High-Level Design (HLD) Generation | Documentation |
| SA-03 | System Integration Architecture | Technical |
| SA-04 | Cloud Migration Strategy | Planning |
| SA-05 | Security Architecture Review | Security |
| SA-06 | Technology Radar & Evaluation | Strategic |
| SA-07 | Capacity Planning & Scalability | Planning |
| SA-08 | Data Architecture Design | Technical |
| SA-09 | Architecture Risk Assessment | Risk |
| SA-10 | Monolith-to-Microservices Decomposition | Technical |
| SA-11 | Enterprise Architecture Review Board Prep | Communication |
| SA-12 | Disaster Recovery Architecture | Technical |
| SA-13 | API Gateway & Integration Pattern Design | Technical |
| SA-14 | FinTech Compliance Architecture Mapping | Compliance |
| SA-15 | Architecture Roadmap for Executive Review | Executive |

---

## SA-01 — Architecture Decision Record (ADR)

### Objective
Create a comprehensive, version-controlled Architecture Decision Record documenting a significant technical decision, its rationale, and consequences.

### Context
```
You are a Senior Architect in a financial services organization operating on Azure.
ADRs are stored in GitHub and reviewed quarterly by the Architecture Review Board.
All decisions must consider SOC2, PCI-DSS, operational risk, and total cost of ownership.
```

### Prompt Template
```
Generate a formal Architecture Decision Record (ADR) for the following decision:

**Decision Title**: {{DECISION_TITLE}}
**ADR Number**: {{ADR_NUMBER}}
**Date**: {{DATE}}
**Author**: {{AUTHOR_NAME}}
**Status**: [Proposed | Accepted | Deprecated | Superseded]

**Context**:
{{TECHNICAL_AND_BUSINESS_CONTEXT}}

**Decision Drivers**:
{{LIST_OF_DRIVERS}}

**Options Considered**:
{{OPTIONS_WITH_PROS_CONS}}

**Decision**:
{{SELECTED_OPTION}}

**Consequences**:
{{POSITIVE_AND_NEGATIVE_CONSEQUENCES}}

Generate a complete ADR in standard markdown format including:

1. **Context and Problem Statement** — What is the architectural challenge?
2. **Decision Drivers** — Functional, NFRs, compliance, cost, team capability
3. **Considered Options** — At least 3 options with structured comparison table
4. **Decision Outcome** — Chosen option with full justification
5. **Positive Consequences** — What this enables
6. **Negative Consequences** — Trade-offs accepted
7. **Compliance Impact** — SOC2/PCI-DSS considerations
8. **Links** — Related ADRs, RFCs, tickets
9. **Review Date** — When this decision should be revisited
```

### Output Format
Standard MADR (Markdown Architectural Decision Record) format, GitHub-renderable.

---

## SA-02 — High-Level Design (HLD) Generation

### Prompt Template
```
Generate a High-Level Design document for the following system or capability:

**System Name**: {{SYSTEM_NAME}}
**Business Capability**: {{CAPABILITY}}
**Stakeholders**: {{STAKEHOLDERS}}
**Architects**: {{ARCHITECTS}}
**Review Date**: {{DATE}}

**Business Requirements**:
{{BUSINESS_REQUIREMENTS}}

**NFRs (Non-Functional Requirements)**:
- Availability: {{AVAILABILITY}}
- Latency: {{LATENCY_SLA}}
- Throughput: {{RPS_TPS}}
- Data Retention: {{RETENTION}}
- RTO: {{RTO}} | RPO: {{RPO}}

**Integration Points**:
{{INTEGRATION_POINTS}}

**Constraints**:
{{CONSTRAINTS}}

Generate a complete HLD including:

1. **Executive Summary** (1 page)
2. **Business Context and Goals**
3. **System Context Diagram** (C4 Level 1 — described textually with Mermaid)
4. **Container Diagram** (C4 Level 2 — Mermaid)
5. **Component Overview** — key services and their responsibilities
6. **Data Flow Diagrams** — key business flows end-to-end
7. **Integration Architecture** — APIs, events, messaging
8. **Infrastructure Architecture** — Azure services, AKS topology
9. **Security Architecture** — authentication, authorization, encryption
10. **Observability Architecture** — logging, metrics, tracing
11. **Disaster Recovery Design** — RTO/RPO achievement strategy
12. **Technology Choices** — with ADR references
13. **Open Questions & Risks**
14. **Next Steps**

Include Mermaid diagram code for each architectural diagram.
```

---

## SA-03 — System Integration Architecture

### Prompt Template
```
Design the integration architecture for the following scenario:

**Integration Name**: {{INTEGRATION_NAME}}
**System A**: {{SYSTEM_A}} ({{SYSTEM_A_TECH}})
**System B**: {{SYSTEM_B}} ({{SYSTEM_B_TECH}})
**Integration Pattern**: [Synchronous REST | Async Event | File-Based | Hybrid]
**Data Volume**: {{VOLUME}} records/day
**Latency Requirement**: {{LATENCY}}

**Business Flow**:
{{FLOW_DESCRIPTION}}

**Data Elements**:
{{DATA_ELEMENTS}}

Design:
1. Integration pattern recommendation with justification
2. Sequence diagram (Mermaid)
3. Error handling and retry strategy
4. Dead letter queue / compensation pattern
5. Data transformation / mapping specification
6. Idempotency design
7. Security controls (mTLS, OAuth scopes, payload encryption)
8. Monitoring and alerting for the integration
9. Testing approach (contract tests, integration tests)
10. Operational runbook for this integration
```

---

## SA-05 — Security Architecture Review

### Prompt Template
```
Perform a Security Architecture Review for the following system:

**System**: {{SYSTEM_NAME}}
**Classification**: {{DATA_CLASSIFICATION}} (e.g., PCI Cardholder Data, PII)
**Deployment**: Azure AKS, microservices
**Internet-Facing**: {{YES | NO}}

**Architecture Summary**:
{{ARCHITECTURE_DESCRIPTION}}

**Current Security Controls**:
{{EXISTING_CONTROLS}}

Review against:
1. **NIST Cybersecurity Framework** — Identify, Protect, Detect, Respond, Recover
2. **OWASP ASVS Level 2** — Application Security Verification Standard
3. **PCI-DSS v4.0 Requirements** — relevant to data in scope
4. **SOC2 Trust Service Criteria** — Security, Availability, Confidentiality

For each area produce:
- Current state assessment
- Gap identification
- Risk rating (Critical/High/Medium/Low)
- Recommended control
- Implementation effort (S/M/L)
- Priority (P1/P2/P3)

Output as a structured security assessment report with an executive summary risk heat map.
```

---

## SA-09 — Architecture Risk Assessment

### Prompt Template
```
Perform a formal Architecture Risk Assessment for the following system or change:

**System / Change**: {{SYSTEM_OR_CHANGE}}
**Deployment Target**: Production
**Business Criticality**: {{TIER_1 | TIER_2 | TIER_3}}

**Architecture Description**:
{{DESCRIPTION}}

**Proposed Change** (if applicable):
{{CHANGE_DESCRIPTION}}

Assess the following risk dimensions:

1. **Technical Risk** — complexity, dependencies, technology maturity
2. **Security Risk** — attack surface, data exposure, compliance gaps
3. **Operational Risk** — observability, runbook maturity, on-call readiness
4. **Scalability Risk** — bottlenecks under load, single points of failure
5. **Data Risk** — data loss, corruption, retention violations
6. **Vendor Risk** — Azure service SLAs, third-party dependencies
7. **Team Risk** — knowledge concentration, key person dependency
8. **Compliance Risk** — SOC2, PCI-DSS gaps

For each risk:
- Risk statement
- Likelihood (1–5)
- Impact (1–5)
- Risk score = Likelihood × Impact
- Current mitigations
- Residual risk
- Recommended additional controls

Output a risk register table and an executive risk summary.
```

---

## SA-10 — Monolith-to-Microservices Decomposition

### Prompt Template
```
Design a strangler-fig decomposition strategy for the following monolithic system:

**Monolith Name**: {{MONOLITH_NAME}}
**Technology**: {{TECH_STACK}}
**Deployment**: {{CURRENT_DEPLOYMENT}}
**Team Size**: {{TEAM_SIZE}}
**Timeline**: {{TARGET_TIMELINE}}

**Current Capabilities in Monolith**:
{{CAPABILITY_LIST}}

**Business Drivers for Decomposition**:
{{DRIVERS}}

**Constraints**:
- Cannot have monolith downtime during migration
- Must maintain all existing integrations during transition
- Each extracted service must be independently deployable to AKS

Design:
1. **Domain decomposition** — identify bounded contexts using DDD
2. **Service extraction sequence** — ordered by risk and value
3. **Strangler Fig pattern** — routing, façade, and cutover strategy
4. **Data decomposition strategy** — shared database to service-owned databases
5. **Incremental migration roadmap** — sprint-by-sprint plan
6. **Testing strategy** — parallel run, contract tests, shadow traffic
7. **Rollback decision gates** — criteria for pausing or reverting
8. **Team topology** — stream-aligned teams per bounded context
9. **Architecture before and after** — Mermaid diagrams
10. **Risk register** for the decomposition program
```

---

## SA-14 — FinTech Compliance Architecture Mapping

### Prompt Template
```
Map the architecture of the following system against relevant compliance frameworks:

**System**: {{SYSTEM_NAME}}
**Compliance Frameworks**: PCI-DSS v4.0, SOC2 Type II, GDPR/PIPEDA

**Architecture Description**:
{{ARCHITECTURE_DESCRIPTION}}

**Data Flows**:
{{DATA_FLOW_DESCRIPTION}}

**Current Controls Inventory**:
{{CONTROLS_LIST}}

For each framework:
1. List applicable requirements
2. Map each requirement to architectural component
3. Identify gaps with severity
4. Recommend compensating or closing controls
5. Estimate implementation effort

Output:
- Compliance matrix (framework × requirement × control × status)
- Gap summary table
- Priority remediation roadmap
- Architecture diagram annotations for compliance zones
```

---

## SA-15 — Architecture Roadmap for Executive Review

### Prompt Template
```
Generate an executive-ready Architecture Roadmap presentation for the following:

**Domain**: {{ARCHITECTURE_DOMAIN}}
**Time Horizon**: {{12 | 18 | 24}} months
**Audience**: Technology Leadership / AVP / CTO

**Current State Summary**:
{{CURRENT_STATE}}

**Target State Vision**:
{{TARGET_STATE}}

**Strategic Initiatives**:
{{INITIATIVES}}

**Known Constraints**:
{{CONSTRAINTS}}

Generate:
1. **Executive Summary** — where we are, where we're going, why it matters
2. **Current State Assessment** — strengths and critical gaps (5 bullets each)
3. **Target Architecture Vision** — narrative + diagram description
4. **Roadmap Phases** — Now (0–6m), Next (6–12m), Later (12–24m)
5. **Investment Summary** — effort estimates by phase
6. **Risk Summary** — top 3 risks and mitigations
7. **Asks from Leadership** — decisions needed, resources, funding

Tone: Strategic, concise, executive-ready. No jargon without definition.
Length: Suitable for 15-minute steering committee slot.
```
