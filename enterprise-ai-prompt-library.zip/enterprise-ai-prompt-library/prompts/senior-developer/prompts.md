# 👨‍💻 Senior Developer Prompt Library
**Role**: Senior Developer | **Stack**: Java/Spring Boot, Polyglot | **Cloud**: Azure | **Platform**: AKS + GitHub Actions

---

## Index

| # | Prompt Name | Category | Complexity |
|---|-------------|----------|------------|
| SD-01 | Code Review & Quality Analysis | Technical | High |
| SD-02 | API Design & Contract Definition | Technical | High |
| SD-03 | Root Cause Analysis — Production Bug | Troubleshooting | High |
| SD-04 | Microservice Design & Implementation | Technical | High |
| SD-05 | Performance Optimization Analysis | Optimization | High |
| SD-06 | Security Vulnerability Assessment | Security | High |
| SD-07 | Technical Debt Identification | Planning | Medium |
| SD-08 | Sprint Planning & Estimation | Planning | Medium |
| SD-09 | Developer Documentation | Documentation | Medium |
| SD-10 | Deployment & Release Guidance | Deployment | High |
| SD-11 | Incident Response — Live Production | Incident Response | Critical |
| SD-12 | Architecture Review Participation | Architecture | High |
| SD-13 | Test Strategy for a Feature | Testing | Medium |
| SD-14 | Onboarding a New Service | Technical | Medium |
| SD-15 | Status Update for Engineering Manager | Communication | Low |
| SD-16 | CI/CD Pipeline Debugging | Troubleshooting | High |

---

## SD-01 — Code Review & Quality Analysis

### Objective
Perform a structured, senior-level code review that identifies defects, security risks, performance issues, and deviations from enterprise engineering standards.

### Context
```
You are a Senior Developer performing a formal code review in a financial services organization.
The codebase uses Java 17 / Spring Boot 3.x, deployed on Azure Kubernetes Service.
Compliance requirements include SOC2 Type II and PCI-DSS Level 1.
All code must adhere to OWASP Top 10 and internal secure coding standards.
```

### Assumptions
- The code compiles and passes basic linting
- Unit test coverage is expected at ≥80%
- The PR is targeted for a production-grade microservice

### Constraints
- Flag any hardcoded credentials, secrets, or PII immediately as BLOCKER
- No logging of sensitive financial data (card numbers, account IDs in plain text)
- Must follow established API contract if it's a public endpoint change

### Required Inputs
```
- Code diff or file(s) to review
- PR description and ticket reference (e.g., JIRA-XXXX)
- Target branch (main/develop/release)
- Any known context about the change
```

### Prompt Template
```
Review the following code change for a financial services microservice.

**PR Description**: {{PR_DESCRIPTION}}
**Ticket**: {{TICKET_ID}}
**Target Branch**: {{TARGET_BRANCH}}
**Service Name**: {{SERVICE_NAME}}

**Code Diff**:
{{CODE_DIFF}}

Perform a comprehensive code review covering:

1. **Correctness** — Does the code do what the PR description says?
2. **Security** — OWASP Top 10, PCI-DSS controls, secrets management, input validation
3. **Performance** — N+1 queries, inefficient loops, blocking I/O, memory leaks
4. **Maintainability** — Naming, complexity, single responsibility, DRY violations
5. **Test Coverage** — Are edge cases tested? Are mocks appropriate?
6. **Observability** — Logging completeness, trace propagation, metrics instrumentation
7. **Error Handling** — Are exceptions caught appropriately? Are retries idempotent?
8. **Compliance** — No PII in logs, no hardcoded credentials, data classification respected

For each issue found, provide:
- Severity: [BLOCKER | MAJOR | MINOR | SUGGESTION]
- Location: file:line
- Issue description
- Recommended fix with code example

End with an overall recommendation: [APPROVE | APPROVE WITH COMMENTS | REQUEST CHANGES | REJECT]
```

### Expected Output
- Structured list of findings by severity
- Code examples for each recommended fix
- Overall review decision with justification

### Validation Criteria
- All BLOCKER items explicitly called out first
- At least one positive observation included
- Recommendations are actionable, not vague

### Escalation Logic
- BLOCKER severity items → notify Engineering Manager and Security team before merge
- PCI-DSS violations → mandatory InfoSec review before any further action

### Example Output Fragment
```
**BLOCKER** — src/main/java/PaymentService.java:142
Hardcoded database password detected: `String pwd = "Prod@2024!"`
Fix: Move to Azure Key Vault reference via Spring Cloud Azure Secrets

**MAJOR** — src/main/java/PaymentService.java:87
SQL query constructed via string concatenation — SQL Injection risk.
Fix: Use Spring Data JPA parameterized queries or PreparedStatement

Overall: REQUEST CHANGES — 1 blocker and 2 majors must be resolved before merge.
```

---

## SD-02 — API Design & Contract Definition

### Objective
Design a RESTful or event-driven API contract that is standards-compliant, backward-compatible, and production-ready for financial services workloads.

### Context
```
You are a Senior Developer designing a new API for a financial services platform.
APIs must follow OpenAPI 3.1 specification.
The platform uses Azure API Management (APIM) as the gateway.
All APIs must be versioned, authenticated (OAuth2/OIDC), and rate-limited.
```

### Prompt Template
```
Design a complete API contract for the following capability:

**Capability**: {{CAPABILITY_NAME}}
**Consumer(s)**: {{CONSUMER_SERVICES_OR_TEAMS}}
**Data Domain**: {{DATA_DOMAIN}}
**SLA Requirement**: {{SLA_LATENCY_MS}} ms p99, {{AVAILABILITY}}% availability

Requirements:
{{FUNCTIONAL_REQUIREMENTS}}

Design the following:

1. **OpenAPI 3.1 specification** (YAML) including:
   - All endpoints with HTTP methods
   - Request/response schemas with examples
   - Error response schemas (RFC 7807 Problem Details)
   - Authentication scheme (OAuth2 Bearer)
   - Rate limiting headers
   - Pagination pattern (cursor-based for large datasets)
   - Idempotency key support for POST/PUT

2. **API versioning strategy** — URI versioning (/v1/) with deprecation timeline

3. **Error catalog** — standard error codes with descriptions

4. **Non-functional requirements** — caching strategy, retry guidance for consumers

5. **Breaking vs non-breaking change classification** for future governance

Format the OpenAPI spec as valid YAML. Include a consumer quick-start example in Java.
```

### Expected Output
- Complete OpenAPI 3.1 YAML spec
- Error catalog table
- Java consumer example
- Breaking change classification table

---

## SD-03 — Root Cause Analysis — Production Bug

### Objective
Systematically diagnose a production defect using structured RCA methodology, identify contributing factors, and produce a remediation plan.

### Prompt Template
```
Perform a Root Cause Analysis for the following production incident:

**Incident ID**: {{INC_ID}}
**Service Affected**: {{SERVICE_NAME}}
**Environment**: Production
**Time of Detection**: {{DETECTION_TIME}}
**Impact**: {{USER_IMPACT}}

**Symptoms Observed**:
{{SYMPTOMS}}

**Logs / Stack Traces**:
{{LOG_DATA}}

**Recent Changes (last 72 hours)**:
{{RECENT_CHANGES}}

**Infrastructure State**:
{{INFRA_STATE}}

Using the 5-Why methodology and Fishbone analysis:

1. **Immediate Cause** — What directly caused the failure?
2. **Contributing Factors** — What conditions allowed this to happen?
3. **Root Cause** — What is the systemic origin?
4. **Why did our controls fail?** — What detection/prevention failed?

Produce:
- Root cause statement (1–2 sentences)
- Timeline of events
- Remediation steps (immediate, short-term, long-term)
- Prevention recommendations
- Metrics/alerts that should have caught this earlier
```

---

## SD-04 — Microservice Design & Implementation

### Prompt Template
```
Design and scaffold a new microservice for the following requirement:

**Service Name**: {{SERVICE_NAME}}
**Domain**: {{BUSINESS_DOMAIN}}
**Responsibilities**: {{SERVICE_RESPONSIBILITIES}}
**Consumers**: {{CONSUMERS}}
**Events Published**: {{EVENTS}}
**Events Consumed**: {{EVENTS_CONSUMED}}
**Data Store**: {{DATA_STORE}}
**SLA**: {{SLA}}

Generate:

1. **Domain model** — entities, value objects, aggregates (DDD language)
2. **Service interface** — REST endpoints or event contracts
3. **Spring Boot project structure** — packages, layers (controller/service/repository/domain)
4. **Key implementation classes** — controller, service, repository stubs with Javadoc
5. **application.yaml** — Azure-ready config with Key Vault references
6. **Dockerfile** — multi-stage, distroless base image
7. **Kubernetes deployment.yaml** — resource limits, liveness/readiness probes, PodDisruptionBudget
8. **Unit test stubs** — JUnit 5 + Mockito
9. **OpenTelemetry instrumentation** — trace and span setup
10. **GitHub Actions pipeline** — build, test, scan (Trivy), push to ACR, deploy to AKS
```

---

## SD-05 — Performance Optimization Analysis

### Prompt Template
```
Analyze the following service for performance bottlenecks and produce an optimization plan:

**Service**: {{SERVICE_NAME}}
**Current p99 Latency**: {{CURRENT_LATENCY}}
**Target p99 Latency**: {{TARGET_LATENCY}}
**Throughput**: {{RPS}}

**Performance Profile / Flame Graph Data**:
{{PROFILE_DATA}}

**Database Query Plans**:
{{QUERY_PLANS}}

**Current Architecture**:
{{ARCH_DESCRIPTION}}

Analyze and recommend:
1. Top 3 bottlenecks by impact
2. Quick wins (< 1 sprint effort)
3. Strategic fixes (1–3 sprints)
4. Infrastructure scaling options (AKS HPA, KEDA, Azure Cache for Redis)
5. Database optimizations (indexes, connection pooling, read replicas)
6. Caching strategy with TTL recommendations
7. Expected impact for each recommendation
8. Measurement plan to validate improvements
```

---

## SD-10 — Deployment & Release Guidance

### Prompt Template
```
Generate a deployment plan for the following release:

**Service**: {{SERVICE_NAME}}
**Version**: {{VERSION}}
**Environment**: {{ENVIRONMENT}}
**Deployment Strategy**: {{BLUE_GREEN | CANARY | ROLLING}}
**Change Type**: {{BREAKING | NON_BREAKING | HOTFIX}}
**Deployment Window**: {{DATE_TIME}}
**Approval Status**: {{CAB_APPROVED | PENDING}}

Generate:
1. Pre-deployment checklist (15 items minimum)
2. Deployment steps with kubectl/Helm commands
3. Smoke test suite (5 critical paths)
4. Rollback procedure with decision criteria
5. Go/No-Go decision matrix
6. Post-deployment monitoring checklist
7. Stakeholder notification draft
8. Definition of Done for this release
```

---

## SD-11 — Incident Response — Live Production

### Objective
Real-time AI-assisted incident response for a live production issue.

### Prompt Template
```
⚠️ LIVE PRODUCTION INCIDENT — RESPOND IMMEDIATELY

**Incident Severity**: {{SEV1 | SEV2}}
**Service**: {{SERVICE_NAME}}
**Detection Source**: {{ALERT_SOURCE}}
**Current Time**: {{TIME}}
**Incident Commander**: {{IC_NAME}}

**Current Symptoms**:
{{SYMPTOMS}}

**Affected Users / Revenue Impact**: {{IMPACT}}

Act as the technical lead on this incident bridge. Provide:

1. **Immediate triage steps** (next 5 minutes)
2. **Likely hypotheses** ranked by probability
3. **Diagnostic commands** to run NOW (kubectl, az cli, curl, SQL)
4. **Mitigation options** — from fastest to most reliable
5. **Communication draft** for status page update
6. **Escalation list** — who to page immediately
7. **Evidence to collect** before any changes

Prioritize speed and safety. Assume SOC2 audit trail requirements.
```

---

## SD-15 — Status Update for Engineering Manager

### Prompt Template
```
Generate a weekly status update for my Engineering Manager.

**My Name**: {{NAME}}
**Team / Squad**: {{TEAM}}
**Week**: {{WEEK_DATE}}

**Work Completed This Week**:
{{COMPLETED_WORK}}

**Work In Progress**:
{{IN_PROGRESS}}

**Blockers / Risks**:
{{BLOCKERS}}

**Next Week Plan**:
{{NEXT_WEEK}}

**Help Needed**:
{{HELP_NEEDED}}

Format as a concise, professional status update (max 300 words).
Use bullet points. Lead with impact, not activity.
Flag any risks in bold with recommended resolution.
```
