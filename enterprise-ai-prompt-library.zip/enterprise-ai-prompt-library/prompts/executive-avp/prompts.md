# 👔 Executive AVP Prompt Library
**Role**: Associate Vice President, Technology | **Industry**: Financial Services | **Methodology**: SAFe Agile

---

## Index

| # | Prompt Name | Category |
|---|-------------|----------|
| AVP-01 | Steering Committee Status Package | Executive Communication |
| AVP-02 | Technology Risk Escalation | Risk |
| AVP-03 | Quarterly Business Review (QBR) Narrative | Reporting |
| AVP-04 | Investment Business Case | Strategic |
| AVP-05 | Vendor Evaluation Summary | Strategic |
| AVP-06 | Team & Delivery Health Assessment | Leadership |
| AVP-07 | Production Incident Executive Briefing | Incident |
| AVP-08 | OKR / Roadmap Narrative | Strategic |
| AVP-09 | Board Technology Update | Executive |
| AVP-10 | Organizational Change Communication | Leadership |
| AVP-11 | Budget Variance Explanation | Financial |
| AVP-12 | Architecture Investment Justification | Strategic |
| AVP-13 | Regulatory Audit Preparation | Compliance |
| AVP-14 | Talent & Retention Strategy Note | Leadership |
| AVP-15 | Technology Strategy One-Pager | Strategic |

---

## AVP-01 — Steering Committee Status Package

### Objective
Produce an executive-grade steering committee status package that communicates program health, risks, financials, and decisions needed — in under 5 minutes of reading time.

### Context
```
You are an Associate Vice President of Technology preparing a monthly steering committee update.
Audience: C-suite, peers (other AVPs), and board-level committee members.
Tone: Confident, direct, data-driven. No technical jargon without translation.
Length: 1-page summary + supporting detail appendix.
```

### Prompt Template
```
Generate a steering committee status package for the following program:

**Program Name**: {{PROGRAM_NAME}}
**Reporting Period**: {{MONTH_YEAR}}
**Overall Status**: {{GREEN | AMBER | RED}}

**Milestones This Period**:
{{COMPLETED_MILESTONES}}

**Milestones Next Period**:
{{UPCOMING_MILESTONES}}

**Financials**:
- Budget: ${{BUDGET}}
- Spent to Date: ${{SPENT}}
- Forecast: ${{FORECAST}}
- Variance: {{VARIANCE_EXPLANATION}}

**Key Risks**:
{{RISKS_AND_STATUS}}

**Decisions Required from Steering Committee**:
{{DECISIONS_NEEDED}}

**Escalations**:
{{ESCALATIONS}}

Generate:

## SECTION 1: Executive Dashboard (one-page)
- Program name, period, RAG status with trend arrow
- 3 headline achievements (1 sentence each)
- 3 top risks with mitigations (1 line each)
- Financial snapshot (budget vs actuals, variance %)
- 3 decisions required (with deadline)
- Next 30 days preview

## SECTION 2: Milestone Tracker
Table: Milestone | Owner | Due Date | Status | Notes

## SECTION 3: Risk Register Summary
Table: Risk | Likelihood | Impact | Mitigation | Owner | Status

## SECTION 4: Financial Detail
- Budget breakdown by workstream
- Burn rate commentary
- Forecast-to-complete

## SECTION 5: Appendix — Supporting Detail
Any technical context translated for executive audience.

Tone: Strategic, decisive, accountable. Use "we" language. Flag problems early with solutions ready.
```

---

## AVP-02 — Technology Risk Escalation

### Prompt Template
```
Draft an executive risk escalation communication for the following situation:

**Risk Title**: {{RISK_TITLE}}
**Risk Owner**: {{OWNER}}
**Date**: {{DATE}}
**Escalating To**: {{RECIPIENT_TITLE}}

**Risk Description**:
{{RISK_DESCRIPTION}}

**Business Impact if Not Addressed**:
{{IMPACT}}

**Current Mitigation Status**:
{{CURRENT_STATE}}

**Decision / Resource Required**:
{{WHAT_IS_NEEDED}}

**Timeline**: Decision required by {{DATE}}

Generate a crisp executive escalation note (max 300 words) that:
1. States the risk clearly in the first sentence
2. Quantifies business impact (revenue, compliance, reputation)
3. Presents 2–3 response options with tradeoffs
4. Makes a clear recommendation
5. Specifies the decision needed and deadline
6. Avoids technical jargon

Tone: Urgent but composed. Confidence-inspiring. Solution-oriented.
```

---

## AVP-04 — Investment Business Case

### Prompt Template
```
Generate an executive investment business case for the following initiative:

**Initiative Name**: {{INITIATIVE_NAME}}
**Investment Amount**: ${{AMOUNT}}
**Timeline**: {{TIMELINE}}
**Sponsor**: {{SPONSOR}}

**Problem Statement**:
{{PROBLEM}}

**Proposed Solution**:
{{SOLUTION}}

**Strategic Alignment**:
{{STRATEGY_ALIGNMENT}}

**Alternatives Considered**:
{{ALTERNATIVES}}

**Expected Benefits**:
- Financial: {{FINANCIAL_BENEFITS}}
- Operational: {{OPERATIONAL_BENEFITS}}
- Risk Reduction: {{RISK_BENEFITS}}
- Strategic: {{STRATEGIC_BENEFITS}}

**Costs**:
- Capital: ${{CAPEX}}
- Operating: ${{OPEX}}/year
- One-time: ${{ONE_TIME}}

**Risks of Not Investing**:
{{STATUS_QUO_RISK}}

Generate:
1. **Executive Summary** (half page, decision-ready)
2. **Problem & Opportunity Statement**
3. **Proposed Investment & Scope**
4. **Benefits Realization Plan** with timeline
5. **Financial Summary** — ROI, NPV, payback period
6. **Risk Assessment** — top 5 risks
7. **Implementation Approach** — high-level phases
8. **Recommendation & Ask**

Tone: Board-ready. Quantify everything possible. Lead with business value, not technology.
```

---

## AVP-07 — Production Incident Executive Briefing

### Prompt Template
```
Generate an executive briefing for a production incident:

**Incident ID**: {{INC_ID}}
**Severity**: {{SEV1 | SEV2}}
**Service Affected**: {{SERVICE}}
**Detection Time**: {{TIME}}
**Resolution Time**: {{TIME}} (or "Ongoing")
**Customer Impact**: {{IMPACT_DESCRIPTION}}

**What Happened** (technical summary already written):
{{TECHNICAL_SUMMARY}}

**Root Cause**:
{{ROOT_CAUSE}}

**Immediate Actions Taken**:
{{ACTIONS}}

**Customer-Facing Impact Duration**: {{DURATION}}

Transform this into an executive briefing that:

1. **Situation** (2 sentences) — what failed, when, customer impact
2. **Resolution Status** (1 sentence) — resolved or active mitigation
3. **Root Cause** (1–2 sentences, no jargon) — why it happened
4. **Customer Impact** — quantified if possible (# customers, $ transactions)
5. **Regulatory / Compliance Implications** — any reporting obligations?
6. **3 Immediate Actions** already taken
7. **3 Long-term Prevention Steps** with owners and dates
8. **What leadership should expect next** — follow-up RCA, regulatory contact?

Tone: Factual, accountable, forward-looking. No blame. Show we are in control.
Length: Max 400 words. Suitable for forwarding to C-suite and board liaison.
```

---

## AVP-08 — OKR / Roadmap Narrative

### Prompt Template
```
Generate an OKR and roadmap narrative for executive review:

**Organization Unit**: {{ORG_UNIT}}
**Period**: {{Q_YEAR}} (SAFe PI or Quarterly)
**Audience**: Technology Leadership / CTO / Board Committee

**Objectives**:
{{OKR_LIST}}

**Key Results** (with current scoring):
{{KR_LIST_WITH_SCORES}}

**Strategic Roadmap Items**:
- Now (this quarter): {{NOW_ITEMS}}
- Next (next quarter): {{NEXT_ITEMS}}
- Later (6–12 months): {{LATER_ITEMS}}

**Dependencies on Other Teams**:
{{DEPENDENCIES}}

**Resource Constraints**:
{{CONSTRAINTS}}

Generate:
1. **OKR Health Summary** — scoring narrative, on-track vs at-risk
2. **Roadmap Narrative** — story of where we're headed and why
3. **Dependency Map** — critical path items and owners
4. **Ask from Leadership** — approvals, decisions, unblocking needed
5. **Success Definition** — what "great" looks like at end of period

Tone: Strategic narrative, not a status report. Paint a vision, show accountability.
```

---

## AVP-09 — Board Technology Update

### Prompt Template
```
Generate a board-level technology update for the following:

**Organization**: {{ORG_NAME}}
**Board Meeting Date**: {{DATE}}
**Section Time Allocation**: 10 minutes

**Themes to Cover**:
1. Technology Strategy Progress: {{THEME_1}}
2. Key Investments & Outcomes: {{THEME_2}}
3. Risk & Cybersecurity Posture: {{THEME_3}}
4. Innovation Initiatives: {{THEME_4}}

**Recent Significant Events**:
{{EVENTS}}

**Financial Period**: {{PERIOD}}

Generate board presentation content:
1. **Opening Frame** — 2-sentence technology health statement
2. **3 Strategic Wins** — measurable outcomes, business language
3. **2 Critical Risks** — current posture and mitigation
4. **Cybersecurity Snapshot** — posture, incidents, investment
5. **Innovation Highlight** — 1 AI/modernization story with ROI
6. **Financial Stewardship** — spend vs plan, efficiency narrative
7. **Next 90 Days** — what the board should watch for

Format: Suitable for board deck slide notes. Each section = 1–2 slides.
Tone: Governance-level. Fiduciary responsibility mindset. Confident and measured.
```

---

## AVP-15 — Technology Strategy One-Pager

### Prompt Template
```
Generate a technology strategy one-pager for:

**Year / Period**: {{YEAR}}
**Audience**: Leadership Team, Board, All-Staff (choose one: {{AUDIENCE}})

**Strategic Pillars**:
{{PILLAR_1}}, {{PILLAR_2}}, {{PILLAR_3}}

**Current State Context**:
{{CURRENT_STATE}}

**Target State**:
{{TARGET_STATE}}

**Top 5 Strategic Initiatives**:
{{INITIATIVES}}

**Guiding Principles** (3–5):
{{PRINCIPLES}}

Generate a one-page technology strategy document:
- Vision statement (1 sentence)
- Mission statement (2 sentences)
- 3 strategic pillars with 2-line descriptions
- Top 5 initiatives with expected outcomes
- 12-month priority focus areas
- What we will NOT do (strategic trade-offs)
- How we measure success

Design for single-page print layout. Professional, inspiring, and credible.
```
