# 📦 Product Manager Prompt Library
**Role**: Product Manager | **Methodology**: SAFe Agile | **Industry**: Financial Services

---

## PM-01 — Product Requirements Document (PRD)

### Prompt Template
```
Generate a comprehensive Product Requirements Document for:

**Feature Name**: {{FEATURE_NAME}}
**Product Area**: {{PRODUCT_AREA}}
**Target PI (Program Increment)**: {{PI_NUMBER}}
**Business Sponsor**: {{SPONSOR}}

**Problem Statement**:
{{PROBLEM}}

**User Research / Evidence**:
{{EVIDENCE}}

**Proposed Solution**:
{{SOLUTION}}

**Target Users**:
{{PERSONAS}}

**Success Metrics**:
{{METRICS}}

**Out of Scope**:
{{OUT_OF_SCOPE}}

Generate:
1. **Executive Summary** (decision-ready, 100 words)
2. **Problem & Opportunity** — why this, why now
3. **User Stories** — in Given/When/Then format (minimum 8)
4. **Acceptance Criteria** — for each user story
5. **Functional Requirements** — numbered, testable
6. **Non-Functional Requirements** — performance, security, accessibility
7. **UX/UI Requirements** — interaction principles
8. **Dependencies** — upstream and downstream
9. **Constraints** — regulatory, technical, timeline
10. **Success Metrics** — leading and lagging indicators
11. **Launch Checklist** — go-to-market readiness items
12. **Open Questions** — decision log
```

---

## PM-02 — Feature Prioritization & Roadmap

### Prompt Template
```
Prioritize the following feature backlog and generate a 12-month roadmap:

**Product**: {{PRODUCT_NAME}}
**Strategic Goals**: {{GOALS}}
**Team Capacity**: {{CAPACITY}} (story points/sprint)
**Sprints in Period**: {{SPRINT_COUNT}}

**Feature Backlog**:
{{FEATURE_LIST_WITH_ROUGH_ESTIMATES}}

**Constraints**:
{{CONSTRAINTS}}

**Stakeholder Priorities**:
{{STAKEHOLDER_INPUT}}

Use RICE scoring (Reach, Impact, Confidence, Effort) to:
1. Score each feature
2. Rank by RICE score
3. Apply strategic alignment filter (must/should/could/won't — MoSCoW)
4. Build a Now/Next/Later roadmap
5. Identify theme groupings for PI Planning
6. Flag dependencies between features
7. Note risks in the prioritization

Output:
- RICE scoring table
- Ranked backlog
- Visual roadmap (described as a table with quarters)
- PI Planning readiness checklist
```

---

## PM-03 — Stakeholder Communication — Feature Update

### Prompt Template
```
Draft a stakeholder update for the following feature:

**Feature**: {{FEATURE_NAME}}
**Status**: {{ON_TRACK | AT_RISK | DELAYED | COMPLETE}}
**Audience**: {{BUSINESS_STAKEHOLDERS | EXECUTIVES | FULL_ORG}}

**What Was Promised**: {{ORIGINAL_COMMITMENT}}
**Current State**: {{CURRENT_STATE}}
**If Delayed — Root Cause**: {{ROOT_CAUSE}}
**New Timeline**: {{NEW_DATE}}
**Impact of Delay**: {{IMPACT}}

Draft a professional stakeholder update (200 words max):
- Open with status headline
- State what's done, what's pending
- If delayed: explain once, clearly, with accountability
- Close with next checkpoint and contact for questions
- Tone: transparent, confident, forward-looking
```

---

## PM-04 — OKR Design & Alignment

### Prompt Template
```
Design OKRs for the following product area:

**Product/Team**: {{PRODUCT_TEAM}}
**Period**: {{Q_YEAR}}
**Company OKRs to Align To**: {{COMPANY_OKRS}}

**Key Business Problems to Solve**:
{{PROBLEMS}}

**Available Capacity**: {{CAPACITY}}

Generate:
1. 3–4 Objectives (inspirational, qualitative, time-bound)
2. 3 Key Results per Objective (measurable, ambitious but achievable)
3. Leading indicators for each KR (weekly tracking metrics)
4. Risks to achieving each KR
5. Initiative mapping — which features/epics deliver which KRs
6. Scoring rubric (0.0 to 1.0 scale explanation)
7. Weekly review cadence template

OKRs should be stretch goals: 70% achievement = success.
```

---

## PM-05 — Release Notes & Go-to-Market

### Prompt Template
```
Generate release notes and go-to-market communications for:

**Release Name**: {{RELEASE_NAME}}
**Version**: {{VERSION}}
**Release Date**: {{DATE}}
**Audience**: {{CUSTOMERS | INTERNAL | BOTH}}

**Features Released**:
{{FEATURE_LIST_WITH_DESCRIPTIONS}}

**Bug Fixes**:
{{BUG_FIX_LIST}}

**Breaking Changes**:
{{BREAKING_CHANGES}}

**Migration Required**: {{YES | NO}}
{{MIGRATION_STEPS}}

Generate:
1. Customer-facing release notes (plain language, benefit-led)
2. Internal release announcement (Slack/email format)
3. External blog post draft (if major release)
4. Support team briefing note
5. FAQ — top 5 anticipated customer questions
6. Rollback/support escalation path for customers
```

---

# 📊 Business Analyst Prompt Library

---

## BA-01 — Business Requirements Document (BRD)

### Prompt Template
```
Generate a Business Requirements Document for:

**Initiative**: {{INITIATIVE_NAME}}
**Business Sponsor**: {{SPONSOR}}
**Target Delivery**: {{DATE}}
**Regulatory Driver**: {{YES | NO}} — {{REGULATION}}

**Business Problem**:
{{PROBLEM_STATEMENT}}

**Business Objectives**:
{{OBJECTIVES}}

**In Scope**:
{{SCOPE}}

**Out of Scope**:
{{OUT_OF_SCOPE}}

**Stakeholders**:
{{STAKEHOLDER_LIST}}

**Current State Process**:
{{AS_IS}}

**Future State Process**:
{{TO_BE}}

**Regulatory & Compliance Requirements**:
{{COMPLIANCE_REQS}}

Generate a full BRD including:
1. Executive Summary
2. Business Context & Problem Statement
3. Objectives & Success Criteria
4. Scope & Boundaries
5. Stakeholder Analysis (RACI)
6. Functional Requirements (numbered, testable, traceable)
7. Non-Functional Requirements
8. Regulatory & Compliance Requirements
9. Process Flows (As-Is and To-Be — Mermaid flowcharts)
10. Data Requirements
11. Integration Requirements
12. Assumptions & Dependencies
13. Constraints & Risks
14. Acceptance Criteria
15. Sign-off Matrix
```

---

## BA-02 — Process Mapping & Gap Analysis

### Prompt Template
```
Perform a process gap analysis for:

**Process Name**: {{PROCESS_NAME}}
**Domain**: {{BUSINESS_DOMAIN}}

**Current State (As-Is)**:
{{AS_IS_PROCESS}}

**Target State (To-Be)**:
{{TO_BE_PROCESS}}

**Known Pain Points**:
{{PAIN_POINTS}}

**Regulatory Requirements Impacting Process**:
{{REQUIREMENTS}}

Produce:
1. As-Is process flow (Mermaid BPMN-style)
2. To-Be process flow (Mermaid)
3. Gap analysis table: Step | Current | Target | Gap | Priority | Owner
4. Root cause analysis for key gaps
5. Requirements to close each gap
6. Change impact assessment
7. Implementation roadmap for process change
8. Training & communication needs
```

---

# 👥 Engineering Manager Prompt Library

---

## EM-01 — Sprint / PI Health Report

### Prompt Template
```
Generate a sprint/PI health report for engineering leadership:

**Team**: {{TEAM_NAME}}
**Sprint/PI**: {{SPRINT_PI_NUMBER}}
**Reporting Period**: {{DATE_RANGE}}

**Velocity**:
- Committed: {{COMMITTED_POINTS}}
- Completed: {{COMPLETED_POINTS}}
- Carry-over: {{CARRYOVER_POINTS}}

**Team Composition**: {{TEAM_SIZE}} engineers

**Highlights**:
{{HIGHLIGHTS}}

**Blockers / Risks**:
{{BLOCKERS}}

**Technical Debt Status**:
{{TECH_DEBT_ITEMS}}

**Team Health Indicators**:
{{HEALTH_SIGNALS}}

Generate:
1. Velocity trend analysis (is the team healthy?)
2. Risk assessment with recommended actions
3. Escalation items for EM/Director
4. Team recognition moments
5. Next sprint planning considerations
6. 3-sentence executive summary suitable for Slack/email
```

---

## EM-02 — Engineering Manager — 1:1 Preparation

### Prompt Template
```
Prepare for a 1:1 meeting with a direct report:

**Team Member**: {{NAME}} ({{ROLE}})
**Meeting Date**: {{DATE}}
**Tenure**: {{TENURE}}
**Current Performance**: {{PERFORMANCE_SIGNALS}}

**Recent Work**:
{{RECENT_CONTRIBUTIONS}}

**Known Challenges or Concerns**:
{{CONCERNS}}

**Career Development Status**:
{{CAREER_GOALS}}

**Topics Requested by Team Member**:
{{THEIR_TOPICS}}

Generate:
1. 5 thoughtful 1:1 questions tailored to this person
2. Feedback to give (SBI format: Situation, Behavior, Impact)
3. Career development talking points
4. Actions to follow up on from last 1:1
5. Recognition moments to celebrate
6. Coaching approach for any performance concerns
```

---

# 🧪 QE / Test Engineer Prompt Library

---

## QE-01 — Test Strategy Document

### Prompt Template
```
Generate a comprehensive Test Strategy for:

**System / Feature**: {{SYSTEM_NAME}}
**Release Date**: {{DATE}}
**Risk Profile**: {{HIGH | MEDIUM | LOW}}
**Data Classification**: {{PCI_SCOPE | PII | INTERNAL}}
**Compliance**: SOC2, PCI-DSS

**System Description**:
{{SYSTEM_DESCRIPTION}}

**Integration Points**:
{{INTEGRATIONS}}

**Non-Functional Requirements**:
{{NFRS}}

Generate a complete Test Strategy including:
1. Test Objectives & Scope
2. Test Types & Coverage Plan
   - Unit (developer-owned, ≥80% line coverage)
   - Integration (Spring Boot Test, TestContainers)
   - Contract (Pact — consumer-driven)
   - API (REST Assured or Postman/Newman)
   - End-to-End (Selenium/Playwright)
   - Performance (k6 or JMeter)
   - Security (OWASP ZAP, Snyk)
   - Accessibility (axe-core, WCAG 2.1 AA)
3. Test Environments & Data Strategy
4. Test Automation Architecture
5. CI/CD Integration Plan
6. Entry & Exit Criteria
7. Defect Management Process
8. Risk-Based Test Prioritization
9. Test Metrics & Reporting
10. Tools & Frameworks Table
11. Roles & Responsibilities (RACI)
```

---

## QE-02 — API Test Suite Generation

### Prompt Template
```
Generate a comprehensive API test suite for:

**API Specification**: {{OPENAPI_YAML_OR_DESCRIPTION}}
**Framework**: REST Assured (Java) or Postman/Newman
**Environments**: dev, staging, production (smoke only)
**Auth**: OAuth2 Bearer Token

Generate test cases for each endpoint covering:
1. **Happy path** — valid inputs, expected response
2. **Authentication** — missing token, expired token, wrong scope
3. **Input validation** — boundary values, null, empty, malformed
4. **Business logic** — domain-specific scenarios
5. **Error handling** — 400, 401, 403, 404, 409, 422, 500 scenarios
6. **Performance baseline** — response time assertions (p95 < 200ms)
7. **Contract compliance** — schema validation against OpenAPI spec

For each test:
- Test ID
- Description
- Preconditions
- Request (method, endpoint, headers, body)
- Expected response (status, body schema, headers)
- Assertions
- Tags (smoke, regression, security)

Generate as REST Assured Java code with JUnit 5 annotations.
Include a Postman collection JSON for the same tests.
```

---

# 📣 Communications Analyst Prompt Library

---

## CA-01 — Production Incident Communication (External)

### Prompt Template
```
Draft external incident communications for:

**Incident**: {{INCIDENT_SUMMARY}}
**Status**: {{INVESTIGATING | IDENTIFIED | MONITORING | RESOLVED}}
**Time**: {{TIME}}
**Affected Services**: {{SERVICES}}
**Customer Impact**: {{IMPACT}}

Generate communications for each status:

## INVESTIGATING
Subject: [Service Name] — We are investigating an issue
Draft: Brief acknowledgment, what customers may experience, we are on it, next update time.

## IDENTIFIED
Subject: [Service Name] — Issue Identified, Fix In Progress
Draft: What we found, fix underway, ETA if known, workaround if available.

## MONITORING
Subject: [Service Name] — Fix Applied, Monitoring
Draft: Confirm fix deployed, watching for full restoration, thank you for patience.

## RESOLVED
Subject: [Service Name] — Issue Resolved
Draft: Confirmed resolved, what happened (plain language), what we're doing to prevent recurrence, apology, contact for questions.

Tone: Empathetic, transparent, professional. Avoid technical jargon.
Channels: Status page, customer email, social media (shorter versions).
```

---

## CA-02 — Executive Briefing Note

### Prompt Template
```
Draft an executive briefing note on the following topic:

**Topic**: {{TOPIC}}
**Audience**: {{C_SUITE | AVP | BOARD}}
**Purpose**: {{INFORM | DECIDE | APPROVE | ESCALATE}}
**Length**: {{1_PAGE | 2_PAGE}}

**Background**:
{{BACKGROUND}}

**Key Facts**:
{{KEY_FACTS}}

**Options / Recommendation**:
{{OPTIONS}}

**Decision Needed By**: {{DATE}}

Generate a briefing note with:
1. Purpose statement (1 sentence)
2. Background (3–4 sentences)
3. Key findings or situation (bullet points)
4. Options considered (if applicable)
5. Recommendation
6. Risks / Considerations
7. Next steps
8. Point of contact

Tone: Formal, precise, decision-enabling. Every sentence must earn its place.
```

---

# 🎧 Support Analyst Prompt Library

---

## SUP-01 — Incident Triage & Diagnosis

### Prompt Template
```
Triage the following support incident:

**Ticket ID**: {{TICKET_ID}}
**Priority**: {{P1 | P2 | P3 | P4}}
**Customer**: {{CUSTOMER_NAME | INTERNAL}}
**Reported Issue**:
{{ISSUE_DESCRIPTION}}

**Steps Already Tried by Customer**:
{{STEPS_TRIED}}

**Environment Details**:
{{ENV_DETAILS}}

**Logs / Screenshots Provided**:
{{ARTIFACTS}}

Provide:
1. **Likely root causes** (ranked by probability)
2. **Immediate diagnostic steps** to confirm root cause
3. **Workaround** (if available) to restore service now
4. **Resolution path** — short-term fix and permanent fix
5. **Escalation criteria** — when to escalate to L3/engineering
6. **Customer response draft** — empathetic, professional, actionable
7. **Knowledge base search terms** to find existing documentation
8. **Ticket classification** — category, subcategory, tags
```

---

## SUP-02 — Root Cause Analysis Report (ITIL)

### Prompt Template
```
Generate an ITIL-compliant Root Cause Analysis report for:

**Problem Record ID**: {{PROBLEM_ID}}
**Related Incidents**: {{INCIDENT_IDS}}
**Affected Service**: {{SERVICE_NAME}}
**Business Impact**: {{IMPACT}}
**Detection Date**: {{DATE}}
**Resolution Date**: {{DATE}}

**Incident Timeline**:
{{TIMELINE}}

**Technical Investigation Summary**:
{{INVESTIGATION}}

**Root Cause Identified**:
{{ROOT_CAUSE}}

Generate a formal Problem Management RCA Report:
1. Problem Record Header
2. Executive Summary (for service owner)
3. Impact Assessment (customers, transactions, SLA breach)
4. Timeline of Events
5. Technical Root Cause Analysis (5-Why)
6. Contributing Factors
7. Why Controls Failed
8. Remediation Actions (Immediate / Short-term / Long-term)
9. Prevention Measures
10. Known Error Record (workaround documented)
11. Lessons Learned
12. Action Item Register with owners and due dates
13. Closure Criteria

Format: ITIL best practice, ServiceNow-ready.
```

---

## SUP-03 — SEV1 Escalation Workflow

### Prompt Template
```
A SEV1 incident has been declared. Generate the escalation workflow:

**Service**: {{SERVICE_NAME}}
**Detection Time**: {{TIME}}
**Current Impact**: {{IMPACT_DESCRIPTION}}
**Assigned L1**: {{L1_ANALYST}}

Generate the SEV1 response checklist:

MINUTE 0–5: Detection & Declaration
MINUTE 5–15: Bridge Establishment & Triage
MINUTE 15–30: Escalation & Communication
MINUTE 30–60: Active Investigation
HOURLY: Stakeholder Updates
RESOLUTION: Closure & Handoff

For each phase provide:
- Actions (numbered)
- Responsible parties
- Communication templates
- Tools / commands to run
- Decision gates (escalate vs. continue)

Also generate:
- Bridge invitation template
- Customer/stakeholder update template (every 30 min)
- Incident Commander responsibilities checklist
- Post-incident review scheduling email
```
