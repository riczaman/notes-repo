# 🔐 Senior DevSecOps Analyst Prompt Library
**Role**: Senior DevSecOps Analyst | **Cloud**: Azure | **Platform**: AKS + GitHub Actions + Terraform | **Compliance**: SOC2, PCI-DSS

---

## Index

| # | Prompt Name | Category |
|---|-------------|----------|
| DSO-01 | CI/CD Pipeline Design & Security Gates | Technical |
| DSO-02 | Infrastructure as Code Review (Terraform) | Security |
| DSO-03 | Container Security Hardening | Security |
| DSO-04 | SAST/DAST/SCA Integration | Security |
| DSO-05 | Kubernetes Security Hardening | Security |
| DSO-06 | Secrets Management Architecture | Security |
| DSO-07 | Compliance as Code | Compliance |
| DSO-08 | Incident Response — Security Event | Incident |
| DSO-09 | Threat Modeling | Security |
| DSO-10 | Security Metrics & Reporting | Reporting |
| DSO-11 | Azure Policy & Governance | Governance |
| DSO-12 | Penetration Test Remediation Plan | Remediation |
| DSO-13 | Security Champions Program | Strategy |
| DSO-14 | Release Security Gate Checklist | Deployment |
| DSO-15 | Vulnerability Risk Prioritization | Risk |

---

## DSO-01 — CI/CD Pipeline Design & Security Gates

### Objective
Design a secure, enterprise-grade CI/CD pipeline with embedded security gates for financial services workloads on GitHub Actions + Azure.

### Context
```
You are a Senior DevSecOps Analyst building security into the software delivery pipeline.
Platform: GitHub Actions, Azure Container Registry (ACR), Azure Kubernetes Service (AKS).
Compliance: SOC2 Type II, PCI-DSS Level 1.
All artifacts must be signed and attested before production deployment.
```

### Prompt Template
```
Design a complete secure CI/CD pipeline for the following service:

**Service Name**: {{SERVICE_NAME}}
**Language/Runtime**: {{JAVA_17 | PYTHON | NODE}}
**Deployment Target**: Azure AKS — {{NAMESPACE}}
**Environment Progression**: dev → staging → production
**Release Cadence**: {{SPRINT_BASED | ON_DEMAND | HOTFIX}}
**Compliance**: SOC2, PCI-DSS

Generate a complete GitHub Actions workflow (YAML) that includes:

## BUILD STAGE
- Checkout with pinned action versions
- Dependency caching
- Maven/Gradle/pip build with SBOM generation (CycloneDX)
- Unit tests with JaCoCo coverage report (fail if <80%)

## SECURITY SCAN STAGE (run in parallel)
- SAST: CodeQL analysis
- SCA: OWASP Dependency Check (fail on CRITICAL CVEs)
- Secret Scanning: Gitleaks
- License compliance check

## CONTAINER STAGE
- Multi-stage Docker build (distroless base)
- Trivy image scan (fail on CRITICAL/HIGH CVEs)
- Image signing with Cosign (Sigstore)
- Push to ACR with SHA-pinned tag

## DEPLOYMENT STAGES (per environment)
- Helm upgrade with --atomic
- Readiness gate: wait for rollout
- Smoke test execution
- DAST scan (OWASP ZAP) — staging only
- Manual approval gate for production (required reviewer: Security Champion)

## COMPLIANCE STAGE
- SBOM attestation
- Audit log to Azure Monitor
- Policy compliance check (OPA Gatekeeper)

## ROLLBACK
- Automatic rollback on failed health check
- Notification to Teams channel

Include all environment variables with Azure Key Vault references, not hardcoded values.
Add inline comments explaining each security control and its compliance mapping.
```

### Expected Output
- Complete `.github/workflows/secure-cicd.yaml`
- Security gate summary table (gate → tool → compliance control)
- Required GitHub Secrets list
- Required Azure resources list

---

## DSO-02 — Infrastructure as Code Review (Terraform)

### Prompt Template
```
Review the following Terraform configuration for security, compliance, and best practices:

**Module/Resource Type**: {{RESOURCE_TYPE}} (e.g., AKS cluster, Azure SQL, Storage Account)
**Environment**: {{ENVIRONMENT}}
**Compliance**: PCI-DSS, SOC2

**Terraform Code**:
{{TERRAFORM_HCL}}

Perform a security-focused review covering:

1. **Authentication & Authorization**
   - RBAC configuration
   - Service principal / managed identity usage
   - No hardcoded credentials

2. **Network Security**
   - Private endpoints enabled
   - Public access disabled where possible
   - NSG rules — least privilege
   - Azure Firewall / DDoS protection

3. **Encryption**
   - Encryption at rest (CMK preferred for PCI scope)
   - Encryption in transit (TLS 1.2+ enforced)
   - Key Vault integration

4. **Logging & Monitoring**
   - Diagnostic settings enabled
   - Log Analytics workspace connected
   - Retention policies compliant

5. **Resource Governance**
   - Tags: required tags (Environment, Owner, CostCenter, DataClassification)
   - Resource locks on production
   - Azure Policy assignments

6. **Resilience**
   - Zone redundancy enabled
   - Backup policies configured
   - Geo-redundancy for critical data

Rate each finding: [BLOCKER | HIGH | MEDIUM | LOW | INFO]
Provide corrected Terraform code for each BLOCKER and HIGH finding.
```

---

## DSO-05 — Kubernetes Security Hardening

### Prompt Template
```
Generate a comprehensive Kubernetes security hardening specification for the following workload:

**Namespace**: {{NAMESPACE}}
**Workload Type**: {{DEPLOYMENT | STATEFULSET | DAEMONSET}}
**Data Classification**: {{PCI_SCOPE | PII | INTERNAL | PUBLIC}}
**Current Deployment YAML**:
{{CURRENT_YAML}}

Produce hardened Kubernetes manifests and policies for:

1. **Pod Security Standards** — Restricted profile enforcement
2. **SecurityContext** — per container:
   - runAsNonRoot: true
   - readOnlyRootFilesystem: true
   - allowPrivilegeEscalation: false
   - drop ALL capabilities
   - seccompProfile: RuntimeDefault

3. **Network Policies** — default deny, explicit allow rules
4. **Resource Limits** — CPU/memory requests and limits
5. **RBAC** — ServiceAccount with minimal permissions
6. **Image Policy** — only signed images from ACR (admission webhook)
7. **OPA Gatekeeper Constraints** — ConstraintTemplates for policy enforcement
8. **Pod Disruption Budget** — availability during disruptions
9. **Horizontal Pod Autoscaler** — scale on CPU/memory/custom metrics
10. **Secret Management** — Azure Key Vault CSI driver instead of K8s secrets

Output all as production-ready YAML files with inline comments.
```

---

## DSO-06 — Secrets Management Architecture

### Prompt Template
```
Design a comprehensive secrets management strategy for the following environment:

**Organization**: Financial Services Enterprise
**Cloud**: Azure
**Workloads**: Microservices on AKS, Azure Functions, Azure SQL
**Compliance**: PCI-DSS, SOC2

Current State:
{{CURRENT_SECRETS_APPROACH}}

Design:
1. **Azure Key Vault topology** — vault per environment, RBAC design
2. **Secret rotation strategy** — automated rotation for all secret types
3. **AKS integration** — Azure Key Vault CSI driver, pod identity
4. **Application integration** — Spring Cloud Azure Secrets, SDK patterns
5. **CI/CD integration** — GitHub Actions OIDC (no static credentials)
6. **Emergency break-glass** — procedure for credential emergency
7. **Audit logging** — Key Vault diagnostic logs → SIEM
8. **Secret classification** — types, owners, rotation frequency
9. **Terraform for Key Vault** — IaC for vault provisioning
10. **Detection** — alerts for secret access anomalies

Include:
- Architecture diagram (Mermaid)
- Secret rotation runbook
- Developer guide (how to consume secrets in Java/Spring Boot)
```

---

## DSO-08 — Security Incident Response

### Prompt Template
```
⚠️ SECURITY INCIDENT — RESPOND IMMEDIATELY

**Incident Type**: {{MALWARE | DATA_BREACH | UNAUTHORIZED_ACCESS | DDOS | INSIDER_THREAT}}
**Detection Source**: {{MICROSOFT_SENTINEL | GITHUB_ADVANCED_SECURITY | MANUAL | VENDOR_REPORT}}
**Detection Time**: {{TIME}}
**Affected Systems**: {{SYSTEMS}}
**Initial Indicators**:
{{INDICATORS_OF_COMPROMISE}}

Act as the Security Incident Response Lead. Provide:

1. **Immediate containment steps** (first 15 minutes)
   - Isolation actions
   - Evidence preservation commands
   - DO NOT DO list (avoid destroying forensic evidence)

2. **Triage classification**
   - Scope assessment
   - Data exposure determination
   - Breach notification obligation assessment (PIPEDA/GDPR timelines)

3. **Investigation steps**
   - Log analysis commands (Azure Monitor, Sentinel KQL queries)
   - Forensic artifact collection
   - Timeline reconstruction approach

4. **Stakeholder notifications** (with timing)
   - CISO notification (immediate)
   - Legal/Compliance (within 1 hour)
   - Executive/Board (within 4 hours for confirmed breach)
   - Regulator notification (as required by PIPEDA: 72 hours)

5. **Eradication & Recovery plan**

6. **Post-incident requirements**
   - Lessons learned format
   - Control improvements
   - Regulatory reporting

Draft the CISO notification email now.
```

---

## DSO-09 — Threat Modeling

### Prompt Template
```
Perform a STRIDE threat model for the following system:

**System**: {{SYSTEM_NAME}}
**Deployment**: Azure AKS, microservices
**External Interfaces**: {{EXTERNAL_INTERFACES}}
**Data Classification**: {{DATA_CLASSIFICATION}}

**Architecture Description**:
{{ARCHITECTURE_DESCRIPTION}}

**Data Flow Diagram** (described textually or as Mermaid):
{{DFD}}

Perform STRIDE analysis:

For each component and data flow, assess:
- **Spoofing** — identity and authentication threats
- **Tampering** — data integrity threats
- **Repudiation** — audit and non-repudiation threats
- **Information Disclosure** — confidentiality threats
- **Denial of Service** — availability threats
- **Elevation of Privilege** — authorization threats

For each threat:
- Threat ID
- Affected component
- Attack scenario
- Likelihood (1–5)
- Impact (1–5)
- DREAD score
- Current mitigations
- Recommended additional controls
- MITRE ATT&CK mapping (if applicable)

Output a threat register table and a prioritized remediation plan.
```

---

## DSO-14 — Release Security Gate Checklist

### Prompt Template
```
Generate a pre-release security gate checklist for the following release:

**Service**: {{SERVICE_NAME}}
**Version**: {{VERSION}}
**Release Type**: {{MAJOR | MINOR | PATCH | HOTFIX}}
**Data in Scope**: {{DATA_CLASSIFICATION}}

Generate a 40-item security gate checklist organized by category:

CATEGORY 1: Code Security (10 items)
CATEGORY 2: Container Security (8 items)
CATEGORY 3: Infrastructure Security (8 items)
CATEGORY 4: Data Security (6 items)
CATEGORY 5: Operational Security (8 items)

For each item include:
- Check description
- How to verify (command or tool)
- Pass criteria
- Owner (Developer | DevSecOps | Architect)
- Compliance mapping (SOC2 CC | PCI-DSS Req)

Output as a markdown checklist with checkboxes, suitable for use in GitHub PR template.
```
