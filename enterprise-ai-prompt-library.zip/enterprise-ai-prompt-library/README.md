# 🏛️ Enterprise AI Prompt Library Repository
### Production-Grade AI Engineering Operating System

> **Configuration**: Financial Services | Azure | SAFe Agile | Java/Spring Boot + Polyglot | GitHub Copilot + Claude | SOC2/PCI-DSS | Microservices on Kubernetes | Enterprise-Scale | Full Platform Integration

---

## 📋 Table of Contents

1. [Repository Overview](#repository-overview)
2. [Repository Structure](#repository-structure)
3. [Quick Start](#quick-start)
4. [Role Index](#role-index)
5. [Agent System](#agent-system)
6. [Governance Model](#governance-model)
7. [Integration Map](#integration-map)
8. [Contributing](#contributing)

---

## Repository Overview

This repository is an **Enterprise AI Engineering Operating System** — a production-grade prompt library, agent framework, skills catalog, and automation suite designed to accelerate delivery across every professional role in a modern financial services technology organization.

### Design Principles

| Principle | Description |
|-----------|-------------|
| **Role-Scoped** | Every prompt is authored for a specific persona with appropriate technical depth |
| **Compliance-First** | SOC2, PCI-DSS, and GDPR constraints embedded by default |
| **AI-Orchestrated** | Prompts are composable, chainable, and agent-ready |
| **Enterprise-Scale** | Designed for 1000+ engineer organizations with formal governance |
| **Platform-Native** | Native integration with Azure, GitHub Actions, Kubernetes, and Terraform |
| **Living System** | Versioned, reviewed quarterly, and maintained by designated owners |

---

## Repository Structure

```
enterprise-ai-prompt-library/
│
├── 📁 prompts/                    # Role-based prompt libraries
│   ├── senior-developer/
│   ├── senior-architect/
│   ├── business-analyst/
│   ├── product-manager/
│   ├── engineering-manager/
│   ├── executive-avp/
│   ├── qe-test-engineer/
│   ├── communications-analyst/
│   ├── devsecops-analyst/
│   └── support-analyst/
│
├── 📁 agents/                     # Autonomous AI agent definitions
│   ├── developer/
│   ├── architect/
│   ├── pm/
│   ├── devsecops/
│   ├── executive-comms/
│   ├── support/
│   └── testing/
│
├── 📁 skills/                     # Reusable skill markdown modules
│
├── 📁 templates/                  # Enterprise document templates
│   ├── brd/
│   ├── hld/
│   ├── lld/
│   ├── rfc/
│   ├── runbook/
│   ├── incident-report/
│   ├── executive-summary/
│   ├── status-report/
│   ├── migration-plan/
│   └── operational-readiness/
│
├── 📁 workflows/                  # Documented AI-assisted workflows
├── 📁 playbooks/                  # Operational playbooks
├── 📁 architecture/               # Architecture decision records (ADRs)
├── 📁 runbooks/                   # Live operational runbooks
├── 📁 documentation/              # System documentation
├── 📁 governance/                 # Governance policies & standards
│
├── 📁 pipelines/                  # CI/CD automation
│   ├── github-actions/
│   ├── azure-devops/
│   ├── terraform/
│   └── kubernetes/
│
├── 📁 support/                    # Support & incident management
├── 📁 testing/                    # QE frameworks & templates
├── 📁 communications/             # Executive communications
└── 📁 config/                     # VS Code, tooling configuration
```

---

## Quick Start

### Prerequisites
- VS Code 1.90+
- GitHub Copilot (licensed)
- Claude API access or Cursor IDE
- Azure CLI authenticated
- kubectl configured

### Setup
```bash
git clone https://github.com/your-org/enterprise-ai-prompt-library.git
cd enterprise-ai-prompt-library
code . --new-window
# Install recommended extensions when prompted
```

See [`config/vscode-setup.md`](config/vscode-setup.md) for full setup guide.

---

## Role Index

| Role | Prompt Location | Agent | Primary Skills |
|------|----------------|-------|---------------|
| Senior Developer | `prompts/senior-developer/` | `agents/developer/` | API Design, CI/CD, Kubernetes |
| Senior Architect | `prompts/senior-architect/` | `agents/architect/` | System Design, ADR, Modernization |
| Business Analyst | `prompts/business-analyst/` | — | BRD, Requirements, Stakeholder Mgmt |
| Product Manager | `prompts/product-manager/` | `agents/pm/` | Roadmap, OKRs, Feature Design |
| Engineering Manager | `prompts/engineering-manager/` | — | Team Health, Delivery Risk, Planning |
| Executive AVP | `prompts/executive-avp/` | `agents/executive-comms/` | Strategy, Risk, Board Reporting |
| QE/Test Engineer | `prompts/qe-test-engineer/` | `agents/testing/` | Test Strategy, Automation, Regression |
| Communications Analyst | `prompts/communications-analyst/` | `agents/executive-comms/` | Exec Comms, Incident Comms |
| DevSecOps Analyst | `prompts/devsecops-analyst/` | `agents/devsecops/` | Security Gates, Pipelines, Terraform |
| Support Analyst | `prompts/support-analyst/` | `agents/support/` | Incident Response, RCA, Escalation |

---

## Agent System

The multi-agent framework supports autonomous and semi-autonomous orchestration of AI workflows. See [`agents/AGENT-ORCHESTRATION.md`](agents/AGENT-ORCHESTRATION.md) for the full design.

```
User Request
     │
     ▼
┌─────────────────┐
│ Orchestrator    │ ◄── Routes by intent, role, severity
└────────┬────────┘
         │
    ┌────┴─────────────────────────────┐
    ▼          ▼           ▼           ▼
Developer   Architect   DevSecOps   Executive
  Agent      Agent       Agent      Comms Agent
```

---

## Governance Model

| Layer | Owner | Cadence |
|-------|-------|---------|
| Prompt authoring standards | AI Engineering Guild | Quarterly |
| Role prompt reviews | Each role's senior lead | Bi-annual |
| Agent behavior audits | AI Governance Committee | Monthly |
| Compliance review | InfoSec & Legal | Quarterly |
| Skills catalog updates | Architecture Chapter | Monthly |

---

## Integration Map

```yaml
integrations:
  source_control:   GitHub Enterprise
  ci_cd:            GitHub Actions + Azure DevOps
  cloud:            Microsoft Azure
  containers:       Azure Kubernetes Service (AKS)
  iac:              Terraform (AzureRM provider)
  ai_tooling:
    - GitHub Copilot
    - Claude (Anthropic)
    - Cursor IDE
  observability:    Azure Monitor + Grafana
  itil:             ServiceNow
  compliance:       SOC2 Type II, PCI-DSS Level 1
```

---

## Version

| Field | Value |
|-------|-------|
| Version | 1.0.0 |
| Last Updated | 2026-05 |
| Maintained By | AI Engineering Guild |
| License | Internal Enterprise Use Only |
