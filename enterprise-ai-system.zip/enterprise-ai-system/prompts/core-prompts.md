# Prompt: Incident Response Triage
# Agent: Support Engineer
# Version: 1.0.0
---
TASK: Triage the following incident. You have 5 minutes.

ALERT:
{{alert_details}}

RECENT DEPLOYMENTS:
{{recent_deployments}}

CURRENT SYSTEM HEALTH:
{{system_health}}

OUTPUT:
## 🚨 INCIDENT TRIAGE

**Severity:** [P1 | P2 | P3 | P4]
**Classification:** [Infrastructure | Application | Data | Security | External]
**Estimated Impact:** [% of users affected, services down]
**Initial Hypothesis:** [Most likely cause based on available signals]

**Immediate Actions:**
1. [Action — owner — deadline]
2. [Action — owner — deadline]

**Escalation Required:** [YES/NO — if YES: who and why]
**War Room Needed:** [YES/NO]
**Customer Communication Required:** [YES/NO — if YES: within N minutes]

**Next Update Due:** [HH:MM]

---

# Prompt: Sprint Planning
# Agent: Product Manager
# Version: 1.0.0
---
TASK: Facilitate sprint {{sprint_number}} planning.

INPUTS:
- Team capacity: {{capacity}} story points
- Sprint duration: {{duration}} days
- Prioritized backlog: {{backlog_items}}
- Previous velocity: {{previous_velocity}}
- Current blockers: {{blockers}}

OUTPUT:
## Sprint {{sprint_number}} Plan

**Sprint Goal:** [One clear sentence capturing the sprint's purpose]

**Selected Stories:**
| Story ID | Title | Points | Owner | Risk |
|----------|-------|--------|-------|------|
| ... | ... | ... | ... | ... |

**Total Committed:** {{total_points}} / {{capacity}} points

**Capacity Buffer:** {{buffer}}% (recommended: 15-20%)

**Dependencies:**
- [Dependency → owner → ETA → risk if delayed]

**Risks:**
- [Risk description → likelihood → mitigation]

**Stories Deferred and Why:**
- [Story ID] — [Reason: capacity | dependency | incomplete AC]

**Definition of Done for this Sprint:**
- [ ] All stories meet DoD checklist
- [ ] QE sign-off obtained
- [ ] Performance benchmarks maintained
- [ ] Documentation updated

---

# Prompt: Architecture Decision Record (ADR)
# Agent: Enterprise Architect
# Version: 1.0.0
---
TASK: Generate an Architecture Decision Record for the following decision.

CONTEXT:
- Decision title: {{title}}
- Background: {{background}}
- Constraints: {{constraints}}
- Stakeholders: {{stakeholders}}
- Related ADRs: {{related_adrs}}

OUTPUT — Follow this EXACT structure:

# ADR-{{number}}: {{title}}

**Date:** {{date}}
**Status:** Proposed
**Deciders:** {{deciders}}
**Reviewed by:** {{reviewers}}

## Context and Problem Statement

[2-3 paragraphs: what is the situation, what problem are we solving, what forces are at play]

## Decision Drivers

- [Driver 1: business need, constraint, or architectural principle]
- [Driver 2]
- [Driver 3]

## Considered Options

1. **Option A:** [Name]
2. **Option B:** [Name]
3. **Option C (if applicable):** [Name]

## Decision Outcome

**Chosen option:** Option [X], because [concise justification tied to decision drivers].

### Positive Consequences
- [Benefit 1]
- [Benefit 2]

### Negative Consequences (and mitigations)
- [Trade-off 1] → Mitigation: [how we address it]
- [Trade-off 2] → Mitigation: [how we address it]

## Pros and Cons of the Options

### Option A: [Name]
- ✅ Pro: [...]
- ✅ Pro: [...]
- ❌ Con: [...]
- ❌ Con: [...]

### Option B: [Name]
- ✅ Pro: [...]
- ❌ Con: [...]
- ❌ Con: [...]

## Trade-off Matrix

| Criterion | Option A | Option B | Option C | Weight |
|-----------|----------|----------|----------|--------|
| Cost | ... | ... | ... | 20% |
| Scalability | ... | ... | ... | 25% |
| Security | ... | ... | ... | 20% |
| Complexity | ... | ... | ... | 15% |
| Vendor Risk | ... | ... | ... | 10% |
| Team Capability | ... | ... | ... | 10% |
| **Score** | **X.X** | **X.X** | **X.X** | |

## Risk Register

| Risk | Likelihood | Impact | Mitigation | Owner |
|------|-----------|--------|-----------|-------|
| ... | H/M/L | H/M/L | ... | ... |

## Implementation Notes

[Key implementation guidance, sequencing, dependencies]

## Review Date

This ADR should be reviewed on {{review_date}} or when [trigger condition].

---

# Prompt: Executive Engineering Report
# Agent: Communications Specialist
# Version: 1.0.0
---
TASK: Generate the monthly engineering summary for executive audience.

SOURCE DATA:
- OKR performance: {{okr_data}}
- Sprint metrics: {{sprint_metrics}}
- Quality metrics: {{quality_metrics}}
- Incidents: {{incident_data}}
- Budget: {{budget_data}}
- Team: {{team_data}}
- Risks: {{risk_register}}

AUDIENCE: {{audience}} (Executive level — non-technical)

RULES:
- Lead with business impact, not technical metrics
- Every metric needs context (is this good or bad? vs. target?)
- Risks framed as: what could go wrong + what we're doing about it
- Decisions needed clearly separated and actionable
- Plain English — no jargon
- One page maximum

OUTPUT:
# Engineering Update — {{month}} {{year}}
*Prepared for {{audience}} | Confidential*

## Headline
[One sentence: the most important thing executives should know this month]

## Delivery Performance
[2-3 bullet points, business-language, with trend indicators ↑↓→]

## Quality & Reliability
[2-3 bullet points, customer impact framing]

## Team & Investment
[Headcount, budget burn vs plan, any highlights]

## Key Risks
🔴 [Critical risk — what it is, business impact, mitigation]
🟡 [Moderate risk — what it is, what we're watching]
🟢 [Risk managed — brief note]

## Decisions Required
1. **[Decision]** — Recommendation: [X] — Deadline: [date]
2. **[Decision]** — Recommendation: [X] — Deadline: [date]

## Next Month Preview
[1-2 sentences on what's coming]
