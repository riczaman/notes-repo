# Getting Started Playbook

## Phase 1: Initial Setup (30 min)
1. Clone the repo and enter the directory
2. Copy `.env.example` to `.env` — add your Anthropic API key
3. Run: `pip install -r requirements.txt`
4. Run: `docker-compose -f scripts/docker-compose.memory.yml up -d`
5. Test: `python scripts/orchestrator.py`

## Phase 2: VS Code (15 min)
1. Open folder in VS Code
2. Install recommended extensions when prompted
3. Press Cmd+Shift+P → Tasks: Run Task → Agent Health Check

## Phase 3: Claude Desktop (10 min)
1. Install Claude Desktop from claude.ai/desktop
2. Add MCP config from README into Claude Desktop config file
3. Restart Claude Desktop

## Phase 4: First Agent Invocation
```bash
python scripts/orchestrator.py
You: Review this code for security issues: [paste code]
# Auto-routes to Senior Developer agent
```

## Phase 5: Customize
1. Edit agent .md files to match your team's standards
2. Update orchestration.yaml with your tool tokens
3. Run validate-agents.py to confirm all is valid
