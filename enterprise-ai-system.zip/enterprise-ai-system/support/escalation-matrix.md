# Escalation Matrix

## By Severity
| Severity | Response SLA | Escalate To |
|----------|-------------|-------------|
| P1 | 5 min | Support → DevSecOps → AVP |
| P2 | 15 min | Support → Senior Dev |
| P3 | 1 hour | Support → Senior Dev |
| P4 | Next day | QE Backlog |

## By Domain
| Issue | First Contact | L1 | L2 |
|-------|-------------|----|----|
| App bug | Support Eng | Senior Dev | Enterprise Arch |
| Infrastructure | DevSecOps | Enterprise Arch | AVP |
| Security | DevSecOps | Enterprise Arch | AVP + CISO |
