# Technology Radar
**Last Updated:** 2025-Q2 | **Owner:** Enterprise Architect

## ADOPT
| Technology | Category | Notes |
|-----------|----------|-------|
| GitHub Actions | CI/CD | Standard pipeline |
| Terraform | IaC | Infrastructure provisioning |
| Kubernetes | Platform | Container orchestration |
| Anthropic Claude | AI/LLM | Primary AI model |
| Qdrant | Vector DB | AI memory store |

## TRIAL
| Technology | Category | Notes |
|-----------|----------|-------|
| Ollama | Local LLM | Local model serving |
| ArgoCD | GitOps | CD for Kubernetes |
| Playwright | Testing | E2E automation |

## HOLD
| Technology | Reason |
|-----------|--------|
| Jenkins | Replacing with GitHub Actions |
