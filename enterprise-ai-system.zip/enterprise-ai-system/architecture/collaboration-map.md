# Agent Collaboration Map

```mermaid
graph TD
    AVP[Executive AVP]:::strategic
    EA[Enterprise Architect]:::strategic
    PM[Product Manager]:::strategic
    SD[Senior Developer]:::execution
    QE[QE Lead]:::execution
    BA[Business Analyst]:::execution
    CS[Communications Specialist]:::execution
    DSO[DevSecOps Engineer]:::infra
    SE[Support Engineer]:::infra

    AVP -->|strategic direction| EA
    AVP -->|investment decisions| PM
    EA -->|architecture approval| SD
    PM -->|stories + AC| SD
    PM -->|sprint scope| QE
    BA -->|validated requirements| PM
    CS -->|executive reports| AVP
    SD -->|code + PR| QE
    SD -->|deployment request| DSO
    QE -->|quality gate| PM
    DSO -->|pipeline + infra| SD
    SE -->|incidents| DSO
    SE -->|bug reports| SD
    CS -->|incident comms| SE

    classDef strategic fill:#7c3aed,color:#fff
    classDef execution fill:#2563eb,color:#fff
    classDef infra fill:#dc2626,color:#fff
```
