# Enterprise AI Operating System
## Implementation Guide & Reference

> **Production-grade AI agent ecosystem for enterprise engineering delivery**

---

## Quick Start

```bash
# 1. Clone and enter the repository
git clone https://github.com/your-org/enterprise-ai-os.git
cd enterprise-ai-os

# 2. Set environment variables
cp .env.example .env
# Edit .env with your API keys and configuration

# 3. Start memory services
docker-compose -f scripts/docker-compose.memory.yml up -d

# 4. Install Python dependencies
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 5. Validate configuration
python scripts/validate-agents.py --dir agents/

# 6. Start the orchestrator
python scripts/orchestrator.py --config workflows/orchestration.yaml
```

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    ENTERPRISE AI OS                          │
├─────────────────┬───────────────────┬───────────────────────┤
│  STRATEGIC TIER │  EXECUTION TIER   │  INFRASTRUCTURE TIER  │
│                 │                   │                       │
│  Executive AVP  │  Senior Developer │  DevSecOps Engineer   │
│  Enterprise     │  QE Lead          │  Support Engineer     │
│  Architect      │  Business Analyst │                       │
│  Product Manager│  Comms Specialist │                       │
├─────────────────┴───────────────────┴───────────────────────┤
│                    ORCHESTRATION LAYER                       │
│         Intent Router → Agent Selector → Context Injector   │
├─────────────────────────────────────────────────────────────┤
│                      MEMORY LAYER                            │
│    Short-term (Redis) │ Long-term (Qdrant) │ Structured (PG) │
├─────────────────────────────────────────────────────────────┤
│                      TOOL LAYER                              │
│  GitHub │ Jira │ Confluence │ Datadog │ Vault │ PagerDuty   │
└─────────────────────────────────────────────────────────────┘
```

---

## Repository Structure

```
enterprise-ai-system/
│
├── agents/                    # Agent definitions (markdown)
│   ├── senior-developer.md
│   ├── enterprise-architect.md
│   ├── product-manager.md
│   ├── devsecops-engineer.md
│   ├── qe-lead.md
│   ├── support-engineer.md
│   └── remaining-agents.md   # BA, Comms, AVP
│
├── prompts/                   # Reusable prompt templates
│   ├── code-review.prompt
│   ├── incident-response.prompt
│   ├── sprint-planning.prompt
│   ├── executive-report.prompt
│   └── adr-template.prompt
│
├── skills/                    # Shared agent skills/capabilities
│   ├── code-analysis.skill
│   ├── diagram-generation.skill
│   ├── metrics-reporting.skill
│   └── communication.skill
│
├── templates/                 # Output templates
│   ├── adr-template.md
│   ├── post-mortem-template.md
│   ├── sprint-report-template.md
│   ├── test-plan-template.md
│   ├── pr-description-template.md
│   └── executive-brief-template.md
│
├── playbooks/                 # Operational playbooks
│   ├── incident-response.md
│   ├── release-process.md
│   ├── sprint-ceremony.md
│   └── onboarding.md
│
├── workflows/                 # Orchestration configuration
│   ├── orchestration.yaml     # Master orchestration config
│   ├── routing-rules.yaml     # Intent routing rules
│   └── memory-config.yaml     # Memory store configuration
│
├── architecture/              # Architecture artifacts
│   ├── collaboration-map.svg  # Agent interaction diagram
│   ├── system-topology.md     # Infrastructure overview
│   ├── data-flow.md           # Data flow documentation
│   └── security-architecture.md
│
├── pipelines/                 # CI/CD pipeline templates
│   ├── node-service.yml       # Node.js service pipeline
│   ├── python-service.yml     # Python service pipeline
│   ├── java-service.yml       # Java service pipeline
│   └── infrastructure.yml     # IaC pipeline
│
├── governance/                # Governance documents
│   ├── adr-registry.md        # ADR index
│   ├── technology-radar.md    # Tech radar
│   ├── security-policy.md     # Security baseline
│   └── compliance-matrix.md   # Control mapping
│
├── testing/                   # Agent test suite
│   ├── unit/                  # Unit tests per agent
│   ├── routing/               # Routing logic tests
│   ├── integration/           # Integration tests
│   └── fixtures/              # Test fixtures
│
├── support/                   # Support operations
│   ├── runbooks/              # Operational runbooks
│   ├── escalation-matrix.md   # Who to call when
│   └── sla-definitions.md     # SLA documentation
│
├── communications/            # Communication assets
│   ├── templates/             # Email, Slack templates
│   ├── style-guide.md         # Brand and writing style
│   └── release-notes/         # Release communication archive
│
├── docs/                      # Documentation
│   ├── getting-started.md
│   ├── agent-development-guide.md
│   ├── integration-guide.md
│   └── api-reference.md
│
├── scripts/                   # Operational scripts
│   ├── orchestrator.py        # Main orchestrator
│   ├── mcp-server.js          # MCP server for VS Code
│   ├── validate-agents.py     # Config validation
│   ├── invoke-agent.py        # CLI agent invocation
│   ├── smoke-tests.py         # Deployment validation
│   ├── health-check.py        # System health
│   └── docker-compose.memory.yml
│
├── .vscode/                   # VS Code configuration
│   ├── settings.json          # Editor settings + MCP config
│   ├── extensions.json        # Recommended extensions
│   ├── tasks.json             # Task runner
│   └── launch.json            # Debug configuration
│
├── .github/                   # GitHub configuration
│   └── workflows/
│       ├── ci-cd.yml          # Main CI/CD pipeline
│       ├── security-scan.yml  # Scheduled security scans
│       └── agent-tests.yml    # Agent behavioral tests
│
├── .env.example               # Environment variable template
├── requirements.txt           # Python dependencies
├── Dockerfile                 # Container definition
└── README.md                  # This file
```

---

## Agent Overview

| Agent | Role | Tier | Primary Domain |
|-------|------|------|----------------|
| Senior Developer | Code implementation, reviews | Execution | Software Delivery |
| Enterprise Architect | Design decisions, ADRs | Strategic-Execution | Architecture |
| Product Manager | Backlog, stories, metrics | Strategic-Execution | Product Management |
| DevSecOps Engineer | Pipelines, security, infra | Execution-Infra | DevSecOps |
| QE Lead | Testing, quality gates | Execution | Quality Engineering |
| Support Engineer | Incidents, operations | Execution-Ops | Production Support |
| Business Analyst | Requirements, process | Strategic-Execution | Requirements |
| Communications Specialist | Reports, announcements | Strategic | Communications |
| Executive AVP | Strategy, governance | Strategic | Leadership |

---

## IDE Integration Setup

### VS Code + GitHub Copilot

```bash
# Install VS Code extensions
code --install-extension GitHub.copilot
code --install-extension GitHub.copilot-chat

# The .vscode/settings.json configures:
# - Copilot enabled for all file types
# - MCP server integration with agent orchestrator
# - Agent-aware snippets and file associations
```

### Claude Desktop Integration

1. Install Claude Desktop from https://claude.ai/desktop
2. Add MCP server to Claude Desktop config:

```json
// ~/Library/Application Support/Claude/claude_desktop_config.json
{
  "mcpServers": {
    "enterprise-ai-os": {
      "command": "node",
      "args": ["/path/to/enterprise-ai-system/scripts/mcp-server.js"],
      "env": {
        "AGENT_CONFIG": "/path/to/enterprise-ai-system/workflows/orchestration.yaml"
      }
    }
  }
}
```

3. Restart Claude Desktop — agents will be available as MCP tools

### Cursor Integration

```json
// .cursor/mcp.json
{
  "mcpServers": {
    "enterprise-ai-os": {
      "command": "node",
      "args": ["./scripts/mcp-server.js"]
    }
  }
}
```

In Cursor settings, enable MCP and the enterprise-ai-os server will provide agent-aware completions.

### Local LLM Integration (Ollama)

```yaml
# workflows/orchestration.yaml — override model_provider for local
orchestration:
  model_provider: ollama          # Switch from anthropic
  local_models:
    default: llama3.2:8b
    code_tasks: deepseek-coder:6.7b
    architecture: mistral:7b
  ollama_host: http://localhost:11434

  # Agent-level overrides
  agents:
    senior-developer:
      model: deepseek-coder:6.7b  # Code-specialized local model
    enterprise-architect:
      model: mixtral:8x7b          # Larger model for complex reasoning
```

```bash
# Start Ollama and pull required models
ollama pull llama3.2:8b
ollama pull deepseek-coder:6.7b
ollama pull mixtral:8x7b

# Configure the orchestrator for local models
export AGENT_MODEL_PROVIDER=ollama
python scripts/orchestrator.py --config workflows/orchestration.yaml
```

---

## Prompt Management

### Prompt Template Structure

```
prompts/
├── {agent-name}/
│   ├── system.prompt           # Agent system prompt
│   ├── {task-name}.prompt      # Task-specific prompts
│   └── examples/               # Few-shot examples
│       ├── {task-name}-01.md
│       └── {task-name}-02.md
└── shared/
    ├── chain-of-thought.prompt  # Reasoning templates
    ├── output-format.prompt     # Format instructions
    └── safety.prompt            # Safety constraints
```

### Prompt Version Control

All prompts are version-controlled in Git. Changes to production prompts require:
1. PR with prompt change
2. A/B test results showing improvement
3. QE review of behavioral changes
4. Enterprise Architect approval for system-prompt changes

### Prompt Chaining

```python
# Example: Feature delivery chain
chain = PromptChain([
    ("business-analyst", "validate_requirements.prompt"),
    ("enterprise-architect", "design_review.prompt", condition="complexity >= HIGH"),
    ("senior-developer", "implement_feature.prompt"),
    ("qe-lead", "test_and_validate.prompt"),
    ("product-manager", "accept_story.prompt"),
])

result = await chain.execute(context={
    "story_id": "ENG-1042",
    "acceptance_criteria": [...],
})
```

---

## Governance Framework

### Decision Authority Matrix

| Decision Type | Agent Authority | Escalation Path |
|--------------|-----------------|-----------------|
| Code implementation | Senior Developer | Enterprise Architect |
| Architecture decision | Enterprise Architect | AVP |
| Sprint scope | Product Manager | AVP |
| Security policy | DevSecOps Engineer | Enterprise Architect → AVP |
| Release sign-off | QE Lead + PM | AVP (if conflict) |
| Investment >$50K | AVP | CTO |
| Production deploy | DevSecOps + PM | AVP (emergency) |

### Quality Gates

Every stage in the delivery pipeline has automated quality gates:

```
Commit → [Secret Scan] → [Lint] → [Unit Tests] → [Coverage Check]
         ↓
PR Created → [SAST] → [SCA] → [Peer Review] → [Architecture Check]
             ↓
Merge → [Integration Tests] → [Container Scan] → [Deploy Staging]
        ↓
Staging → [E2E Tests] → [Performance] → [DAST] → [QE Sign-off]
          ↓
Production → [Smoke Tests] → [Canary Monitor] → [Full Deploy]
```

---

## Environment Variables

```bash
# .env.example

# AI Model Configuration
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_MODEL=claude-sonnet-4-20250514

# Memory Stores
REDIS_URL=redis://localhost:6379
QDRANT_URL=http://localhost:6333
DATABASE_URL=postgresql://user:pass@localhost:5432/agent_memory

# Tool Integrations
GITHUB_TOKEN=ghp_...
JIRA_URL=https://your-org.atlassian.net
JIRA_API_TOKEN=...
CONFLUENCE_URL=https://your-org.atlassian.net/wiki
DATADOG_API_KEY=...
PAGERDUTY_API_KEY=...
VAULT_ADDR=https://vault.your-org.com
VAULT_TOKEN=...
SLACK_BOT_TOKEN=xoxb-...

# Orchestrator Settings
AGENT_ENV=production
LOG_LEVEL=INFO
AUDIT_LOG_ENABLED=true
RATE_LIMIT_PER_MINUTE=100
```

---

## Security Baseline

All agents operate under these security constraints:

1. **No hardcoded credentials** — all secrets via Vault
2. **Audit logging** — every agent interaction logged
3. **Rate limiting** — per-agent and system-wide
4. **Input validation** — all inputs sanitized before processing
5. **Output filtering** — PII detection on all outputs
6. **MFA required** — for all human access to the system
7. **Least privilege** — agents have minimal required permissions
8. **Encryption at rest and in transit** — all data encrypted

---

## Support & Contributing

- **Issues:** GitHub Issues with agent label
- **Escalations:** See `support/escalation-matrix.md`
- **Agent Development:** See `docs/agent-development-guide.md`
- **Runbooks:** See `support/runbooks/`

---

## License

Enterprise Internal — Confidential  
© 2025 Your Organization. All rights reserved.
