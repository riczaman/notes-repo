#!/usr/bin/env node
/**
 * Enterprise AI OS — MCP Server
 * Exposes agents as MCP tools for VS Code, Claude Desktop, and Cursor
 */

const readline = require('readline');

const AGENTS = [
  'senior-developer', 'enterprise-architect', 'product-manager',
  'devsecops-engineer', 'qe-lead', 'support-engineer',
  'business-analyst', 'communications-specialist', 'executive-avp'
];

const tools = AGENTS.map(id => ({
  name: `invoke_${id.replace(/-/g, '_')}`,
  description: `Invoke the ${id} agent with a task or question`,
  inputSchema: {
    type: 'object',
    properties: {
      prompt: { type: 'string', description: 'The task or question for the agent' },
      context: { type: 'string', description: 'Optional additional context' }
    },
    required: ['prompt']
  }
}));

// MCP protocol: respond to JSON-RPC over stdio
const rl = readline.createInterface({ input: process.stdin });
rl.on('line', (line) => {
  try {
    const req = JSON.parse(line);
    let response;
    if (req.method === 'tools/list') {
      response = { jsonrpc: '2.0', id: req.id, result: { tools } };
    } else if (req.method === 'tools/call') {
      const agentId = req.params.name.replace('invoke_', '').replace(/_/g, '-');
      response = {
        jsonrpc: '2.0', id: req.id,
        result: { content: [{ type: 'text', text: `[${agentId}] Ready. Prompt: ${req.params.arguments.prompt}\n\nNote: Connect ANTHROPIC_API_KEY and run orchestrator.py for live responses.` }] }
      };
    } else {
      response = { jsonrpc: '2.0', id: req.id, result: {} };
    }
    process.stdout.write(JSON.stringify(response) + '\n');
  } catch (e) {}
});
