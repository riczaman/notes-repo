#!/usr/bin/env python3
"""
Enterprise AI Operating System — Main Orchestrator
Routes requests to the appropriate agent based on intent.
"""

import os
import json
import yaml
import anthropic
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# Load orchestration config
CONFIG_PATH = Path(__file__).parent.parent / "workflows" / "orchestration.yaml"
with open(CONFIG_PATH) as f:
    config = yaml.safe_load(f)

client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

AGENTS = {
    "senior-developer":         Path("agents/senior-developer.md"),
    "enterprise-architect":     Path("agents/enterprise-architect.md"),
    "product-manager":          Path("agents/product-manager.md"),
    "devsecops-engineer":       Path("agents/devsecops-engineer.md"),
    "qe-lead":                  Path("agents/qe-lead.md"),
    "support-engineer":         Path("agents/support-engineer.md"),
}

def load_agent_prompt(agent_id: str) -> str:
    """Load the system prompt section from an agent markdown file."""
    agent_file = Path(__file__).parent.parent / AGENTS.get(agent_id, "")
    if not agent_file.exists():
        return f"You are a helpful {agent_id} assistant."
    content = agent_file.read_text()
    # Extract system prompt block
    if "```\nYou are" in content:
        start = content.index("```\nYou are") + 4
        end = content.index("\n```", start)
        return content[start:end]
    return content[:2000]

def route_to_agent(user_message: str) -> str:
    """Simple intent-based routing."""
    msg = user_message.lower()
    if any(k in msg for k in ["code", "implement", "bug", "pr", "review", "function"]):
        return "senior-developer"
    if any(k in msg for k in ["architecture", "adr", "design", "system", "scalab"]):
        return "enterprise-architect"
    if any(k in msg for k in ["story", "backlog", "sprint", "okr", "roadmap", "stakeholder"]):
        return "product-manager"
    if any(k in msg for k in ["pipeline", "deploy", "security", "infra", "terraform", "cve"]):
        return "devsecops-engineer"
    if any(k in msg for k in ["test", "quality", "defect", "bug report", "coverage"]):
        return "qe-lead"
    if any(k in msg for k in ["incident", "outage", "alert", "p1", "p2", "down"]):
        return "support-engineer"
    return "product-manager"  # default

def invoke_agent(agent_id: str, user_message: str) -> str:
    """Invoke a specific agent with a message."""
    system_prompt = load_agent_prompt(agent_id)
    print(f"\n🤖 Routing to: {agent_id.upper()}\n{'─'*50}")
    response = client.messages.create(
        model=config["orchestration"]["primary_model"],
        max_tokens=2048,
        system=system_prompt,
        messages=[{"role": "user", "content": user_message}]
    )
    return response.content[0].text

def run_interactive():
    """Run interactive CLI session."""
    print("🚀 Enterprise AI Operating System")
    print("   Type 'exit' to quit, 'agent:<name>' to force a specific agent\n")
    while True:
        user_input = input("You: ").strip()
        if not user_input or user_input.lower() == "exit":
            break
        # Allow forcing an agent
        forced_agent = None
        if user_input.startswith("agent:"):
            parts = user_input.split(" ", 1)
            forced_agent = parts[0].replace("agent:", "")
            user_input = parts[1] if len(parts) > 1 else ""
        agent_id = forced_agent or route_to_agent(user_input)
        response = invoke_agent(agent_id, user_input)
        print(f"\n{response}\n")

if __name__ == "__main__":
    run_interactive()
