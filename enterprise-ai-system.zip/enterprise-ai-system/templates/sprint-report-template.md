# Sprint {{NUMBER}} Report
**Period:** YYYY-MM-DD to YYYY-MM-DD | **Goal:** [Sprint Goal]

## Status: 🟢 On Track

## Velocity
| Metric | Target | Actual |
|--------|--------|--------|
| Story Points | X | X |

## Completed Stories
| ID | Title | Points |
|----|-------|--------|

## Blockers & Risks
[List with owner and mitigation]
