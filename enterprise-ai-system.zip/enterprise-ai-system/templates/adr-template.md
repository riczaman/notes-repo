# ADR-XXXX: [Title]
**Date:** YYYY-MM-DD | **Status:** Proposed | **Deciders:** [Names]

## Context
[What is the situation and problem?]

## Decision
[What was decided?]

## Consequences
[Results — good and bad]

## Alternatives Considered
| Option | Pros | Cons |
|--------|------|------|

## Risk Register
| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|

## Review Date: YYYY-MM-DD
