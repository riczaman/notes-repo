# Post-Mortem: [Incident Title]
**ID:** INC-XXXX | **Date:** YYYY-MM-DD | **Duration:** X min | **Severity:** P1/P2

## Impact
| Users Affected | Duration | Revenue Impact |
|---------------|----------|----------------|

## Timeline
| Time (UTC) | Event |
|------------|-------|

## Root Cause
[Technical description]

## Five Whys
1. Why? → 2. Why? → 3. Why? → 4. Why? → 5. **Root cause**

## Action Items
| Action | Owner | Due | Priority |
|--------|-------|-----|----------|
