import { promises as fs } from 'node:fs';
import path from 'node:path';
import { env } from '../config/env';

/**
 * Minimal persistence driver over a directory of JSON arrays.
 *
 * Two properties matter and are the reason this is a class rather than bare
 * fs calls scattered through the repositories:
 *
 * 1. Writes are serialised per file. Node is single threaded but `await`
 *    interleaves, so two concurrent PATCHes could otherwise read-modify-write
 *    over each other. Each file gets a promise chain that acts as a mutex.
 * 2. Writes are atomic. We write a temp file and rename it, so a crash mid-write
 *    can never leave a half-written file that the app then fails to parse.
 *
 * Files are re-read on every access rather than cached, which is deliberate:
 * the requirement is that JSON files stay hand-editable while the server runs.
 */
export class JsonFileStore {
  private readonly writeQueues = new Map<string, Promise<unknown>>();

  constructor(private readonly dir: string = env.dataDir) {}

  private filePath(file: string): string {
    return path.join(this.dir, file);
  }

  async read<T>(file: string): Promise<T[]> {
    try {
      const raw = await fs.readFile(this.filePath(file), 'utf8');
      const trimmed = raw.trim();
      if (!trimmed) return [];
      const parsed = JSON.parse(trimmed);
      if (!Array.isArray(parsed)) {
        throw new Error(`${file} must contain a JSON array at the top level.`);
      }
      return parsed as T[];
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        await this.write(file, []);
        return [];
      }
      if (error instanceof SyntaxError) {
        throw new Error(`${file} is not valid JSON. Fix the file and retry. (${error.message})`);
      }
      throw error;
    }
  }

  async write<T>(file: string, rows: T[]): Promise<void> {
    await fs.mkdir(this.dir, { recursive: true });
    const target = this.filePath(file);
    const temp = `${target}.${process.pid}.tmp`;
    await fs.writeFile(temp, `${JSON.stringify(rows, null, env.jsonIndent)}\n`, 'utf8');
    await fs.rename(temp, target);
  }

  /**
   * Read, transform, write - with no other mutation of the same file interleaving.
   * Every repository write goes through here.
   */
  async mutate<T, R>(file: string, mutator: (rows: T[]) => Promise<{ rows: T[]; result: R }> | { rows: T[]; result: R }): Promise<R> {
    const previous = this.writeQueues.get(file) ?? Promise.resolve();
    const run = previous.then(async () => {
      const rows = await this.read<T>(file);
      const { rows: next, result } = await mutator(rows);
      await this.write(file, next);
      return result;
    });
    // Keep the chain alive even if this operation rejects.
    this.writeQueues.set(
      file,
      run.catch(() => undefined),
    );
    return run;
  }

  async listFiles(): Promise<string[]> {
    await fs.mkdir(this.dir, { recursive: true });
    const entries = await fs.readdir(this.dir);
    return entries.filter((name) => name.endsWith('.json'));
  }
}

export const jsonFileStore = new JsonFileStore();
