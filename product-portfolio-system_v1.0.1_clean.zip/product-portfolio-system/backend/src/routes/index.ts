import { Router } from 'express';
import { ENTITY_DESCRIPTORS } from '@shared';
import { CrudController } from '../controllers/CrudController';
import { insightsController } from '../controllers/InsightsController';
import { asyncHandler } from '../core/http';

/**
 * Routes are generated from the shared entity registry.
 *
 * Thirteen collections x five verbs is 65 endpoints that would otherwise be 65
 * near-identical hand-written route files. Adding a collection means adding a
 * registry entry and a JSON file - the API surface follows automatically.
 */
const crudRouter = (): Router => {
  const router = Router();

  for (const descriptor of ENTITY_DESCRIPTORS) {
    const controller = new CrudController(descriptor.name);
    const base = `/${descriptor.path}`;

    router.get(base, asyncHandler(controller.list));
    router.post(base, asyncHandler(controller.create));
    // Registered before /:id so "bulk" is never read as an identifier.
    router.patch(`${base}/bulk`, asyncHandler(controller.bulk));
    router.get(`${base}/:id`, asyncHandler(controller.get));
    router.put(`${base}/:id`, asyncHandler(controller.update));
    router.patch(`${base}/:id`, asyncHandler(controller.update));
    router.delete(`${base}/:id`, asyncHandler(controller.remove));
  }

  return router;
};

export const apiRouter = (): Router => {
  const router = Router();

  router.get('/health', (_req, res) => {
    res.json({ data: { status: 'ok', uptimeSeconds: Math.round(process.uptime()) } });
  });

  router.get('/meta/entities', asyncHandler(insightsController.meta));
  router.get('/dashboard/summary', asyncHandler(insightsController.dashboard));
  router.get('/search', asyncHandler(insightsController.search));
  router.get('/graph/dependencies', asyncHandler(insightsController.dependencyGraph));

  // Specific application route must be declared before the generic /applications/:id.
  router.get('/applications/:id/overview', asyncHandler(insightsController.applicationOverview));

  router.use(crudRouter());
  return router;
};
