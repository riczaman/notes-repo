import type { Request, Response } from 'express';
import type { EntityName } from '@shared';
import { HttpStatus, sendItem, sendList } from '../core/http';
import { BadRequestError } from '../core/errors';
import { getService } from '../services';
import type { CrudService } from '../services/CrudService';
import type { Identified } from '../repositories/Repository';

/**
 * Thin HTTP adapter. Controllers translate request/response only - no business
 * rules, no file access. One instance serves every collection because the shape
 * of a REST resource does not vary between them.
 */
export class CrudController {
  constructor(private readonly entity: EntityName) {}

  /**
   * The controller is deliberately entity-agnostic, so it works against the
   * base record shape. Per-entity typing lives in the shared schemas and is
   * enforced by the service, not here.
   */
  private get service(): CrudService<Identified> {
    return getService(this.entity) as unknown as CrudService<Identified>;
  }

  list = async (req: Request, res: Response) => {
    const { data, meta } = await this.service.list(req.query as Record<string, unknown>);
    sendList(res, data, meta);
  };

  get = async (req: Request, res: Response) => {
    sendItem(res, await this.service.get(req.params.id));
  };

  create = async (req: Request, res: Response) => {
    sendItem(res, await this.service.create(req.body), HttpStatus.CREATED);
  };

  update = async (req: Request, res: Response) => {
    sendItem(res, await this.service.update(req.params.id, req.body));
  };

  remove = async (req: Request, res: Response) => {
    await this.service.remove(req.params.id);
    res.status(HttpStatus.NO_CONTENT).end();
  };

  /** PATCH /:entity/bulk - used by drag-and-drop so a board move is one request. */
  bulk = async (req: Request, res: Response) => {
    const body = req.body as { updates?: { id: string; patch: unknown }[] };
    if (!Array.isArray(body?.updates)) {
      throw new BadRequestError('Expected a body of the form { updates: [{ id, patch }] }.');
    }
    sendItem(res, await this.service.reorder(body.updates));
  };
}
