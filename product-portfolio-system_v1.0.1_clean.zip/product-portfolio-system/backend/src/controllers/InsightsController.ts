import type { Request, Response } from 'express';
import { sendItem } from '../core/http';
import { insightsService } from '../services/InsightsService';

export class InsightsController {
  dashboard = async (_req: Request, res: Response) => {
    sendItem(res, await insightsService.dashboard());
  };

  applicationOverview = async (req: Request, res: Response) => {
    sendItem(res, await insightsService.applicationOverview(req.params.id));
  };

  search = async (req: Request, res: Response) => {
    const term = typeof req.query.q === 'string' ? req.query.q : '';
    const limit = Number(req.query.limit ?? 40) || 40;
    sendItem(res, await insightsService.search(term, limit));
  };

  dependencyGraph = async (req: Request, res: Response) => {
    const applicationId = typeof req.query.applicationId === 'string' ? req.query.applicationId : undefined;
    sendItem(res, await insightsService.dependencyGraph(applicationId));
  };

  meta = async (_req: Request, res: Response) => {
    sendItem(res, insightsService.meta());
  };
}

export const insightsController = new InsightsController();
