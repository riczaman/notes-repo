import { ENTITY_DESCRIPTORS, ENTITY_REGISTRY, type EntityName, type EntityTypeMap } from '@shared';
import { jsonFileStore } from '../data/JsonFileStore';
import { JsonRepository } from './JsonRepository';
import type { Identified, Repository } from './Repository';

/**
 * Composition root for persistence.
 *
 * This is the only file that knows which Repository implementation is in play.
 * To move to SQLite or Postgres, build the map with a different class here and
 * nothing else in the codebase changes.
 */
const idPrefix = (name: EntityName): string =>
  ({
    applications: 'app',
    epics: 'epic',
    features: 'feat',
    tasks: 'task',
    releases: 'rel',
    milestones: 'ms',
    stakeholders: 'stk',
    risks: 'risk',
    bugs: 'bug',
    technicalDebt: 'debt',
    dependencies: 'dep',
    tickets: 'tkt',
    notes: 'note',
  })[name];

type RepositoryMap = { [K in EntityName]: Repository<EntityTypeMap[K] & Identified> };

const repositories = Object.fromEntries(
  ENTITY_DESCRIPTORS.map((descriptor) => [
    descriptor.name,
    new JsonRepository(descriptor.singular, descriptor.file, jsonFileStore, idPrefix(descriptor.name)),
  ]),
) as unknown as RepositoryMap;

export const getRepository = <K extends EntityName>(name: K): RepositoryMap[K] => repositories[name];

export const allRepositories = (): { name: EntityName; repository: Repository<Identified> }[] =>
  ENTITY_DESCRIPTORS.map((descriptor) => ({
    name: descriptor.name,
    repository: repositories[descriptor.name] as Repository<Identified>,
  }));

export { ENTITY_REGISTRY };
export type { Repository };
