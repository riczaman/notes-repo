import { NotFoundError } from '../core/errors';
import { JsonFileStore } from '../data/JsonFileStore';
import { newId } from '../utils/id';
import { nowIso } from '../utils/time';
import type { Identified, Repository } from './Repository';

/**
 * JSON-file implementation of Repository.
 *
 * IDs: new records get a UUID. Seeded records keep readable slugs such as
 * `app-usff` or `task-usff-014` on purpose - IDs are opaque strings to every
 * layer, and readable ones make the JSON files editable by hand, which is a
 * stated requirement of this build.
 */
export class JsonRepository<T extends Identified> implements Repository<T> {
  constructor(
    readonly name: string,
    private readonly file: string,
    private readonly store: JsonFileStore,
    private readonly idPrefix?: string,
  ) {}

  async list(): Promise<T[]> {
    return this.store.read<T>(this.file);
  }

  async findById(id: string): Promise<T | null> {
    const rows = await this.list();
    return rows.find((row) => row.id === id) ?? null;
  }

  async create(input: Omit<T, keyof Identified>): Promise<T> {
    const timestamp = nowIso();
    const record = {
      ...(input as object),
      id: newId(this.idPrefix),
      createdAt: timestamp,
      updatedAt: timestamp,
    } as T;

    return this.store.mutate<T, T>(this.file, (rows) => ({
      rows: [...rows, record],
      result: record,
    }));
  }

  async update(id: string, patch: Partial<Omit<T, 'id' | 'createdAt'>>): Promise<T> {
    return this.store.mutate<T, T>(this.file, (rows) => {
      const index = rows.findIndex((row) => row.id === id);
      if (index === -1) throw new NotFoundError(this.name, id);
      const next = {
        ...rows[index],
        ...patch,
        id: rows[index].id,
        createdAt: rows[index].createdAt,
        updatedAt: nowIso(),
      } as T;
      const copy = [...rows];
      copy[index] = next;
      return { rows: copy, result: next };
    });
  }

  async remove(id: string): Promise<void> {
    await this.store.mutate<T, void>(this.file, (rows) => {
      if (!rows.some((row) => row.id === id)) throw new NotFoundError(this.name, id);
      return { rows: rows.filter((row) => row.id !== id), result: undefined };
    });
  }

  async updateMany(patches: { id: string; patch: Partial<T> }[]): Promise<T[]> {
    if (patches.length === 0) return [];
    return this.store.mutate<T, T[]>(this.file, (rows) => {
      const byId = new Map(rows.map((row) => [row.id, row]));
      const touched: T[] = [];
      for (const { id, patch } of patches) {
        const current = byId.get(id);
        if (!current) throw new NotFoundError(this.name, id);
        const next = {
          ...current,
          ...patch,
          id: current.id,
          createdAt: current.createdAt,
          updatedAt: nowIso(),
        } as T;
        byId.set(id, next);
        touched.push(next);
      }
      return { rows: rows.map((row) => byId.get(row.id) ?? row), result: touched };
    });
  }

  async removeWhere(predicate: (row: T) => boolean): Promise<number> {
    return this.store.mutate<T, number>(this.file, (rows) => {
      const kept = rows.filter((row) => !predicate(row));
      return { rows: kept, result: rows.length - kept.length };
    });
  }
}
