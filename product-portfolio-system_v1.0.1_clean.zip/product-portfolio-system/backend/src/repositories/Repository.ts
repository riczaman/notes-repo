export interface Identified {
  id: string;
  createdAt: string;
  updatedAt: string;
}

/**
 * The contract the rest of the backend is written against.
 *
 * Nothing above this line knows the data lives in JSON files. Swapping in a
 * SqliteRepository or PostgresRepository later is a change to one factory
 * function in repositories/index.ts - services, controllers and the whole
 * frontend stay untouched. That is the entire point of this interface.
 */
export interface Repository<T extends Identified> {
  readonly name: string;
  list(): Promise<T[]>;
  findById(id: string): Promise<T | null>;
  create(input: Omit<T, keyof Identified>): Promise<T>;
  update(id: string, patch: Partial<Omit<T, 'id' | 'createdAt'>>): Promise<T>;
  remove(id: string): Promise<void>;
  /** Applies many patches inside one write. Used by Kanban drag-and-drop. */
  updateMany(patches: { id: string; patch: Partial<T> }[]): Promise<T[]>;
  /** Removes every record whose field equals value. Used for cascade deletes. */
  removeWhere(predicate: (row: T) => boolean): Promise<number>;
}
