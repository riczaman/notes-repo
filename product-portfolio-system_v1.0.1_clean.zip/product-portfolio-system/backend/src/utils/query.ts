import type { EntityDescriptor, ListMeta } from '@shared';

const RESERVED = new Set(['q', 'page', 'pageSize', 'sort', 'order']);

const asArray = (value: unknown): string[] => {
  if (Array.isArray(value)) return value.map(String);
  if (typeof value === 'string') return value.split(',').map((part) => part.trim()).filter(Boolean);
  return [];
};

const fieldMatches = (row: Record<string, unknown>, field: string, wanted: string[]): boolean => {
  const value = row[field];
  if (Array.isArray(value)) return value.some((item) => wanted.includes(String(item)));
  if (value === null || value === undefined) return wanted.includes('null') || wanted.includes('');
  return wanted.includes(String(value));
};

const haystack = (row: Record<string, unknown>, fields: string[]): string =>
  fields
    .map((field) => {
      const value = row[field];
      if (Array.isArray(value)) return value.join(' ');
      return value == null ? '' : String(value);
    })
    .join(' ')
    .toLowerCase();

const compare = (a: unknown, b: unknown): number => {
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  const left = a == null ? '' : String(a);
  const right = b == null ? '' : String(b);
  // Empty values sort last so records missing a date do not head the list.
  if (!left && right) return 1;
  if (left && !right) return -1;
  return left.localeCompare(right, undefined, { numeric: true, sensitivity: 'base' });
};

export interface ListResult<T> {
  data: T[];
  meta: ListMeta;
}

/**
 * Generic list pipeline: filter -> search -> sort -> paginate.
 *
 * Any query parameter that names a field on the record filters by equality,
 * comma separated values behave as OR, and array fields match if they contain
 * the value. That single rule covers every filter the UI needs
 * (application, owner, status, priority, release, quarter, risk, tag) without
 * a bespoke handler per collection.
 */
export function applyListQuery<T extends { id: string }>(
  rows: T[],
  query: Record<string, unknown>,
  descriptor: EntityDescriptor,
): ListResult<T> {
  let result = rows as unknown as Record<string, unknown>[];

  for (const [key, raw] of Object.entries(query)) {
    if (RESERVED.has(key)) continue;
    const wanted = asArray(raw);
    if (wanted.length === 0) continue;
    result = result.filter((row) => fieldMatches(row, key, wanted));
  }

  const term = typeof query.q === 'string' ? query.q.trim().toLowerCase() : '';
  if (term) {
    const words = term.split(/\s+/);
    result = result.filter((row) => {
      const text = haystack(row, descriptor.searchFields);
      return words.every((word) => text.includes(word));
    });
  }

  const sortField = typeof query.sort === 'string' && query.sort ? query.sort : descriptor.defaultSort;
  const direction = query.order === 'desc' ? -1 : 1;
  result = [...result].sort((a, b) => compare(a[sortField], b[sortField]) * direction);

  const total = result.length;
  const page = Math.max(1, Number(query.page ?? 1) || 1);
  const pageSize = Math.min(500, Math.max(1, Number(query.pageSize ?? 200) || 200));
  const start = (page - 1) * pageSize;
  const paged = result.slice(start, start + pageSize);

  return {
    data: paged as unknown as T[],
    meta: { total, page, pageSize, pageCount: Math.max(1, Math.ceil(total / pageSize)) },
  };
}
