export const nowIso = (): string => new Date().toISOString();

export const toDate = (value: string | null | undefined): Date | null => {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
};

/** Calendar quarter label such as "Q3 2026". Used by roadmap grouping. */
export const quarterOf = (value: string | null | undefined): string => {
  const date = toDate(value);
  if (!date) return '';
  return `Q${Math.floor(date.getUTCMonth() / 3) + 1} ${date.getUTCFullYear()}`;
};
