import { randomUUID } from 'node:crypto';

/**
 * UUID v4 from the Node standard library - no dependency needed.
 * An optional prefix keeps generated IDs as readable as the seeded ones.
 */
export const newId = (prefix?: string): string => (prefix ? `${prefix}-${randomUUID()}` : randomUUID());
