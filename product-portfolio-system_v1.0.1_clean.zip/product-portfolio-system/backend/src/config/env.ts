import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

/**
 * Central config. Everything the app can be tuned with lives here so a future
 * Docker or Postgres setup only has to change environment variables.
 */
export const env = {
  port: Number(process.env.PORT ?? 4000),
  host: process.env.HOST ?? '127.0.0.1',
  nodeEnv: process.env.NODE_ENV ?? 'development',
  /** Root of the JSON "database". Swap the driver, keep the path meaning. */
  dataDir: process.env.DATA_DIR ?? path.resolve(here, '../../data'),
  /** Where `POST /api/admin/backup` writes snapshots. */
  backupDir: process.env.BACKUP_DIR ?? path.resolve(here, '../../data/.backups'),
  corsOrigins: (process.env.CORS_ORIGINS ?? 'http://localhost:5173,http://127.0.0.1:5173').split(','),
  /** Pretty-print JSON files so they stay hand-editable and diff cleanly. */
  jsonIndent: 2,
} as const;
