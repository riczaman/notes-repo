import type { Application } from '@shared';
import type { Identified } from '../repositories/Repository';
import { allRepositories } from '../repositories';
import { CrudService } from './CrudService';

/**
 * Applications own most other records. Deleting one without cleaning up would
 * leave orphans that break every rollup, so this is the one collection with
 * cascade behaviour. It overrides a hook rather than special-casing the base
 * service, so the generic path stays generic.
 */
export class ApplicationService extends CrudService<Application & Identified> {
  protected override async afterRemove(id: string): Promise<void> {
    for (const { name, repository } of allRepositories()) {
      if (name === 'applications') continue;
      await repository.removeWhere((row) => {
        const record = row as unknown as Record<string, unknown>;
        if (record.applicationId === id) return true;
        if (record.fromApplicationId === id) return true;
        const many = record.applicationIds;
        // Notes and stakeholders span applications - only drop them if this was the only link.
        if (Array.isArray(many)) return many.length === 1 && many[0] === id;
        return false;
      });
    }
  }
}
