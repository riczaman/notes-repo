import { ENTITY_DESCRIPTORS, type EntityName, type EntityTypeMap } from '@shared';
import { getRepository } from '../repositories';
import type { Identified } from '../repositories/Repository';
import { ApplicationService } from './ApplicationService';
import { CrudService } from './CrudService';

type ServiceMap = { [K in EntityName]: CrudService<EntityTypeMap[K] & Identified> };

const build = (): ServiceMap => {
  const entries = ENTITY_DESCRIPTORS.map((descriptor) => {
    const repository = getRepository(descriptor.name) as never;
    const service =
      descriptor.name === 'applications'
        ? new ApplicationService(descriptor, repository)
        : new CrudService(descriptor, repository);
    return [descriptor.name, service];
  });
  return Object.fromEntries(entries) as ServiceMap;
};

const services = build();

export const getService = <K extends EntityName>(name: K): ServiceMap[K] => services[name];

export { CrudService };
