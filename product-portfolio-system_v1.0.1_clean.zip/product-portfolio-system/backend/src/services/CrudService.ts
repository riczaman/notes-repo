import type { EntityDescriptor } from '@shared';
import { ValidationError } from '../core/errors';
import { NotFoundError } from '../core/errors';
import type { Identified, Repository } from '../repositories/Repository';
import { applyListQuery, type ListResult } from '../utils/query';

/**
 * Generic application service for a collection.
 *
 * Validation, filtering, pagination and the not-found rule are identical for all
 * 13 collections, so they live here once. Collections that need extra behaviour
 * subclass and override a single method (see ApplicationService), which keeps
 * the open/closed principle honest instead of growing if-statements per entity.
 */
export class CrudService<T extends Identified> {
  constructor(
    protected readonly descriptor: EntityDescriptor,
    protected readonly repository: Repository<T>,
  ) {}

  async list(query: Record<string, unknown>): Promise<ListResult<T>> {
    const rows = await this.repository.list();
    return applyListQuery(rows, query, this.descriptor);
  }

  async listAll(): Promise<T[]> {
    return this.repository.list();
  }

  async get(id: string): Promise<T> {
    const record = await this.repository.findById(id);
    if (!record) throw new NotFoundError(this.descriptor.singular, id);
    return record;
  }

  async create(body: unknown): Promise<T> {
    const parsed = this.descriptor.createSchema.safeParse(body);
    if (!parsed.success) throw new ValidationError(parsed.error.flatten());
    return this.repository.create(parsed.data as Omit<T, keyof Identified>);
  }

  async update(id: string, body: unknown): Promise<T> {
    const parsed = this.descriptor.updateSchema.safeParse(body);
    if (!parsed.success) throw new ValidationError(parsed.error.flatten());
    await this.get(id);
    return this.repository.update(id, parsed.data as Partial<T>);
  }

  async remove(id: string): Promise<void> {
    await this.get(id);
    await this.repository.remove(id);
    await this.afterRemove(id);
  }

  /** Bulk patch used by Kanban reordering: one write, one revalidation. */
  async reorder(patches: { id: string; patch: unknown }[]): Promise<T[]> {
    const validated = patches.map(({ id, patch }) => {
      const parsed = this.descriptor.updateSchema.safeParse(patch);
      if (!parsed.success) throw new ValidationError(parsed.error.flatten());
      return { id, patch: parsed.data as Partial<T> };
    });
    return this.repository.updateMany(validated);
  }

  /** Extension point for cascade behaviour. No-op by default. */
  protected async afterRemove(_id: string): Promise<void> {
    return undefined;
  }
}
