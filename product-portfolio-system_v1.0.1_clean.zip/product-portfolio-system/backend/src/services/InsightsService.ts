import {
  ENTITY_DESCRIPTORS,
  ENTITY_REGISTRY,
  OPEN_TICKET_STATUSES,
  RISK_SCALE_WEIGHT,
  type Application,
  type ApplicationRollup,
  type Bug,
  type DashboardSummary,
  type Dependency,
  type DependencyGraph,
  type Epic,
  type Feature,
  type GraphEdge,
  type GraphNode,
  type Milestone,
  type Note,
  type PortfolioCounts,
  type Release,
  type Risk,
  type SearchHit,
  type Stakeholder,
  type Task,
  type TechnicalDebt,
  type Ticket,
} from '@shared';
import { NotFoundError } from '../core/errors';
import { getRepository } from '../repositories';
import { nowIso } from '../utils/time';

const CLOSED_RISK = new Set(['closed', 'accepted']);
const CLOSED_BUG = new Set(['resolved', 'closed', 'wont_fix']);
const CLOSED_DEBT = new Set(['resolved']);
const OPEN_TICKETS = new Set<string>(OPEN_TICKET_STATUSES);

interface Snapshot {
  applications: Application[];
  epics: Epic[];
  features: Feature[];
  tasks: Task[];
  releases: Release[];
  milestones: Milestone[];
  stakeholders: Stakeholder[];
  risks: Risk[];
  bugs: Bug[];
  technicalDebt: TechnicalDebt[];
  dependencies: Dependency[];
  tickets: Ticket[];
  notes: Note[];
}

const countBy = <T>(rows: T[], key: (row: T) => string): { value: string; count: number }[] => {
  const map = new Map<string, number>();
  for (const row of rows) {
    const value = key(row);
    map.set(value, (map.get(value) ?? 0) + 1);
  }
  return [...map.entries()].map(([value, count]) => ({ value, count }));
};

export const riskScore = (risk: Pick<Risk, 'likelihood' | 'impact'>): number =>
  RISK_SCALE_WEIGHT[risk.likelihood] * RISK_SCALE_WEIGHT[risk.impact];

/**
 * Read-side service. Everything here is derived, never stored: rollups computed
 * on request cannot drift out of sync with the records they summarise, and the
 * whole dataset is small enough that recomputing is cheaper than invalidating a
 * cache. If the dataset ever outgrows that, this is the one class to memoise.
 */
export class InsightsService {
  private async snapshot(): Promise<Snapshot> {
    const [
      applications,
      epics,
      features,
      tasks,
      releases,
      milestones,
      stakeholders,
      risks,
      bugs,
      technicalDebt,
      dependencies,
      tickets,
      notes,
    ] = await Promise.all([
      getRepository('applications').list(),
      getRepository('epics').list(),
      getRepository('features').list(),
      getRepository('tasks').list(),
      getRepository('releases').list(),
      getRepository('milestones').list(),
      getRepository('stakeholders').list(),
      getRepository('risks').list(),
      getRepository('bugs').list(),
      getRepository('technicalDebt').list(),
      getRepository('dependencies').list(),
      getRepository('tickets').list(),
      getRepository('notes').list(),
    ]);
    return {
      applications,
      epics,
      features,
      tasks,
      releases,
      milestones,
      stakeholders,
      risks,
      bugs,
      technicalDebt,
      dependencies,
      tickets,
      notes,
    } as Snapshot;
  }

  private rollup(app: Application, s: Snapshot): ApplicationRollup {
    const tasks = s.tasks.filter((t) => t.applicationId === app.id);
    const done = tasks.filter((t) => t.status === 'done').length;
    const epics = s.epics.filter((e) => e.applicationId === app.id);
    const progress =
      tasks.length > 0
        ? Math.round((done / tasks.length) * 100)
        : epics.length > 0
          ? Math.round(epics.reduce((sum, e) => sum + e.progress, 0) / epics.length)
          : 0;

    return {
      applicationId: app.id,
      name: app.name,
      shortName: app.shortName,
      color: app.color,
      health: app.health,
      lifecycle: app.lifecycle,
      progress,
      totals: {
        epics: epics.length,
        features: s.features.filter((f) => f.applicationId === app.id).length,
        tasks: tasks.length,
        tasksDone: done,
        tasksBlocked: tasks.filter((t) => t.status === 'blocked').length,
        openRisks: s.risks.filter((r) => r.applicationId === app.id && !CLOSED_RISK.has(r.status)).length,
        criticalRisks: s.risks.filter(
          (r) => r.applicationId === app.id && !CLOSED_RISK.has(r.status) && riskScore(r) >= 9,
        ).length,
        openBugs: s.bugs.filter((b) => b.applicationId === app.id && !CLOSED_BUG.has(b.status)).length,
        openDebt: s.technicalDebt.filter((d) => d.applicationId === app.id && !CLOSED_DEBT.has(d.status)).length,
        openTickets: s.tickets.filter((t) => t.applicationId === app.id && OPEN_TICKETS.has(t.status)).length,
        dependencies: s.dependencies.filter((d) => d.fromApplicationId === app.id).length,
      },
    };
  }

  private counts(s: Snapshot): PortfolioCounts {
    return {
      applications: s.applications.length,
      epics: s.epics.length,
      features: s.features.length,
      tasks: s.tasks.length,
      openTasks: s.tasks.filter((t) => t.status !== 'done').length,
      blockedTasks: s.tasks.filter((t) => t.status === 'blocked').length,
      doneTasks: s.tasks.filter((t) => t.status === 'done').length,
      risks: s.risks.length,
      openRisks: s.risks.filter((r) => !CLOSED_RISK.has(r.status)).length,
      criticalRisks: s.risks.filter((r) => !CLOSED_RISK.has(r.status) && riskScore(r) >= 9).length,
      bugs: s.bugs.length,
      openBugs: s.bugs.filter((b) => !CLOSED_BUG.has(b.status)).length,
      technicalDebt: s.technicalDebt.length,
      openTechnicalDebt: s.technicalDebt.filter((d) => !CLOSED_DEBT.has(d.status)).length,
      dependencies: s.dependencies.length,
      blockedDependencies: s.dependencies.filter((d) => d.status === 'blocked').length,
      tickets: s.tickets.length,
      openTickets: s.tickets.filter((t) => OPEN_TICKETS.has(t.status)).length,
      releases: s.releases.length,
      milestones: s.milestones.length,
    };
  }

  async dashboard(): Promise<DashboardSummary> {
    const s = await this.snapshot();
    const openRisks = s.risks.filter((r) => !CLOSED_RISK.has(r.status));

    const matrix = new Map<string, { count: number; ids: string[] }>();
    for (const risk of openRisks) {
      const key = `${risk.likelihood}|${risk.impact}`;
      const bucket = matrix.get(key) ?? { count: 0, ids: [] };
      bucket.count += 1;
      bucket.ids.push(risk.id);
      matrix.set(key, bucket);
    }

    const today = new Date().toISOString().slice(0, 10);

    return {
      generatedAt: nowIso(),
      counts: this.counts(s),
      applications: [...s.applications]
        .sort((a, b) => a.sortOrder - b.sortOrder)
        .map((app) => this.rollup(app, s)),
      statusBreakdown: countBy(s.tasks, (t) => t.status).map(({ value, count }) => ({ status: value, count })),
      priorityBreakdown: countBy(s.tasks, (t) => t.priority).map(({ value, count }) => ({
        priority: value,
        count,
      })),
      riskMatrix: [...matrix.entries()].map(([key, bucket]) => {
        const [likelihood, impact] = key.split('|');
        return { likelihood, impact, count: bucket.count, ids: bucket.ids };
      }),
      horizonBreakdown: countBy([...s.epics, ...s.features, ...s.tasks], (row) => row.horizon).map(
        ({ value, count }) => ({ horizon: value, count }),
      ),
      upcomingMilestones: [...s.milestones]
        .filter((m) => m.status !== 'cancelled')
        .sort((a, b) => a.date.localeCompare(b.date))
        .filter((m) => m.date >= today || m.status === 'at_risk')
        .slice(0, 8)
        .map((m) => ({
          id: m.id,
          name: m.name,
          date: m.date,
          status: m.status,
          applicationId: m.applicationId,
          type: m.type,
        })),
      topRisks: openRisks
        .map((r) => ({
          id: r.id,
          title: r.title,
          applicationId: r.applicationId,
          score: riskScore(r),
          status: r.status,
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 8),
    };
  }

  /** Everything one application page needs, in a single round trip. */
  async applicationOverview(id: string) {
    const s = await this.snapshot();
    const application = s.applications.find((app) => app.id === id);
    if (!application) throw new NotFoundError('Application', id);

    const byApp = <T extends { applicationId?: string | null }>(rows: T[]) =>
      rows.filter((row) => row.applicationId === id);

    return {
      application,
      rollup: this.rollup(application, s),
      epics: byApp(s.epics),
      features: byApp(s.features),
      tasks: byApp(s.tasks),
      releases: byApp(s.releases),
      milestones: byApp(s.milestones),
      risks: byApp(s.risks),
      bugs: byApp(s.bugs),
      technicalDebt: byApp(s.technicalDebt),
      tickets: byApp(s.tickets),
      dependencies: s.dependencies.filter((d) => d.fromApplicationId === id || d.toApplicationId === id),
      stakeholders: s.stakeholders.filter(
        (p) => p.applicationIds.includes(id) || application.stakeholderIds.includes(p.id),
      ),
      notes: s.notes.filter((n) => n.applicationIds.includes(id)),
    };
  }

  /**
   * Global search across every collection. Scoring is intentionally simple:
   * a title hit beats a body hit, an exact prefix beats a substring. Good enough
   * for a few thousand records and it keeps the dependency list at zero.
   */
  async search(term: string, limit = 40): Promise<SearchHit[]> {
    const needle = term.trim().toLowerCase();
    if (!needle) return [];
    const hits: SearchHit[] = [];

    for (const descriptor of ENTITY_DESCRIPTORS) {
      const rows = (await getRepository(descriptor.name).list()) as unknown as Record<string, unknown>[];
      for (const row of rows) {
        const title = String(row[descriptor.titleField] ?? '');
        const titleLower = title.toLowerCase();
        let score = 0;
        if (titleLower === needle) score = 100;
        else if (titleLower.startsWith(needle)) score = 70;
        else if (titleLower.includes(needle)) score = 50;
        else {
          const body = descriptor.searchFields
            .map((field) => {
              const value = row[field];
              return Array.isArray(value) ? value.join(' ') : String(value ?? '');
            })
            .join(' ')
            .toLowerCase();
          if (body.includes(needle)) score = 20;
        }
        if (score === 0) continue;

        const applicationField = descriptor.applicationField;
        const applicationId =
          applicationField === 'applicationIds'
            ? ((row.applicationIds as string[] | undefined)?.[0] ?? null)
            : applicationField
              ? ((row[applicationField] as string | null) ?? null)
              : (row.id as string);

        hits.push({
          entity: descriptor.name,
          id: String(row.id),
          title: title || '(untitled)',
          subtitle: descriptor.subtitleFields
            .map((field) => String(row[field] ?? ''))
            .filter(Boolean)
            .join(' · '),
          applicationId,
          score,
        });
      }
    }

    return hits.sort((a, b) => b.score - a.score || a.title.localeCompare(b.title)).slice(0, limit);
  }

  /**
   * Dependency graph for React Flow. Application nodes come from the
   * applications collection; external nodes are derived from distinct
   * `toExternalName` values so there is no second list to keep in sync.
   */
  async dependencyGraph(applicationId?: string): Promise<DependencyGraph> {
    const [applications, dependencies] = await Promise.all([
      getRepository('applications').list(),
      getRepository('dependencies').list(),
    ]);

    const edgesSource = applicationId
      ? dependencies.filter((d) => d.fromApplicationId === applicationId || d.toApplicationId === applicationId)
      : dependencies;

    const nodes = new Map<string, GraphNode>();
    const appById = new Map(applications.map((app) => [app.id, app]));

    const addApp = (id: string) => {
      const app = appById.get(id);
      if (!app) return;
      nodes.set(app.id, { id: app.id, label: app.shortName, kind: 'application', color: app.color });
    };

    const externalId = (name: string) => `ext:${name.toLowerCase().replace(/\s+/g, '-')}`;

    const edges: GraphEdge[] = [];
    for (const dep of edgesSource) {
      addApp(dep.fromApplicationId);
      let targetId: string;
      if (dep.toApplicationId) {
        addApp(dep.toApplicationId);
        targetId = dep.toApplicationId;
      } else {
        const name = dep.toExternalName || 'Unnamed system';
        targetId = externalId(name);
        if (!nodes.has(targetId)) {
          nodes.set(targetId, { id: targetId, label: name, kind: 'external', category: dep.type });
        }
      }
      if (!nodes.has(dep.fromApplicationId)) continue;
      edges.push({
        id: dep.id,
        source: dep.fromApplicationId,
        target: targetId,
        label: dep.label,
        type: dep.type,
        status: dep.status,
        criticality: dep.criticality,
      });
    }

    return { nodes: [...nodes.values()], edges };
  }

  /** Small meta endpoint so the client can render entity labels without hardcoding. */
  meta() {
    return ENTITY_DESCRIPTORS.map((d) => ({
      name: d.name,
      path: d.path,
      label: d.label,
      singular: d.singular,
      icon: d.icon,
      applicationField: d.applicationField,
    }));
  }
}

export const insightsService = new InsightsService();
export { ENTITY_REGISTRY };
