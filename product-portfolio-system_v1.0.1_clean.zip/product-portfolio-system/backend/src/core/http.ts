import type { NextFunction, Request, RequestHandler, Response } from 'express';
import type { ListMeta } from '@shared';

export const HttpStatus = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE: 422,
  SERVER_ERROR: 500,
} as const;

/** Wraps async handlers so rejected promises reach the error middleware. */
export const asyncHandler =
  <T extends RequestHandler>(handler: T): RequestHandler =>
  (req: Request, res: Response, next: NextFunction) => {
    void Promise.resolve(handler(req, res, next)).catch(next);
  };

export const sendItem = <T>(res: Response, data: T, status: number = HttpStatus.OK) =>
  res.status(status).json({ data });

export const sendList = <T>(res: Response, data: T[], meta: ListMeta) => res.status(HttpStatus.OK).json({ data, meta });
