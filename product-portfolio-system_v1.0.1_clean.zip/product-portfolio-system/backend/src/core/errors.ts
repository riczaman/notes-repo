/**
 * One error type for anything the API answers with deliberately.
 * Controllers throw these; a single middleware turns them into responses.
 * Anything else that escapes is a genuine 500 and gets logged as such.
 */
export class AppError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
    readonly details?: unknown,
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string, id?: string) {
    super(404, 'NOT_FOUND', id ? `${resource} '${id}' was not found.` : `${resource} was not found.`);
  }
}

export class ValidationError extends AppError {
  constructor(details: unknown, message = 'The request body failed validation.') {
    super(422, 'VALIDATION_FAILED', message, details);
  }
}

export class BadRequestError extends AppError {
  constructor(message: string, details?: unknown) {
    super(400, 'BAD_REQUEST', message, details);
  }
}

export class ConflictError extends AppError {
  constructor(message: string, details?: unknown) {
    super(409, 'CONFLICT', message, details);
  }
}
