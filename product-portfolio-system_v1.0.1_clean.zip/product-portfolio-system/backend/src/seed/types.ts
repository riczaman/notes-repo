/**
 * A seed row carries an explicit id plus only the fields that matter.
 * The runner pushes each row through the entity's Zod schema, which fills every
 * remaining field from its declared default, so seed data can never drift out of
 * shape with the schema.
 */
export type Seed<T extends { id: string }> = Partial<T> & { id: string };
