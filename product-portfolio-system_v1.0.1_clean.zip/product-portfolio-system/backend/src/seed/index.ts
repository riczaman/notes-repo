import { ENTITY_REGISTRY, type EntityName } from '@shared';
import { env } from '../config/env';
import { jsonFileStore } from '../data/JsonFileStore';
import { applications, milestones, releases, stakeholders } from './portfolio.seed';
import { epics, features, tasks } from './delivery.seed';
import { bugs, dependencies, notes, risks, technicalDebt, tickets } from './governance.seed';

/**
 * Writes backend/data/*.json from the seed modules.
 *
 * Run with `npm run seed` (or `npm run seed -- --force`).
 * Without --force, a collection that already has records is left alone, so
 * re-running the seed never destroys work entered through the UI.
 */
const STAMP = '2026-08-10T09:00:00.000Z';

const collections: { name: EntityName; rows: { id: string }[] }[] = [
  { name: 'applications', rows: applications },
  { name: 'stakeholders', rows: stakeholders },
  { name: 'releases', rows: releases },
  { name: 'milestones', rows: milestones },
  { name: 'epics', rows: epics },
  { name: 'features', rows: features },
  { name: 'tasks', rows: tasks },
  { name: 'risks', rows: risks },
  { name: 'bugs', rows: bugs },
  { name: 'technicalDebt', rows: technicalDebt },
  { name: 'dependencies', rows: dependencies },
  { name: 'tickets', rows: tickets },
  { name: 'notes', rows: notes },
];

const run = async () => {
  const force = process.argv.includes('--force');
  console.log(`\n  Seeding ${env.dataDir}${force ? ' (force: existing files will be replaced)' : ''}\n`);

  for (const { name, rows } of collections) {
    const descriptor = ENTITY_REGISTRY[name];
    const existing = await jsonFileStore.read(descriptor.file);

    if (existing.length > 0 && !force) {
      console.log(`  skip   ${descriptor.file.padEnd(22)} ${String(existing.length).padStart(4)} records already present`);
      continue;
    }

    const parsed = rows.map((row, index) => {
      const result = descriptor.entitySchema.safeParse({ createdAt: STAMP, updatedAt: STAMP, ...row });
      if (!result.success) {
        console.error(`\n  Seed row ${index} in ${name} (${row.id}) failed validation:`);
        console.error(JSON.stringify(result.error.flatten(), null, 2));
        process.exit(1);
      }
      return result.data;
    });

    await jsonFileStore.write(descriptor.file, parsed);
    console.log(`  write  ${descriptor.file.padEnd(22)} ${String(parsed.length).padStart(4)} records`);
  }

  console.log('\n  Done.\n');
};

run().catch((error) => {
  console.error('Seeding failed:', error);
  process.exit(1);
});
