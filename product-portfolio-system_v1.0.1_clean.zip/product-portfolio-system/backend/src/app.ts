import cors from 'cors';
import express, { type Express } from 'express';
import { env } from './config/env';
import { errorHandler } from './middleware/errorHandler';
import { notFound } from './middleware/notFound';
import { requestLogger } from './middleware/requestLogger';
import { apiRouter } from './routes';

export const createApp = (): Express => {
  const app = express();

  app.use(
    cors({
      origin: (origin, callback) => {
        // Same-origin and tooling requests arrive without an Origin header.
        if (!origin || env.corsOrigins.includes(origin)) return callback(null, true);
        return callback(new Error(`Origin ${origin} is not allowed.`));
      },
    }),
  );
  app.use(express.json({ limit: '2mb' }));
  app.use(requestLogger);

  app.use('/api', apiRouter());
  app.use(notFound);
  app.use(errorHandler);

  return app;
};
