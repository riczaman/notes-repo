import type { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { AppError } from '../core/errors';
import { HttpStatus } from '../core/http';

/**
 * Single exit point for failures. Every response body has the same shape,
 * `{ error: { code, message, details } }`, so the client has one error path.
 */
export const errorHandler = (error: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (error instanceof AppError) {
    res.status(error.status).json({
      error: { code: error.code, message: error.message, details: error.details },
    });
    return;
  }

  if (error instanceof ZodError) {
    res.status(HttpStatus.UNPROCESSABLE).json({
      error: { code: 'VALIDATION_FAILED', message: 'Request validation failed.', details: error.flatten() },
    });
    return;
  }

  if (error instanceof SyntaxError && 'body' in error) {
    res.status(HttpStatus.BAD_REQUEST).json({
      error: { code: 'MALFORMED_JSON', message: 'The request body was not valid JSON.' },
    });
    return;
  }

  const message = error instanceof Error ? error.message : 'Unexpected server error.';
  console.error('[api] unhandled error:', error);
  res.status(HttpStatus.SERVER_ERROR).json({
    error: { code: 'INTERNAL_ERROR', message },
  });
};
