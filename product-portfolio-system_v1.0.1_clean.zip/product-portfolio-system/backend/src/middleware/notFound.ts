import type { Request, Response } from 'express';
import { HttpStatus } from '../core/http';

export const notFound = (req: Request, res: Response) => {
  res.status(HttpStatus.NOT_FOUND).json({
    error: { code: 'ROUTE_NOT_FOUND', message: `No route matches ${req.method} ${req.originalUrl}.` },
  });
};
