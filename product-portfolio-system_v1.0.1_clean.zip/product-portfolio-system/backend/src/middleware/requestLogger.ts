import type { NextFunction, Request, Response } from 'express';

const RESET = '[0m';

const colour = (status: number): string => {
  if (status >= 500) return '[31m';
  if (status >= 400) return '[33m';
  if (status >= 300) return '[36m';
  return '[32m';
};

/** Tiny request log. A dependency for this would not earn its place. */
export const requestLogger = (req: Request, res: Response, next: NextFunction) => {
  const start = performance.now();
  res.on('finish', () => {
    const ms = (performance.now() - start).toFixed(1);
    console.log(
      `${colour(res.statusCode)}${res.statusCode}${RESET} ${req.method.padEnd(6)} ${req.originalUrl} ${ms}ms`,
    );
  });
  next();
};
