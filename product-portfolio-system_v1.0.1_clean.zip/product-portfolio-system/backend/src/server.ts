import { ENTITY_DESCRIPTORS } from '@shared';
import { createApp } from './app';
import { env } from './config/env';
import { jsonFileStore } from './data/JsonFileStore';

/**
 * Entry point. Touching each data file at boot means a missing collection is
 * created empty rather than throwing on the first request, and a corrupt file
 * fails loudly here instead of halfway through a page load.
 */
const bootstrap = async () => {
  for (const descriptor of ENTITY_DESCRIPTORS) {
    const rows = await jsonFileStore.read(descriptor.file);
    console.log(`  ${descriptor.file.padEnd(22)} ${String(rows.length).padStart(4)} records`);
  }

  const app = createApp();
  app.listen(env.port, env.host, () => {
    console.log(`\n  Portfolio API ready on http://${env.host}:${env.port}/api`);
    console.log(`  Data directory: ${env.dataDir}\n`);
  });
};

bootstrap().catch((error) => {
  console.error('Failed to start the API:', error);
  process.exit(1);
});
