import type { z } from 'zod';
import type { EntityName } from './api';
import * as portfolio from './schemas/portfolio';
import * as delivery from './schemas/delivery';
import * as quality from './schemas/quality';
import * as integration from './schemas/integration';

/**
 * The registry is the spine of the system.
 *
 * Backend: routes, repositories, services and validation are generated from it,
 * so adding a collection is one entry plus one JSON file - no new controller.
 * Frontend: the typed API client, global search and the entity pickers read the
 * same descriptors, so a new collection shows up on both sides at once.
 */
export interface EntityDescriptor {
  name: EntityName;
  /** URL segment under /api. */
  path: string;
  /** File under backend/data. */
  file: string;
  label: string;
  singular: string;
  /** Lucide icon name resolved on the frontend. */
  icon: string;
  createSchema: z.ZodTypeAny;
  updateSchema: z.ZodTypeAny;
  entitySchema: z.ZodTypeAny;
  /** Field rendered as the record title in search results and pickers. */
  titleField: string;
  /** Fields concatenated into the search-result subtitle. */
  subtitleFields: string[];
  /** Fields scanned by ?q= and by global search. */
  searchFields: string[];
  /** How a record links back to an application, if at all. */
  applicationField: 'applicationId' | 'fromApplicationId' | 'applicationIds' | null;
  defaultSort: string;
}

const d = (descriptor: EntityDescriptor): EntityDescriptor => descriptor;

export const ENTITY_REGISTRY: Record<EntityName, EntityDescriptor> = {
  applications: d({
    name: 'applications',
    path: 'applications',
    file: 'applications.json',
    label: 'Applications',
    singular: 'Application',
    icon: 'LayoutGrid',
    createSchema: portfolio.applicationCreateSchema,
    updateSchema: portfolio.applicationUpdateSchema,
    entitySchema: portfolio.applicationSchema,
    titleField: 'name',
    subtitleFields: ['tagline', 'businessOwner'],
    searchFields: ['name', 'shortName', 'key', 'tagline', 'description', 'vision', 'tags'],
    applicationField: null,
    defaultSort: 'sortOrder',
  }),
  epics: d({
    name: 'epics',
    path: 'epics',
    file: 'epics.json',
    label: 'Epics',
    singular: 'Epic',
    icon: 'Flag',
    createSchema: delivery.epicCreateSchema,
    updateSchema: delivery.epicUpdateSchema,
    entitySchema: delivery.epicSchema,
    titleField: 'title',
    subtitleFields: ['goal'],
    searchFields: ['title', 'goal', 'problemStatement', 'businessValue', 'owner', 'tags'],
    applicationField: 'applicationId',
    defaultSort: 'title',
  }),
  features: d({
    name: 'features',
    path: 'features',
    file: 'features.json',
    label: 'Features',
    singular: 'Feature',
    icon: 'Boxes',
    createSchema: delivery.featureCreateSchema,
    updateSchema: delivery.featureUpdateSchema,
    entitySchema: delivery.featureSchema,
    titleField: 'title',
    subtitleFields: ['problem'],
    searchFields: ['title', 'problem', 'solution', 'technicalDesign', 'owner', 'tags'],
    applicationField: 'applicationId',
    defaultSort: 'title',
  }),
  tasks: d({
    name: 'tasks',
    path: 'tasks',
    file: 'tasks.json',
    label: 'Tasks',
    singular: 'Task',
    icon: 'CheckSquare',
    createSchema: delivery.taskCreateSchema,
    updateSchema: delivery.taskUpdateSchema,
    entitySchema: delivery.taskSchema,
    titleField: 'title',
    subtitleFields: ['owner', 'status'],
    searchFields: ['title', 'description', 'owner', 'notes', 'tags'],
    applicationField: 'applicationId',
    defaultSort: 'boardOrder',
  }),
  releases: d({
    name: 'releases',
    path: 'releases',
    file: 'releases.json',
    label: 'Releases',
    singular: 'Release',
    icon: 'Rocket',
    createSchema: portfolio.releaseCreateSchema,
    updateSchema: portfolio.releaseUpdateSchema,
    entitySchema: portfolio.releaseSchema,
    titleField: 'name',
    subtitleFields: ['version', 'quarter'],
    searchFields: ['name', 'version', 'scopeSummary', 'notes', 'quarter', 'tags'],
    applicationField: 'applicationId',
    defaultSort: 'targetDate',
  }),
  milestones: d({
    name: 'milestones',
    path: 'milestones',
    file: 'milestones.json',
    label: 'Milestones',
    singular: 'Milestone',
    icon: 'Milestone',
    createSchema: portfolio.milestoneCreateSchema,
    updateSchema: portfolio.milestoneUpdateSchema,
    entitySchema: portfolio.milestoneSchema,
    titleField: 'name',
    subtitleFields: ['date', 'type'],
    searchFields: ['name', 'description', 'owner', 'quarter'],
    applicationField: 'applicationId',
    defaultSort: 'date',
  }),
  stakeholders: d({
    name: 'stakeholders',
    path: 'stakeholders',
    file: 'stakeholders.json',
    label: 'Stakeholders',
    singular: 'Stakeholder',
    icon: 'Users',
    createSchema: portfolio.stakeholderCreateSchema,
    updateSchema: portfolio.stakeholderUpdateSchema,
    entitySchema: portfolio.stakeholderSchema,
    titleField: 'name',
    subtitleFields: ['role', 'org'],
    searchFields: ['name', 'role', 'org', 'email', 'notes'],
    applicationField: 'applicationIds',
    defaultSort: 'name',
  }),
  risks: d({
    name: 'risks',
    path: 'risks',
    file: 'risks.json',
    label: 'Risks',
    singular: 'Risk',
    icon: 'ShieldAlert',
    createSchema: quality.riskCreateSchema,
    updateSchema: quality.riskUpdateSchema,
    entitySchema: quality.riskSchema,
    titleField: 'title',
    subtitleFields: ['category', 'status'],
    searchFields: ['title', 'description', 'mitigation', 'owner', 'decisionNeeded', 'tags'],
    applicationField: 'applicationId',
    defaultSort: 'title',
  }),
  bugs: d({
    name: 'bugs',
    path: 'bugs',
    file: 'bugs.json',
    label: 'Bugs',
    singular: 'Bug',
    icon: 'Bug',
    createSchema: quality.bugCreateSchema,
    updateSchema: quality.bugUpdateSchema,
    entitySchema: quality.bugSchema,
    titleField: 'title',
    subtitleFields: ['severity', 'status'],
    searchFields: ['title', 'description', 'owner', 'environment', 'tags'],
    applicationField: 'applicationId',
    defaultSort: 'title',
  }),
  technicalDebt: d({
    name: 'technicalDebt',
    path: 'technical-debt',
    file: 'technicalDebt.json',
    label: 'Technical Debt',
    singular: 'Debt Item',
    icon: 'Wrench',
    createSchema: quality.technicalDebtCreateSchema,
    updateSchema: quality.technicalDebtUpdateSchema,
    entitySchema: quality.technicalDebtSchema,
    titleField: 'title',
    subtitleFields: ['category', 'priority'],
    searchFields: ['title', 'issue', 'impact', 'suggestedFix', 'owner', 'tags'],
    applicationField: 'applicationId',
    defaultSort: 'title',
  }),
  dependencies: d({
    name: 'dependencies',
    path: 'dependencies',
    file: 'dependencies.json',
    label: 'Dependencies',
    singular: 'Dependency',
    icon: 'Share2',
    createSchema: integration.dependencyCreateSchema,
    updateSchema: integration.dependencyUpdateSchema,
    entitySchema: integration.dependencySchema,
    titleField: 'label',
    subtitleFields: ['toExternalName', 'type'],
    searchFields: ['label', 'description', 'toExternalName', 'owner', 'team', 'notes', 'tags'],
    applicationField: 'fromApplicationId',
    defaultSort: 'label',
  }),
  tickets: d({
    name: 'tickets',
    path: 'tickets',
    file: 'tickets.json',
    label: 'Request Tracker',
    singular: 'Request',
    icon: 'Ticket',
    createSchema: integration.ticketCreateSchema,
    updateSchema: integration.ticketUpdateSchema,
    entitySchema: integration.ticketSchema,
    titleField: 'title',
    subtitleFields: ['externalId', 'system'],
    searchFields: ['externalId', 'title', 'requester', 'assignee', 'notes', 'tags'],
    applicationField: 'applicationId',
    defaultSort: 'externalId',
  }),
  notes: d({
    name: 'notes',
    path: 'notes',
    file: 'notes.json',
    label: 'Meeting Notes',
    singular: 'Note',
    icon: 'NotebookPen',
    createSchema: integration.noteCreateSchema,
    updateSchema: integration.noteUpdateSchema,
    entitySchema: integration.noteSchema,
    titleField: 'title',
    subtitleFields: ['date', 'source'],
    searchFields: ['title', 'rawNotes', 'summary', 'decisions', 'openQuestions', 'attendees', 'tags'],
    applicationField: 'applicationIds',
    defaultSort: 'date',
  }),
};

export const ENTITY_DESCRIPTORS = Object.values(ENTITY_REGISTRY);
