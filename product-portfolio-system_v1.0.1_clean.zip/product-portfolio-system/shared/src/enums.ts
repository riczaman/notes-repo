import { z } from 'zod';

/**
 * Every controlled vocabulary in the product lives here, once.
 * Zod enums are the single source of truth: the backend validates against them,
 * the frontend renders selects and badges from them, and TypeScript unions are inferred.
 * Adding a value here makes it available everywhere with no other change.
 */

const enumWithLabels = <T extends readonly [string, ...string[]]>(
  values: T,
  labels: Record<T[number], string>,
) => ({
  schema: z.enum(values),
  values,
  labels,
  options: values.map((v) => ({ value: v, label: labels[v as T[number]] })),
});

/* ------------------------------------------------------------------ workflow */

export const WORK_STATUSES = [
  'backlog',
  'discovery',
  'ready',
  'in_progress',
  'blocked',
  'testing',
  'done',
] as const;
export const workStatus = enumWithLabels(WORK_STATUSES, {
  backlog: 'Backlog',
  discovery: 'Discovery',
  ready: 'Ready',
  in_progress: 'In Progress',
  blocked: 'Blocked',
  testing: 'Testing',
  done: 'Done',
});
export const workStatusSchema = workStatus.schema;
export type WorkStatus = z.infer<typeof workStatusSchema>;

/** Statuses that mean "no longer consuming capacity". */
export const TERMINAL_STATUSES: WorkStatus[] = ['done'];

export const PRIORITIES = ['critical', 'high', 'medium', 'low'] as const;
export const priority = enumWithLabels(PRIORITIES, {
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
});
export const prioritySchema = priority.schema;
export type Priority = z.infer<typeof prioritySchema>;

export const HORIZONS = ['now', 'next', 'later'] as const;
export const horizon = enumWithLabels(HORIZONS, {
  now: 'Now',
  next: 'Next',
  later: 'Later',
});
export const horizonSchema = horizon.schema;
export type Horizon = z.infer<typeof horizonSchema>;

/* --------------------------------------------------------------- application */

export const LIFECYCLES = ['discovery', 'build', 'live', 'sustain', 'sunset'] as const;
export const lifecycle = enumWithLabels(LIFECYCLES, {
  discovery: 'Discovery',
  build: 'Build',
  live: 'Live',
  sustain: 'Sustain',
  sunset: 'Sunset',
});
export const lifecycleSchema = lifecycle.schema;
export type Lifecycle = z.infer<typeof lifecycleSchema>;

export const HEALTHS = ['on_track', 'at_risk', 'off_track', 'not_started', 'complete'] as const;
export const health = enumWithLabels(HEALTHS, {
  on_track: 'On Track',
  at_risk: 'At Risk',
  off_track: 'Off Track',
  not_started: 'Not Started',
  complete: 'Complete',
});
export const healthSchema = health.schema;
export type Health = z.infer<typeof healthSchema>;

/* ---------------------------------------------------------------------- risk */

export const RISK_SCALES = ['low', 'medium', 'high', 'critical'] as const;
export const riskScale = enumWithLabels(RISK_SCALES, {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
});
export const riskScaleSchema = riskScale.schema;
export type RiskScale = z.infer<typeof riskScaleSchema>;

export const RISK_SCALE_WEIGHT: Record<RiskScale, number> = {
  low: 1,
  medium: 2,
  high: 3,
  critical: 4,
};

export const RISK_STATUSES = ['open', 'mitigating', 'monitoring', 'accepted', 'closed'] as const;
export const riskStatus = enumWithLabels(RISK_STATUSES, {
  open: 'Open',
  mitigating: 'Mitigating',
  monitoring: 'Monitoring',
  accepted: 'Accepted',
  closed: 'Closed',
});
export const riskStatusSchema = riskStatus.schema;
export type RiskStatus = z.infer<typeof riskStatusSchema>;

export const RISK_CATEGORIES = [
  'scope',
  'architecture',
  'delivery',
  'security',
  'vendor',
  'governance',
  'resourcing',
  'data',
  'compliance',
] as const;
export const riskCategory = enumWithLabels(RISK_CATEGORIES, {
  scope: 'Scope',
  architecture: 'Architecture',
  delivery: 'Delivery',
  security: 'Security',
  vendor: 'Vendor',
  governance: 'Governance',
  resourcing: 'Resourcing',
  data: 'Data',
  compliance: 'Compliance',
});
export const riskCategorySchema = riskCategory.schema;
export type RiskCategory = z.infer<typeof riskCategorySchema>;

/* ---------------------------------------------------------------------- bugs */

export const BUG_SEVERITIES = ['sev1', 'sev2', 'sev3', 'sev4'] as const;
export const bugSeverity = enumWithLabels(BUG_SEVERITIES, {
  sev1: 'Sev 1 - Critical',
  sev2: 'Sev 2 - High',
  sev3: 'Sev 3 - Medium',
  sev4: 'Sev 4 - Low',
});
export const bugSeveritySchema = bugSeverity.schema;
export type BugSeverity = z.infer<typeof bugSeveritySchema>;

export const BUG_STATUSES = [
  'new',
  'triaged',
  'in_progress',
  'testing',
  'resolved',
  'closed',
  'wont_fix',
] as const;
export const bugStatus = enumWithLabels(BUG_STATUSES, {
  new: 'New',
  triaged: 'Triaged',
  in_progress: 'In Progress',
  testing: 'Testing',
  resolved: 'Resolved',
  closed: 'Closed',
  wont_fix: "Won't Fix",
});
export const bugStatusSchema = bugStatus.schema;
export type BugStatus = z.infer<typeof bugStatusSchema>;

/* ------------------------------------------------------------- technical debt */

export const DEBT_STATUSES = ['identified', 'accepted', 'planned', 'in_progress', 'resolved'] as const;
export const debtStatus = enumWithLabels(DEBT_STATUSES, {
  identified: 'Identified',
  accepted: 'Accepted',
  planned: 'Planned',
  in_progress: 'In Progress',
  resolved: 'Resolved',
});
export const debtStatusSchema = debtStatus.schema;
export type DebtStatus = z.infer<typeof debtStatusSchema>;

export const DEBT_CATEGORIES = [
  'security',
  'architecture',
  'code_quality',
  'infrastructure',
  'data',
  'process',
  'testing',
  'documentation',
] as const;
export const debtCategory = enumWithLabels(DEBT_CATEGORIES, {
  security: 'Security',
  architecture: 'Architecture',
  code_quality: 'Code Quality',
  infrastructure: 'Infrastructure',
  data: 'Data',
  process: 'Process',
  testing: 'Testing',
  documentation: 'Documentation',
});
export const debtCategorySchema = debtCategory.schema;
export type DebtCategory = z.infer<typeof debtCategorySchema>;

/* --------------------------------------------------------------- dependencies */

export const DEPENDENCY_TYPES = [
  'internal',
  'external_team',
  'azure_resource',
  'api',
  'infrastructure',
  'security',
  'networking',
  'vendor',
  'data',
] as const;
export const dependencyType = enumWithLabels(DEPENDENCY_TYPES, {
  internal: 'Internal',
  external_team: 'External Team',
  azure_resource: 'Azure Resource',
  api: 'API',
  infrastructure: 'Infrastructure',
  security: 'Security',
  networking: 'Networking',
  vendor: 'Vendor',
  data: 'Data',
});
export const dependencyTypeSchema = dependencyType.schema;
export type DependencyType = z.infer<typeof dependencyTypeSchema>;

export const DEPENDENCY_STATUSES = [
  'not_started',
  'in_discussion',
  'agreed',
  'in_progress',
  'blocked',
  'delivered',
] as const;
export const dependencyStatus = enumWithLabels(DEPENDENCY_STATUSES, {
  not_started: 'Not Started',
  in_discussion: 'In Discussion',
  agreed: 'Agreed',
  in_progress: 'In Progress',
  blocked: 'Blocked',
  delivered: 'Delivered',
});
export const dependencyStatusSchema = dependencyStatus.schema;
export type DependencyStatus = z.infer<typeof dependencyStatusSchema>;

/* -------------------------------------------------------------------- release */

export const RELEASE_STATUSES = ['planned', 'in_progress', 'released', 'cancelled'] as const;
export const releaseStatus = enumWithLabels(RELEASE_STATUSES, {
  planned: 'Planned',
  in_progress: 'In Progress',
  released: 'Released',
  cancelled: 'Cancelled',
});
export const releaseStatusSchema = releaseStatus.schema;
export type ReleaseStatus = z.infer<typeof releaseStatusSchema>;

export const MILESTONE_TYPES = ['go_live', 'gate', 'decision', 'governance', 'delivery', 'external'] as const;
export const milestoneType = enumWithLabels(MILESTONE_TYPES, {
  go_live: 'Go Live',
  gate: 'Gate',
  decision: 'Decision',
  governance: 'Governance',
  delivery: 'Delivery',
  external: 'External',
});
export const milestoneTypeSchema = milestoneType.schema;
export type MilestoneType = z.infer<typeof milestoneTypeSchema>;

export const MILESTONE_STATUSES = ['planned', 'at_risk', 'hit', 'missed', 'cancelled'] as const;
export const milestoneStatus = enumWithLabels(MILESTONE_STATUSES, {
  planned: 'Planned',
  at_risk: 'At Risk',
  hit: 'Hit',
  missed: 'Missed',
  cancelled: 'Cancelled',
});
export const milestoneStatusSchema = milestoneStatus.schema;
export type MilestoneStatus = z.infer<typeof milestoneStatusSchema>;

/* --------------------------------------------------------------- stakeholders */

export const STAKEHOLDER_TYPES = [
  'executive',
  'business',
  'technical',
  'vendor',
  'governance',
  'delivery',
] as const;
export const stakeholderType = enumWithLabels(STAKEHOLDER_TYPES, {
  executive: 'Executive',
  business: 'Business',
  technical: 'Technical',
  vendor: 'Vendor',
  governance: 'Governance',
  delivery: 'Delivery',
});
export const stakeholderTypeSchema = stakeholderType.schema;
export type StakeholderType = z.infer<typeof stakeholderTypeSchema>;

export const INFLUENCES = ['low', 'medium', 'high'] as const;
export const influence = enumWithLabels(INFLUENCES, {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
});
export const influenceSchema = influence.schema;
export type Influence = z.infer<typeof influenceSchema>;

/* ------------------------------------------------------------------- tickets */

export const TICKET_SYSTEMS = [
  'jira',
  'azure_devops',
  'servicenow',
  'cra',
  'access_request',
  'change_request',
  'procurement',
  'other',
] as const;
export const ticketSystem = enumWithLabels(TICKET_SYSTEMS, {
  jira: 'Jira',
  azure_devops: 'Azure DevOps',
  servicenow: 'ServiceNow',
  cra: 'CRA / Risk Assessment',
  access_request: 'Access Request',
  change_request: 'Change Request',
  procurement: 'Procurement',
  other: 'Other',
});
export const ticketSystemSchema = ticketSystem.schema;
export type TicketSystem = z.infer<typeof ticketSystemSchema>;

export const TICKET_TYPES = [
  'story',
  'bug',
  'task',
  'incident',
  'request',
  'approval',
  'governance',
  'change',
] as const;
export const ticketType = enumWithLabels(TICKET_TYPES, {
  story: 'Story',
  bug: 'Bug',
  task: 'Task',
  incident: 'Incident',
  request: 'Request',
  approval: 'Approval',
  governance: 'Governance',
  change: 'Change',
});
export const ticketTypeSchema = ticketType.schema;
export type TicketType = z.infer<typeof ticketTypeSchema>;

export const TICKET_STATUSES = [
  'draft',
  'submitted',
  'in_review',
  'approved',
  'in_progress',
  'blocked',
  'done',
  'rejected',
  'cancelled',
] as const;
export const ticketStatus = enumWithLabels(TICKET_STATUSES, {
  draft: 'Draft',
  submitted: 'Submitted',
  in_review: 'In Review',
  approved: 'Approved',
  in_progress: 'In Progress',
  blocked: 'Blocked',
  done: 'Done',
  rejected: 'Rejected',
  cancelled: 'Cancelled',
});
export const ticketStatusSchema = ticketStatus.schema;
export type TicketStatus = z.infer<typeof ticketStatusSchema>;

export const OPEN_TICKET_STATUSES: TicketStatus[] = [
  'draft',
  'submitted',
  'in_review',
  'approved',
  'in_progress',
  'blocked',
];

/* --------------------------------------------------------------------- notes */

export const NOTE_SOURCES = ['meeting', 'email', 'teams', 'onenote', 'brain_dump', 'workshop', 'call'] as const;
export const noteSource = enumWithLabels(NOTE_SOURCES, {
  meeting: 'Meeting',
  email: 'Email',
  teams: 'Teams',
  onenote: 'OneNote',
  brain_dump: 'Brain Dump',
  workshop: 'Workshop',
  call: 'Call',
});
export const noteSourceSchema = noteSource.schema;
export type NoteSource = z.infer<typeof noteSourceSchema>;

export const ACTION_STATUSES = ['open', 'in_progress', 'done', 'dropped'] as const;
export const actionStatus = enumWithLabels(ACTION_STATUSES, {
  open: 'Open',
  in_progress: 'In Progress',
  done: 'Done',
  dropped: 'Dropped',
});
export const actionStatusSchema = actionStatus.schema;
export type ActionStatus = z.infer<typeof actionStatusSchema>;
