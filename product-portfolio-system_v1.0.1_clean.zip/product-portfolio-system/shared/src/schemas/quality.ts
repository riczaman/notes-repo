import { z } from 'zod';
import { defineEntity, optionalDate, optionalRef, stringList, text } from '../base';
import {
  bugSeveritySchema,
  bugStatusSchema,
  debtCategorySchema,
  debtStatusSchema,
  prioritySchema,
  riskCategorySchema,
  riskScaleSchema,
  riskStatusSchema,
} from '../enums';

/* ---------------------------------------------------------------------- risk */

export const risk = defineEntity({
  applicationId: optionalRef(),
  title: z.string().min(1),
  description: text(),
  likelihood: riskScaleSchema.default('medium'),
  impact: riskScaleSchema.default('medium'),
  category: riskCategorySchema.default('delivery'),
  status: riskStatusSchema.default('open'),
  mitigation: text(),
  owner: text(),
  dueDate: optionalDate(),
  escalated: z.boolean().default(false),
  /** Free-text pointer to the decision or forum that closes this out. */
  decisionNeeded: text(),
  tags: stringList(),
});

export const riskSchema = risk.entitySchema;
export const riskCreateSchema = risk.createSchema;
export const riskUpdateSchema = risk.updateSchema;
export type Risk = z.infer<typeof riskSchema>;

/* ----------------------------------------------------------------------- bug */

export const bug = defineEntity({
  applicationId: z.string().min(1),
  title: z.string().min(1),
  description: text(),
  severity: bugSeveritySchema.default('sev3'),
  status: bugStatusSchema.default('new'),
  reproductionSteps: stringList(),
  expectedResult: text(),
  actualResult: text(),
  owner: text(),
  reportedBy: text(),
  environment: text(),
  foundInRelease: text(),
  ticketId: optionalRef(),
  tags: stringList(),
});

export const bugSchema = bug.entitySchema;
export const bugCreateSchema = bug.createSchema;
export const bugUpdateSchema = bug.updateSchema;
export type Bug = z.infer<typeof bugSchema>;

/* ------------------------------------------------------------- technical debt */

export const technicalDebt = defineEntity({
  applicationId: z.string().min(1),
  title: z.string().min(1),
  issue: text(),
  impact: text(),
  category: debtCategorySchema.default('architecture'),
  priority: prioritySchema.default('medium'),
  status: debtStatusSchema.default('identified'),
  estimatedEffort: text(),
  suggestedFix: text(),
  owner: text(),
  targetReleaseId: optionalRef(),
  identifiedDate: optionalDate(),
  tags: stringList(),
});

export const technicalDebtSchema = technicalDebt.entitySchema;
export const technicalDebtCreateSchema = technicalDebt.createSchema;
export const technicalDebtUpdateSchema = technicalDebt.updateSchema;
export type TechnicalDebt = z.infer<typeof technicalDebtSchema>;
