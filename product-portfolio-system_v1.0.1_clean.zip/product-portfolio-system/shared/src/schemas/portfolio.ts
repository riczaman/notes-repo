import { z } from 'zod';
import { defineEntity, optionalDate, optionalRef, stringList, text } from '../base';
import {
  healthSchema,
  influenceSchema,
  lifecycleSchema,
  milestoneStatusSchema,
  milestoneTypeSchema,
  releaseStatusSchema,
  stakeholderTypeSchema,
} from '../enums';

/* --------------------------------------------------------------- application */

export const application = defineEntity({
  key: z.string().min(1),
  name: z.string().min(1),
  shortName: z.string().min(1),
  tagline: text(),
  description: text(),
  lifecycle: lifecycleSchema.default('build'),
  health: healthSchema.default('on_track'),
  color: z.string().default('#2dd4bf'),
  businessOwner: text(),
  technicalOwner: text(),
  deliveryLead: text(),
  vendor: text(),
  platform: text(),
  vision: text(),
  currentState: text(),
  futureState: text(),
  architectureNotes: text(),
  executiveSummary: text(),
  leadershipAttention: stringList(),
  stakeholderIds: stringList(),
  startDate: optionalDate(),
  targetGoLive: optionalDate(),
  tags: stringList(),
  sortOrder: z.number().int().default(0),
});

export const applicationSchema = application.entitySchema;
export const applicationCreateSchema = application.createSchema;
export const applicationUpdateSchema = application.updateSchema;
export type Application = z.infer<typeof applicationSchema>;

/* --------------------------------------------------------------- stakeholder */

export const stakeholder = defineEntity({
  name: z.string().min(1),
  role: text(),
  org: text(),
  email: text(),
  type: stakeholderTypeSchema.default('business'),
  influence: influenceSchema.default('medium'),
  applicationIds: stringList(),
  notes: text(),
});

export const stakeholderSchema = stakeholder.entitySchema;
export const stakeholderCreateSchema = stakeholder.createSchema;
export const stakeholderUpdateSchema = stakeholder.updateSchema;
export type Stakeholder = z.infer<typeof stakeholderSchema>;

/* ------------------------------------------------------------------- release */

export const release = defineEntity({
  applicationId: z.string().min(1),
  name: z.string().min(1),
  version: text(),
  status: releaseStatusSchema.default('planned'),
  targetDate: optionalDate(),
  releasedDate: optionalDate(),
  quarter: text(),
  scopeSummary: text(),
  notes: text(),
  tags: stringList(),
});

export const releaseSchema = release.entitySchema;
export const releaseCreateSchema = release.createSchema;
export const releaseUpdateSchema = release.updateSchema;
export type Release = z.infer<typeof releaseSchema>;

/* ----------------------------------------------------------------- milestone */

export const milestone = defineEntity({
  applicationId: optionalRef(),
  name: z.string().min(1),
  description: text(),
  date: z.string(),
  type: milestoneTypeSchema.default('delivery'),
  status: milestoneStatusSchema.default('planned'),
  owner: text(),
  releaseId: optionalRef(),
  quarter: text(),
});

export const milestoneSchema = milestone.entitySchema;
export const milestoneCreateSchema = milestone.createSchema;
export const milestoneUpdateSchema = milestone.updateSchema;
export type Milestone = z.infer<typeof milestoneSchema>;
