import { z } from 'zod';
import { defineEntity, optionalDate, optionalRef, stringList, text } from '../base';
import { horizonSchema, prioritySchema, workStatusSchema } from '../enums';

/* ---------------------------------------------------------------------- epic */

export const epic = defineEntity({
  applicationId: z.string().min(1),
  title: z.string().min(1),
  goal: text(),
  problemStatement: text(),
  businessValue: text(),
  status: workStatusSchema.default('backlog'),
  priority: prioritySchema.default('medium'),
  horizon: horizonSchema.default('later'),
  owner: text(),
  progress: z.number().int().min(0).max(100).default(0),
  openQuestions: stringList(),
  dependencyIds: stringList(),
  riskIds: stringList(),
  quarter: text(),
  startDate: optionalDate(),
  targetDate: optionalDate(),
  tags: stringList(),
});

export const epicSchema = epic.entitySchema;
export const epicCreateSchema = epic.createSchema;
export const epicUpdateSchema = epic.updateSchema;
export type Epic = z.infer<typeof epicSchema>;

/* ------------------------------------------------------------------- feature */

export const feature = defineEntity({
  applicationId: z.string().min(1),
  epicId: optionalRef(),
  title: z.string().min(1),
  problem: text(),
  solution: text(),
  acceptanceCriteria: stringList(),
  technicalDesign: text(),
  estimate: text(),
  priority: prioritySchema.default('medium'),
  status: workStatusSchema.default('backlog'),
  horizon: horizonSchema.default('later'),
  owner: text(),
  targetReleaseId: optionalRef(),
  dependencyIds: stringList(),
  tags: stringList(),
});

export const featureSchema = feature.entitySchema;
export const featureCreateSchema = feature.createSchema;
export const featureUpdateSchema = feature.updateSchema;
export type Feature = z.infer<typeof featureSchema>;

/* ---------------------------------------------------------------------- task */

export const task = defineEntity({
  title: z.string().min(1),
  description: text(),
  applicationId: z.string().min(1),
  epicId: optionalRef(),
  featureId: optionalRef(),
  priority: prioritySchema.default('medium'),
  status: workStatusSchema.default('backlog'),
  horizon: horizonSchema.default('now'),
  owner: text(),
  estimate: text(),
  storyPoints: z.number().nullable().default(null),
  businessValue: z.number().int().min(0).max(5).default(3),
  technicalValue: z.number().int().min(0).max(5).default(3),
  acceptanceCriteria: stringList(),
  dependencyIds: stringList(),
  riskId: optionalRef(),
  notes: text(),
  targetReleaseId: optionalRef(),
  dueDate: optionalDate(),
  quarter: text(),
  tags: stringList(),
  /** Position inside its Kanban column, kept dense on reorder. */
  boardOrder: z.number().default(0),
});

export const taskSchema = task.entitySchema;
export const taskCreateSchema = task.createSchema;
export const taskUpdateSchema = task.updateSchema;
export type Task = z.infer<typeof taskSchema>;
