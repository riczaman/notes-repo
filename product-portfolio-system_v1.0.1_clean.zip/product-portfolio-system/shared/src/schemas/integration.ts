import { z } from 'zod';
import { defineEntity, optionalDate, optionalRef, stringList, text } from '../base';
import {
  actionStatusSchema,
  dependencyStatusSchema,
  dependencyTypeSchema,
  noteSourceSchema,
  prioritySchema,
  riskScaleSchema,
  ticketStatusSchema,
  ticketSystemSchema,
  ticketTypeSchema,
} from '../enums';

/* ---------------------------------------------------------------- dependency */

/**
 * A dependency is a directed edge. The source is always one of our applications.
 * The target is either another application (`toApplicationId`) or a system we do
 * not own (`toExternalName`), which is how external nodes get into the graph
 * without needing a separate "systems" collection to maintain by hand.
 */
export const dependency = defineEntity({
  fromApplicationId: z.string().min(1),
  toApplicationId: optionalRef(),
  toExternalName: text(),
  label: z.string().min(1),
  description: text(),
  type: dependencyTypeSchema.default('internal'),
  status: dependencyStatusSchema.default('in_discussion'),
  criticality: riskScaleSchema.default('medium'),
  owner: text(),
  team: text(),
  neededBy: optionalDate(),
  notes: text(),
  tags: stringList(),
});

export const dependencySchema = dependency.entitySchema;
export const dependencyCreateSchema = dependency.createSchema;
export const dependencyUpdateSchema = dependency.updateSchema;
export type Dependency = z.infer<typeof dependencySchema>;

/* -------------------------------------------------------------------- ticket */

export const ticket = defineEntity({
  applicationId: z.string().min(1),
  system: ticketSystemSchema.default('jira'),
  externalId: z.string().min(1),
  title: z.string().min(1),
  type: ticketTypeSchema.default('request'),
  status: ticketStatusSchema.default('submitted'),
  priority: prioritySchema.default('medium'),
  requester: text(),
  assignee: text(),
  url: text(),
  openedDate: optionalDate(),
  dueDate: optionalDate(),
  closedDate: optionalDate(),
  linkedTaskId: optionalRef(),
  linkedEpicId: optionalRef(),
  linkedRiskId: optionalRef(),
  notes: text(),
  tags: stringList(),
});

export const ticketSchema = ticket.entitySchema;
export const ticketCreateSchema = ticket.createSchema;
export const ticketUpdateSchema = ticket.updateSchema;
export type Ticket = z.infer<typeof ticketSchema>;

/* ---------------------------------------------------------------------- note */

export const actionItemSchema = z.object({
  text: z.string(),
  owner: z.string().default(''),
  dueDate: z.string().nullable().default(null),
  status: actionStatusSchema.default('open'),
});
export type ActionItem = z.infer<typeof actionItemSchema>;

export const note = defineEntity({
  title: z.string().min(1),
  date: z.string(),
  source: noteSourceSchema.default('meeting'),
  applicationIds: stringList(),
  attendees: stringList(),
  rawNotes: text(),
  summary: text(),
  decisions: stringList(),
  openQuestions: stringList(),
  actionItems: z.array(actionItemSchema).default([]),
  /** Set once the note has been triaged into tasks/risks/epics. */
  processed: z.boolean().default(false),
  linkedEntityIds: stringList(),
  tags: stringList(),
});

export const noteSchema = note.entitySchema;
export const noteCreateSchema = note.createSchema;
export const noteUpdateSchema = note.updateSchema;
export type Note = z.infer<typeof noteSchema>;
