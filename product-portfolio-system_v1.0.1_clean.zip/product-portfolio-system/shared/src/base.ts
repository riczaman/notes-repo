import { z } from 'zod';

/**
 * Every stored record carries the same audit fields. Keeping them in one place
 * means a future migration (soft delete, version, createdBy) touches one file.
 */
export const auditFields = {
  id: z.string().min(1),
  createdAt: z.string(),
  updatedAt: z.string(),
};

export const auditSchema = z.object(auditFields);
export type AuditFields = z.infer<typeof auditSchema>;

/** Optional free text that should still round-trip as "" rather than undefined. */
export const text = () => z.string().trim().default('');
export const optionalDate = () => z.string().nullable().default(null);
export const optionalRef = () => z.string().nullable().default(null);
export const stringList = () => z.array(z.string()).default([]);

/**
 * Turns a "create" schema into the full stored entity plus its update variant.
 * One helper keeps the create/update/entity trio consistent for all 13 collections.
 */
export function defineEntity<S extends z.ZodRawShape>(shape: S) {
  const createSchema = z.object(shape);
  return {
    createSchema,
    updateSchema: createSchema.partial(),
    entitySchema: createSchema.extend(auditFields),
  };
}

export type EntityOf<T extends { entitySchema: z.ZodTypeAny }> = z.infer<T['entitySchema']>;
