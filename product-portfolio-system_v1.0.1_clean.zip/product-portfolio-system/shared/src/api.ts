import { z } from 'zod';

/** Envelope used by every list endpoint. */
export interface ListMeta {
  total: number;
  page: number;
  pageSize: number;
  pageCount: number;
}

export interface ListResponse<T> {
  data: T[];
  meta: ListMeta;
}

export interface ItemResponse<T> {
  data: T;
}

export interface ApiErrorBody {
  error: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export const listQuerySchema = z.object({
  q: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(500).default(200),
  sort: z.string().optional(),
  order: z.enum(['asc', 'desc']).default('asc'),
});
export type ListQuery = z.infer<typeof listQuerySchema>;

/** Names of every collection the API exposes. Used to generate routes and the client. */
export const ENTITY_NAMES = [
  'applications',
  'epics',
  'features',
  'tasks',
  'releases',
  'milestones',
  'stakeholders',
  'risks',
  'bugs',
  'technicalDebt',
  'dependencies',
  'tickets',
  'notes',
] as const;
export type EntityName = (typeof ENTITY_NAMES)[number];

/** URL segment for each collection (camelCase collections get kebab paths). */
export const ENTITY_PATHS: Record<EntityName, string> = {
  applications: 'applications',
  epics: 'epics',
  features: 'features',
  tasks: 'tasks',
  releases: 'releases',
  milestones: 'milestones',
  stakeholders: 'stakeholders',
  risks: 'risks',
  bugs: 'bugs',
  technicalDebt: 'technical-debt',
  dependencies: 'dependencies',
  tickets: 'tickets',
  notes: 'notes',
};

export interface SearchHit {
  entity: EntityName;
  id: string;
  title: string;
  subtitle: string;
  applicationId: string | null;
  score: number;
}

export interface PortfolioCounts {
  applications: number;
  epics: number;
  features: number;
  tasks: number;
  openTasks: number;
  blockedTasks: number;
  doneTasks: number;
  risks: number;
  openRisks: number;
  criticalRisks: number;
  bugs: number;
  openBugs: number;
  technicalDebt: number;
  openTechnicalDebt: number;
  dependencies: number;
  blockedDependencies: number;
  tickets: number;
  openTickets: number;
  releases: number;
  milestones: number;
}

export interface ApplicationRollup {
  applicationId: string;
  name: string;
  shortName: string;
  color: string;
  health: string;
  lifecycle: string;
  progress: number;
  totals: {
    epics: number;
    features: number;
    tasks: number;
    tasksDone: number;
    tasksBlocked: number;
    openRisks: number;
    criticalRisks: number;
    openBugs: number;
    openDebt: number;
    openTickets: number;
    dependencies: number;
  };
}

export interface DashboardSummary {
  generatedAt: string;
  counts: PortfolioCounts;
  applications: ApplicationRollup[];
  statusBreakdown: { status: string; count: number }[];
  priorityBreakdown: { priority: string; count: number }[];
  riskMatrix: { likelihood: string; impact: string; count: number; ids: string[] }[];
  horizonBreakdown: { horizon: string; count: number }[];
  upcomingMilestones: {
    id: string;
    name: string;
    date: string;
    status: string;
    applicationId: string | null;
    type: string;
  }[];
  topRisks: { id: string; title: string; applicationId: string | null; score: number; status: string }[];
}

export interface GraphNode {
  id: string;
  label: string;
  kind: 'application' | 'external';
  category?: string;
  color?: string;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  label: string;
  type: string;
  status: string;
  criticality: string;
}

export interface DependencyGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}
