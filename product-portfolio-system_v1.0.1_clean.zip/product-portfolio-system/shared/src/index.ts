export * from './api';
export * from './base';
export * from './enums';
export * from './registry';
export * from './schemas/portfolio';
export * from './schemas/delivery';
export * from './schemas/quality';
export * from './schemas/integration';

import type { Application, Milestone, Release, Stakeholder } from './schemas/portfolio';
import type { Epic, Feature, Task } from './schemas/delivery';
import type { Bug, Risk, TechnicalDebt } from './schemas/quality';
import type { Dependency, Note, Ticket } from './schemas/integration';

/** Maps a collection name to its record type, so the API client stays typed end to end. */
export interface EntityTypeMap {
  applications: Application;
  epics: Epic;
  features: Feature;
  tasks: Task;
  releases: Release;
  milestones: Milestone;
  stakeholders: Stakeholder;
  risks: Risk;
  bugs: Bug;
  technicalDebt: TechnicalDebt;
  dependencies: Dependency;
  tickets: Ticket;
  notes: Note;
}
