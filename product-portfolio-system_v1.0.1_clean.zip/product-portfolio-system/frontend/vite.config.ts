import path from 'node:path';
import { fileURLToPath } from 'node:url';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

const here = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(here, 'src'),
      // The shared contract is compiled from source, so a schema change is picked
      // up by the dev server without a build step in between.
      '@shared': path.resolve(here, '../shared/src'),
    },
  },
  build: {
    rollupOptions: {
      output: {
        /**
         * Vendor code is split by library so a change to application code does
         * not invalidate the cached copy of React or Recharts. Combined with the
         * lazy routes, the charting, graph and drag-and-drop libraries are only
         * fetched by the views that actually use them.
         */
        manualChunks: {
          react: ['react', 'react-dom', 'react-router-dom'],
          query: ['@tanstack/react-query'],
          charts: ['recharts'],
          graph: ['@xyflow/react'],
          dnd: ['@dnd-kit/core', '@dnd-kit/sortable', '@dnd-kit/utilities'],
          forms: ['react-hook-form', '@hookform/resolvers', 'zod'],
        },
      },
    },
  },
  server: {
    port: 5173,
    // Same-origin API calls in the browser: no CORS in development, and the
    // production build can sit behind the same host without changing the client.
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:4000',
        changeOrigin: true,
      },
    },
    fs: {
      allow: [path.resolve(here, '..')],
    },
  },
});
