import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { queryKeys } from '@/lib/queryKeys';

/** Derived, read-only views. All computed server side from the same snapshot. */

export const useDashboard = () =>
  useQuery({
    queryKey: queryKeys.dashboard(),
    queryFn: async () => (await api.dashboard()).data,
  });

export const useApplicationOverview = (id?: string) =>
  useQuery({
    queryKey: queryKeys.overview(id ?? ''),
    queryFn: async () => (await api.applicationOverview(id as string)).data,
    enabled: Boolean(id),
  });

export const useGlobalSearch = (term: string) =>
  useQuery({
    queryKey: queryKeys.search(term),
    queryFn: async () => (await api.search(term)).data,
    enabled: term.trim().length >= 2,
  });

export const useDependencyGraph = (applicationId?: string) =>
  useQuery({
    queryKey: queryKeys.graph(applicationId),
    queryFn: async () => (await api.dependencyGraph(applicationId)).data,
  });
