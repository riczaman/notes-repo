import { useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';

/**
 * Filter state lives in the URL, not in component state.
 *
 * That makes a filtered view shareable and bookmarkable, survives a refresh,
 * and means back/forward behave the way a user expects. It also keeps the
 * filter bar stateless, so it can be reused on every page unchanged.
 */
export function useFilters(defaults: Record<string, string> = {}) {
  const [params, setParams] = useSearchParams();

  const values = useMemo(() => {
    const result: Record<string, string> = { ...defaults };
    params.forEach((value, key) => {
      result[key] = value;
    });
    return result;
  }, [params, defaults]);

  const setFilter = useCallback(
    (key: string, value: string) => {
      setParams(
        (current) => {
          const next = new URLSearchParams(current);
          if (!value || value === 'all') next.delete(key);
          else next.set(key, value);
          return next;
        },
        { replace: true },
      );
    },
    [setParams],
  );

  const clear = useCallback(() => setParams(new URLSearchParams(), { replace: true }), [setParams]);

  /** Only the filters the API should receive: `all` and empty values are dropped. */
  const query = useMemo(() => {
    const result: Record<string, string> = {};
    for (const [key, value] of Object.entries(values)) {
      if (value && value !== 'all') result[key] = value;
    }
    return result;
  }, [values]);

  const activeCount = Object.keys(query).filter((key) => key !== 'q').length;

  return { values, query, setFilter, clear, activeCount };
}
