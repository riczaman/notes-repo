import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ENTITY_REGISTRY, type EntityName, type EntityTypeMap } from '@shared';
import { toast } from 'sonner';
import { api, ApiError } from '@/lib/api';
import { DERIVED_KEYS, queryKeys } from '@/lib/queryKeys';

/**
 * Generic data hooks.
 *
 * One implementation serves all 13 collections. Pages call
 * `useEntityList('tasks', filters)` and get typed records, loading state and
 * cache invalidation without a bespoke hook per entity.
 */

export function useEntityList<K extends EntityName>(entity: K, params?: Record<string, unknown>, enabled = true) {
  return useQuery({
    queryKey: queryKeys.list(entity, params),
    queryFn: async () => (await api.list(entity, params)).data,
    enabled,
    placeholderData: (previous) => previous,
  });
}

export function useEntityItem<K extends EntityName>(entity: K, id?: string) {
  return useQuery({
    queryKey: queryKeys.item(entity, id ?? ''),
    queryFn: async () => (await api.get(entity, id as string)).data,
    enabled: Boolean(id),
  });
}

const useInvalidate = (entity: EntityName) => {
  const client = useQueryClient();
  return () => {
    void client.invalidateQueries({ queryKey: queryKeys.entity(entity) });
    for (const key of DERIVED_KEYS) void client.invalidateQueries({ queryKey: key });
  };
};

const describe = (error: unknown): string => {
  if (error instanceof ApiError) {
    const details = error.details as { fieldErrors?: Record<string, string[]> } | undefined;
    const first = details?.fieldErrors ? Object.entries(details.fieldErrors)[0] : undefined;
    return first ? `${first[0]}: ${first[1]?.[0] ?? 'invalid'}` : error.message;
  }
  return error instanceof Error ? error.message : 'Something went wrong.';
};

export function useCreateEntity<K extends EntityName>(entity: K) {
  const invalidate = useInvalidate(entity);
  return useMutation({
    mutationFn: (body: Partial<EntityTypeMap[K]>) => api.create(entity, body),
    onSuccess: () => {
      invalidate();
      toast.success(`${ENTITY_REGISTRY[entity].singular} created`);
    },
    onError: (error) => toast.error(`Could not create`, { description: describe(error) }),
  });
}

export function useUpdateEntity<K extends EntityName>(entity: K) {
  const invalidate = useInvalidate(entity);
  return useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Partial<EntityTypeMap[K]> }) => api.update(entity, id, patch),
    onSuccess: () => {
      invalidate();
      toast.success(`${ENTITY_REGISTRY[entity].singular} updated`);
    },
    onError: (error) => toast.error('Could not save', { description: describe(error) }),
  });
}

export function useDeleteEntity<K extends EntityName>(entity: K) {
  const invalidate = useInvalidate(entity);
  return useMutation({
    mutationFn: (id: string) => api.remove(entity, id),
    onSuccess: () => {
      invalidate();
      toast.success(`${ENTITY_REGISTRY[entity].singular} deleted`);
    },
    onError: (error) => toast.error('Could not delete', { description: describe(error) }),
  });
}

/**
 * Bulk patch with an optimistic cache write. The board must not flicker back to
 * the old column while the request is in flight, so the cache is updated first
 * and rolled back if the server rejects it.
 */
export function useBulkUpdate<K extends EntityName>(entity: K) {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (updates: { id: string; patch: Partial<EntityTypeMap[K]> }[]) => api.bulk(entity, updates),
    onMutate: async (updates) => {
      await client.cancelQueries({ queryKey: queryKeys.entity(entity) });
      const snapshot = client.getQueriesData({ queryKey: queryKeys.entity(entity) });
      const patchById = new Map(updates.map((u) => [u.id, u.patch]));

      client.setQueriesData<EntityTypeMap[K][]>({ queryKey: queryKeys.entity(entity) }, (rows) =>
        Array.isArray(rows)
          ? rows.map((row) => {
              const patch = patchById.get((row as { id: string }).id);
              return patch ? { ...row, ...patch } : row;
            })
          : rows,
      );

      return { snapshot };
    },
    onError: (error, _updates, context) => {
      for (const [key, data] of context?.snapshot ?? []) client.setQueryData(key, data);
      toast.error('Could not move the card', { description: describe(error) });
    },
    onSettled: () => {
      void client.invalidateQueries({ queryKey: queryKeys.entity(entity) });
      for (const key of DERIVED_KEYS) void client.invalidateQueries({ queryKey: key });
    },
  });
}
