import {
  actionStatus,
  bugSeverity,
  bugStatus,
  debtCategory,
  debtStatus,
  dependencyStatus,
  dependencyType,
  health,
  horizon,
  influence,
  lifecycle,
  milestoneStatus,
  milestoneType,
  noteSource,
  priority,
  releaseStatus,
  riskCategory,
  riskScale,
  riskStatus,
  stakeholderType,
  ticketStatus,
  ticketSystem,
  ticketType,
  workStatus,
  RISK_SCALE_WEIGHT,
  type Priority,
  type RiskScale,
} from '@shared';

export type Tone = 'neutral' | 'info' | 'success' | 'warning' | 'danger' | 'primary' | 'accent';

/**
 * Every controlled value renders through here, so a status looks the same on a
 * card, in a table and on a board without three copies of the mapping.
 */
const TONES: Record<string, Tone> = {
  // work status
  backlog: 'neutral',
  discovery: 'info',
  ready: 'primary',
  in_progress: 'primary',
  blocked: 'danger',
  testing: 'warning',
  done: 'success',
  // priority
  critical: 'danger',
  high: 'warning',
  medium: 'info',
  low: 'neutral',
  // health
  on_track: 'success',
  at_risk: 'warning',
  off_track: 'danger',
  not_started: 'neutral',
  complete: 'success',
  // lifecycle
  build: 'primary',
  live: 'success',
  sustain: 'info',
  sunset: 'neutral',
  // risk status
  open: 'danger',
  mitigating: 'warning',
  monitoring: 'info',
  accepted: 'neutral',
  closed: 'success',
  // bug severity
  sev1: 'danger',
  sev2: 'warning',
  sev3: 'info',
  sev4: 'neutral',
  // bug status
  new: 'danger',
  triaged: 'warning',
  resolved: 'success',
  wont_fix: 'neutral',
  // debt status
  identified: 'warning',
  planned: 'info',
  // dependency status
  not_started_dep: 'neutral',
  in_discussion: 'warning',
  agreed: 'info',
  delivered: 'success',
  // release / milestone
  released: 'success',
  cancelled: 'neutral',
  hit: 'success',
  missed: 'danger',
  // ticket status
  draft: 'neutral',
  submitted: 'info',
  in_review: 'warning',
  approved: 'primary',
  rejected: 'danger',
  // horizon
  now: 'primary',
  next: 'info',
  later: 'neutral',
  // scale
  very_high: 'danger',
};

export const toneOf = (value: string): Tone => TONES[value] ?? 'neutral';

export const TONE_CLASSES: Record<Tone, string> = {
  neutral: 'bg-foreground/[0.06] text-muted border-border',
  info: 'bg-info/10 text-info border-info/25',
  success: 'bg-success/10 text-success border-success/25',
  warning: 'bg-warning/10 text-warning border-warning/25',
  danger: 'bg-danger/10 text-danger border-danger/25',
  primary: 'bg-primary/12 text-primary border-primary/30',
  accent: 'bg-accent/10 text-accent border-accent/25',
};

export const TONE_DOT: Record<Tone, string> = {
  neutral: 'bg-subtle',
  info: 'bg-info',
  success: 'bg-success',
  warning: 'bg-warning',
  danger: 'bg-danger',
  primary: 'bg-primary',
  accent: 'bg-accent',
};

/** Every enum the UI renders, keyed so a field config can name one by string. */
export const ENUMS = {
  workStatus,
  priority,
  horizon,
  lifecycle,
  health,
  riskScale,
  riskStatus,
  riskCategory,
  bugSeverity,
  bugStatus,
  debtStatus,
  debtCategory,
  dependencyType,
  dependencyStatus,
  releaseStatus,
  milestoneType,
  milestoneStatus,
  stakeholderType,
  influence,
  ticketSystem,
  ticketType,
  ticketStatus,
  noteSource,
  actionStatus,
} as const;

export type EnumKey = keyof typeof ENUMS;

const LABEL_LOOKUP: Record<string, string> = Object.values(ENUMS).reduce<Record<string, string>>((acc, group) => {
  for (const option of group.options) acc[option.value] ||= option.label;
  return acc;
}, {});

export const labelOf = (value?: string | null): string => {
  if (!value) return '—';
  return LABEL_LOOKUP[value] ?? value;
};

export const riskScore = (likelihood: RiskScale, impact: RiskScale): number =>
  RISK_SCALE_WEIGHT[likelihood] * RISK_SCALE_WEIGHT[impact];

export const riskBand = (score: number): { label: string; tone: Tone } => {
  if (score >= 12) return { label: 'Critical', tone: 'danger' };
  if (score >= 9) return { label: 'High', tone: 'danger' };
  if (score >= 6) return { label: 'Elevated', tone: 'warning' };
  if (score >= 3) return { label: 'Moderate', tone: 'info' };
  return { label: 'Low', tone: 'neutral' };
};

export const PRIORITY_ORDER: Record<Priority, number> = {
  critical: 0,
  high: 1,
  medium: 2,
  low: 3,
};

/** Kanban columns, in board order. */
export const BOARD_COLUMNS = workStatus.values.map((value) => ({
  id: value,
  label: workStatus.labels[value],
}));
