import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** Tailwind-aware class merge used by every component. */
export const cn = (...inputs: ClassValue[]) => twMerge(clsx(inputs));

/**
 * `new Date('2026-08-10')` is parsed as UTC midnight, which renders as the 9th
 * anywhere west of Greenwich. Date-only strings in this app mean a calendar day,
 * not an instant, so they are constructed in local time. Timestamps that carry a
 * time component (createdAt, updatedAt) are left alone.
 */
const parseDate = (value: string): Date | null => {
  const dateOnly = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  const date = dateOnly
    ? new Date(Number(dateOnly[1]), Number(dateOnly[2]) - 1, Number(dateOnly[3]))
    : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

export const formatDate = (value?: string | null, fallback = '—'): string => {
  if (!value) return fallback;
  const date = parseDate(value);
  if (!date) return value;
  return date.toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' });
};

export const formatDateTime = (value?: string | null, fallback = '—'): string => {
  if (!value) return fallback;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString(undefined, {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const relativeDays = (value?: string | null): number | null => {
  if (!value) return null;
  const date = parseDate(value);
  if (!date) return null;
  date.setHours(0, 0, 0, 0);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((date.getTime() - today.getTime()) / 86_400_000);
};

export const quarterOf = (value?: string | null): string => {
  if (!value) return '';
  const date = parseDate(value);
  if (!date) return '';
  return `Q${Math.floor(date.getMonth() / 3) + 1} ${date.getFullYear()}`;
};

export function groupBy<T, K extends string>(rows: T[], key: (row: T) => K): Record<K, T[]> {
  return rows.reduce(
    (acc, row) => {
      const value = key(row);
      (acc[value] ||= []).push(row);
      return acc;
    },
    {} as Record<K, T[]>,
  );
}

export const percent = (value: number, total: number): number =>
  total === 0 ? 0 : Math.round((value / total) * 100);

export const initials = (name: string): string =>
  name
    .split(/[\s/]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('');

/** Deterministic pastel-free hue from a string. Used for owner avatars. */
export const hueFromString = (value: string): number => {
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) hash = (hash * 31 + value.charCodeAt(i)) % 360;
  return hash;
};

export const truncate = (value: string, max: number): string =>
  value.length <= max ? value : `${value.slice(0, max - 1)}…`;

export const uniq = <T>(rows: T[]): T[] => [...new Set(rows)];

export const compactNumber = (value: number): string =>
  value >= 1000 ? `${(value / 1000).toFixed(1)}k` : String(value);
