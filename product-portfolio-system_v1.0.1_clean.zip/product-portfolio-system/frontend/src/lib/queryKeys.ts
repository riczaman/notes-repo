import type { EntityName } from '@shared';

/**
 * Query keys in one place. Mutations invalidate by prefix, which is why every
 * key starts with the collection name: writing a task invalidates every task
 * list regardless of the filters that produced it, plus the derived views.
 */
export const queryKeys = {
  entity: (entity: EntityName) => [entity] as const,
  list: (entity: EntityName, params?: Record<string, unknown>) => [entity, 'list', params ?? {}] as const,
  item: (entity: EntityName, id: string) => [entity, 'item', id] as const,
  dashboard: () => ['dashboard'] as const,
  overview: (id: string) => ['overview', id] as const,
  search: (term: string) => ['search', term] as const,
  graph: (applicationId?: string) => ['graph', applicationId ?? 'all'] as const,
};

/** Views that are computed from many collections and must refresh after any write. */
export const DERIVED_KEYS = [['dashboard'], ['overview'], ['graph'], ['search']];
