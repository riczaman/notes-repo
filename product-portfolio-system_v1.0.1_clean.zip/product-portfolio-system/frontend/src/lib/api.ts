import {
  ENTITY_REGISTRY,
  type ApiErrorBody,
  type DashboardSummary,
  type DependencyGraph,
  type EntityName,
  type EntityTypeMap,
  type ItemResponse,
  type ListResponse,
  type SearchHit,
} from '@shared';

const BASE = '/api';

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
    readonly details?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

/** Turns a filter object into a query string, dropping empty values. */
export const toQuery = (params: Record<string, unknown> = {}): string => {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '' || value === 'all') continue;
    if (Array.isArray(value)) {
      if (value.length === 0) continue;
      search.set(key, value.join(','));
    } else {
      search.set(key, String(value));
    }
  }
  const qs = search.toString();
  return qs ? `?${qs}` : '';
};

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
  });

  if (response.status === 204) return undefined as T;

  const payload = await response.json().catch(() => null);

  if (!response.ok) {
    const body = payload as ApiErrorBody | null;
    throw new ApiError(
      response.status,
      body?.error?.code ?? 'UNKNOWN',
      body?.error?.message ?? `Request failed with status ${response.status}.`,
      body?.error?.details,
    );
  }

  return payload as T;
}

const pathFor = (entity: EntityName) => ENTITY_REGISTRY[entity].path;

/**
 * One typed client for every collection.
 *
 * `EntityTypeMap` ties the collection name to its record type, so
 * `api.list('tasks')` returns `Task[]` and a typo in the name is a compile error.
 */
export const api = {
  list: <K extends EntityName>(entity: K, params?: Record<string, unknown>) =>
    request<ListResponse<EntityTypeMap[K]>>(`/${pathFor(entity)}${toQuery(params)}`),

  get: <K extends EntityName>(entity: K, id: string) =>
    request<ItemResponse<EntityTypeMap[K]>>(`/${pathFor(entity)}/${id}`),

  create: <K extends EntityName>(entity: K, body: Partial<EntityTypeMap[K]>) =>
    request<ItemResponse<EntityTypeMap[K]>>(`/${pathFor(entity)}`, {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  update: <K extends EntityName>(entity: K, id: string, body: Partial<EntityTypeMap[K]>) =>
    request<ItemResponse<EntityTypeMap[K]>>(`/${pathFor(entity)}/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(body),
    }),

  remove: <K extends EntityName>(entity: K, id: string) =>
    request<void>(`/${pathFor(entity)}/${id}`, { method: 'DELETE' }),

  /** One request for a whole board move rather than one per card. */
  bulk: <K extends EntityName>(entity: K, updates: { id: string; patch: Partial<EntityTypeMap[K]> }[]) =>
    request<ItemResponse<EntityTypeMap[K][]>>(`/${pathFor(entity)}/bulk`, {
      method: 'PATCH',
      body: JSON.stringify({ updates }),
    }),

  dashboard: () => request<ItemResponse<DashboardSummary>>('/dashboard/summary'),

  applicationOverview: (id: string) => request<ItemResponse<ApplicationOverview>>(`/applications/${id}/overview`),

  search: (q: string) => request<ItemResponse<SearchHit[]>>(`/search${toQuery({ q })}`),

  dependencyGraph: (applicationId?: string) =>
    request<ItemResponse<DependencyGraph>>(`/graph/dependencies${toQuery({ applicationId })}`),

  health: () => request<ItemResponse<{ status: string; uptimeSeconds: number }>>('/health'),
};

export interface ApplicationOverview {
  application: EntityTypeMap['applications'];
  rollup: DashboardSummary['applications'][number];
  epics: EntityTypeMap['epics'][];
  features: EntityTypeMap['features'][];
  tasks: EntityTypeMap['tasks'][];
  releases: EntityTypeMap['releases'][];
  milestones: EntityTypeMap['milestones'][];
  risks: EntityTypeMap['risks'][];
  bugs: EntityTypeMap['bugs'][];
  technicalDebt: EntityTypeMap['technicalDebt'][];
  tickets: EntityTypeMap['tickets'][];
  dependencies: EntityTypeMap['dependencies'][];
  stakeholders: EntityTypeMap['stakeholders'][];
  notes: EntityTypeMap['notes'][];
}
