import type { EntityName } from '@shared';
import type { EnumKey } from '@/lib/display';

export type FieldType =
  | 'text'
  | 'textarea'
  | 'longtext'
  | 'select'
  | 'number'
  | 'date'
  | 'tags'
  | 'list'
  | 'switch'
  | 'ref'
  | 'multiref'
  | 'color';

export interface FieldDef {
  name: string;
  label: string;
  type: FieldType;
  /** For `select`: which shared enum supplies the options. */
  enumKey?: EnumKey;
  /** For `ref` / `multiref`: which collection to pick from. */
  refEntity?: EntityName;
  /** Narrow ref options to records belonging to the currently selected application. */
  scopeToApplication?: boolean;
  placeholder?: string;
  help?: string;
  /** Grid span inside the two-column form. */
  span?: 1 | 2;
  min?: number;
  max?: number;
}

const f = (field: FieldDef): FieldDef => field;

const APPLICATION_REF = f({
  name: 'applicationId',
  label: 'Application',
  type: 'ref',
  refEntity: 'applications',
});

const TAGS = f({ name: 'tags', label: 'Tags', type: 'tags', span: 2, placeholder: 'comma, separated' });

/**
 * Form definitions.
 *
 * A field list per collection is all it takes to get a working create/edit
 * dialog, because EntityFormDialog renders by type and validates against the
 * same Zod schema the API uses. Adding a field to a schema and a line here is
 * the whole change.
 */
export const FORM_FIELDS: Record<EntityName, FieldDef[]> = {
  applications: [
    f({ name: 'name', label: 'Name', type: 'text', span: 2 }),
    f({ name: 'shortName', label: 'Short name', type: 'text' }),
    f({ name: 'key', label: 'Key', type: 'text', placeholder: 'USFF' }),
    f({ name: 'tagline', label: 'Tagline', type: 'text', span: 2 }),
    f({ name: 'lifecycle', label: 'Lifecycle', type: 'select', enumKey: 'lifecycle' }),
    f({ name: 'health', label: 'Health', type: 'select', enumKey: 'health' }),
    f({ name: 'color', label: 'Colour', type: 'color' }),
    f({ name: 'sortOrder', label: 'Sort order', type: 'number' }),
    f({ name: 'businessOwner', label: 'Business owner', type: 'text' }),
    f({ name: 'technicalOwner', label: 'Technical owner', type: 'text' }),
    f({ name: 'deliveryLead', label: 'Delivery lead', type: 'text' }),
    f({ name: 'vendor', label: 'Vendor', type: 'text' }),
    f({ name: 'platform', label: 'Platform', type: 'text', span: 2 }),
    f({ name: 'startDate', label: 'Start date', type: 'date' }),
    f({ name: 'targetGoLive', label: 'Target go-live', type: 'date' }),
    f({ name: 'description', label: 'Description', type: 'textarea', span: 2 }),
    f({ name: 'executiveSummary', label: 'Executive summary', type: 'textarea', span: 2 }),
    f({ name: 'vision', label: 'Vision', type: 'textarea', span: 2 }),
    f({ name: 'currentState', label: 'Current state', type: 'textarea', span: 2 }),
    f({ name: 'futureState', label: 'Future state', type: 'textarea', span: 2 }),
    f({ name: 'architectureNotes', label: 'Architecture notes', type: 'textarea', span: 2 }),
    f({
      name: 'leadershipAttention',
      label: 'Leadership attention',
      type: 'list',
      span: 2,
      help: 'One item per line.',
    }),
    TAGS,
  ],

  epics: [
    f({ name: 'title', label: 'Title', type: 'text', span: 2 }),
    APPLICATION_REF,
    f({ name: 'owner', label: 'Owner', type: 'text' }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'workStatus' }),
    f({ name: 'priority', label: 'Priority', type: 'select', enumKey: 'priority' }),
    f({ name: 'horizon', label: 'Horizon', type: 'select', enumKey: 'horizon' }),
    f({ name: 'progress', label: 'Progress %', type: 'number', min: 0, max: 100 }),
    f({ name: 'quarter', label: 'Quarter', type: 'text', placeholder: 'Q4 2026' }),
    f({ name: 'targetDate', label: 'Target date', type: 'date' }),
    f({ name: 'goal', label: 'Goal', type: 'textarea', span: 2 }),
    f({ name: 'problemStatement', label: 'Problem statement', type: 'textarea', span: 2 }),
    f({ name: 'businessValue', label: 'Business value', type: 'textarea', span: 2 }),
    f({ name: 'openQuestions', label: 'Open questions', type: 'list', span: 2, help: 'One per line.' }),
    TAGS,
  ],

  features: [
    f({ name: 'title', label: 'Title', type: 'text', span: 2 }),
    APPLICATION_REF,
    f({ name: 'epicId', label: 'Epic', type: 'ref', refEntity: 'epics', scopeToApplication: true }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'workStatus' }),
    f({ name: 'priority', label: 'Priority', type: 'select', enumKey: 'priority' }),
    f({ name: 'horizon', label: 'Horizon', type: 'select', enumKey: 'horizon' }),
    f({ name: 'owner', label: 'Owner', type: 'text' }),
    f({ name: 'estimate', label: 'Estimate', type: 'text', placeholder: '2 sprints' }),
    f({
      name: 'targetReleaseId',
      label: 'Target release',
      type: 'ref',
      refEntity: 'releases',
      scopeToApplication: true,
    }),
    f({ name: 'problem', label: 'Problem', type: 'textarea', span: 2 }),
    f({ name: 'solution', label: 'Solution', type: 'textarea', span: 2 }),
    f({ name: 'acceptanceCriteria', label: 'Acceptance criteria', type: 'list', span: 2, help: 'One per line.' }),
    f({ name: 'technicalDesign', label: 'Technical design', type: 'textarea', span: 2 }),
    TAGS,
  ],

  tasks: [
    f({ name: 'title', label: 'Title', type: 'text', span: 2 }),
    APPLICATION_REF,
    f({ name: 'owner', label: 'Owner', type: 'text' }),
    f({ name: 'epicId', label: 'Epic', type: 'ref', refEntity: 'epics', scopeToApplication: true }),
    f({ name: 'featureId', label: 'Feature', type: 'ref', refEntity: 'features', scopeToApplication: true }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'workStatus' }),
    f({ name: 'priority', label: 'Priority', type: 'select', enumKey: 'priority' }),
    f({ name: 'horizon', label: 'Horizon', type: 'select', enumKey: 'horizon' }),
    f({ name: 'estimate', label: 'Estimate', type: 'text', placeholder: '3d' }),
    f({ name: 'storyPoints', label: 'Story points', type: 'number', min: 0 }),
    f({ name: 'dueDate', label: 'Due date', type: 'date' }),
    f({ name: 'businessValue', label: 'Business value (0-5)', type: 'number', min: 0, max: 5 }),
    f({ name: 'technicalValue', label: 'Technical value (0-5)', type: 'number', min: 0, max: 5 }),
    f({ name: 'quarter', label: 'Quarter', type: 'text', placeholder: 'Q4 2026' }),
    f({
      name: 'targetReleaseId',
      label: 'Target release',
      type: 'ref',
      refEntity: 'releases',
      scopeToApplication: true,
    }),
    f({ name: 'riskId', label: 'Linked risk', type: 'ref', refEntity: 'risks' }),
    f({ name: 'description', label: 'Description', type: 'textarea', span: 2 }),
    f({ name: 'acceptanceCriteria', label: 'Acceptance criteria', type: 'list', span: 2, help: 'One per line.' }),
    f({ name: 'notes', label: 'Notes', type: 'textarea', span: 2 }),
    TAGS,
  ],

  releases: [
    f({ name: 'name', label: 'Name', type: 'text', span: 2 }),
    APPLICATION_REF,
    f({ name: 'version', label: 'Version', type: 'text' }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'releaseStatus' }),
    f({ name: 'quarter', label: 'Quarter', type: 'text', placeholder: 'Q4 2026' }),
    f({ name: 'targetDate', label: 'Target date', type: 'date' }),
    f({ name: 'releasedDate', label: 'Released date', type: 'date' }),
    f({ name: 'scopeSummary', label: 'Scope summary', type: 'textarea', span: 2 }),
    f({ name: 'notes', label: 'Notes', type: 'textarea', span: 2 }),
    TAGS,
  ],

  milestones: [
    f({ name: 'name', label: 'Name', type: 'text', span: 2 }),
    APPLICATION_REF,
    f({ name: 'date', label: 'Date', type: 'date' }),
    f({ name: 'type', label: 'Type', type: 'select', enumKey: 'milestoneType' }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'milestoneStatus' }),
    f({ name: 'owner', label: 'Owner', type: 'text' }),
    f({ name: 'quarter', label: 'Quarter', type: 'text' }),
    f({ name: 'releaseId', label: 'Release', type: 'ref', refEntity: 'releases', scopeToApplication: true }),
    f({ name: 'description', label: 'Description', type: 'textarea', span: 2 }),
  ],

  stakeholders: [
    f({ name: 'name', label: 'Name', type: 'text', span: 2 }),
    f({ name: 'role', label: 'Role', type: 'text' }),
    f({ name: 'org', label: 'Organisation', type: 'text' }),
    f({ name: 'email', label: 'Email', type: 'text' }),
    f({ name: 'type', label: 'Type', type: 'select', enumKey: 'stakeholderType' }),
    f({ name: 'influence', label: 'Influence', type: 'select', enumKey: 'influence' }),
    f({ name: 'applicationIds', label: 'Applications', type: 'multiref', refEntity: 'applications', span: 2 }),
    f({ name: 'notes', label: 'Notes', type: 'textarea', span: 2 }),
  ],

  risks: [
    f({ name: 'title', label: 'Title', type: 'text', span: 2 }),
    APPLICATION_REF,
    f({ name: 'owner', label: 'Owner', type: 'text' }),
    f({ name: 'likelihood', label: 'Likelihood', type: 'select', enumKey: 'riskScale' }),
    f({ name: 'impact', label: 'Impact', type: 'select', enumKey: 'riskScale' }),
    f({ name: 'category', label: 'Category', type: 'select', enumKey: 'riskCategory' }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'riskStatus' }),
    f({ name: 'dueDate', label: 'Review by', type: 'date' }),
    f({ name: 'escalated', label: 'Escalated to leadership', type: 'switch' }),
    f({ name: 'description', label: 'Description', type: 'textarea', span: 2 }),
    f({ name: 'mitigation', label: 'Mitigation', type: 'textarea', span: 2 }),
    f({ name: 'decisionNeeded', label: 'Decision needed', type: 'textarea', span: 2 }),
    TAGS,
  ],

  bugs: [
    f({ name: 'title', label: 'Title', type: 'text', span: 2 }),
    APPLICATION_REF,
    f({ name: 'owner', label: 'Owner', type: 'text' }),
    f({ name: 'severity', label: 'Severity', type: 'select', enumKey: 'bugSeverity' }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'bugStatus' }),
    f({ name: 'reportedBy', label: 'Reported by', type: 'text' }),
    f({ name: 'environment', label: 'Environment', type: 'text', placeholder: 'UAT' }),
    f({ name: 'foundInRelease', label: 'Found in release', type: 'text' }),
    f({ name: 'ticketId', label: 'Linked request', type: 'ref', refEntity: 'tickets', scopeToApplication: true }),
    f({ name: 'description', label: 'Description', type: 'textarea', span: 2 }),
    f({ name: 'reproductionSteps', label: 'Reproduction steps', type: 'list', span: 2, help: 'One step per line.' }),
    f({ name: 'expectedResult', label: 'Expected result', type: 'textarea', span: 2 }),
    f({ name: 'actualResult', label: 'Actual result', type: 'textarea', span: 2 }),
    TAGS,
  ],

  technicalDebt: [
    f({ name: 'title', label: 'Title', type: 'text', span: 2 }),
    APPLICATION_REF,
    f({ name: 'owner', label: 'Owner', type: 'text' }),
    f({ name: 'category', label: 'Category', type: 'select', enumKey: 'debtCategory' }),
    f({ name: 'priority', label: 'Priority', type: 'select', enumKey: 'priority' }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'debtStatus' }),
    f({ name: 'estimatedEffort', label: 'Estimated effort', type: 'text', placeholder: '3 days' }),
    f({ name: 'identifiedDate', label: 'Identified', type: 'date' }),
    f({
      name: 'targetReleaseId',
      label: 'Target release',
      type: 'ref',
      refEntity: 'releases',
      scopeToApplication: true,
    }),
    f({ name: 'issue', label: 'Issue', type: 'textarea', span: 2 }),
    f({ name: 'impact', label: 'Impact', type: 'textarea', span: 2 }),
    f({ name: 'suggestedFix', label: 'Suggested fix', type: 'textarea', span: 2 }),
    TAGS,
  ],

  dependencies: [
    f({ name: 'label', label: 'Label', type: 'text', span: 2 }),
    f({ name: 'fromApplicationId', label: 'From application', type: 'ref', refEntity: 'applications' }),
    f({ name: 'toApplicationId', label: 'To application', type: 'ref', refEntity: 'applications' }),
    f({
      name: 'toExternalName',
      label: 'To external system',
      type: 'text',
      span: 2,
      help: 'Use this when the target is not one of our applications. It becomes a node on the graph.',
    }),
    f({ name: 'type', label: 'Type', type: 'select', enumKey: 'dependencyType' }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'dependencyStatus' }),
    f({ name: 'criticality', label: 'Criticality', type: 'select', enumKey: 'riskScale' }),
    f({ name: 'neededBy', label: 'Needed by', type: 'date' }),
    f({ name: 'owner', label: 'Owner', type: 'text' }),
    f({ name: 'team', label: 'Team', type: 'text' }),
    f({ name: 'description', label: 'Description', type: 'textarea', span: 2 }),
    f({ name: 'notes', label: 'Notes', type: 'textarea', span: 2 }),
    TAGS,
  ],

  tickets: [
    f({ name: 'externalId', label: 'Ticket number', type: 'text', placeholder: 'JIRA-1234' }),
    f({ name: 'system', label: 'System', type: 'select', enumKey: 'ticketSystem' }),
    f({ name: 'title', label: 'Title', type: 'text', span: 2 }),
    APPLICATION_REF,
    f({ name: 'type', label: 'Type', type: 'select', enumKey: 'ticketType' }),
    f({ name: 'status', label: 'Status', type: 'select', enumKey: 'ticketStatus' }),
    f({ name: 'priority', label: 'Priority', type: 'select', enumKey: 'priority' }),
    f({ name: 'requester', label: 'Requester', type: 'text' }),
    f({ name: 'assignee', label: 'Assignee', type: 'text' }),
    f({ name: 'url', label: 'Link', type: 'text', span: 2, placeholder: 'https://' }),
    f({ name: 'openedDate', label: 'Opened', type: 'date' }),
    f({ name: 'dueDate', label: 'Due', type: 'date' }),
    f({ name: 'closedDate', label: 'Closed', type: 'date' }),
    f({ name: 'linkedTaskId', label: 'Linked task', type: 'ref', refEntity: 'tasks', scopeToApplication: true }),
    f({ name: 'linkedEpicId', label: 'Linked epic', type: 'ref', refEntity: 'epics', scopeToApplication: true }),
    f({ name: 'linkedRiskId', label: 'Linked risk', type: 'ref', refEntity: 'risks' }),
    f({ name: 'notes', label: 'Notes', type: 'textarea', span: 2 }),
    TAGS,
  ],

  notes: [
    f({ name: 'title', label: 'Title', type: 'text', span: 2 }),
    f({ name: 'date', label: 'Date', type: 'date' }),
    f({ name: 'source', label: 'Source', type: 'select', enumKey: 'noteSource' }),
    f({ name: 'applicationIds', label: 'Applications', type: 'multiref', refEntity: 'applications', span: 2 }),
    f({ name: 'attendees', label: 'Attendees', type: 'tags', span: 2, placeholder: 'comma, separated' }),
    f({ name: 'summary', label: 'Summary', type: 'textarea', span: 2 }),
    f({
      name: 'rawNotes',
      label: 'Raw notes',
      type: 'longtext',
      span: 2,
      help: 'Paste anything here. Triage it into tasks, risks and epics afterwards.',
    }),
    f({ name: 'decisions', label: 'Decisions', type: 'list', span: 2, help: 'One per line.' }),
    f({ name: 'openQuestions', label: 'Open questions', type: 'list', span: 2, help: 'One per line.' }),
    f({ name: 'processed', label: 'Triaged into records', type: 'switch' }),
    TAGS,
  ],
};

/** Values used when a create dialog opens with nothing pre-filled. */
export const CREATE_DEFAULTS: Partial<Record<EntityName, Record<string, unknown>>> = {
  applications: { color: '#2dd4bf', lifecycle: 'build', health: 'on_track', sortOrder: 99 },
  epics: { status: 'backlog', priority: 'medium', horizon: 'later', progress: 0 },
  features: { status: 'backlog', priority: 'medium', horizon: 'later' },
  tasks: { status: 'backlog', priority: 'medium', horizon: 'now', businessValue: 3, technicalValue: 3 },
  releases: { status: 'planned' },
  milestones: { type: 'delivery', status: 'planned', date: new Date().toISOString().slice(0, 10) },
  stakeholders: { type: 'business', influence: 'medium' },
  risks: { likelihood: 'medium', impact: 'medium', category: 'delivery', status: 'open', escalated: false },
  bugs: { severity: 'sev3', status: 'new' },
  technicalDebt: { category: 'architecture', priority: 'medium', status: 'identified' },
  dependencies: { type: 'internal', status: 'in_discussion', criticality: 'medium' },
  tickets: { system: 'jira', type: 'request', status: 'submitted', priority: 'medium' },
  notes: { source: 'meeting', date: new Date().toISOString().slice(0, 10), processed: false },
};
