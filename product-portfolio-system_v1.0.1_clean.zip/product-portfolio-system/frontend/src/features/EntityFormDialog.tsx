import * as React from 'react';
import { Controller, useForm } from 'react-hook-form';
import { ENTITY_REGISTRY, type EntityName } from '@shared';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogBody,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input, Textarea } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';
import { Switch } from '@/components/ui/misc';
import { ENUMS } from '@/lib/display';
import { cn } from '@/lib/utils';
import { useCreateEntity, useEntityList, useUpdateEntity } from '@/hooks/useEntities';
import { CREATE_DEFAULTS, FORM_FIELDS, type FieldDef } from './fields';

/* ------------------------------------------------------------------ helpers */

const toFormValue = (field: FieldDef, raw: unknown): unknown => {
  if (field.type === 'tags' || field.type === 'list') return Array.isArray(raw) ? raw : [];
  if (field.type === 'multiref') return Array.isArray(raw) ? raw : [];
  if (field.type === 'switch') return Boolean(raw);
  if (raw === null || raw === undefined) return '';
  return raw;
};

/**
 * Form values are strings; the API wants typed values. This is the single place
 * that conversion happens, driven by the field type rather than by field name.
 */
const toPayloadValue = (field: FieldDef, raw: unknown): unknown => {
  switch (field.type) {
    case 'number': {
      if (raw === '' || raw === null || raw === undefined) return undefined;
      const parsed = Number(raw);
      return Number.isNaN(parsed) ? undefined : parsed;
    }
    case 'date':
    case 'ref':
      // Nullable in every schema, so an empty control clears the value.
      return raw === '' || raw === undefined ? null : raw;
    case 'switch':
      return Boolean(raw);
    case 'tags':
    case 'list':
    case 'multiref':
      return Array.isArray(raw) ? raw.filter(Boolean) : [];
    default:
      return raw ?? '';
  }
};

/**
 * Zod's default messages are written for developers ("String must contain at
 * least 1 character(s)"). The schema stays the source of truth; only the
 * wording shown to a person is rewritten.
 */
const friendlyMessage = (message: string): string => {
  if (/at least 1 character/i.test(message)) return 'Required';
  if (/^Expected .*, received null$/i.test(message)) return 'Required';
  if (/^Required$/i.test(message)) return 'Required';
  return message;
};

/* -------------------------------------------------------------- ref control */

const RefSelect = ({
  field,
  value,
  onChange,
  applicationId,
}: {
  field: FieldDef;
  value: string;
  onChange: (value: string) => void;
  applicationId?: string;
}) => {
  const scoped = field.scopeToApplication && applicationId ? { applicationId } : undefined;
  const { data = [] } = useEntityList(field.refEntity as EntityName, scoped);
  const descriptor = ENTITY_REGISTRY[field.refEntity as EntityName];

  const options = data.map((row) => ({
    value: (row as { id: string }).id,
    label: String((row as Record<string, unknown>)[descriptor.titleField] ?? '(untitled)'),
  }));

  return (
    <Select
      value={value || 'all'}
      onValueChange={(next) => onChange(next === 'all' ? '' : next)}
      options={options}
      allowEmpty
      emptyLabel="None"
      placeholder="None"
    />
  );
};

const MultiRefToggle = ({
  field,
  value,
  onChange,
}: {
  field: FieldDef;
  value: string[];
  onChange: (value: string[]) => void;
}) => {
  const { data = [] } = useEntityList(field.refEntity as EntityName);
  const descriptor = ENTITY_REGISTRY[field.refEntity as EntityName];

  return (
    <div className="flex flex-wrap gap-1.5">
      {data.map((row) => {
        const id = (row as { id: string }).id;
        const label = String((row as Record<string, unknown>)[descriptor.titleField] ?? id);
        const active = value.includes(id);
        return (
          <button
            key={id}
            type="button"
            onClick={() => onChange(active ? value.filter((v) => v !== id) : [...value, id])}
            className={cn(
              'rounded-full border px-2.5 py-1 text-xs transition-colors',
              active
                ? 'border-primary/40 bg-primary/12 text-primary'
                : 'border-border text-muted hover:border-primary/30 hover:text-foreground',
            )}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
};

/* ------------------------------------------------------------------- dialog */

interface EntityFormDialogProps<K extends EntityName> {
  entity: K;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Record being edited. Omit to create. */
  record?: Record<string, unknown> | null;
  /** Pre-filled values for a create, e.g. the application whose page you are on. */
  presets?: Record<string, unknown>;
}

/**
 * One dialog creates and edits every collection.
 *
 * Validation runs against the same Zod schema the API validates with, so the
 * client cannot submit something the server would reject for a different reason
 * than the one shown. Server-side field errors are mapped back onto the form,
 * which keeps the two in step without duplicating the rules.
 */
export function EntityFormDialog<K extends EntityName>({
  entity,
  open,
  onOpenChange,
  record,
  presets,
}: EntityFormDialogProps<K>) {
  const descriptor = ENTITY_REGISTRY[entity];
  const fields = FORM_FIELDS[entity];
  const isEdit = Boolean(record?.id);

  const create = useCreateEntity(entity);
  const update = useUpdateEntity(entity);

  const defaultValues = React.useMemo(() => {
    const source: Record<string, unknown> = {
      ...(CREATE_DEFAULTS[entity] ?? {}),
      ...(presets ?? {}),
      ...(record ?? {}),
    };
    return Object.fromEntries(fields.map((field) => [field.name, toFormValue(field, source[field.name])]));
  }, [entity, fields, record, presets]);

  const form = useForm<Record<string, unknown>>({ defaultValues });

  /**
   * Which fields are mandatory is derived by parsing an empty object against the
   * create schema: anything with a Zod default passes, so only the genuinely
   * required fields come back as errors. No second list to keep in sync.
   */
  const requiredFields = React.useMemo(() => {
    const result = descriptor.createSchema.safeParse({});
    if (result.success) return new Set<string>();
    return new Set(Object.keys(result.error.flatten().fieldErrors));
  }, [descriptor]);

  React.useEffect(() => {
    if (open) form.reset(defaultValues);
  }, [open, defaultValues, form]);

  const applicationId = String(form.watch('applicationId') ?? form.watch('fromApplicationId') ?? '');

  const onSubmit = form.handleSubmit(async (values) => {
    const payload: Record<string, unknown> = {};
    for (const field of fields) {
      const next = toPayloadValue(field, values[field.name]);
      if (next !== undefined) payload[field.name] = next;
    }

    const schema = isEdit ? descriptor.updateSchema : descriptor.createSchema;
    const parsed = schema.safeParse(payload);
    if (!parsed.success) {
      const fieldErrors = parsed.error.flatten().fieldErrors as Record<string, string[] | undefined>;
      for (const [name, messages] of Object.entries(fieldErrors)) {
        form.setError(name, { message: friendlyMessage(messages?.[0] ?? 'Invalid value') });
      }
      return;
    }

    try {
      if (isEdit) await update.mutateAsync({ id: String(record?.id), patch: parsed.data as never });
      else await create.mutateAsync(parsed.data as never);
      onOpenChange(false);
    } catch {
      // Toast is raised by the mutation; the dialog stays open so nothing is lost.
    }
  });

  const pending = create.isPending || update.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="xl">
        <DialogHeader>
          <DialogTitle>
            {isEdit ? 'Edit' : 'New'} {descriptor.singular.toLowerCase()}
          </DialogTitle>
          <DialogDescription>
            {isEdit
              ? `Changes are written to backend/data/${descriptor.file}.`
              : `A new record is appended to backend/data/${descriptor.file}.`}
          </DialogDescription>
        </DialogHeader>

        <DialogBody>
          <form id="entity-form" onSubmit={onSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {fields.map((field) => {
              const error = form.formState.errors[field.name]?.message as string | undefined;
              return (
                <div key={field.name} className={cn('space-y-1.5', field.span === 2 && 'sm:col-span-2')}>
                  <Label htmlFor={field.name}>
                    {field.label}
                    {requiredFields.has(field.name) ? <span className="ml-1 text-danger">*</span> : null}
                  </Label>

                  {field.type === 'text' || field.type === 'color' ? (
                    <div className={field.type === 'color' ? 'flex items-center gap-2' : undefined}>
                      {field.type === 'color' ? (
                        <input
                          type="color"
                          value={String(form.watch(field.name) ?? '#2dd4bf')}
                          onChange={(event) => form.setValue(field.name, event.target.value)}
                          className="size-9 shrink-0 cursor-pointer rounded-md border border-input bg-transparent p-1"
                        />
                      ) : null}
                      <Input id={field.name} placeholder={field.placeholder} {...form.register(field.name)} />
                    </div>
                  ) : null}

                  {field.type === 'number' ? (
                    <Input
                      id={field.name}
                      type="number"
                      min={field.min}
                      max={field.max}
                      {...form.register(field.name)}
                    />
                  ) : null}

                  {field.type === 'date' ? <Input id={field.name} type="date" {...form.register(field.name)} /> : null}

                  {field.type === 'textarea' ? (
                    <Textarea id={field.name} placeholder={field.placeholder} {...form.register(field.name)} />
                  ) : null}

                  {field.type === 'longtext' ? (
                    <Textarea id={field.name} rows={12} className="font-mono text-xs" {...form.register(field.name)} />
                  ) : null}

                  {field.type === 'select' ? (
                    <Controller
                      control={form.control}
                      name={field.name}
                      render={({ field: control }) => (
                        <Select
                          value={String(control.value ?? '')}
                          onValueChange={control.onChange}
                          options={[...(ENUMS[field.enumKey!]?.options ?? [])]}
                        />
                      )}
                    />
                  ) : null}

                  {field.type === 'switch' ? (
                    <Controller
                      control={form.control}
                      name={field.name}
                      render={({ field: control }) => (
                        <div className="flex h-9 items-center">
                          <Switch checked={Boolean(control.value)} onCheckedChange={control.onChange} />
                        </div>
                      )}
                    />
                  ) : null}

                  {field.type === 'ref' ? (
                    <Controller
                      control={form.control}
                      name={field.name}
                      render={({ field: control }) => (
                        <RefSelect
                          field={field}
                          value={String(control.value ?? '')}
                          onChange={control.onChange}
                          applicationId={applicationId}
                        />
                      )}
                    />
                  ) : null}

                  {field.type === 'multiref' ? (
                    <Controller
                      control={form.control}
                      name={field.name}
                      render={({ field: control }) => (
                        <MultiRefToggle
                          field={field}
                          value={(control.value as string[]) ?? []}
                          onChange={control.onChange}
                        />
                      )}
                    />
                  ) : null}

                  {field.type === 'tags' ? (
                    <Controller
                      control={form.control}
                      name={field.name}
                      render={({ field: control }) => (
                        <Input
                          value={((control.value as string[]) ?? []).join(', ')}
                          placeholder={field.placeholder}
                          onChange={(event) =>
                            control.onChange(
                              event.target.value
                                .split(',')
                                .map((part) => part.trim())
                                .filter(Boolean),
                            )
                          }
                        />
                      )}
                    />
                  ) : null}

                  {field.type === 'list' ? (
                    <Controller
                      control={form.control}
                      name={field.name}
                      render={({ field: control }) => (
                        <Textarea
                          value={((control.value as string[]) ?? []).join('\n')}
                          onChange={(event) =>
                            control.onChange(
                              event.target.value
                                .split('\n')
                                .map((line) => line.trim())
                                .filter(Boolean),
                            )
                          }
                        />
                      )}
                    />
                  ) : null}

                  {error ? <p className="text-xs text-danger">{error}</p> : null}
                  {!error && field.help ? <p className="text-xs text-subtle">{field.help}</p> : null}
                </div>
              );
            })}
          </form>
        </DialogBody>

        <DialogFooter>
          <Button variant="ghost" type="button" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button variant="primary" type="submit" form="entity-form" disabled={pending}>
            {pending ? 'Saving…' : isEdit ? 'Save changes' : `Create ${descriptor.singular.toLowerCase()}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
