import * as React from 'react';
import { MoreHorizontal, Pencil, Plus, Trash2 } from 'lucide-react';
import { ENTITY_REGISTRY, type EntityName } from '@shared';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { DataTable, type Column } from '@/components/common/DataTable';
import { FilterBar } from '@/components/common/FilterBar';
import { PageHeader } from '@/components/common/PageHeader';
import { ConfirmDialog } from '@/components/common/ConfirmDialog';
import { useDeleteEntity, useEntityList } from '@/hooks/useEntities';
import { useDebounce } from '@/hooks/useDebounce';
import { useFilters } from '@/hooks/useFilters';
import { COLUMNS } from './columns';
import { FILTERS } from './filters';
import { EntityFormDialog } from './EntityFormDialog';
import { useLookups } from './useLookups';

interface EntityListPageProps {
  entity: EntityName;
  title?: string;
  description?: string;
  /** Locks the page to one application: hides that filter and pre-fills new records. */
  applicationId?: string;
  /** Rendered above the table, e.g. summary tiles on the risk register. */
  children?: React.ReactNode;
  embedded?: boolean;
}

/**
 * The generic list page.
 *
 * Every collection route renders this component. The differences between
 * Tasks, Risks and Requests live in `columns.tsx`, `filters.ts` and `fields.ts`
 * as data, not as thirteen near-identical page components. That is the single
 * biggest reason this codebase stays small as collections are added.
 */
export function EntityListPage({
  entity,
  title,
  description,
  applicationId,
  children,
  embedded = false,
}: EntityListPageProps) {
  const descriptor = ENTITY_REGISTRY[entity];
  const lookups = useLookups();

  const { values, query, setFilter, clear, activeCount } = useFilters();
  const debouncedSearch = useDebounce(values.q ?? '', 250);

  const appField = entity === 'dependencies' ? 'fromApplicationId' : 'applicationId';
  const effectiveQuery = React.useMemo(
    () => ({
      ...query,
      q: debouncedSearch || undefined,
      ...(applicationId ? { [appField]: applicationId } : {}),
    }),
    [query, debouncedSearch, applicationId, appField],
  );

  const { data: rows = [], isLoading } = useEntityList(entity, effectiveQuery);
  const remove = useDeleteEntity(entity);

  const [editing, setEditing] = React.useState<Record<string, unknown> | null | undefined>(undefined);
  const [deleting, setDeleting] = React.useState<Record<string, unknown> | null>(null);

  const filters = React.useMemo(() => {
    const all = FILTERS[entity](lookups);
    return applicationId ? all.filter((filter) => filter.key !== appField) : all;
  }, [entity, lookups, applicationId, appField]);

  const columns = React.useMemo<Column<Record<string, any>>[]>(() => {
    const base = COLUMNS[entity]({ appById: lookups.appById });
    const visible = applicationId ? base.filter((column) => column.key !== appField) : base;
    return [
      ...visible,
      {
        key: '__actions',
        header: '',
        width: '44px',
        sortable: false,
        align: 'right',
        render: (row) => (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                onClick={(event) => event.stopPropagation()}
                aria-label="Row actions"
              >
                <MoreHorizontal className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" onClick={(event) => event.stopPropagation()}>
              <DropdownMenuItem onSelect={() => setEditing(row)}>
                <Pencil /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem destructive onSelect={() => setDeleting(row)}>
                <Trash2 /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ),
      },
    ];
  }, [entity, lookups, applicationId, appField]);

  const newButton = (
    <Button variant="primary" onClick={() => setEditing(null)}>
      <Plus /> New {descriptor.singular.toLowerCase()}
    </Button>
  );

  return (
    <div>
      {embedded ? (
        <div className="mb-4 flex items-center justify-between gap-3">
          <p className="text-sm text-muted">
            <span className="num font-medium text-foreground">{rows.length}</span> {descriptor.label.toLowerCase()}
          </p>
          {newButton}
        </div>
      ) : (
        <PageHeader
          title={title ?? descriptor.label}
          description={description}
          actions={newButton}
          meta={
            <span className="text-xs text-muted">
              <span className="num font-medium text-foreground">{rows.length}</span> records ·{' '}
              <span className="font-mono text-2xs">backend/data/{descriptor.file}</span>
            </span>
          }
        />
      )}

      {children}

      <FilterBar
        filters={filters}
        values={values}
        onChange={setFilter}
        onClear={clear}
        activeCount={activeCount}
        searchPlaceholder={`Search ${descriptor.label.toLowerCase()}`}
      />

      <DataTable
        rows={rows as Record<string, any>[]}
        columns={columns}
        loading={isLoading}
        rowKey={(row) => String(row.id)}
        onRowClick={(row) => setEditing(row)}
        empty={{
          title: `No ${descriptor.label.toLowerCase()} match`,
          description:
            activeCount > 0 || values.q
              ? 'Try clearing the filters, or create the first record.'
              : `Nothing has been added yet. Create one, or edit backend/data/${descriptor.file} directly.`,
          action: newButton,
        }}
      />

      {editing !== undefined ? (
        <EntityFormDialog
          entity={entity}
          open
          onOpenChange={(open) => !open && setEditing(undefined)}
          record={editing}
          presets={applicationId ? { [appField]: applicationId } : undefined}
        />
      ) : null}

      <ConfirmDialog
        open={Boolean(deleting)}
        onOpenChange={(open) => !open && setDeleting(null)}
        title={`Delete this ${descriptor.singular.toLowerCase()}?`}
        description={
          entity === 'applications'
            ? 'Deleting an application also removes its epics, features, tasks, risks, debt, dependencies and requests. This cannot be undone.'
            : undefined
        }
        pending={remove.isPending}
        onConfirm={() => {
          if (!deleting) return;
          remove.mutate(String(deleting.id), { onSuccess: () => setDeleting(null) });
        }}
      />
    </div>
  );
}
