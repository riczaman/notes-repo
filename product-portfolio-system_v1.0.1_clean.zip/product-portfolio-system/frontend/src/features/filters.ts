import type { EntityName } from '@shared';
import type { FilterDef } from '@/components/common/FilterBar';
import type { Option } from '@/components/ui/select';
import { ENUMS } from '@/lib/display';

export interface FilterCtx {
  appOptions: Option[];
  ownerOptions: Option[];
  releaseOptions: Option[];
  quarterOptions: Option[];
}

const enumFilter = (key: string, label: string, enumKey: keyof typeof ENUMS, width?: string): FilterDef => ({
  key,
  label,
  options: [...ENUMS[enumKey].options],
  width,
});

const appFilter = (ctx: FilterCtx, key = 'applicationId'): FilterDef => ({
  key,
  label: 'applications',
  options: ctx.appOptions,
  width: 'w-[160px]',
});

const ownerFilter = (ctx: FilterCtx): FilterDef => ({ key: 'owner', label: 'owners', options: ctx.ownerOptions });

/**
 * Which dimensions each collection can be sliced by. The API filters on any
 * field name, so this list is purely about which ones are worth putting in
 * front of a person.
 */
export const FILTERS: Record<EntityName, (ctx: FilterCtx) => FilterDef[]> = {
  applications: () => [
    enumFilter('lifecycle', 'lifecycle', 'lifecycle'),
    enumFilter('health', 'health', 'health'),
  ],
  epics: (ctx) => [
    appFilter(ctx),
    enumFilter('status', 'statuses', 'workStatus'),
    enumFilter('priority', 'priorities', 'priority'),
    enumFilter('horizon', 'horizons', 'horizon'),
    ownerFilter(ctx),
  ],
  features: (ctx) => [
    appFilter(ctx),
    enumFilter('status', 'statuses', 'workStatus'),
    enumFilter('priority', 'priorities', 'priority'),
    enumFilter('horizon', 'horizons', 'horizon'),
    { key: 'targetReleaseId', label: 'releases', options: ctx.releaseOptions, width: 'w-[180px]' },
  ],
  tasks: (ctx) => [
    appFilter(ctx),
    enumFilter('status', 'statuses', 'workStatus'),
    enumFilter('priority', 'priorities', 'priority'),
    enumFilter('horizon', 'horizons', 'horizon'),
    ownerFilter(ctx),
    { key: 'targetReleaseId', label: 'releases', options: ctx.releaseOptions, width: 'w-[180px]' },
    { key: 'quarter', label: 'quarters', options: ctx.quarterOptions, width: 'w-[130px]' },
  ],
  releases: (ctx) => [appFilter(ctx), enumFilter('status', 'statuses', 'releaseStatus')],
  milestones: (ctx) => [
    appFilter(ctx),
    enumFilter('type', 'types', 'milestoneType'),
    enumFilter('status', 'statuses', 'milestoneStatus'),
  ],
  stakeholders: () => [
    enumFilter('type', 'types', 'stakeholderType'),
    enumFilter('influence', 'influence', 'influence'),
  ],
  risks: (ctx) => [
    appFilter(ctx),
    enumFilter('status', 'statuses', 'riskStatus'),
    enumFilter('likelihood', 'likelihood', 'riskScale'),
    enumFilter('impact', 'impact', 'riskScale'),
    enumFilter('category', 'categories', 'riskCategory'),
    ownerFilter(ctx),
  ],
  bugs: (ctx) => [
    appFilter(ctx),
    enumFilter('severity', 'severities', 'bugSeverity'),
    enumFilter('status', 'statuses', 'bugStatus'),
    ownerFilter(ctx),
  ],
  technicalDebt: (ctx) => [
    appFilter(ctx),
    enumFilter('category', 'categories', 'debtCategory'),
    enumFilter('priority', 'priorities', 'priority'),
    enumFilter('status', 'statuses', 'debtStatus'),
  ],
  dependencies: (ctx) => [
    appFilter(ctx, 'fromApplicationId'),
    enumFilter('type', 'types', 'dependencyType'),
    enumFilter('status', 'statuses', 'dependencyStatus'),
    enumFilter('criticality', 'criticality', 'riskScale'),
  ],
  tickets: (ctx) => [
    appFilter(ctx),
    enumFilter('system', 'systems', 'ticketSystem', 'w-[160px]'),
    enumFilter('type', 'types', 'ticketType'),
    enumFilter('status', 'statuses', 'ticketStatus'),
    enumFilter('priority', 'priorities', 'priority'),
  ],
  notes: () => [enumFilter('source', 'sources', 'noteSource')],
};
