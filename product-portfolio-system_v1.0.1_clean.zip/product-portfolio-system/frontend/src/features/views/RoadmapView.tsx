import * as React from 'react';
import { CircleDashed, Plus } from 'lucide-react';
import type { Epic } from '@shared';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/ui/badge';
import { Progress, Skeleton } from '@/components/ui/misc';
import { Select } from '@/components/ui/select';
import { AppChip, OwnerChip } from '@/components/common/atoms';
import { EntityFormDialog } from '@/features/EntityFormDialog';
import { useLookups } from '@/features/useLookups';
import { useEntityList } from '@/hooks/useEntities';
import { horizon as horizonEnum } from '@shared';
import { cn, formatDate, groupBy } from '@/lib/utils';

type GroupKey = 'horizon' | 'quarter' | 'status' | 'application';

const GROUP_OPTIONS = [
  { value: 'horizon', label: 'Now / Next / Later' },
  { value: 'quarter', label: 'Quarter' },
  { value: 'status', label: 'Status' },
  { value: 'application', label: 'Application' },
];

const HORIZON_BLURB: Record<string, string> = {
  now: 'Committed and in flight this quarter.',
  next: 'Agreed direction, not yet started.',
  later: 'Directional. Dates deliberately soft.',
};

/**
 * Roadmap.
 *
 * Epics are the roadmap unit rather than tasks: a roadmap that lists tasks is a
 * backlog with different styling. The grouping switch re-cuts the same records
 * by horizon, quarter, release or application without refetching.
 */
export function RoadmapView({ applicationId }: { applicationId?: string }) {
  const query = React.useMemo(() => (applicationId ? { applicationId } : {}), [applicationId]);
  const { data: epics = [], isLoading } = useEntityList('epics', query);
  const { data: features = [] } = useEntityList('features', query);
  const { appById } = useLookups();

  const [groupBy_, setGroupBy] = React.useState<GroupKey>('horizon');
  const [editing, setEditing] = React.useState<Epic | null | undefined>(undefined);

  const featureCount = React.useMemo(() => {
    const counts = new Map<string, number>();
    for (const feature of features) {
      if (!feature.epicId) continue;
      counts.set(feature.epicId, (counts.get(feature.epicId) ?? 0) + 1);
    }
    return counts;
  }, [features]);

  const groups = React.useMemo(() => {
    const keyOf = (epic: Epic): string => {
      switch (groupBy_) {
        case 'quarter':
          return epic.quarter || 'Unscheduled';
        case 'status':
          return epic.status;
        case 'application':
          return appById(epic.applicationId)?.name ?? 'Unassigned';
        default:
          return epic.horizon;
      }
    };

    const grouped = groupBy(epics, keyOf);

    const order =
      groupBy_ === 'horizon'
        ? [...horizonEnum.values]
        : Object.keys(grouped).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

    return order.filter((key) => grouped[key]?.length).map((key) => ({ key, epics: grouped[key] ?? [] }));
  }, [epics, groupBy_, appById]);

  if (isLoading) {
    return (
      <div className="grid gap-4 lg:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-96" />
        ))}
      </div>
    );
  }

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <span className="text-xs text-subtle">Group by</span>
        <Select
          value={groupBy_}
          onValueChange={(value) => setGroupBy(value as GroupKey)}
          options={GROUP_OPTIONS}
          className="w-[190px]"
        />
        <span className="text-xs text-muted">
          <span className="num font-medium text-foreground">{epics.length}</span> epics
        </span>
        <Button variant="primary" size="sm" className="ml-auto" onClick={() => setEditing(null)}>
          <Plus /> New epic
        </Button>
      </div>

      <div
        className={cn(
          'grid items-start gap-4',
          groups.length <= 3 ? 'lg:grid-cols-3' : 'md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4',
        )}
      >
        {groups.map((group) => (
          <section key={group.key} className="panel flex flex-col overflow-hidden">
            <header className="flex items-center justify-between gap-2 border-b border-border px-4 py-3">
              <div className="min-w-0">
                <h3 className="truncate text-sm font-semibold capitalize tracking-tight text-foreground">
                  {groupBy_ === 'horizon' ? horizonEnum.labels[group.key as 'now'] : group.key}
                </h3>
                {groupBy_ === 'horizon' && HORIZON_BLURB[group.key] ? (
                  <p className="mt-0.5 text-2xs text-subtle">{HORIZON_BLURB[group.key]}</p>
                ) : null}
              </div>
              <span className="num shrink-0 rounded-full border border-border px-2 py-0.5 text-2xs text-muted">
                {group.epics.length}
              </span>
            </header>

            <div className="flex flex-col gap-2 p-3">
              {group.epics.map((epic) => (
                <button
                  key={epic.id}
                  type="button"
                  onClick={() => setEditing(epic)}
                  className="rounded-md border border-border bg-card p-3 text-left transition-colors hover:border-primary/40"
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="min-w-0 flex-1 text-sm font-medium leading-snug text-foreground">{epic.title}</p>
                    <StatusBadge value={epic.priority} dot={false} />
                  </div>

                  {epic.goal ? <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-muted">{epic.goal}</p> : null}

                  <div className="mt-2.5">
                    <div className="mb-1 flex items-center justify-between text-2xs text-subtle">
                      <span>{featureCount.get(epic.id) ?? 0} features</span>
                      <span className="num">{epic.progress}%</span>
                    </div>
                    <Progress value={epic.progress} tone={epic.status === 'blocked' ? 'danger' : 'primary'} />
                  </div>

                  <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 border-t border-border/70 pt-2">
                    <div className="flex items-center gap-2">
                      {!applicationId ? <AppChip application={appById(epic.applicationId)} size="xs" link={false} /> : null}
                      <StatusBadge value={epic.status} />
                    </div>
                    <span className="text-2xs text-subtle">
                      {epic.targetDate ? formatDate(epic.targetDate) : epic.quarter || 'No date'}
                    </span>
                  </div>

                  {epic.openQuestions.length > 0 ? (
                    <p className="mt-2 inline-flex items-center gap-1.5 text-2xs text-warning">
                      <CircleDashed className="size-3" />
                      {epic.openQuestions.length} open question{epic.openQuestions.length === 1 ? '' : 's'}
                    </p>
                  ) : null}

                  {epic.owner ? (
                    <div className="mt-2">
                      <OwnerChip name={epic.owner} />
                    </div>
                  ) : null}
                </button>
              ))}
            </div>
          </section>
        ))}
      </div>

      {editing !== undefined ? (
        <EntityFormDialog
          entity="epics"
          open
          onOpenChange={(open) => !open && setEditing(undefined)}
          record={editing as unknown as Record<string, unknown>}
          presets={applicationId ? { applicationId } : undefined}
        />
      ) : null}
    </>
  );
}
