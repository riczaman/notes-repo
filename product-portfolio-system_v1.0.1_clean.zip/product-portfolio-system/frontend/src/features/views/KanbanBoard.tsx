import * as React from 'react';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  closestCorners,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragOverEvent,
  type DragStartEvent,
} from '@dnd-kit/core';
import { SortableContext, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical, Plus } from 'lucide-react';
import type { Task, WorkStatus } from '@shared';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/misc';
import { AppChip, OwnerChip } from '@/components/common/atoms';
import { EntityFormDialog } from '@/features/EntityFormDialog';
import { useLookups } from '@/features/useLookups';
import { useBulkUpdate, useEntityList } from '@/hooks/useEntities';
import { BOARD_COLUMNS } from '@/lib/display';
import { cn, formatDate, relativeDays } from '@/lib/utils';

type Columns = Record<string, Task[]>;

const buildColumns = (tasks: Task[]): Columns => {
  const columns: Columns = Object.fromEntries(BOARD_COLUMNS.map((column) => [column.id, [] as Task[]]));
  for (const task of tasks) (columns[task.status] ??= []).push(task);
  for (const key of Object.keys(columns)) columns[key].sort((a, b) => a.boardOrder - b.boardOrder);
  return columns;
};

/* ---------------------------------------------------------------- card */

const TaskCard = ({ task, onOpen }: { task: Task; onOpen?: (task: Task) => void }) => {
  const { appById } = useLookups();
  const days = relativeDays(task.dueDate);

  return (
    <div
      onClick={() => onOpen?.(task)}
      className="group cursor-pointer rounded-md border border-border bg-card p-3 shadow-panel transition-colors hover:border-primary/40"
    >
      <div className="flex items-start gap-2">
        <p className="min-w-0 flex-1 text-sm font-medium leading-snug text-foreground">{task.title}</p>
        <GripVertical className="mt-0.5 size-3.5 shrink-0 text-subtle opacity-0 transition-opacity group-hover:opacity-100" />
      </div>

      <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
        <StatusBadge value={task.priority} />
        {task.storyPoints ? (
          <span className="num rounded border border-border px-1.5 py-0.5 text-2xs text-muted">
            {task.storyPoints} pts
          </span>
        ) : null}
        {task.dueDate ? (
          <span
            className={cn(
              'text-2xs',
              days !== null && days < 0 ? 'text-danger' : days !== null && days < 14 ? 'text-warning' : 'text-subtle',
            )}
          >
            {formatDate(task.dueDate)}
          </span>
        ) : null}
      </div>

      <div className="mt-2.5 flex items-center justify-between gap-2 border-t border-border/70 pt-2">
        <AppChip application={appById(task.applicationId)} size="xs" link={false} />
        <OwnerChip name={task.owner} />
      </div>
    </div>
  );
};

const SortableTask = ({ task, onOpen }: { task: Task; onOpen: (task: Task) => void }) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: task.id });

  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Translate.toString(transform), transition }}
      // touch-action none is required by dnd-kit's pointer sensor on touch devices,
      // and select-none stops a drag from turning into a text selection.
      className={cn('touch-none select-none', isDragging && 'opacity-40')}
      {...attributes}
      {...listeners}
    >
      <TaskCard task={task} onOpen={onOpen} />
    </div>
  );
};

/* -------------------------------------------------------------- column */

const Column = ({
  id,
  label,
  tasks,
  onOpen,
  onAdd,
}: {
  id: string;
  label: string;
  tasks: Task[];
  onOpen: (task: Task) => void;
  onAdd: (status: string) => void;
}) => {
  const { setNodeRef, isOver } = useDroppable({ id });

  return (
    <div className="flex w-[276px] shrink-0 flex-col">
      <div className="mb-2 flex items-center gap-2 px-1">
        <StatusBadge value={id} />
        <span className="num text-xs text-subtle">{tasks.length}</span>
        <Button variant="ghost" size="icon" className="ml-auto size-6" onClick={() => onAdd(id)} aria-label={`Add to ${label}`}>
          <Plus className="size-3.5" />
        </Button>
      </div>

      <div
        ref={setNodeRef}
        className={cn(
          'flex min-h-[140px] flex-1 flex-col gap-2 rounded-lg border border-dashed p-2 transition-colors',
          isOver ? 'border-primary/50 bg-primary/[0.06]' : 'border-border/70 bg-surface/40',
        )}
      >
        <SortableContext items={tasks.map((task) => task.id)} strategy={verticalListSortingStrategy}>
          {tasks.map((task) => (
            <SortableTask key={task.id} task={task} onOpen={onOpen} />
          ))}
        </SortableContext>
        {tasks.length === 0 ? <p className="px-1 py-4 text-center text-2xs text-subtle">Drop here</p> : null}
      </div>
    </div>
  );
};

/* --------------------------------------------------------------- board */

/**
 * Kanban board over the task collection.
 *
 * The dragged card's position is held in local state so the board never waits
 * on the network, and the move is persisted as a single bulk PATCH containing
 * every card whose column or order changed. React Query rolls the cache back if
 * that request fails.
 */
export function KanbanBoard({ applicationId }: { applicationId?: string }) {
  const query = React.useMemo(() => (applicationId ? { applicationId } : {}), [applicationId]);
  const { data: tasks = [], isLoading } = useEntityList('tasks', query);
  const bulk = useBulkUpdate('tasks');

  const [columns, setColumns] = React.useState<Columns>(() => buildColumns(tasks));
  const [dragging, setDragging] = React.useState<Task | null>(null);
  const [editing, setEditing] = React.useState<Task | null | undefined>(undefined);
  const [addStatus, setAddStatus] = React.useState<string | null>(null);

  // Keep the board in step with the server, except while a card is in hand.
  React.useEffect(() => {
    if (!dragging) setColumns(buildColumns(tasks));
  }, [tasks, dragging]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const findColumn = (id: string): string | undefined => {
    if (columns[id]) return id;
    return Object.keys(columns).find((key) => columns[key].some((task) => task.id === id));
  };

  const onDragStart = (event: DragStartEvent) => {
    const id = String(event.active.id);
    const column = findColumn(id);
    setDragging(column ? (columns[column].find((task) => task.id === id) ?? null) : null);
  };

  const onDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    if (!over) return;
    const from = findColumn(String(active.id));
    const to = findColumn(String(over.id));
    if (!from || !to || from === to) return;

    setColumns((current) => {
      const moving = current[from].find((task) => task.id === String(active.id));
      if (!moving) return current;
      const overIndex = current[to].findIndex((task) => task.id === String(over.id));
      const insertAt = overIndex === -1 ? current[to].length : overIndex;
      return {
        ...current,
        [from]: current[from].filter((task) => task.id !== moving.id),
        [to]: [...current[to].slice(0, insertAt), { ...moving, status: to as WorkStatus }, ...current[to].slice(insertAt)],
      };
    });
  };

  const onDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setDragging(null);
    if (!over) return;

    const from = findColumn(String(active.id));
    const to = findColumn(String(over.id));
    if (!from || !to) return;

    const next: Columns = Object.fromEntries(Object.entries(columns).map(([key, list]) => [key, [...list]]));
    const moving = next[from].find((task) => task.id === String(active.id));
    if (!moving) return;

    if (from === to) {
      const list = next[from];
      const oldIndex = list.findIndex((task) => task.id === moving.id);
      const overIndex = list.findIndex((task) => task.id === String(over.id));
      if (oldIndex !== -1 && overIndex !== -1 && oldIndex !== overIndex) {
        list.splice(oldIndex, 1);
        list.splice(overIndex, 0, moving);
      }
    } else {
      // A fast drop can finish before onDragOver ever fires for the new column,
      // so the cross-column case is resolved here as well rather than assumed.
      next[from] = next[from].filter((task) => task.id !== moving.id);
      const overIndex = next[to].findIndex((task) => task.id === String(over.id));
      const insertAt = overIndex === -1 ? next[to].length : overIndex;
      next[to].splice(insertAt, 0, { ...moving, status: to as WorkStatus });
    }

    setColumns(next);

    // Persist only what actually changed against the server copy.
    const serverById = new Map(tasks.map((task) => [task.id, task]));
    const updates: { id: string; patch: Partial<Task> }[] = [];
    for (const [status, items] of Object.entries(next)) {
      items.forEach((task, index) => {
        const original = serverById.get(task.id);
        const boardOrder = (index + 1) * 10;
        if (!original) return;
        if (original.status !== status || original.boardOrder !== boardOrder) {
          updates.push({ id: task.id, patch: { status: status as WorkStatus, boardOrder } });
        }
      });
    }
    if (updates.length > 0) bulk.mutate(updates);
  };

  if (isLoading) {
    return (
      <div className="flex gap-3 overflow-x-auto pb-2">
        {BOARD_COLUMNS.map((column) => (
          <Skeleton key={column.id} className="h-80 w-[276px] shrink-0" />
        ))}
      </div>
    );
  }

  return (
    <>
      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        onDragStart={onDragStart}
        onDragOver={onDragOver}
        onDragEnd={onDragEnd}
        onDragCancel={() => setDragging(null)}
      >
        <div className="flex select-none gap-3 overflow-x-auto pb-3">
          {BOARD_COLUMNS.map((column) => (
            <Column
              key={column.id}
              id={column.id}
              label={column.label}
              tasks={columns[column.id] ?? []}
              onOpen={(task) => setEditing(task)}
              onAdd={(status) => setAddStatus(status)}
            />
          ))}
        </div>

        <DragOverlay dropAnimation={{ duration: 180, easing: 'cubic-bezier(0.22, 1, 0.36, 1)' }}>
          {dragging ? (
            <div className="w-[260px] rotate-1">
              <TaskCard task={dragging} />
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>

      {editing !== undefined ? (
        <EntityFormDialog
          entity="tasks"
          open
          onOpenChange={(open) => !open && setEditing(undefined)}
          record={editing as unknown as Record<string, unknown>}
        />
      ) : null}

      {addStatus ? (
        <EntityFormDialog
          entity="tasks"
          open
          onOpenChange={(open) => !open && setAddStatus(null)}
          record={null}
          presets={{ status: addStatus, ...(applicationId ? { applicationId } : {}) }}
        />
      ) : null}
    </>
  );
}
