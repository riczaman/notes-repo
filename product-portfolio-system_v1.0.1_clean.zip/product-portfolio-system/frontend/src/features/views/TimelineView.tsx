import * as React from 'react';
import { Flag, Milestone as MilestoneIcon, Rocket } from 'lucide-react';
import { StatusBadge } from '@/components/ui/badge';
import { EmptyState, Skeleton } from '@/components/ui/misc';
import { useEntityList } from '@/hooks/useEntities';
import { useLookups } from '@/features/useLookups';
import { cn, formatDate, quarterOf } from '@/lib/utils';

interface TimelineItem {
  id: string;
  kind: 'release' | 'milestone' | 'epic';
  label: string;
  date: string;
  status: string;
  applicationId: string | null;
}

const ICON = { release: Rocket, milestone: MilestoneIcon, epic: Flag };

const quarterSortKey = (quarter: string): string => {
  const match = /^Q(\d) (\d{4})$/.exec(quarter);
  return match ? `${match[2]}-${match[1]}` : `9999-${quarter}`;
};

/**
 * Quarter grid rather than a pixel-accurate Gantt.
 *
 * The dates in this portfolio are quarter-level commitments, so a day-precise
 * bar chart would imply confidence the underlying data does not have. Each cell
 * holds the releases, milestones and epic targets landing in that quarter.
 */
export function TimelineView({ applicationId }: { applicationId?: string }) {
  const query = React.useMemo(() => (applicationId ? { applicationId } : {}), [applicationId]);
  const { data: releases = [], isLoading } = useEntityList('releases', query);
  const { data: milestones = [] } = useEntityList('milestones', query);
  const { data: epics = [] } = useEntityList('epics', query);
  const { applications, appById } = useLookups();

  const items: TimelineItem[] = React.useMemo(
    () => [
      ...releases
        .filter((release) => release.targetDate)
        .map((release) => ({
          id: release.id,
          kind: 'release' as const,
          label: release.name,
          date: release.targetDate as string,
          status: release.status,
          applicationId: release.applicationId,
        })),
      ...milestones.map((milestone) => ({
        id: milestone.id,
        kind: 'milestone' as const,
        label: milestone.name,
        date: milestone.date,
        status: milestone.status,
        applicationId: milestone.applicationId,
      })),
      ...epics
        .filter((epic) => epic.targetDate)
        .map((epic) => ({
          id: epic.id,
          kind: 'epic' as const,
          label: epic.title,
          date: epic.targetDate as string,
          status: epic.status,
          applicationId: epic.applicationId,
        })),
    ],
    [releases, milestones, epics],
  );

  const quarters = React.useMemo(() => {
    const set = new Set(items.map((item) => quarterOf(item.date)).filter(Boolean));
    return [...set].sort((a, b) => quarterSortKey(a).localeCompare(quarterSortKey(b)));
  }, [items]);

  const rows = React.useMemo(() => {
    const relevant = applicationId ? applications.filter((app) => app.id === applicationId) : applications;
    const portfolioItems = items.filter((item) => !item.applicationId);
    return [
      ...relevant.map((app) => ({
        id: app.id,
        name: app.shortName,
        color: app.color,
        items: items.filter((item) => item.applicationId === app.id),
      })),
      ...(portfolioItems.length > 0 && !applicationId
        ? [{ id: 'portfolio', name: 'Portfolio', color: 'hsl(var(--muted))', items: portfolioItems }]
        : []),
    ];
  }, [applications, items, applicationId]);

  const currentQuarter = quarterOf(new Date().toISOString());

  if (isLoading) return <Skeleton className="h-80" />;
  if (quarters.length === 0) {
    return (
      <div className="panel">
        <EmptyState
          icon={MilestoneIcon}
          title="Nothing scheduled yet"
          description="Add target dates to releases, milestones or epics and they appear here."
        />
      </div>
    );
  }

  return (
    <div className="panel overflow-x-auto">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-border">
            <th className="sticky left-0 z-10 w-[130px] bg-card px-4 py-2.5 text-left text-2xs font-semibold uppercase tracking-wider text-subtle">
              Application
            </th>
            {quarters.map((quarter) => (
              <th
                key={quarter}
                className={cn(
                  'min-w-[210px] px-3 py-2.5 text-left text-2xs font-semibold uppercase tracking-wider',
                  quarter === currentQuarter ? 'bg-primary/[0.07] text-primary' : 'text-subtle',
                )}
              >
                {quarter}
                {quarter === currentQuarter ? <span className="ml-1.5 normal-case opacity-70">current</span> : null}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className="border-b border-border/60 last:border-0">
              <td className="sticky left-0 z-10 bg-card px-4 py-3 align-top">
                <span className="inline-flex items-center gap-2 text-xs font-medium text-foreground">
                  <span className="size-2 shrink-0 rounded-[3px]" style={{ backgroundColor: row.color }} />
                  {row.name}
                </span>
              </td>
              {quarters.map((quarter) => {
                const cellItems = row.items.filter((item) => quarterOf(item.date) === quarter);
                return (
                  <td
                    key={quarter}
                    className={cn('px-2 py-2 align-top', quarter === currentQuarter && 'bg-primary/[0.04]')}
                  >
                    <div className="space-y-1.5">
                      {cellItems.map((item) => {
                        const Icon = ICON[item.kind];
                        return (
                          <div
                            key={`${item.kind}-${item.id}`}
                            className="rounded-md border border-border bg-elevated/60 px-2 py-1.5"
                            title={`${item.label} · ${formatDate(item.date)}`}
                          >
                            <div className="flex items-start gap-1.5">
                              <Icon className="mt-0.5 size-3 shrink-0 text-subtle" />
                              <span className="line-clamp-2 text-xs leading-snug text-foreground/90">{item.label}</span>
                            </div>
                            <div className="mt-1 flex items-center justify-between gap-2">
                              <span className="text-2xs text-subtle">{formatDate(item.date)}</span>
                              <StatusBadge value={item.status} dot={false} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
