import * as React from 'react';
import {
  Background,
  BackgroundVariant,
  Controls,
  Handle,
  MarkerType,
  Position,
  ReactFlow,
  type Edge,
  type Node,
  type NodeProps,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import type { DependencyGraph } from '@shared';
import { Skeleton, Switch } from '@/components/ui/misc';
import { useDependencyGraph } from '@/hooks/useInsights';
import { labelOf } from '@/lib/display';
import { cn } from '@/lib/utils';

/* --------------------------------------------------------------- nodes */

type AppNodeData = { label: string; color?: string };
type ExternalNodeData = { label: string; category?: string };

const ApplicationNode = ({ data }: NodeProps) => {
  const { label, color } = data as AppNodeData;
  return (
    <div className="min-w-[132px] rounded-lg border border-border bg-card px-3 py-2 shadow-lift">
      <Handle type="target" position={Position.Left} className="!size-1.5 !border-0 !bg-primary/60" />
      <div className="flex items-center gap-2">
        <span className="size-2.5 shrink-0 rounded-[3px]" style={{ backgroundColor: color }} />
        <span className="text-sm font-semibold text-foreground">{label}</span>
      </div>
      <p className="mt-0.5 text-2xs uppercase tracking-wider text-subtle">Our application</p>
      <Handle type="source" position={Position.Right} className="!size-1.5 !border-0 !bg-primary/60" />
    </div>
  );
};

const ExternalNode = ({ data }: NodeProps) => {
  const { label, category } = data as ExternalNodeData;
  return (
    <div className="min-w-[150px] max-w-[210px] rounded-lg border border-dashed border-border bg-surface px-3 py-2">
      <Handle type="target" position={Position.Left} className="!size-1.5 !border-0 !bg-subtle" />
      <p className="text-xs font-medium leading-snug text-foreground/90">{label}</p>
      {category ? <p className="mt-0.5 text-2xs uppercase tracking-wider text-subtle">{labelOf(category)}</p> : null}
      <Handle type="source" position={Position.Right} className="!size-1.5 !border-0 !bg-subtle" />
    </div>
  );
};

const nodeTypes = { application: ApplicationNode, external: ExternalNode };

/* -------------------------------------------------------------- layout */

const EDGE_COLOR: Record<string, string> = {
  blocked: '#ef4444',
  not_started: '#64748b',
  in_discussion: '#f59e0b',
  agreed: '#38bdf8',
  in_progress: '#2dd4bf',
  delivered: '#34d399',
};

const ROW_HEIGHT = 76;
const GROUP_GAP = 56;
const EXTERNAL_X = 300;
const COLUMN_WIDTH = 250;
const COLUMNS = 2;

/**
 * Layout is computed here rather than pulled in as a layout library.
 *
 * Each application gets its own cluster: the application on the left, the
 * systems it depends on banked to the right of it. A single tall column of
 * externals (the obvious first attempt) produced a graph too tall to read, and
 * a force-directed layout would be prettier but would lose the one thing this
 * picture is for - seeing, per application, what it is waiting on.
 *
 * An external shared by two applications is placed with the first one that
 * claims it; the second application's edge then crosses the canvas, which is
 * exactly the coupling worth noticing.
 */
const toFlow = (graph: DependencyGraph, showLabels: boolean): { nodes: Node[]; edges: Edge[] } => {
  const apps = graph.nodes.filter((node) => node.kind === 'application');
  const externals = graph.nodes.filter((node) => node.kind === 'external');

  // First application to depend on an external owns its position.
  const ownerOf = new Map<string, string>();
  for (const edge of graph.edges) {
    if (!ownerOf.has(edge.target) && externals.some((node) => node.id === edge.target)) {
      ownerOf.set(edge.target, edge.source);
    }
  }

  const nodes: Node[] = [];
  let cursorY = 0;

  for (const app of apps) {
    const owned = externals.filter((node) => ownerOf.get(node.id) === app.id);
    const rows = Math.max(1, Math.ceil(owned.length / COLUMNS));
    const blockHeight = rows * ROW_HEIGHT;

    nodes.push({
      id: app.id,
      type: 'application',
      position: { x: 0, y: cursorY + blockHeight / 2 - 30 },
      data: { label: app.label, color: app.color },
      draggable: true,
    });

    owned.forEach((node, index) => {
      nodes.push({
        id: node.id,
        type: 'external',
        position: {
          x: EXTERNAL_X + (index % COLUMNS) * COLUMN_WIDTH,
          y: cursorY + Math.floor(index / COLUMNS) * ROW_HEIGHT,
        },
        data: { label: node.label, category: node.category },
        draggable: true,
      });
    });

    cursorY += blockHeight + GROUP_GAP;
  }

  // Anything left unclaimed (no matching edge source) still needs a position.
  externals
    .filter((node) => !nodes.some((placed) => placed.id === node.id))
    .forEach((node, index) => {
      nodes.push({
        id: node.id,
        type: 'external',
        position: { x: EXTERNAL_X + (index % COLUMNS) * COLUMN_WIDTH, y: cursorY + Math.floor(index / COLUMNS) * ROW_HEIGHT },
        data: { label: node.label, category: node.category },
        draggable: true,
      });
    });

  const edges: Edge[] = graph.edges.map((edge) => ({
    id: edge.id,
    source: edge.source,
    target: edge.target,
    // Labels are off by default: with this many converging edges they overlap
    // into noise, and the table underneath carries the same text with its owner
    // and status. The toggle is there for when you want them.
    label: showLabels ? edge.label : undefined,
    type: 'smoothstep',
    animated: edge.status === 'in_progress',
    labelStyle: { fill: 'currentColor', fontSize: 10 },
    labelBgStyle: { fill: 'hsl(var(--card))', fillOpacity: 0.9 },
    labelBgPadding: [4, 2],
    labelBgBorderRadius: 4,
    style: {
      stroke: EDGE_COLOR[edge.status] ?? '#64748b',
      strokeWidth: edge.criticality === 'critical' ? 2.2 : edge.criticality === 'high' ? 1.6 : 1,
      strokeDasharray: edge.status === 'not_started' ? '4 4' : undefined,
    },
    markerEnd: { type: MarkerType.ArrowClosed, color: EDGE_COLOR[edge.status] ?? '#64748b', width: 14, height: 14 },
  }));

  return { nodes, edges };
};

/* --------------------------------------------------------------- view */

export function DependencyGraphView({ applicationId, height = 560 }: { applicationId?: string; height?: number }) {
  const { data, isLoading } = useDependencyGraph(applicationId);
  const [showLabels, setShowLabels] = React.useState(false);

  const flow = React.useMemo(() => (data ? toFlow(data, showLabels) : { nodes: [], edges: [] }), [data, showLabels]);

  if (isLoading) return <Skeleton style={{ height }} className="w-full" />;

  return (
    <div className="panel relative overflow-hidden" style={{ height }}>
      <label className="absolute right-3 top-3 z-10 flex cursor-pointer items-center gap-2 rounded-md border border-border bg-card px-2.5 py-1.5 text-xs text-muted">
        <Switch checked={showLabels} onCheckedChange={setShowLabels} />
        Edge labels
      </label>
      <ReactFlow
        nodes={flow.nodes}
        edges={flow.edges}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.18 }}
        proOptions={{ hideAttribution: true }}
        minZoom={0.25}
        className="text-muted"
      >
        <Background variant={BackgroundVariant.Dots} gap={22} size={1} className="text-border" color="currentColor" />
        <Controls showInteractive={false} className="!border-border !bg-card" />
      </ReactFlow>
    </div>
  );
}

export const DependencyLegend = ({ className }: { className?: string }) => (
  <div className={cn('flex flex-wrap items-center gap-x-4 gap-y-2 text-2xs text-muted', className)}>
    {Object.entries(EDGE_COLOR).map(([status, color]) => (
      <span key={status} className="inline-flex items-center gap-1.5">
        <span className="h-0.5 w-5 rounded-full" style={{ backgroundColor: color }} />
        {labelOf(status)}
      </span>
    ))}
    <span className="inline-flex items-center gap-1.5">
      <span className="h-2.5 w-4 rounded-sm border border-dashed border-border" />
      System we do not own
    </span>
  </div>
);
