import { useMemo } from 'react';
import type { Application } from '@shared';
import { useEntityList } from '@/hooks/useEntities';
import { uniq } from '@/lib/utils';

/**
 * Shared reference data. Every list page needs the application list for chips
 * and filters, plus the distinct owners and quarters currently in use, so it is
 * fetched once and cached by React Query rather than per page.
 */
export function useLookups() {
  const { data: applications = [] } = useEntityList('applications');
  const { data: releases = [] } = useEntityList('releases');
  const { data: tasks = [] } = useEntityList('tasks');
  const { data: epics = [] } = useEntityList('epics');

  return useMemo(() => {
    const byId = new Map(applications.map((app) => [app.id, app]));

    const owners = uniq(
      [...tasks.map((t) => t.owner), ...epics.map((e) => e.owner)].filter((owner): owner is string => Boolean(owner)),
    ).sort();

    const quarters = uniq(
      [...tasks.map((t) => t.quarter), ...releases.map((r) => r.quarter)].filter((q): q is string => Boolean(q)),
    ).sort();

    return {
      applications,
      releases,
      appById: (id?: string | null): Application | undefined => (id ? byId.get(id) : undefined),
      appOptions: applications.map((app) => ({ value: app.id, label: app.shortName })),
      ownerOptions: owners.map((owner) => ({ value: owner, label: owner })),
      releaseOptions: releases.map((release) => ({ value: release.id, label: release.name })),
      quarterOptions: quarters.map((quarter) => ({ value: quarter, label: quarter })),
    };
  }, [applications, releases, tasks, epics]);
}
