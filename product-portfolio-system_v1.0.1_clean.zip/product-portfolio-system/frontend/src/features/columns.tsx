import { ExternalLink } from 'lucide-react';
import type { Application, EntityName } from '@shared';
import type { Column } from '@/components/common/DataTable';
import { Badge, StatusBadge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/misc';
import { AppChip, OwnerChip, TagList } from '@/components/common/atoms';
import { labelOf, riskBand, riskScore } from '@/lib/display';
import { formatDate, relativeDays, truncate } from '@/lib/utils';

export interface ColumnCtx {
  appById: (id?: string | null) => Application | undefined;
}

type AnyRow = Record<string, any>;

/* ------------------------------------------------------------ shared cells */

const titleCell = (key: string, subKey?: string): Column<AnyRow> => ({
  key,
  header: 'Title',
  width: '30%',
  render: (row) => (
    <div className="min-w-0">
      <p className="truncate font-medium text-foreground">{row[key]}</p>
      {subKey && row[subKey] ? <p className="truncate text-xs text-muted">{truncate(String(row[subKey]), 90)}</p> : null}
    </div>
  ),
});

const appCell = (ctx: ColumnCtx, key = 'applicationId'): Column<AnyRow> => ({
  key,
  header: 'App',
  width: '110px',
  render: (row) => <AppChip application={ctx.appById(row[key])} />,
  sortValue: (row) => ctx.appById(row[key])?.shortName ?? 'zz',
});

const ownerCell: Column<AnyRow> = {
  key: 'owner',
  header: 'Owner',
  width: '150px',
  render: (row) => <OwnerChip name={row.owner} />,
};

const badgeCell = (key: string, header: string, width = '120px'): Column<AnyRow> => ({
  key,
  header,
  width,
  render: (row) => <StatusBadge value={row[key]} />,
});

const dateCell = (key: string, header: string, highlight = false): Column<AnyRow> => ({
  key,
  header,
  width: '120px',
  render: (row) => {
    const value = row[key] as string | null;
    if (!value) return <span className="text-xs text-subtle">—</span>;
    const days = relativeDays(value);
    const overdue = highlight && days !== null && days < 0;
    const soon = highlight && days !== null && days >= 0 && days <= 14;
    return (
      <span className={overdue ? 'text-xs text-danger' : soon ? 'text-xs text-warning' : 'text-xs text-muted'}>
        {formatDate(value)}
      </span>
    );
  },
});

const tagsCell: Column<AnyRow> = {
  key: 'tags',
  header: 'Tags',
  width: '160px',
  sortable: false,
  render: (row) => <TagList tags={row.tags} />,
};

/**
 * Table columns per collection.
 *
 * Kept as data next to the form definitions so a new field shows up in the
 * table and the form from one place, rather than being wired into a bespoke
 * page component per entity.
 */
export const COLUMNS: Record<EntityName, (ctx: ColumnCtx) => Column<AnyRow>[]> = {
  applications: (ctx) => [
    {
      key: 'name',
      header: 'Application',
      width: '28%',
      render: (row) => (
        <div className="flex items-center gap-2.5">
          <span className="size-2.5 shrink-0 rounded-[3px]" style={{ backgroundColor: row.color }} />
          <div className="min-w-0">
            <p className="truncate font-medium text-foreground">{row.name}</p>
            <p className="truncate text-xs text-muted">{row.tagline}</p>
          </div>
        </div>
      ),
    },
    badgeCell('lifecycle', 'Lifecycle', '110px'),
    badgeCell('health', 'Health', '110px'),
    { key: 'businessOwner', header: 'Business owner', render: (row) => <OwnerChip name={row.businessOwner} /> },
    { key: 'technicalOwner', header: 'Technical owner', render: (row) => <OwnerChip name={row.technicalOwner} /> },
    dateCell('targetGoLive', 'Target go-live', true),
  ],

  epics: (ctx) => [
    titleCell('title', 'goal'),
    appCell(ctx),
    badgeCell('status', 'Status'),
    badgeCell('priority', 'Priority', '100px'),
    badgeCell('horizon', 'Horizon', '90px'),
    ownerCell,
    {
      key: 'progress',
      header: 'Progress',
      width: '120px',
      render: (row) => (
        <div className="flex items-center gap-2">
          <Progress value={row.progress} className="w-14" />
          <span className="num text-xs text-muted">{row.progress}%</span>
        </div>
      ),
    },
    dateCell('targetDate', 'Target', true),
  ],

  features: (ctx) => [
    titleCell('title', 'problem'),
    appCell(ctx),
    badgeCell('status', 'Status'),
    badgeCell('priority', 'Priority', '100px'),
    badgeCell('horizon', 'Horizon', '90px'),
    ownerCell,
    { key: 'estimate', header: 'Estimate', width: '110px', render: (row) => row.estimate || '—' },
  ],

  tasks: (ctx) => [
    titleCell('title', 'description'),
    appCell(ctx),
    badgeCell('status', 'Status'),
    badgeCell('priority', 'Priority', '100px'),
    ownerCell,
    {
      key: 'storyPoints',
      header: 'Pts',
      width: '60px',
      align: 'right',
      render: (row) => <span className="num text-xs text-muted">{row.storyPoints ?? '—'}</span>,
    },
    dateCell('dueDate', 'Due', true),
    tagsCell,
  ],

  releases: (ctx) => [
    titleCell('name', 'scopeSummary'),
    appCell(ctx),
    { key: 'version', header: 'Version', width: '90px', render: (row) => <span className="num text-xs">{row.version || '—'}</span> },
    badgeCell('status', 'Status'),
    { key: 'quarter', header: 'Quarter', width: '100px', render: (row) => row.quarter || '—' },
    dateCell('targetDate', 'Target', true),
  ],

  milestones: (ctx) => [
    titleCell('name', 'description'),
    appCell(ctx),
    badgeCell('type', 'Type', '110px'),
    badgeCell('status', 'Status', '110px'),
    dateCell('date', 'Date', true),
    ownerCell,
  ],

  stakeholders: (ctx) => [
    {
      key: 'name',
      header: 'Name',
      width: '22%',
      render: (row) => <OwnerChip name={row.name} />,
    },
    { key: 'role', header: 'Role', render: (row) => row.role || '—' },
    { key: 'org', header: 'Organisation', width: '160px', render: (row) => row.org || '—' },
    badgeCell('type', 'Type', '110px'),
    badgeCell('influence', 'Influence', '100px'),
    {
      key: 'applicationIds',
      header: 'Applications',
      width: '200px',
      sortable: false,
      render: (row) => (
        <span className="flex flex-wrap gap-2">
          {(row.applicationIds as string[]).map((id) => (
            <AppChip key={id} application={ctx.appById(id)} size="xs" />
          ))}
        </span>
      ),
    },
  ],

  risks: (ctx) => [
    titleCell('title', 'description'),
    appCell(ctx),
    {
      key: 'score',
      header: 'Score',
      width: '110px',
      sortValue: (row) => riskScore(row.likelihood, row.impact),
      render: (row) => {
        const score = riskScore(row.likelihood, row.impact);
        const band = riskBand(score);
        return (
          <Badge tone={band.tone} dot>
            {band.label} · {score}
          </Badge>
        );
      },
    },
    badgeCell('likelihood', 'Likelihood', '110px'),
    badgeCell('impact', 'Impact', '110px'),
    badgeCell('status', 'Status', '110px'),
    { key: 'category', header: 'Category', width: '110px', render: (row) => labelOf(row.category) },
    ownerCell,
  ],

  bugs: (ctx) => [
    titleCell('title', 'description'),
    appCell(ctx),
    badgeCell('severity', 'Severity', '130px'),
    badgeCell('status', 'Status', '110px'),
    ownerCell,
    { key: 'environment', header: 'Environment', width: '110px', render: (row) => row.environment || '—' },
  ],

  technicalDebt: (ctx) => [
    titleCell('title', 'issue'),
    appCell(ctx),
    { key: 'category', header: 'Category', width: '120px', render: (row) => labelOf(row.category) },
    badgeCell('priority', 'Priority', '100px'),
    badgeCell('status', 'Status', '110px'),
    { key: 'estimatedEffort', header: 'Effort', width: '100px', render: (row) => row.estimatedEffort || '—' },
    ownerCell,
  ],

  dependencies: (ctx) => [
    {
      key: 'label',
      header: 'Dependency',
      width: '26%',
      render: (row) => (
        <div className="min-w-0">
          <p className="truncate font-medium text-foreground">{row.label}</p>
          {row.description ? <p className="truncate text-xs text-muted">{truncate(row.description, 80)}</p> : null}
        </div>
      ),
    },
    appCell(ctx, 'fromApplicationId'),
    {
      key: 'target',
      header: 'Depends on',
      width: '180px',
      sortValue: (row) => ctx.appById(row.toApplicationId)?.shortName ?? row.toExternalName ?? '',
      render: (row) =>
        row.toApplicationId ? (
          <AppChip application={ctx.appById(row.toApplicationId)} />
        ) : (
          <span className="text-xs text-foreground/80">{row.toExternalName || '—'}</span>
        ),
    },
    { key: 'type', header: 'Type', width: '120px', render: (row) => labelOf(row.type) },
    badgeCell('status', 'Status', '120px'),
    badgeCell('criticality', 'Criticality', '110px'),
    { key: 'team', header: 'Team', width: '130px', render: (row) => row.team || row.owner || '—' },
  ],

  tickets: (ctx) => [
    {
      key: 'externalId',
      header: 'Ticket',
      width: '170px',
      render: (row) => (
        <span className="num inline-flex items-center gap-1 whitespace-nowrap text-xs font-medium text-primary">
          {row.externalId}
          {row.url ? <ExternalLink className="size-3 opacity-60" /> : null}
        </span>
      ),
    },
    { key: 'system', header: 'System', width: '130px', render: (row) => labelOf(row.system) },
    titleCell('title'),
    appCell(ctx),
    badgeCell('type', 'Type', '100px'),
    badgeCell('status', 'Status', '120px'),
    badgeCell('priority', 'Priority', '100px'),
    { key: 'assignee', header: 'Assignee', width: '150px', render: (row) => <OwnerChip name={row.assignee} /> },
    dateCell('dueDate', 'Due', true),
  ],

  notes: (ctx) => [
    titleCell('title', 'summary'),
    dateCell('date', 'Date'),
    badgeCell('source', 'Source', '110px'),
    {
      key: 'applicationIds',
      header: 'Applications',
      width: '190px',
      sortable: false,
      render: (row) => (
        <span className="flex flex-wrap gap-2">
          {(row.applicationIds as string[]).map((id) => (
            <AppChip key={id} application={ctx.appById(id)} size="xs" />
          ))}
        </span>
      ),
    },
    {
      key: 'actionItems',
      header: 'Actions',
      width: '90px',
      align: 'right',
      sortValue: (row) => (row.actionItems ?? []).length,
      render: (row) => <span className="num text-xs text-muted">{(row.actionItems ?? []).length}</span>,
    },
    {
      key: 'processed',
      header: 'Triaged',
      width: '100px',
      render: (row) => <StatusBadge value={row.processed ? 'done' : 'backlog'} />,
    },
  ],
};
