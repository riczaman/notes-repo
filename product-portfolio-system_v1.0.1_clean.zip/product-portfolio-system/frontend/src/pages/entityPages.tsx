import { EntityListPage } from '@/features/EntityListPage';

/**
 * Collection routes.
 *
 * Each one is a description of intent, not an implementation: the table,
 * filters, form and validation all come from the shared entity configuration.
 * If one of these ever needs to become bespoke, it can, without the other
 * twelve changing.
 */

export const EpicsPage = () => (
  <EntityListPage
    entity="epics"
    description="Epics are the roadmap unit. Each one carries a goal, the problem it solves, the business value and its open questions."
  />
);

export const FeaturesPage = () => (
  <EntityListPage
    entity="features"
    description="Problem, solution, acceptance criteria and technical design for each deliverable slice."
  />
);

export const TasksPage = () => (
  <EntityListPage
    entity="tasks"
    description="Everything in flight across the portfolio. Use the board for moving work; use this for cutting across applications."
  />
);

export const ReleasesPage = () => (
  <EntityListPage entity="releases" description="What ships when, and what is in it." />
);

export const MilestonesPage = () => (
  <EntityListPage
    entity="milestones"
    description="Dates that matter: go-lives, gates, governance checkpoints and the decisions the plan is waiting on."
  />
);

export const StakeholdersPage = () => (
  <EntityListPage
    entity="stakeholders"
    description="Who owns what, who decides what, and which applications each person touches."
  />
);

export const RisksPage = () => (
  <EntityListPage
    entity="risks"
    title="Risk register"
    description="Likelihood times impact gives the score. Anything scoring nine or above needs a named owner and a decision date, not a mitigation sentence."
  />
);

export const TechnicalDebtPage = () => (
  <EntityListPage
    entity="technicalDebt"
    title="Technical debt"
    description="Issue, impact, effort and a suggested fix. Debt without a suggested fix is a complaint."
  />
);

export const BugsPage = () => (
  <EntityListPage
    entity="bugs"
    title="Bug tracker"
    description="Severity, reproduction steps, owner and status."
  />
);

export const TicketsPage = () => (
  <EntityListPage
    entity="tickets"
    title="Request tracker"
    description="Jira stories, Azure DevOps items, ServiceNow tickets, CRA assessments, access requests, change requests and procurement asks: one row per external reference, linked back to the work it belongs to."
  />
);
