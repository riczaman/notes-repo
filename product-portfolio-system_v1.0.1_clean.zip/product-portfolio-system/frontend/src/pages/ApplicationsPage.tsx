import * as React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight, Plus, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { StatusBadge } from '@/components/ui/badge';
import { Progress, Skeleton } from '@/components/ui/misc';
import { PageHeader } from '@/components/common/PageHeader';
import { EntityFormDialog } from '@/features/EntityFormDialog';
import { useDashboard } from '@/hooks/useInsights';
import { useEntityList } from '@/hooks/useEntities';
import { formatDate, truncate } from '@/lib/utils';

/**
 * Portfolio index.
 *
 * Design decision: applications get both a shared index and a page of their own.
 * The index answers "how is the portfolio doing"; the detail page is a workspace
 * for one application, because roadmap, board and governance only make sense in
 * a single application's context. The global list pages then let you cut across
 * applications when you need to.
 */
export default function ApplicationsPage() {
  const { data: applications = [], isLoading } = useEntityList('applications');
  const { data: summary } = useDashboard();
  const [creating, setCreating] = React.useState(false);

  const rollupById = new Map((summary?.applications ?? []).map((row) => [row.applicationId, row]));

  return (
    <div>
      <PageHeader
        title="Applications"
        description="Each application owns its own roadmap, board, risks, dependencies and request tracker. Open one to work inside it."
        actions={
          <Button variant="primary" onClick={() => setCreating(true)}>
            <Plus /> New application
          </Button>
        }
      />

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {applications.map((app) => {
            const rollup = rollupById.get(app.id);
            return (
              <Card key={app.id} className="panel-hover overflow-hidden">
                <div className="h-1" style={{ backgroundColor: app.color }} />
                <CardContent className="space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <Link
                        to={`/applications/${app.id}`}
                        className="group inline-flex items-center gap-1.5 text-base font-semibold tracking-tight text-foreground hover:text-primary"
                      >
                        {app.name}
                        <ArrowUpRight className="size-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
                      </Link>
                      <p className="mt-0.5 text-xs text-muted">{app.tagline}</p>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-1.5">
                      <StatusBadge value={app.health} />
                      <StatusBadge value={app.lifecycle} dot={false} />
                    </div>
                  </div>

                  <p className="text-sm leading-relaxed text-foreground/80">{truncate(app.description, 230)}</p>

                  {rollup ? (
                    <div>
                      <div className="mb-1.5 flex items-center justify-between text-xs">
                        <span className="text-muted">
                          {rollup.totals.tasksDone} of {rollup.totals.tasks} tasks done
                        </span>
                        <span className="num font-medium text-foreground">{rollup.progress}%</span>
                      </div>
                      <Progress value={rollup.progress} />
                    </div>
                  ) : null}

                  <dl className="grid grid-cols-4 gap-2 border-t border-border pt-3 text-xs">
                    {[
                      ['Epics', rollup?.totals.epics ?? 0],
                      ['Open risks', rollup?.totals.openRisks ?? 0],
                      ['Debt', rollup?.totals.openDebt ?? 0],
                      ['Requests', rollup?.totals.openTickets ?? 0],
                    ].map(([label, value]) => (
                      <div key={label as string}>
                        <dt className="text-2xs uppercase tracking-wider text-subtle">{label}</dt>
                        <dd className="num text-sm font-medium text-foreground">{value}</dd>
                      </div>
                    ))}
                  </dl>

                  <div className="flex flex-wrap items-center gap-x-5 gap-y-1.5 border-t border-border pt-3 text-xs text-muted">
                    <span className="inline-flex items-center gap-1.5">
                      <Users className="size-3.5 text-subtle" />
                      {app.businessOwner || 'Owner TBC'}
                    </span>
                    <span>Tech: {app.technicalOwner || 'TBC'}</span>
                    {app.targetGoLive ? <span>Target: {formatDate(app.targetGoLive)}</span> : null}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {creating ? <EntityFormDialog entity="applications" open onOpenChange={() => setCreating(false)} record={null} /> : null}
    </div>
  );
}
