import * as React from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { SearchX } from 'lucide-react';
import { ENTITY_REGISTRY, type EntityName } from '@shared';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { EmptyState, Skeleton } from '@/components/ui/misc';
import { PageHeader } from '@/components/common/PageHeader';
import { AppChip } from '@/components/common/atoms';
import { useGlobalSearch } from '@/hooks/useInsights';
import { useDebounce } from '@/hooks/useDebounce';
import { useLookups } from '@/features/useLookups';
import { groupBy } from '@/lib/utils';

const ROUTES: Record<EntityName, string> = {
  applications: '/applications',
  epics: '/epics',
  features: '/features',
  tasks: '/tasks',
  releases: '/releases',
  milestones: '/milestones',
  stakeholders: '/stakeholders',
  risks: '/risks',
  bugs: '/bugs',
  technicalDebt: '/technical-debt',
  dependencies: '/dependencies',
  tickets: '/requests',
  notes: '/notes',
};

export default function SearchPage() {
  const [params, setParams] = useSearchParams();
  const term = params.get('q') ?? '';
  const debounced = useDebounce(term, 250);
  const { data: hits = [], isFetching } = useGlobalSearch(debounced);
  const { appById } = useLookups();

  const grouped = groupBy(hits, (hit) => hit.entity);

  return (
    <div>
      <PageHeader
        title="Search"
        description="One query across applications, epics, features, tasks, releases, milestones, stakeholders, risks, bugs, debt, dependencies, requests and notes."
      />

      <Input
        autoFocus
        value={term}
        onChange={(event) => setParams(event.target.value ? { q: event.target.value } : {}, { replace: true })}
        placeholder="Search everything"
        className="mb-5 h-11 max-w-xl text-base"
      />

      {debounced.length < 2 ? (
        <p className="text-sm text-subtle">Type at least two characters.</p>
      ) : isFetching && hits.length === 0 ? (
        <div className="grid gap-3 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-40" />
          ))}
        </div>
      ) : hits.length === 0 ? (
        <div className="panel">
          <EmptyState icon={SearchX} title={`No matches for “${debounced}”`} />
        </div>
      ) : (
        <div className="grid items-start gap-3 md:grid-cols-2 xl:grid-cols-3">
          {Object.entries(grouped).map(([entity, entityHits]) => (
            <Card key={entity}>
              <CardHeader>
                <CardTitle>{ENTITY_REGISTRY[entity as EntityName].label}</CardTitle>
                <span className="num text-xs text-subtle">{entityHits.length}</span>
              </CardHeader>
              <CardContent className="space-y-1 pt-0">
                {entityHits.map((hit) => (
                  <Link
                    key={hit.id}
                    to={
                      hit.entity === 'applications'
                        ? `/applications/${hit.id}`
                        : `${ROUTES[hit.entity]}?q=${encodeURIComponent(hit.title)}`
                    }
                    className="block rounded-md px-2 py-1.5 transition-colors hover:bg-foreground/[0.05]"
                  >
                    <p className="text-sm text-foreground">{hit.title}</p>
                    <p className="flex items-center gap-2 text-xs text-subtle">
                      {hit.applicationId && hit.entity !== 'applications' ? (
                        <AppChip application={appById(hit.applicationId)} size="xs" link={false} />
                      ) : null}
                      {hit.subtitle}
                    </p>
                  </Link>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
