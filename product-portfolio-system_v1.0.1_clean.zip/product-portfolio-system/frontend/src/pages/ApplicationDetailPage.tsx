import * as React from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Mail, Pencil } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge, StatusBadge } from '@/components/ui/badge';
import { Progress, Skeleton } from '@/components/ui/misc';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BulletList, Field, OwnerChip, Prose, SectionTitle } from '@/components/common/atoms';
import { StatCard } from '@/components/common/StatCard';
import { EntityFormDialog } from '@/features/EntityFormDialog';
import { EntityListPage } from '@/features/EntityListPage';
import { DependencyGraphView, DependencyLegend } from '@/features/views/DependencyGraphView';
import { KanbanBoard } from '@/features/views/KanbanBoard';
import { RoadmapView } from '@/features/views/RoadmapView';
import { TimelineView } from '@/features/views/TimelineView';
import { useApplicationOverview } from '@/hooks/useInsights';
import { riskBand, riskScore } from '@/lib/display';
import { formatDate } from '@/lib/utils';

const TABS = [
  { value: 'overview', label: 'Overview' },
  { value: 'roadmap', label: 'Roadmap' },
  { value: 'board', label: 'Board' },
  { value: 'timeline', label: 'Timeline' },
  { value: 'epics', label: 'Epics' },
  { value: 'features', label: 'Features' },
  { value: 'tasks', label: 'Tasks' },
  { value: 'requests', label: 'Requests' },
  { value: 'risks', label: 'Risks' },
  { value: 'debt', label: 'Tech Debt' },
  { value: 'bugs', label: 'Bugs' },
  { value: 'dependencies', label: 'Dependencies' },
  { value: 'releases', label: 'Releases' },
  { value: 'notes', label: 'Notes' },
];

export default function ApplicationDetailPage() {
  const { id = '' } = useParams();
  const [params, setParams] = useSearchParams();
  const tab = params.get('tab') ?? 'overview';
  const { data, isLoading } = useApplicationOverview(id);
  const [editing, setEditing] = React.useState(false);

  const setTab = (value: string) => {
    // Changing tab clears filters that belonged to the previous tab's table.
    setParams(value === 'overview' ? {} : { tab: value }, { replace: true });
  };

  if (isLoading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-72" />
        <Skeleton className="h-40" />
        <Skeleton className="h-72" />
      </div>
    );
  }

  const { application: app, rollup, risks, milestones, stakeholders, epics, tickets } = data;
  const topRisks = [...risks]
    .filter((risk) => !['closed', 'accepted'].includes(risk.status))
    .sort((a, b) => riskScore(b.likelihood, b.impact) - riskScore(a.likelihood, a.impact))
    .slice(0, 5);

  return (
    <div>
      {/* -------------------------------------------------------- header */}
      <div className="mb-6">
        <Link
          to="/applications"
          className="mb-3 inline-flex items-center gap-1.5 text-xs text-muted transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-3.5" /> All applications
        </Link>

        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2.5">
              <span className="size-3 shrink-0 rounded-[4px]" style={{ backgroundColor: app.color }} />
              <h1 className="text-xl font-semibold tracking-tight text-foreground">{app.name}</h1>
              <Badge tone="neutral" className="num">
                {app.key}
              </Badge>
            </div>
            <p className="mt-1.5 max-w-3xl text-sm leading-relaxed text-muted">{app.tagline}</p>
            <div className="mt-2.5 flex flex-wrap items-center gap-2">
              <StatusBadge value={app.health} />
              <StatusBadge value={app.lifecycle} dot={false} />
              {app.targetGoLive ? (
                <span className="text-xs text-subtle">Target go-live {formatDate(app.targetGoLive)}</span>
              ) : null}
            </div>
          </div>

          <Button variant="secondary" onClick={() => setEditing(true)}>
            <Pencil /> Edit application
          </Button>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          {TABS.map((item) => (
            <TabsTrigger key={item.value} value={item.value}>
              {item.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* ------------------------------------------------------ overview */}
        <TabsContent value="overview" className="space-y-7">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
            <StatCard label="Progress" value={`${rollup.progress}%`} hint={`${rollup.totals.tasksDone}/${rollup.totals.tasks} tasks`} />
            <StatCard label="Epics" value={rollup.totals.epics} tone="info" />
            <StatCard label="Blocked" value={rollup.totals.tasksBlocked} tone={rollup.totals.tasksBlocked ? 'danger' : 'neutral'} />
            <StatCard label="Open risks" value={rollup.totals.openRisks} hint={`${rollup.totals.criticalRisks} high+`} tone="danger" />
            <StatCard label="Tech debt" value={rollup.totals.openDebt} tone="warning" />
            <StatCard label="Open requests" value={rollup.totals.openTickets} tone="accent" />
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <div className="space-y-4 lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Where this stands</CardTitle>
                </CardHeader>
                <CardContent className="space-y-5 pt-0">
                  <Field label="Executive summary">
                    <Prose text={app.executiveSummary} />
                  </Field>
                  <Field label="Vision">
                    <Prose text={app.vision} />
                  </Field>
                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label="Current state">
                      <Prose text={app.currentState} />
                    </Field>
                    <Field label="Future state">
                      <Prose text={app.futureState} />
                    </Field>
                  </div>
                  <Field label="Architecture notes">
                    <Prose text={app.architectureNotes} />
                  </Field>
                </CardContent>
              </Card>

              {app.leadershipAttention.length > 0 ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Leadership attention</CardTitle>
                    <span className="text-2xs uppercase tracking-wider text-subtle">Needs a decision</span>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <BulletList items={app.leadershipAttention} />
                  </CardContent>
                </Card>
              ) : null}

              <Card>
                <CardHeader>
                  <CardTitle>Epic progress</CardTitle>
                  <button onClick={() => setTab('roadmap')} className="text-xs text-primary hover:underline">
                    Roadmap
                  </button>
                </CardHeader>
                <CardContent className="space-y-3 pt-0">
                  {epics.length === 0 ? (
                    <p className="py-4 text-center text-xs text-subtle">No epics yet.</p>
                  ) : (
                    epics.map((epic) => (
                      <div key={epic.id} className="flex items-center gap-3">
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm text-foreground">{epic.title}</p>
                          <p className="text-2xs text-subtle">
                            {epic.quarter || 'Unscheduled'} · {epic.owner || 'Unassigned'}
                          </p>
                        </div>
                        <StatusBadge value={epic.status} />
                        <div className="w-24 shrink-0">
                          <Progress value={epic.progress} />
                        </div>
                        <span className="num w-9 shrink-0 text-right text-xs text-muted">{epic.progress}%</span>
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Ownership</CardTitle>
                </CardHeader>
                <CardContent className="grid gap-4 pt-0 sm:grid-cols-2 lg:grid-cols-1">
                  <Field label="Business owner">
                    <OwnerChip name={app.businessOwner} />
                  </Field>
                  <Field label="Technical owner">
                    <OwnerChip name={app.technicalOwner} />
                  </Field>
                  <Field label="Delivery lead">
                    <OwnerChip name={app.deliveryLead} />
                  </Field>
                  <Field label="Platform">{app.platform}</Field>
                  {app.vendor ? <Field label="Vendor">{app.vendor}</Field> : null}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Stakeholders</CardTitle>
                  <Link to="/stakeholders" className="text-xs text-primary hover:underline">
                    All
                  </Link>
                </CardHeader>
                <CardContent className="space-y-3 pt-0">
                  {stakeholders.length === 0 ? (
                    <p className="py-3 text-center text-xs text-subtle">None linked yet.</p>
                  ) : (
                    stakeholders.map((person) => (
                      <div key={person.id} className="flex items-start gap-2.5">
                        <div className="min-w-0 flex-1">
                          <OwnerChip name={person.name} />
                          <p className="mt-0.5 pl-[26px] text-2xs text-subtle">
                            {person.role}
                            {person.org ? ` · ${person.org}` : ''}
                          </p>
                        </div>
                        {person.email ? (
                          <a href={`mailto:${person.email}`} className="text-subtle hover:text-primary">
                            <Mail className="size-3.5" />
                          </a>
                        ) : null}
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Top risks</CardTitle>
                  <button onClick={() => setTab('risks')} className="text-xs text-primary hover:underline">
                    Register
                  </button>
                </CardHeader>
                <CardContent className="space-y-2.5 pt-0">
                  {topRisks.length === 0 ? (
                    <p className="py-3 text-center text-xs text-subtle">No open risks.</p>
                  ) : (
                    topRisks.map((risk) => {
                      const score = riskScore(risk.likelihood, risk.impact);
                      const band = riskBand(score);
                      return (
                        <div key={risk.id} className="flex items-start gap-2.5">
                          <Badge tone={band.tone} className="num mt-0.5 shrink-0">
                            {score}
                          </Badge>
                          <div className="min-w-0">
                            <p className="text-sm leading-snug text-foreground">{risk.title}</p>
                            {risk.decisionNeeded ? (
                              <p className="mt-0.5 text-2xs text-warning">{risk.decisionNeeded}</p>
                            ) : null}
                          </div>
                        </div>
                      );
                    })
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Upcoming milestones</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2.5 pt-0">
                  {milestones.length === 0 ? (
                    <p className="py-3 text-center text-xs text-subtle">None recorded.</p>
                  ) : (
                    [...milestones]
                      .sort((a, b) => a.date.localeCompare(b.date))
                      .slice(0, 6)
                      .map((milestone) => (
                        <div key={milestone.id} className="flex items-center gap-2.5">
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm text-foreground">{milestone.name}</p>
                            <p className="text-2xs text-subtle">{formatDate(milestone.date)}</p>
                          </div>
                          <StatusBadge value={milestone.status} dot={false} />
                        </div>
                      ))
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* -------------------------------------------------------- views */}
        <TabsContent value="roadmap">
          <RoadmapView applicationId={id} />
        </TabsContent>

        <TabsContent value="board">
          <KanbanBoard applicationId={id} />
        </TabsContent>

        <TabsContent value="timeline">
          <TimelineView applicationId={id} />
        </TabsContent>

        <TabsContent value="dependencies" className="space-y-3">
          <SectionTitle action={<DependencyLegend />}>Dependency graph</SectionTitle>
          <DependencyGraphView applicationId={id} height={460} />
          <EntityListPage entity="dependencies" applicationId={id} embedded />
        </TabsContent>

        {/* ------------------------------------------------- scoped tables */}
        <TabsContent value="epics">
          <EntityListPage entity="epics" applicationId={id} embedded />
        </TabsContent>
        <TabsContent value="features">
          <EntityListPage entity="features" applicationId={id} embedded />
        </TabsContent>
        <TabsContent value="tasks">
          <EntityListPage entity="tasks" applicationId={id} embedded />
        </TabsContent>
        <TabsContent value="requests">
          <div className="mb-4 rounded-md border border-border bg-surface/60 px-4 py-3 text-xs leading-relaxed text-muted">
            Every Jira story, Azure DevOps item, ServiceNow ticket, access request, change request and governance
            approval for {app.shortName}, in one place. {tickets.length} tracked.
          </div>
          <EntityListPage entity="tickets" applicationId={id} embedded />
        </TabsContent>
        <TabsContent value="risks">
          <EntityListPage entity="risks" applicationId={id} embedded />
        </TabsContent>
        <TabsContent value="debt">
          <EntityListPage entity="technicalDebt" applicationId={id} embedded />
        </TabsContent>
        <TabsContent value="bugs">
          <EntityListPage entity="bugs" applicationId={id} embedded />
        </TabsContent>
        <TabsContent value="releases">
          <EntityListPage entity="releases" applicationId={id} embedded />
        </TabsContent>
        <TabsContent value="notes">
          <EntityListPage entity="notes" embedded />
        </TabsContent>
      </Tabs>

      {editing ? (
        <EntityFormDialog
          entity="applications"
          open
          onOpenChange={() => setEditing(false)}
          record={app as unknown as Record<string, unknown>}
        />
      ) : null}
    </div>
  );
}
