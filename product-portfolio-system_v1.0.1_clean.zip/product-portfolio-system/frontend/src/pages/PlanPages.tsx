import { useSearchParams } from 'react-router-dom';
import { PageHeader } from '@/components/common/PageHeader';
import { Select } from '@/components/ui/select';
import { EntityListPage } from '@/features/EntityListPage';
import { RoadmapView } from '@/features/views/RoadmapView';
import { KanbanBoard } from '@/features/views/KanbanBoard';
import { TimelineView } from '@/features/views/TimelineView';
import { DependencyGraphView, DependencyLegend } from '@/features/views/DependencyGraphView';
import { useLookups } from '@/features/useLookups';

/** Shared application picker for the portfolio-wide plan views. */
const ApplicationScope = () => {
  const [params, setParams] = useSearchParams();
  const { appOptions } = useLookups();
  const value = params.get('applicationId') ?? 'all';

  return (
    <Select
      value={value}
      onValueChange={(next) => {
        const updated = new URLSearchParams(params);
        if (next === 'all') updated.delete('applicationId');
        else updated.set('applicationId', next);
        setParams(updated, { replace: true });
      }}
      options={appOptions}
      allowEmpty
      emptyLabel="All applications"
      className="w-[190px]"
    />
  );
};

const useScope = () => useSearchParams()[0].get('applicationId') ?? undefined;

export const RoadmapPage = () => {
  const applicationId = useScope();
  return (
    <div>
      <PageHeader
        title="Roadmap"
        description="Now is committed. Next is agreed but not started. Later is directional, and the dates are deliberately soft."
        actions={<ApplicationScope />}
      />
      <RoadmapView applicationId={applicationId} />
    </div>
  );
};

export const BoardPage = () => {
  const applicationId = useScope();
  return (
    <div>
      <PageHeader
        title="Board"
        description="Drag a card to change its status. The move is saved as one request, and rolled back if the API rejects it."
        actions={<ApplicationScope />}
      />
      <KanbanBoard applicationId={applicationId} />
    </div>
  );
};

export const TimelinePage = () => {
  const applicationId = useScope();
  return (
    <div>
      <PageHeader
        title="Timeline"
        description="Releases, milestones and epic target dates by quarter."
        actions={<ApplicationScope />}
      />
      <TimelineView applicationId={applicationId} />
    </div>
  );
};

export const DependenciesPage = () => {
  const applicationId = useScope();
  return (
    <div>
      <PageHeader
        title="Dependencies"
        description="Solid boxes are applications we own. Dashed boxes are systems, teams and vendors we depend on. Line colour is the status of that dependency."
        actions={<ApplicationScope />}
        meta={<DependencyLegend />}
      />
      <DependencyGraphView applicationId={applicationId} height={520} />
      <div className="mt-6">
        <EntityListPage entity="dependencies" applicationId={applicationId} embedded />
      </div>
    </div>
  );
};
