import * as React from 'react';
import { CheckCircle2, ClipboardList, Pencil, Plus, Search } from 'lucide-react';
import type { Note } from '@shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { StatusBadge } from '@/components/ui/badge';
import { EmptyState, Skeleton } from '@/components/ui/misc';
import { PageHeader } from '@/components/common/PageHeader';
import { AppChip, BulletList, Field, Prose } from '@/components/common/atoms';
import { EntityFormDialog } from '@/features/EntityFormDialog';
import { useLookups } from '@/features/useLookups';
import { useEntityList } from '@/hooks/useEntities';
import { useDebounce } from '@/hooks/useDebounce';
import { cn, formatDate, truncate } from '@/lib/utils';

/**
 * Meeting notes.
 *
 * A list-plus-reader rather than a table: these records are read, not scanned.
 * Raw text is stored verbatim so nothing is lost, and the structured fields
 * (decisions, open questions, action items) are what later become tasks and
 * risks. `processed` marks a note as triaged so the inbox stays honest.
 */
export default function NotesPage() {
  const [term, setTerm] = React.useState('');
  const debounced = useDebounce(term, 250);
  const { data: notes = [], isLoading } = useEntityList('notes', debounced ? { q: debounced } : {});
  const { appById } = useLookups();

  const [selectedId, setSelectedId] = React.useState<string | null>(null);
  const [editing, setEditing] = React.useState<Note | null | undefined>(undefined);

  const sorted = React.useMemo(() => [...notes].sort((a, b) => b.date.localeCompare(a.date)), [notes]);
  const selected = sorted.find((note) => note.id === selectedId) ?? sorted[0];

  return (
    <div>
      <PageHeader
        title="Meeting notes"
        description="Paste raw notes, emails, Teams threads or a brain dump. Keep the original text, pull the decisions and actions out of it, then triage into tasks, risks and epics."
        actions={
          <Button variant="primary" onClick={() => setEditing(null)}>
            <Plus /> New note
          </Button>
        }
      />

      <div className="grid gap-4 lg:grid-cols-[minmax(280px,340px)_1fr]">
        {/* ------------------------------------------------------- list */}
        <div className="space-y-3">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-subtle" />
            <Input
              value={term}
              onChange={(event) => setTerm(event.target.value)}
              placeholder="Search notes"
              className="pl-8"
            />
          </div>

          {isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-20" />
              ))}
            </div>
          ) : sorted.length === 0 ? (
            <div className="panel">
              <EmptyState icon={ClipboardList} title="No notes" description="Create the first one." />
            </div>
          ) : (
            <div className="space-y-2">
              {sorted.map((note) => (
                <button
                  key={note.id}
                  type="button"
                  onClick={() => setSelectedId(note.id)}
                  className={cn(
                    'w-full rounded-lg border p-3 text-left transition-colors',
                    selected?.id === note.id
                      ? 'border-primary/45 bg-primary/[0.07]'
                      : 'border-border bg-card hover:border-primary/30',
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="min-w-0 flex-1 text-sm font-medium leading-snug text-foreground">{note.title}</p>
                    {note.processed ? <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-success" /> : null}
                  </div>
                  <p className="mt-1 text-2xs text-subtle">
                    {formatDate(note.date)} · {note.source.replace('_', ' ')}
                  </p>
                  {note.summary ? (
                    <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-muted">{truncate(note.summary, 140)}</p>
                  ) : null}
                  {note.applicationIds.length > 0 ? (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {note.applicationIds.map((id) => (
                        <AppChip key={id} application={appById(id)} size="xs" link={false} />
                      ))}
                    </div>
                  ) : null}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ----------------------------------------------------- reader */}
        {selected ? (
          <Card className="h-fit">
            <CardHeader>
              <div className="min-w-0">
                <CardTitle className="text-base">{selected.title}</CardTitle>
                <p className="mt-1 text-xs text-muted">
                  {formatDate(selected.date)} · {selected.source.replace('_', ' ')}
                  {selected.attendees.length > 0 ? ` · ${selected.attendees.join(', ')}` : ''}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <StatusBadge value={selected.processed ? 'done' : 'backlog'} />
                <Button variant="secondary" size="sm" onClick={() => setEditing(selected)}>
                  <Pencil /> Edit
                </Button>
              </div>
            </CardHeader>

            <CardContent className="space-y-6 pt-0">
              {selected.summary ? (
                <Field label="Summary">
                  <Prose text={selected.summary} />
                </Field>
              ) : null}

              {selected.decisions.length > 0 ? (
                <Field label="Decisions">
                  <BulletList items={selected.decisions} />
                </Field>
              ) : null}

              {selected.openQuestions.length > 0 ? (
                <Field label="Open questions">
                  <BulletList items={selected.openQuestions} />
                </Field>
              ) : null}

              {selected.actionItems.length > 0 ? (
                <Field label="Action items">
                  <ul className="space-y-2">
                    {selected.actionItems.map((action, index) => (
                      <li key={index} className="flex flex-wrap items-center gap-2 text-sm">
                        <StatusBadge value={action.status === 'done' ? 'done' : action.status} dot={false} />
                        <span className="text-foreground/90">{action.text}</span>
                        <span className="text-2xs text-subtle">
                          {action.owner || 'Unassigned'}
                          {action.dueDate ? ` · ${formatDate(action.dueDate)}` : ''}
                        </span>
                      </li>
                    ))}
                  </ul>
                </Field>
              ) : null}

              <Field label="Raw notes">
                {selected.rawNotes ? (
                  <pre className="max-h-[420px] overflow-auto whitespace-pre-wrap rounded-md border border-border bg-surface/60 p-3 font-mono text-xs leading-relaxed text-foreground/85">
                    {selected.rawNotes}
                  </pre>
                ) : (
                  <p className="text-sm text-subtle">Nothing pasted yet.</p>
                )}
              </Field>
            </CardContent>
          </Card>
        ) : null}
      </div>

      {editing !== undefined ? (
        <EntityFormDialog
          entity="notes"
          open
          onOpenChange={(open) => !open && setEditing(undefined)}
          record={editing as unknown as Record<string, unknown>}
        />
      ) : null}
    </div>
  );
}
