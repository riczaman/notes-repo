import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { EmptyState } from '@/components/ui/misc';

export default function NotFoundPage() {
  return (
    <div className="panel">
      <EmptyState
        icon={Compass}
        title="That page does not exist"
        description="The link may be out of date, or the record it pointed at was deleted."
        action={
          <Button variant="primary" asChild>
            <Link to="/">Back to the dashboard</Link>
          </Button>
        }
      />
    </div>
  );
}
