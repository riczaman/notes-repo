import { Link, useNavigate } from 'react-router-dom';
import {
  AlertOctagon,
  ArrowUpRight,
  Bug,
  CheckSquare,
  LayoutGrid,
  Milestone as MilestoneIcon,
  ShieldAlert,
  Ticket,
  Wrench,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge, StatusBadge } from '@/components/ui/badge';
import { Progress, Skeleton } from '@/components/ui/misc';
import { PageHeader } from '@/components/common/PageHeader';
import { StatCard } from '@/components/common/StatCard';
import { SectionTitle } from '@/components/common/atoms';
import { ChartLegend, CountBars, RiskMatrix, StatusDonut } from '@/components/charts/charts';
import { useDashboard } from '@/hooks/useInsights';
import { useLookups } from '@/features/useLookups';
import { formatDate, formatDateTime, relativeDays } from '@/lib/utils';
import { riskBand } from '@/lib/display';

const HEALTH_TONE = { on_track: 'success', at_risk: 'warning', off_track: 'danger' } as const;

export default function DashboardPage() {
  const { data, isLoading } = useDashboard();
  const { appById } = useLookups();
  const navigate = useNavigate();

  if (isLoading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-9 w-64" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  const { counts, applications, statusBreakdown, priorityBreakdown, horizonBreakdown, riskMatrix, topRisks, upcomingMilestones } =
    data;

  const statusData = statusBreakdown.map((row) => ({ key: row.status, count: row.count }));
  const priorityData = priorityBreakdown.map((row) => ({ key: row.priority, count: row.count }));
  const horizonData = horizonBreakdown.map((row) => ({ key: row.horizon, count: row.count }));

  return (
    <div className="space-y-7">
      <PageHeader
        title="Portfolio dashboard"
        description="Four initiatives, one view. Everything below is derived from the JSON files in backend/data on each request, so it cannot drift from the records."
        meta={<span className="text-xs text-subtle">Generated {formatDateTime(data.generatedAt)}</span>}
      />

      {/* ------------------------------------------------------------ tiles */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Applications" value={counts.applications} icon={LayoutGrid} to="/applications" tone="primary" />
        <StatCard
          label="Open tasks"
          value={counts.openTasks}
          hint={`${counts.doneTasks} done of ${counts.tasks}`}
          icon={CheckSquare}
          to="/tasks"
          tone="info"
        />
        <StatCard
          label="Blocked"
          value={counts.blockedTasks}
          hint="Waiting on someone else"
          icon={AlertOctagon}
          to="/tasks?status=blocked"
          tone={counts.blockedTasks > 0 ? 'danger' : 'neutral'}
        />
        <StatCard
          label="Open risks"
          value={counts.openRisks}
          hint={`${counts.criticalRisks} scoring high or above`}
          icon={ShieldAlert}
          to="/risks"
          tone="danger"
        />
        <StatCard
          label="Technical debt"
          value={counts.openTechnicalDebt}
          hint={`${counts.openBugs} open bugs`}
          icon={Wrench}
          to="/technical-debt"
          tone="warning"
        />
        <StatCard
          label="Open requests"
          value={counts.openTickets}
          hint={`${counts.tickets} tracked in total`}
          icon={Ticket}
          to="/requests"
          tone="accent"
        />
      </div>

      {/* ----------------------------------------------------- applications */}
      <section>
        <SectionTitle
          action={
            <Link to="/applications" className="inline-flex items-center gap-1 text-xs text-primary hover:underline">
              All applications <ArrowUpRight className="size-3" />
            </Link>
          }
        >
          Application health
        </SectionTitle>

        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {applications.map((app) => (
            <Link key={app.applicationId} to={`/applications/${app.applicationId}`}>
              <Card className="panel-hover h-full">
                <CardHeader className="items-center">
                  <div className="flex min-w-0 items-center gap-2">
                    <span className="size-2.5 shrink-0 rounded-[3px]" style={{ backgroundColor: app.color }} />
                    <CardTitle className="truncate">{app.name}</CardTitle>
                  </div>
                  <Badge tone={HEALTH_TONE[app.health as keyof typeof HEALTH_TONE] ?? 'neutral'} dot>
                    {app.health.replace('_', ' ')}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-3.5">
                  <div>
                    <div className="mb-1.5 flex items-center justify-between text-xs">
                      <span className="text-muted">Task completion</span>
                      <span className="num font-medium text-foreground">{app.progress}%</span>
                    </div>
                    <Progress
                      value={app.progress}
                      tone={app.progress > 60 ? 'success' : app.progress > 25 ? 'primary' : 'warning'}
                    />
                  </div>

                  <dl className="grid grid-cols-3 gap-y-2.5 text-xs">
                    {[
                      ['Epics', app.totals.epics],
                      ['Features', app.totals.features],
                      ['Tasks', app.totals.tasks],
                      ['Blocked', app.totals.tasksBlocked],
                      ['Risks', app.totals.openRisks],
                      ['Debt', app.totals.openDebt],
                    ].map(([label, value]) => (
                      <div key={label as string}>
                        <dt className="text-2xs uppercase tracking-wider text-subtle">{label}</dt>
                        <dd className="num text-sm font-medium text-foreground">{value}</dd>
                      </div>
                    ))}
                  </dl>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* ---------------------------------------------------------- charts */}
      <div className="grid gap-3 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Work by status</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <StatusDonut data={statusData} total={counts.tasks} />
            <ChartLegend data={statusData} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Tasks by priority</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <CountBars data={priorityData} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Everything by horizon</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <CountBars data={horizonData} height={130} />
            <p className="mt-2 text-xs leading-relaxed text-muted">
              Epics, features and tasks combined. A portfolio with nothing in Later is not planning; one with nothing in
              Now is not delivering.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* ------------------------------------------------- risk and dates */}
      <div className="grid gap-3 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Risk exposure</CardTitle>
            <span className="num text-xs text-muted">{counts.openRisks} open</span>
          </CardHeader>
          <CardContent>
            <RiskMatrix
              cells={riskMatrix}
              onSelect={(likelihood, impact) => navigate(`/risks?likelihood=${likelihood}&impact=${impact}`)}
            />
          </CardContent>
        </Card>

        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Highest scoring risks</CardTitle>
            <Link to="/risks" className="text-xs text-primary hover:underline">
              Register
            </Link>
          </CardHeader>
          <CardContent className="space-y-2.5 pt-0">
            {topRisks.map((risk) => {
              const band = riskBand(risk.score);
              const app = appById(risk.applicationId);
              return (
                <Link
                  key={risk.id}
                  to={`/risks?q=${encodeURIComponent(risk.title)}`}
                  className="flex items-start gap-2.5 rounded-md px-2 py-1.5 transition-colors hover:bg-foreground/[0.05]"
                >
                  <Badge tone={band.tone} className="num mt-0.5 shrink-0">
                    {risk.score}
                  </Badge>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm text-foreground">{risk.title}</span>
                    <span className="block text-xs text-subtle">{app?.shortName ?? 'Portfolio'}</span>
                  </span>
                </Link>
              );
            })}
          </CardContent>
        </Card>

        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Next dates that matter</CardTitle>
            <Link to="/timeline" className="text-xs text-primary hover:underline">
              Timeline
            </Link>
          </CardHeader>
          <CardContent className="space-y-2.5 pt-0">
            {upcomingMilestones.length === 0 ? (
              <p className="py-6 text-center text-xs text-subtle">No upcoming milestones.</p>
            ) : (
              upcomingMilestones.map((milestone) => {
                const days = relativeDays(milestone.date);
                const app = appById(milestone.applicationId);
                return (
                  <div key={milestone.id} className="flex items-start gap-2.5 px-2 py-1.5">
                    <MilestoneIcon className="mt-0.5 size-3.5 shrink-0 text-subtle" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm text-foreground">{milestone.name}</p>
                      <p className="text-xs text-subtle">
                        {app?.shortName ?? 'Portfolio'} · {formatDate(milestone.date)}
                        {days !== null ? (
                          <span className={days < 0 ? 'text-danger' : days < 30 ? 'text-warning' : ''}>
                            {' '}
                            · {days < 0 ? `${Math.abs(days)}d overdue` : `in ${days}d`}
                          </span>
                        ) : null}
                      </p>
                    </div>
                    <StatusBadge value={milestone.status} dot={false} />
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>
      </div>

      {counts.openBugs > 0 ? (
        <Link
          to="/bugs"
          className="panel panel-hover flex items-center gap-3 px-4 py-3 text-sm text-muted transition-colors"
        >
          <Bug className="size-4 text-warning" />
          <span>
            <span className="num font-medium text-foreground">{counts.openBugs}</span> open defect
            {counts.openBugs === 1 ? '' : 's'} across the portfolio.
          </span>
          <ArrowUpRight className="ml-auto size-3.5 text-subtle" />
        </Link>
      ) : null}
    </div>
  );
}
