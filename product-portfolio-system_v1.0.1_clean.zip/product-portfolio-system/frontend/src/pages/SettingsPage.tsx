import { useQuery } from '@tanstack/react-query';
import { CheckCircle2, Database, Moon, Sun, XCircle } from 'lucide-react';
import { ENTITY_DESCRIPTORS } from '@shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/misc';
import { PageHeader } from '@/components/common/PageHeader';
import { Field } from '@/components/common/atoms';
import { api } from '@/lib/api';
import { useDashboard } from '@/hooks/useInsights';
import { useTheme } from '@/hooks/useTheme';

const Code = ({ children }: { children: string }) => (
  <code className="rounded border border-border bg-surface px-1.5 py-0.5 font-mono text-2xs text-foreground/90">
    {children}
  </code>
);

export default function SettingsPage() {
  const { theme, toggle } = useTheme();
  const { data: summary } = useDashboard();
  const health = useQuery({
    queryKey: ['health'],
    queryFn: () => api.health(),
    refetchInterval: 30_000,
    retry: false,
  });

  const counts = summary?.counts as unknown as Record<string, number> | undefined;

  return (
    <div>
      <PageHeader
        title="Settings"
        description="How this instance is wired together, and what changes when you edit the files behind it."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>API</CardTitle>
            {health.isSuccess ? (
              <span className="inline-flex items-center gap-1.5 text-xs text-success">
                <CheckCircle2 className="size-3.5" /> Connected
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-xs text-danger">
                <XCircle className="size-3.5" /> Unreachable
              </span>
            )}
          </CardHeader>
          <CardContent className="space-y-4 pt-0">
            <Field label="Base URL">
              <Code>/api</Code> proxied to <Code>http://127.0.0.1:4000</Code>
            </Field>
            <Field label="Uptime">
              {health.data ? `${health.data.data.uptimeSeconds}s` : 'The API is not responding. Start it with npm run dev:api.'}
            </Field>
            <Field label="Storage">
              JSON files in <Code>backend/data</Code>. Edit them by hand while the server runs: files are read on every
              request, so a refresh picks up your changes.
            </Field>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-sm text-foreground">Dark mode</p>
                <p className="text-xs text-muted">Stored in localStorage and applied before first paint.</p>
              </div>
              <div className="flex items-center gap-2">
                <Sun className="size-3.5 text-subtle" />
                <Switch checked={theme === 'dark'} onCheckedChange={toggle} />
                <Moon className="size-3.5 text-subtle" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Collections</CardTitle>
            <span className="inline-flex items-center gap-1.5 text-xs text-muted">
              <Database className="size-3.5" /> {ENTITY_DESCRIPTORS.length} JSON files
            </span>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-2xs uppercase tracking-wider text-subtle">
                    <th className="py-2 text-left font-semibold">Collection</th>
                    <th className="py-2 text-left font-semibold">File</th>
                    <th className="py-2 text-left font-semibold">Endpoint</th>
                    <th className="py-2 text-right font-semibold">Records</th>
                  </tr>
                </thead>
                <tbody>
                  {ENTITY_DESCRIPTORS.map((descriptor) => (
                    <tr key={descriptor.name} className="border-b border-border/60 last:border-0">
                      <td className="py-2 text-foreground">{descriptor.label}</td>
                      <td className="py-2">
                        <Code>{`backend/data/${descriptor.file}`}</Code>
                      </td>
                      <td className="py-2">
                        <Code>{`/api/${descriptor.path}`}</Code>
                      </td>
                      <td className="num py-2 text-right text-muted">{counts?.[descriptor.name] ?? '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Working with the data</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-0 text-sm leading-relaxed text-foreground/85">
            <Field label="Re-seed">
              <p>
                <Code>npm run seed</Code> fills empty collections only. <Code>npm run seed:force</Code> replaces
                everything with the August 2026 baseline, discarding anything entered since.
              </p>
            </Field>
            <Field label="Back up">
              <p>
                <Code>npm run backup</Code> copies every JSON file into a timestamped folder under{' '}
                <Code>backend/data/.backups</Code>. Run it before a force re-seed.
              </p>
            </Field>
            <Field label="Swapping the database">
              <p>
                Everything above the repository layer is written against the <Code>Repository</Code> interface. Moving to
                SQLite or Postgres means writing one new implementation and changing{' '}
                <Code>backend/src/repositories/index.ts</Code>. No service, controller, route or React component changes.
              </p>
            </Field>
            <div className="flex gap-2 pt-1">
              <Button variant="secondary" size="sm" onClick={() => health.refetch()}>
                Re-check API
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
