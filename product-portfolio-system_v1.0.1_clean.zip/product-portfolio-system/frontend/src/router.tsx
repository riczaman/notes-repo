import { lazy } from 'react';
import { createBrowserRouter } from 'react-router-dom';
import { AppShell } from '@/components/layout/AppShell';

/**
 * Routes mirror the sidebar. Collection routes are deliberately flat
 * (`/tasks`, `/risks`) with filters in the query string, so any view a person
 * builds is a URL they can paste to someone else.
 *
 * Every route is lazily loaded. Recharts, React Flow and dnd-kit are the three
 * heaviest dependencies in the app and each is used by a single view, so
 * shipping them in the initial bundle would make every page wait for code most
 * sessions never run.
 */
const named = <T extends Record<string, unknown>>(loader: () => Promise<T>, key: keyof T) =>
  lazy(() => loader().then((module) => ({ default: module[key] as React.ComponentType })));

const DashboardPage = lazy(() => import('@/pages/DashboardPage'));
const ApplicationsPage = lazy(() => import('@/pages/ApplicationsPage'));
const ApplicationDetailPage = lazy(() => import('@/pages/ApplicationDetailPage'));
const NotesPage = lazy(() => import('@/pages/NotesPage'));
const SearchPage = lazy(() => import('@/pages/SearchPage'));
const SettingsPage = lazy(() => import('@/pages/SettingsPage'));
const NotFoundPage = lazy(() => import('@/pages/NotFoundPage'));

const plan = () => import('@/pages/PlanPages');
const RoadmapPage = named(plan, 'RoadmapPage');
const BoardPage = named(plan, 'BoardPage');
const TimelinePage = named(plan, 'TimelinePage');
const DependenciesPage = named(plan, 'DependenciesPage');

const entities = () => import('@/pages/entityPages');
const EpicsPage = named(entities, 'EpicsPage');
const FeaturesPage = named(entities, 'FeaturesPage');
const TasksPage = named(entities, 'TasksPage');
const ReleasesPage = named(entities, 'ReleasesPage');
const MilestonesPage = named(entities, 'MilestonesPage');
const StakeholdersPage = named(entities, 'StakeholdersPage');
const RisksPage = named(entities, 'RisksPage');
const TechnicalDebtPage = named(entities, 'TechnicalDebtPage');
const BugsPage = named(entities, 'BugsPage');
const TicketsPage = named(entities, 'TicketsPage');

export const router = createBrowserRouter([
  {
    path: '/',
    element: <AppShell />,
    children: [
      { index: true, element: <DashboardPage /> },
      { path: 'applications', element: <ApplicationsPage /> },
      { path: 'applications/:id', element: <ApplicationDetailPage /> },

      { path: 'roadmap', element: <RoadmapPage /> },
      { path: 'board', element: <BoardPage /> },
      { path: 'timeline', element: <TimelinePage /> },
      { path: 'releases', element: <ReleasesPage /> },
      { path: 'milestones', element: <MilestonesPage /> },

      { path: 'epics', element: <EpicsPage /> },
      { path: 'features', element: <FeaturesPage /> },
      { path: 'tasks', element: <TasksPage /> },

      { path: 'risks', element: <RisksPage /> },
      { path: 'technical-debt', element: <TechnicalDebtPage /> },
      { path: 'bugs', element: <BugsPage /> },
      { path: 'dependencies', element: <DependenciesPage /> },
      { path: 'requests', element: <TicketsPage /> },

      { path: 'notes', element: <NotesPage /> },
      { path: 'stakeholders', element: <StakeholdersPage /> },
      { path: 'search', element: <SearchPage /> },
      { path: 'settings', element: <SettingsPage /> },

      { path: '*', element: <NotFoundPage /> },
    ],
  },
]);
