import React from 'react';
import ReactDOM from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { RouterProvider } from 'react-router-dom';
import { Toaster } from 'sonner';
import { router } from './router';
import './styles/index.css';

/**
 * Cache policy: the data behind this app is a set of JSON files one person
 * edits, so aggressive refetching buys nothing. Queries stay fresh for 30
 * seconds and refetch when the window regains focus, which covers the case of
 * editing a JSON file by hand and switching back to the browser.
 */
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      refetchOnWindowFocus: true,
      retry: 1,
    },
  },
});

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
      <Toaster
        position="bottom-right"
        toastOptions={{
          className: 'border border-border bg-elevated text-foreground text-sm',
        }}
      />
    </QueryClientProvider>
  </React.StrictMode>,
);
