import * as React from 'react';
import { cn } from '@/lib/utils';
import { labelOf, TONE_CLASSES, TONE_DOT, toneOf, type Tone } from '@/lib/display';

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: Tone;
  dot?: boolean;
  size?: 'sm' | 'md';
}

export const Badge = ({ className, tone = 'neutral', dot = false, size = 'sm', children, ...props }: BadgeProps) => (
  <span
    className={cn(
      'inline-flex items-center gap-1.5 rounded-full border font-medium',
      size === 'sm' ? 'px-2 py-0.5 text-2xs' : 'px-2.5 py-1 text-xs',
      TONE_CLASSES[tone],
      className,
    )}
    {...props}
  >
    {dot ? <span className={cn('size-1.5 rounded-full', TONE_DOT[tone])} /> : null}
    {children}
  </span>
);

/**
 * Renders any controlled value with its own tone and label.
 * Every status, priority, severity and health chip in the app goes through here,
 * which is why they stay consistent across tables, cards and boards.
 */
export const StatusBadge = ({
  value,
  dot = true,
  size = 'sm',
  className,
}: {
  value?: string | null;
  dot?: boolean;
  size?: 'sm' | 'md';
  className?: string;
}) => {
  if (!value) return <span className="text-xs text-subtle">—</span>;
  return (
    <Badge tone={toneOf(value)} dot={dot} size={size} className={className}>
      {labelOf(value)}
    </Badge>
  );
};
