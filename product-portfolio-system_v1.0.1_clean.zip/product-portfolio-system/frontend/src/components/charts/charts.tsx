import * as React from 'react';
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { labelOf } from '@/lib/display';
import { cn } from '@/lib/utils';

/**
 * Literal hex values rather than CSS variables: Recharts writes colours into SVG
 * presentation attributes, and these tones are chosen to hold up on both the
 * light and dark surfaces so one palette serves both themes.
 */
export const CHART_COLORS: Record<string, string> = {
  backlog: '#64748b',
  discovery: '#38bdf8',
  ready: '#2dd4bf',
  in_progress: '#14b8a6',
  blocked: '#ef4444',
  testing: '#f59e0b',
  done: '#34d399',

  critical: '#ef4444',
  high: '#f59e0b',
  medium: '#38bdf8',
  low: '#64748b',

  now: '#2dd4bf',
  next: '#38bdf8',
  later: '#64748b',
};

const colorFor = (key: string, fallback = '#2dd4bf') => CHART_COLORS[key] ?? fallback;

const ChartTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const item = payload[0];
  return (
    <div className="rounded-md border border-border bg-elevated px-2.5 py-1.5 text-xs shadow-pop">
      <span className="text-muted">{labelOf(item.payload.key)}</span>{' '}
      <span className="num font-medium text-foreground">{item.value}</span>
    </div>
  );
};

/* --------------------------------------------------------------- donut */

export const StatusDonut = ({
  data,
  total,
  centerLabel = 'tasks',
}: {
  data: { key: string; count: number }[];
  total: number;
  centerLabel?: string;
}) => (
  <div className="relative h-[190px]">
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie
          data={data}
          dataKey="count"
          nameKey="key"
          innerRadius={58}
          outerRadius={82}
          paddingAngle={2}
          stroke="none"
        >
          {data.map((entry) => (
            <Cell key={entry.key} fill={colorFor(entry.key)} />
          ))}
        </Pie>
        <RTooltip content={<ChartTooltip />} />
      </PieChart>
    </ResponsiveContainer>
    <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
      <span className="num text-2xl font-semibold text-foreground">{total}</span>
      <span className="text-2xs uppercase tracking-wider text-subtle">{centerLabel}</span>
    </div>
  </div>
);

/* ---------------------------------------------------------------- bars */

export const CountBars = ({ data, height = 190 }: { data: { key: string; count: number }[]; height?: number }) => (
  <div style={{ height }}>
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 12, bottom: 4, left: 4 }} barSize={14}>
        <XAxis type="number" hide />
        <YAxis
          type="category"
          dataKey="key"
          width={92}
          tickLine={false}
          axisLine={false}
          tick={{ fontSize: 11, fill: 'currentColor' }}
          tickFormatter={(value: string) => labelOf(value)}
          className="text-muted"
        />
        <RTooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(127,127,127,0.08)' }} />
        <Bar dataKey="count" radius={[3, 3, 3, 3]}>
          {data.map((entry) => (
            <Cell key={entry.key} fill={colorFor(entry.key)} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  </div>
);

/* --------------------------------------------------------- risk matrix */

const SCALE = ['low', 'medium', 'high', 'critical'] as const;
const WEIGHT: Record<string, number> = { low: 1, medium: 2, high: 3, critical: 4 };

const cellTone = (score: number): string => {
  if (score >= 12) return 'bg-danger/35 text-foreground';
  if (score >= 9) return 'bg-danger/20 text-foreground';
  if (score >= 6) return 'bg-warning/20 text-foreground';
  if (score >= 3) return 'bg-info/15 text-foreground';
  return 'bg-foreground/[0.05] text-muted';
};

/**
 * Likelihood on the vertical axis, impact on the horizontal, exactly as a risk
 * register is normally read. Clicking a cell filters the register to those risks.
 */
export const RiskMatrix = ({
  cells,
  onSelect,
}: {
  cells: { likelihood: string; impact: string; count: number }[];
  onSelect?: (likelihood: string, impact: string) => void;
}) => {
  const lookup = new Map(cells.map((cell) => [`${cell.likelihood}|${cell.impact}`, cell.count]));

  return (
    <div className="flex gap-2">
      <div className="flex flex-col justify-between py-1 text-2xs uppercase tracking-wider text-subtle">
        <span className="-rotate-90 whitespace-nowrap pb-6 pt-6">Likelihood</span>
      </div>
      <div className="flex-1">
        <div className="grid grid-cols-4 gap-1.5">
          {[...SCALE].reverse().map((likelihood) =>
            SCALE.map((impact) => {
              const count = lookup.get(`${likelihood}|${impact}`) ?? 0;
              const score = WEIGHT[likelihood] * WEIGHT[impact];
              return (
                <button
                  key={`${likelihood}-${impact}`}
                  type="button"
                  disabled={count === 0}
                  onClick={() => onSelect?.(likelihood, impact)}
                  className={cn(
                    'flex aspect-[3/2] flex-col items-center justify-center rounded-md border border-border/50 transition-transform',
                    cellTone(score),
                    count > 0 && onSelect && 'cursor-pointer hover:scale-[1.03]',
                  )}
                  title={`${labelOf(likelihood)} likelihood · ${labelOf(impact)} impact`}
                >
                  <span className="num text-base font-semibold">{count || ''}</span>
                </button>
              );
            }),
          )}
        </div>
        <div className="mt-1.5 grid grid-cols-4 gap-1.5 text-center text-2xs text-subtle">
          {SCALE.map((impact) => (
            <span key={impact}>{labelOf(impact)}</span>
          ))}
        </div>
        <p className="mt-1 text-center text-2xs uppercase tracking-wider text-subtle">Impact</p>
      </div>
    </div>
  );
};

/* -------------------------------------------------------------- legend */

export const ChartLegend = ({ data }: { data: { key: string; count: number }[] }) => (
  <ul className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1.5">
    {data.map((entry) => (
      <li key={entry.key} className="flex items-center gap-2 text-xs">
        <span className="size-2 shrink-0 rounded-full" style={{ backgroundColor: colorFor(entry.key) }} />
        <span className="truncate text-muted">{labelOf(entry.key)}</span>
        <span className="num ml-auto text-foreground">{entry.count}</span>
      </li>
    ))}
  </ul>
);
