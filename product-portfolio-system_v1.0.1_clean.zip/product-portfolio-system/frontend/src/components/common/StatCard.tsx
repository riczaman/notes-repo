import * as React from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { TONE_DOT, type Tone } from '@/lib/display';

interface StatCardProps {
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  tone?: Tone;
  icon?: React.ComponentType<{ className?: string }>;
  to?: string;
  className?: string;
}

/**
 * The one number-plus-context tile used across the dashboard and detail pages.
 * A coloured rule rather than a coloured card: the number stays the loudest
 * thing on the tile.
 */
export const StatCard = ({ label, value, hint, tone = 'primary', icon: Icon, to, className }: StatCardProps) => {
  const content = (
    <div
      className={cn(
        'panel sheen relative h-full overflow-hidden px-4 py-3.5',
        to && 'panel-hover cursor-pointer',
        className,
      )}
    >
      <div className={cn('absolute inset-y-0 left-0 w-0.5', TONE_DOT[tone])} />
      <div className="flex items-start justify-between gap-3">
        <p className="text-2xs font-medium uppercase tracking-wider text-subtle">{label}</p>
        {Icon ? <Icon className="size-3.5 shrink-0 text-subtle" /> : null}
      </div>
      <p className="num mt-2 text-2xl font-semibold text-foreground">{value}</p>
      {hint ? <p className="mt-1 text-xs leading-relaxed text-muted">{hint}</p> : null}
    </div>
  );

  return to ? <Link to={to}>{content}</Link> : content;
};
