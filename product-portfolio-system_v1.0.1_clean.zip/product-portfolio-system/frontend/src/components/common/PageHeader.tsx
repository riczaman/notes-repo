import * as React from 'react';
import { cn } from '@/lib/utils';

export const PageHeader = ({
  title,
  description,
  actions,
  meta,
  className,
}: {
  title: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  meta?: React.ReactNode;
  className?: string;
}) => (
  <div className={cn('mb-6 flex flex-wrap items-start justify-between gap-4', className)}>
    <div className="min-w-0 space-y-1.5">
      <h1 className="text-xl font-semibold tracking-tight text-foreground">{title}</h1>
      {description ? <p className="max-w-2xl text-sm leading-relaxed text-muted">{description}</p> : null}
      {meta ? <div className="flex flex-wrap items-center gap-2 pt-1">{meta}</div> : null}
    </div>
    {actions ? <div className="flex shrink-0 items-center gap-2">{actions}</div> : null}
  </div>
);
