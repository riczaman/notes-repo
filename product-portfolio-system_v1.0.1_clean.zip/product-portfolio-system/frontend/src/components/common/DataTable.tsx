import * as React from 'react';
import { ArrowDown, ArrowUp, ChevronsUpDown, Inbox } from 'lucide-react';
import { cn } from '@/lib/utils';
import { EmptyState, Skeleton } from '@/components/ui/misc';

export interface Column<T> {
  key: string;
  header: string;
  /** Cell renderer. Falls back to the raw value at `key`. */
  render?: (row: T) => React.ReactNode;
  /** Value used for sorting when the cell renders something non-comparable. */
  sortValue?: (row: T) => string | number;
  width?: string;
  align?: 'left' | 'right';
  className?: string;
  sortable?: boolean;
}

interface DataTableProps<T> {
  rows: T[];
  columns: Column<T>[];
  loading?: boolean;
  onRowClick?: (row: T) => void;
  rowKey: (row: T) => string;
  empty?: { title: string; description?: string; action?: React.ReactNode };
  className?: string;
  /** Sticky header needs a bounded height; pass one when the table is inside a page scroll. */
  maxHeight?: string;
}

/**
 * One table for the whole app.
 *
 * Sorting is client side and deliberate: the API already returns the filtered
 * set, and re-sorting a few hundred rows in the browser is instant and avoids a
 * round trip per header click. Server sorting is still available through the
 * `sort` query parameter when a page needs it.
 */
export function DataTable<T>({
  rows,
  columns,
  loading,
  onRowClick,
  rowKey,
  empty,
  className,
  maxHeight,
}: DataTableProps<T>) {
  const [sort, setSort] = React.useState<{ key: string; dir: 'asc' | 'desc' } | null>(null);

  const sorted = React.useMemo(() => {
    if (!sort) return rows;
    const column = columns.find((c) => c.key === sort.key);
    if (!column) return rows;
    const value = (row: T) => {
      if (column.sortValue) return column.sortValue(row);
      const raw = (row as Record<string, unknown>)[column.key];
      return typeof raw === 'number' ? raw : String(raw ?? '');
    };
    return [...rows].sort((a, b) => {
      const left = value(a);
      const right = value(b);
      const result =
        typeof left === 'number' && typeof right === 'number'
          ? left - right
          : String(left).localeCompare(String(right), undefined, { numeric: true });
      return sort.dir === 'asc' ? result : -result;
    });
  }, [rows, sort, columns]);

  const toggleSort = (key: string) =>
    setSort((current) =>
      current?.key === key ? (current.dir === 'asc' ? { key, dir: 'desc' } : null) : { key, dir: 'asc' },
    );

  if (loading) {
    return (
      <div className="panel overflow-hidden">
        <div className="space-y-px">
          {Array.from({ length: 6 }).map((_, index) => (
            <Skeleton key={index} className="h-11 rounded-none" />
          ))}
        </div>
      </div>
    );
  }

  if (sorted.length === 0) {
    return (
      <div className="panel">
        <EmptyState
          icon={Inbox}
          title={empty?.title ?? 'Nothing here yet'}
          description={empty?.description}
          action={empty?.action}
        />
      </div>
    );
  }

  return (
    <div className={cn('panel overflow-hidden', className)}>
      <div className="overflow-x-auto" style={maxHeight ? { maxHeight, overflowY: 'auto' } : undefined}>
        <table className="w-full border-collapse text-sm">
          <thead className="sticky top-0 z-10 bg-surface/95 backdrop-blur">
            <tr className="border-b border-border">
              {columns.map((column) => {
                const sortable = column.sortable !== false;
                const active = sort?.key === column.key;
                return (
                  <th
                    key={column.key}
                    style={column.width ? { width: column.width } : undefined}
                    className={cn(
                      'whitespace-nowrap px-3 py-2.5 text-2xs font-semibold uppercase tracking-wider text-subtle',
                      column.align === 'right' ? 'text-right' : 'text-left',
                    )}
                  >
                    {sortable ? (
                      <button
                        type="button"
                        onClick={() => toggleSort(column.key)}
                        className={cn(
                          'inline-flex items-center gap-1 transition-colors hover:text-foreground',
                          active && 'text-foreground',
                        )}
                      >
                        {column.header}
                        {active ? (
                          sort.dir === 'asc' ? (
                            <ArrowUp className="size-3" />
                          ) : (
                            <ArrowDown className="size-3" />
                          )
                        ) : (
                          <ChevronsUpDown className="size-3 opacity-0 transition-opacity group-hover:opacity-100" />
                        )}
                      </button>
                    ) : (
                      column.header
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {sorted.map((row) => (
              <tr
                key={rowKey(row)}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                className={cn(
                  'group border-b border-border/60 transition-colors last:border-0',
                  onRowClick && 'cursor-pointer hover:bg-primary/[0.05]',
                )}
              >
                {columns.map((column) => (
                  <td
                    key={column.key}
                    className={cn(
                      'px-3 py-2.5 align-middle text-foreground/90',
                      column.align === 'right' && 'text-right',
                      column.className,
                    )}
                  >
                    {column.render ? column.render(row) : String((row as Record<string, unknown>)[column.key] ?? '—')}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
