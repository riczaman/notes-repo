import * as React from 'react';
import { Search, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, type Option } from '@/components/ui/select';
import { cn } from '@/lib/utils';

export interface FilterDef {
  key: string;
  label: string;
  options: Option[];
  width?: string;
}

/**
 * Stateless filter bar driven by a config array. Every list page reuses it and
 * supplies only the dimensions that make sense for that collection, which is
 * why there is no per-page filter component anywhere in this codebase.
 */
export const FilterBar = ({
  filters,
  values,
  onChange,
  onClear,
  activeCount,
  searchPlaceholder = 'Search',
  right,
  className,
}: {
  filters: FilterDef[];
  values: Record<string, string>;
  onChange: (key: string, value: string) => void;
  onClear: () => void;
  activeCount: number;
  searchPlaceholder?: string;
  right?: React.ReactNode;
  className?: string;
}) => (
  <div className={cn('mb-4 flex flex-wrap items-center gap-2', className)}>
    <div className="relative min-w-[200px] flex-1 sm:max-w-xs">
      <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-subtle" />
      <Input
        value={values.q ?? ''}
        onChange={(event) => onChange('q', event.target.value)}
        placeholder={searchPlaceholder}
        className="pl-8"
      />
    </div>

    {filters.map((filter) => (
      <Select
        key={filter.key}
        value={values[filter.key] ?? 'all'}
        onValueChange={(value) => onChange(filter.key, value)}
        options={filter.options}
        allowEmpty
        emptyLabel={`All ${filter.label.toLowerCase()}`}
        className={filter.width ?? 'w-[150px]'}
      />
    ))}

    {activeCount > 0 || values.q ? (
      <Button variant="ghost" size="sm" onClick={onClear} className="gap-1">
        <X className="size-3.5" />
        Clear
      </Button>
    ) : null}

    {right ? <div className="ml-auto flex items-center gap-2">{right}</div> : null}
  </div>
);
