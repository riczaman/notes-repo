import * as React from 'react';
import { Link } from 'react-router-dom';
import { cn, hueFromString, initials } from '@/lib/utils';
import type { Application } from '@shared';

/** Small square carrying an application's colour. Used everywhere an app is named. */
export const AppChip = ({
  application,
  size = 'sm',
  link = true,
  className,
}: {
  application?: Pick<Application, 'id' | 'shortName' | 'color'> | null;
  size?: 'xs' | 'sm' | 'md';
  link?: boolean;
  className?: string;
}) => {
  if (!application) return <span className="text-xs text-subtle">Portfolio</span>;

  const body = (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 font-medium text-foreground/90 transition-colors',
        size === 'xs' ? 'text-2xs' : 'text-xs',
        link && 'hover:text-primary',
        className,
      )}
    >
      <span
        className={cn('shrink-0 rounded-[3px]', size === 'md' ? 'size-2.5' : 'size-2')}
        style={{ backgroundColor: application.color }}
      />
      {application.shortName}
    </span>
  );

  return link ? (
    <Link to={`/applications/${application.id}`} onClick={(event) => event.stopPropagation()}>
      {body}
    </Link>
  ) : (
    body
  );
};

/** Owner avatar with a deterministic hue, so the same person looks the same everywhere. */
export const OwnerChip = ({ name, className }: { name?: string | null; className?: string }) => {
  if (!name) return <span className="text-xs text-subtle">Unassigned</span>;
  const hue = hueFromString(name);
  return (
    <span className={cn('inline-flex items-center gap-1.5 text-xs text-foreground/85', className)}>
      <span
        className="grid size-5 shrink-0 place-items-center rounded-full text-[9px] font-semibold"
        style={{
          backgroundColor: `hsl(${hue} 45% 30% / 0.45)`,
          color: `hsl(${hue} 70% 78%)`,
        }}
      >
        {initials(name)}
      </span>
      <span className="truncate">{name}</span>
    </span>
  );
};

export const TagList = ({ tags, max = 3 }: { tags?: string[]; max?: number }) => {
  if (!tags?.length) return null;
  const shown = tags.slice(0, max);
  const rest = tags.length - shown.length;
  return (
    <span className="inline-flex flex-wrap items-center gap-1">
      {shown.map((tag) => (
        <span key={tag} className="rounded border border-border bg-foreground/[0.04] px-1.5 py-0.5 text-2xs text-muted">
          {tag}
        </span>
      ))}
      {rest > 0 ? <span className="text-2xs text-subtle">+{rest}</span> : null}
    </span>
  );
};

/** Label/value pair used on every detail panel. */
export const Field = ({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) => (
  <div className={cn('space-y-1', className)}>
    <p className="text-2xs font-medium uppercase tracking-wider text-subtle">{label}</p>
    <div className="text-sm leading-relaxed text-foreground/90">{children || <span className="text-subtle">—</span>}</div>
  </div>
);

/** Preserves the line breaks people paste in without pulling in a markdown renderer. */
export const Prose = ({ text, className }: { text?: string | null; className?: string }) => {
  if (!text) return <span className="text-subtle">—</span>;
  return <p className={cn('whitespace-pre-wrap text-sm leading-relaxed text-foreground/85', className)}>{text}</p>;
};

export const BulletList = ({ items, empty = '—' }: { items?: string[]; empty?: string }) => {
  if (!items?.length) return <span className="text-sm text-subtle">{empty}</span>;
  return (
    <ul className="space-y-1.5">
      {items.map((item, index) => (
        <li key={index} className="flex gap-2 text-sm leading-relaxed text-foreground/85">
          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-primary/70" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
};

export const SectionTitle = ({
  children,
  action,
  className,
}: {
  children: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}) => (
  <div className={cn('mb-3 flex items-center justify-between gap-3', className)}>
    <h2 className="text-xs font-semibold uppercase tracking-wider text-subtle">{children}</h2>
    {action}
  </div>
);
