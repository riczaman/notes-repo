import {
  Boxes,
  Bug,
  CalendarRange,
  CheckSquare,
  Flag,
  KanbanSquare,
  LayoutDashboard,
  LayoutGrid,
  Map,
  Milestone,
  NotebookPen,
  Rocket,
  Settings,
  Share2,
  ShieldAlert,
  Ticket,
  Users,
  Wrench,
  type LucideIcon,
} from 'lucide-react';

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  /** Key into the dashboard counts, rendered as a badge in the sidebar. */
  countKey?: string;
  end?: boolean;
}

export interface NavGroup {
  label: string;
  items: NavItem[];
}

/** Sidebar structure. Order follows how the work is actually reviewed: portfolio, then plan, then delivery, then governance. */
export const NAV_GROUPS: NavGroup[] = [
  {
    label: 'Portfolio',
    items: [
      { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
      { to: '/applications', label: 'Applications', icon: LayoutGrid, countKey: 'applications' },
    ],
  },
  {
    label: 'Plan',
    items: [
      { to: '/roadmap', label: 'Roadmap', icon: Map },
      { to: '/board', label: 'Board', icon: KanbanSquare },
      { to: '/timeline', label: 'Timeline', icon: CalendarRange },
      { to: '/releases', label: 'Releases', icon: Rocket, countKey: 'releases' },
      { to: '/milestones', label: 'Milestones', icon: Milestone, countKey: 'milestones' },
    ],
  },
  {
    label: 'Delivery',
    items: [
      { to: '/epics', label: 'Epics', icon: Flag, countKey: 'epics' },
      { to: '/features', label: 'Features', icon: Boxes, countKey: 'features' },
      { to: '/tasks', label: 'Tasks', icon: CheckSquare, countKey: 'openTasks' },
    ],
  },
  {
    label: 'Governance',
    items: [
      { to: '/risks', label: 'Risks', icon: ShieldAlert, countKey: 'openRisks' },
      { to: '/technical-debt', label: 'Technical Debt', icon: Wrench, countKey: 'openTechnicalDebt' },
      { to: '/bugs', label: 'Bugs', icon: Bug, countKey: 'openBugs' },
      { to: '/dependencies', label: 'Dependencies', icon: Share2, countKey: 'dependencies' },
      { to: '/requests', label: 'Request Tracker', icon: Ticket, countKey: 'openTickets' },
    ],
  },
  {
    label: 'Knowledge',
    items: [
      { to: '/notes', label: 'Meeting Notes', icon: NotebookPen },
      { to: '/stakeholders', label: 'Stakeholders', icon: Users },
      { to: '/settings', label: 'Settings', icon: Settings },
    ],
  },
];

/** Route segment to human label, used by the breadcrumb trail. */
export const ROUTE_LABELS: Record<string, string> = {
  applications: 'Applications',
  roadmap: 'Roadmap',
  board: 'Board',
  timeline: 'Timeline',
  releases: 'Releases',
  milestones: 'Milestones',
  epics: 'Epics',
  features: 'Features',
  tasks: 'Tasks',
  risks: 'Risks',
  'technical-debt': 'Technical Debt',
  bugs: 'Bugs',
  dependencies: 'Dependencies',
  requests: 'Request Tracker',
  notes: 'Meeting Notes',
  stakeholders: 'Stakeholders',
  settings: 'Settings',
  search: 'Search',
};
