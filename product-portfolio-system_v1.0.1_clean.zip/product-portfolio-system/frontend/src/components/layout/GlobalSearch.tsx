import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { CornerDownLeft, Search } from 'lucide-react';
import { ENTITY_REGISTRY, type EntityName, type SearchHit } from '@shared';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/misc';
import { useDebounce } from '@/hooks/useDebounce';
import { useGlobalSearch } from '@/hooks/useInsights';
import { cn, groupBy } from '@/lib/utils';

/** Where a hit navigates to. Records without a page of their own open their list, filtered. */
const routeForHit = (hit: SearchHit): string => {
  const routes: Record<EntityName, string> = {
    applications: `/applications/${hit.id}`,
    epics: '/epics',
    features: '/features',
    tasks: '/tasks',
    releases: '/releases',
    milestones: '/milestones',
    stakeholders: '/stakeholders',
    risks: '/risks',
    bugs: '/bugs',
    technicalDebt: '/technical-debt',
    dependencies: '/dependencies',
    tickets: '/requests',
    notes: '/notes',
  };
  const base = routes[hit.entity];
  return hit.entity === 'applications' ? base : `${base}?q=${encodeURIComponent(hit.title)}`;
};

export const GlobalSearch = ({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) => {
  const [term, setTerm] = React.useState('');
  const debounced = useDebounce(term, 200);
  const { data: hits = [], isFetching } = useGlobalSearch(debounced);
  const navigate = useNavigate();
  const [cursor, setCursor] = React.useState(0);

  React.useEffect(() => setCursor(0), [debounced]);
  React.useEffect(() => {
    if (!open) setTerm('');
  }, [open]);

  const go = React.useCallback(
    (hit: SearchHit) => {
      navigate(routeForHit(hit));
      onOpenChange(false);
    },
    [navigate, onOpenChange],
  );

  const onKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setCursor((value) => Math.min(value + 1, hits.length - 1));
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      setCursor((value) => Math.max(value - 1, 0));
    } else if (event.key === 'Enter' && hits[cursor]) {
      event.preventDefault();
      go(hits[cursor]);
    }
  };

  const grouped = groupBy(hits, (hit) => hit.entity);
  let index = -1;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="lg" className="top-[12%] translate-y-0 p-0">
        <div className="flex items-center gap-2.5 border-b border-border px-4">
          <Search className="size-4 shrink-0 text-subtle" />
          <input
            autoFocus
            value={term}
            onChange={(event) => setTerm(event.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Search every application, epic, task, risk, request and note"
            className="h-12 w-full bg-transparent pr-8 text-sm text-foreground outline-none placeholder:text-subtle"
          />
        </div>

        <div className="max-h-[52vh] overflow-y-auto p-2">
          {debounced.length < 2 ? (
            <p className="px-3 py-6 text-center text-xs text-subtle">Type at least two characters.</p>
          ) : isFetching && hits.length === 0 ? (
            <div className="space-y-1 p-1">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-10" />
              ))}
            </div>
          ) : hits.length === 0 ? (
            <p className="px-3 py-6 text-center text-xs text-subtle">No matches for “{debounced}”.</p>
          ) : (
            Object.entries(grouped).map(([entity, entityHits]) => (
              <div key={entity} className="mb-2">
                <p className="px-2 py-1 text-2xs font-semibold uppercase tracking-wider text-subtle">
                  {ENTITY_REGISTRY[entity as EntityName].label}
                </p>
                {entityHits.map((hit) => {
                  index += 1;
                  const active = index === cursor;
                  return (
                    <button
                      key={`${hit.entity}-${hit.id}`}
                      type="button"
                      onMouseEnter={() => setCursor(hits.indexOf(hit))}
                      onClick={() => go(hit)}
                      className={cn(
                        'flex w-full items-center gap-3 rounded-md px-2 py-2 text-left transition-colors',
                        active ? 'bg-primary/12' : 'hover:bg-foreground/[0.05]',
                      )}
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm text-foreground">{hit.title}</p>
                        {hit.subtitle ? <p className="truncate text-xs text-muted">{hit.subtitle}</p> : null}
                      </div>
                      {active ? <CornerDownLeft className="size-3.5 shrink-0 text-subtle" /> : null}
                    </button>
                  );
                })}
              </div>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
