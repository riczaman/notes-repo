import * as React from 'react';
import { NavLink } from 'react-router-dom';
import { PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tooltip } from '@/components/ui/misc';
import { useDashboard } from '@/hooks/useInsights';
import { useEntityList } from '@/hooks/useEntities';
import { NAV_GROUPS } from './navigation';

const STORAGE_KEY = 'ppm-sidebar';

export const Sidebar = () => {
  const [collapsed, setCollapsed] = React.useState(() => localStorage.getItem(STORAGE_KEY) === 'collapsed');
  const { data: summary } = useDashboard();
  const { data: applications = [] } = useEntityList('applications');

  React.useEffect(() => {
    localStorage.setItem(STORAGE_KEY, collapsed ? 'collapsed' : 'expanded');
  }, [collapsed]);

  const counts = summary?.counts as unknown as Record<string, number> | undefined;

  return (
    <aside
      className={cn(
        'sticky top-0 z-30 flex h-screen shrink-0 flex-col border-r border-border bg-surface transition-[width] duration-200',
        collapsed ? 'w-[60px]' : 'w-[228px]',
      )}
    >
      <div className={cn('flex h-14 shrink-0 items-center gap-2.5 border-b border-border px-3.5')}>
        <div className="grid size-7 shrink-0 place-items-center rounded-md bg-primary text-primary-foreground">
          <span className="text-xs font-bold">P</span>
        </div>
        {!collapsed ? (
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold tracking-tight text-foreground">Portfolio</p>
            <p className="truncate text-2xs text-subtle">TPM product management</p>
          </div>
        ) : null}
      </div>

      <nav className="flex-1 space-y-5 overflow-y-auto px-2.5 py-4">
        {NAV_GROUPS.map((group) => (
          <div key={group.label}>
            {!collapsed ? (
              <p className="mb-1.5 px-2 text-2xs font-semibold uppercase tracking-wider text-subtle">{group.label}</p>
            ) : null}
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const count = item.countKey ? counts?.[item.countKey] : undefined;
                return (
                  <li key={item.to}>
                    <Tooltip content={collapsed ? item.label : null}>
                      <NavLink
                        to={item.to}
                        end={item.end}
                        className={({ isActive }) =>
                          cn(
                            'group relative flex items-center gap-2.5 rounded-md px-2 py-1.5 text-sm transition-colors',
                            isActive
                              ? 'bg-primary/12 text-foreground'
                              : 'text-muted hover:bg-foreground/[0.05] hover:text-foreground',
                          )
                        }
                      >
                        {({ isActive }) => (
                          <>
                            <span
                              className={cn(
                                'absolute left-0 top-1/2 h-4 w-0.5 -translate-y-1/2 rounded-r-full bg-primary transition-opacity',
                                isActive ? 'opacity-100' : 'opacity-0',
                              )}
                            />
                            <item.icon className={cn('size-4 shrink-0', isActive ? 'text-primary' : '')} />
                            {!collapsed ? (
                              <>
                                <span className="truncate">{item.label}</span>
                                {count !== undefined && count > 0 ? (
                                  <span className="num ml-auto text-2xs text-subtle">{count}</span>
                                ) : null}
                              </>
                            ) : null}
                          </>
                        )}
                      </NavLink>
                    </Tooltip>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}

        {!collapsed && applications.length > 0 ? (
          <div>
            <p className="mb-1.5 px-2 text-2xs font-semibold uppercase tracking-wider text-subtle">Your applications</p>
            <ul className="space-y-0.5">
              {applications.map((app) => (
                <li key={app.id}>
                  <NavLink
                    to={`/applications/${app.id}`}
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-2.5 rounded-md px-2 py-1.5 text-sm transition-colors',
                        isActive ? 'bg-foreground/[0.07] text-foreground' : 'text-muted hover:text-foreground',
                      )
                    }
                  >
                    <span className="size-2 shrink-0 rounded-[3px]" style={{ backgroundColor: app.color }} />
                    <span className="truncate">{app.shortName}</span>
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </nav>

      <button
        type="button"
        onClick={() => setCollapsed((value) => !value)}
        className="flex h-11 shrink-0 items-center gap-2.5 border-t border-border px-4 text-xs text-subtle transition-colors hover:text-foreground"
      >
        {collapsed ? <PanelLeftOpen className="size-4" /> : <PanelLeftClose className="size-4" />}
        {!collapsed ? 'Collapse' : null}
      </button>
    </aside>
  );
};
