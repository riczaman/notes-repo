import * as React from 'react';
import { Link, Outlet, useLocation, useMatch } from 'react-router-dom';
import { ChevronRight, Moon, Search, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton, TooltipProvider } from '@/components/ui/misc';
import { useTheme } from '@/hooks/useTheme';
import { useEntityList } from '@/hooks/useEntities';
import { cn } from '@/lib/utils';
import { GlobalSearch } from './GlobalSearch';
import { Sidebar } from './Sidebar';
import { ROUTE_LABELS } from './navigation';

const Breadcrumbs = () => {
  const location = useLocation();
  const appMatch = useMatch('/applications/:id/*');
  const { data: applications = [] } = useEntityList('applications');

  const segments = location.pathname.split('/').filter(Boolean);
  if (segments.length === 0) return <span className="text-sm font-medium text-foreground">Dashboard</span>;

  const crumbs: { label: string; to?: string }[] = [{ label: 'Portfolio', to: '/' }];
  let path = '';

  segments.forEach((segment, index) => {
    path += `/${segment}`;
    const isLast = index === segments.length - 1;
    const appName = appMatch?.params.id === segment ? applications.find((a) => a.id === segment)?.name : undefined;
    crumbs.push({
      label: appName ?? ROUTE_LABELS[segment] ?? segment,
      to: isLast ? undefined : path,
    });
  });

  return (
    <nav className="flex min-w-0 items-center gap-1 text-sm">
      {crumbs.map((crumb, index) => (
        <React.Fragment key={`${crumb.label}-${index}`}>
          {index > 0 ? <ChevronRight className="size-3.5 shrink-0 text-subtle" /> : null}
          {crumb.to ? (
            <Link to={crumb.to} className="shrink-0 text-muted transition-colors hover:text-foreground">
              {crumb.label}
            </Link>
          ) : (
            <span className="truncate font-medium text-foreground">{crumb.label}</span>
          )}
        </React.Fragment>
      ))}
    </nav>
  );
};

/** Shown while a lazily loaded route chunk is fetched. Shaped like a page so the layout does not jump. */
const RouteFallback = () => (
  <div className="space-y-4">
    <Skeleton className="h-8 w-64" />
    <Skeleton className="h-4 w-96" />
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {Array.from({ length: 4 }).map((_, index) => (
        <Skeleton key={index} className="h-24" />
      ))}
    </div>
    <Skeleton className="h-72" />
  </div>
);

export const AppShell = () => {
  const { theme, toggle } = useTheme();
  const [searchOpen, setSearchOpen] = React.useState(false);

  // Cmd/Ctrl+K opens search from anywhere.
  React.useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <TooltipProvider>
      <div className="flex min-h-screen bg-background">
        <Sidebar />

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 flex h-14 shrink-0 items-center gap-3 border-b border-border bg-background/85 px-5 backdrop-blur">
            <Breadcrumbs />

            <div className="ml-auto flex shrink-0 items-center gap-2">
              <button
                type="button"
                onClick={() => setSearchOpen(true)}
                className={cn(
                  'flex h-8 items-center gap-2 rounded-md border border-border bg-surface px-2.5 text-xs text-subtle transition-colors hover:border-primary/40 hover:text-foreground',
                )}
              >
                <Search className="size-3.5" />
                <span className="hidden sm:inline">Search</span>
                <kbd className="hidden rounded border border-border bg-elevated px-1 py-0.5 font-mono text-[10px] sm:inline">
                  ⌘K
                </kbd>
              </button>

              <Button variant="ghost" size="icon" onClick={toggle} aria-label="Toggle theme">
                {theme === 'dark' ? <Sun /> : <Moon />}
              </Button>
            </div>
          </header>

          <main className="flex-1 px-5 py-6 lg:px-8">
            <div className="mx-auto w-full max-w-[1500px]">
              <React.Suspense fallback={<RouteFallback />}>
                <Outlet />
              </React.Suspense>
            </div>
          </main>
        </div>
      </div>

      <GlobalSearch open={searchOpen} onOpenChange={setSearchOpen} />
    </TooltipProvider>
  );
};
