# Intake playbook

How a piece of raw information becomes records in this system.

Use it yourself, or paste it to an assistant along with the raw text and ask for the JSON. The rules are deliberately mechanical so the same input always lands in the same place.

---

## Step 0: everything lands in Meeting Notes first

Paste the raw text into a note (`backend/data/notes.json`) before anything else, with `processed: false`. Never paraphrase into a task and throw the original away: six weeks later the exact wording is what settles the argument.

Set `processed: true` only once the note has been triaged into records.

---

## Step 1: route each item

Work through the note one statement at a time.

| The statement is… | It becomes | File |
| --- | --- | --- |
| A multi-month outcome with its own goal and business case | **Epic** | `epics.json` |
| A slice of an epic a user would notice | **Feature** | `features.json` |
| A single piece of work someone finishes in days | **Task** | `tasks.json` |
| Something that *might* happen and would hurt | **Risk** | `risks.json` |
| Something that *has* happened and is wrong | **Bug** | `bugs.json` |
| A shortcut taken, or a fix deferred | **Technical debt** | `technicalDebt.json` |
| "We are waiting on X" where X is another team or system | **Dependency** | `dependencies.json` |
| A reference in another system (Jira, ADO, ServiceNow, CRA, access, change) | **Ticket** | `tickets.json` |
| A date someone will be held to | **Milestone** | `milestones.json` |
| A bundle of scope shipping together | **Release** | `releases.json` |
| A person who decides, owns or is affected | **Stakeholder** | `stakeholders.json` |

### The distinctions people get wrong

**Risk vs issue.** A risk has not happened yet. "EMS scope may exceed capacity" is a risk. "EMS scope has exceeded capacity and MLP2a slipped" is no longer a risk; it is a fact that changes dates and probably creates tasks. Close the risk with `status: "closed"` and record what actually happened.

**Risk vs dependency.** "We depend on the Ariba API" is a dependency. "The Ariba API rate limits may not support our design" is a risk. You often need both, with the risk referencing the dependency in its description.

**Technical debt vs bug.** A bug is broken. Debt works but costs you later. "Rate limiting is missing" is debt. "Rate limiting rejects valid requests" is a bug.

**Epic vs feature vs task.** If it has its own business case and open questions, it is an epic. If a user would describe it as a thing the product now does, it is a feature. If it is work rather than outcome, it is a task.

**A decision is not a task.** "Decide whether PETL is a supported platform" is a task only if *you* are doing the deciding. If someone else decides, it is a risk with `decisionNeeded` set and a `dueDate`, plus a ticket if there is a formal approval to raise.

---

## Step 2: check whether it already exists

Search first (`⌘K`). Most new information updates an existing record rather than creating one.

- Same work, new detail → update the existing record. Append to `notes`, do not overwrite the description.
- Same work, changed status → update `status` and any date. The `updatedAt` field is maintained for you.
- Same problem, different application → a separate record. Records belong to one application.
- Genuinely new → create it.

---

## Step 3: attach it to the hierarchy

Every record must answer: **which application?**

If the answer is "more than one", it belongs to the portfolio: set `applicationId: null` (risks and milestones allow this). The four cross-cutting risks in the seed data are exactly this case.

Then link upward where it applies:

```
Application → Epic → Feature → Task
                       ↘ Release → Milestone
```

A task with no `epicId` is fine for operational work. A task with no `applicationId` is not allowed, and the schema rejects it.

---

## Step 4: write the record

**IDs.** Readable slugs for anything you write by hand: `task-usff-026`, `risk-petl-funding`. Keep the prefix consistent with the collection. Records created through the UI get UUIDs; both are just strings.

**Cross-references.** Point at IDs, never at titles: `epicId: "epic-usff-ems"`, `riskId: "risk-usff-ems-scope"`. Nothing in the app resolves a reference by name.

**Dates.** `YYYY-MM-DD`. Use `null` for unknown, never `"TBD"` — the field is typed as a date.

**Unknowns.** Leave the string empty or write `TBC`. Do not invent an owner, a date or an estimate. An empty field is information; a fabricated one is a lie the system will repeat back to you in a status report.

**Estimates.** Free text (`"3d"`, `"2 sprints"`, `"TBC"`) because that is how they actually arrive. `storyPoints` is the numeric field if you want arithmetic.

---

## Step 5: close the loop

Set `processed: true` on the note and list the IDs you created in its `linkedEntityIds`. That is what makes the note auditable later: you can see what came out of that meeting.

---

## Worked example

> "Call with the EMS team. They still owe us the procurement policy doc, so we can't finalise the skip logic. Also they want the agenda export in Excel, not a system integration. Raised JIRA-4471 to track the policy ask. If the doc doesn't land by end of August, MLP2a slips."

Four records, plus the note itself:

1. **Note** — the whole quote in `rawNotes`, `source: "call"`, `applicationIds: ["app-usff"]`.
2. **Task** — "Obtain the procurement policy document from the EMS team", `status: "blocked"`, `applicationId: "app-usff"`, `epicId: "epic-usff-ems"`.
3. **Ticket** — `externalId: "JIRA-4471"`, `system: "jira"`, `type: "request"`, `linkedTaskId` pointing at the task above.
4. **Risk** — "Procurement policy document may not arrive before the MLP2a cut-off", `likelihood: "high"`, `impact: "high"`, `dueDate: "2026-08-31"`.
5. **Feature** — update the existing agenda builder feature: add "Export is the hand-off; no downstream system integration" to `technicalDesign`.

Note what did *not* happen: the Excel preference did not become a new task. It is a constraint on existing work, so it went into that work's design field.

---

## Anti-patterns

- **A task per sentence.** Meeting notes are not a backlog. Most sentences are context.
- **A risk with no owner and no date.** That is a worry, not a managed risk. Give it both or close it.
- **Debt with no suggested fix.** That is a complaint. The `suggestedFix` field is what makes it actionable.
- **Duplicating an epic per application.** Cross-cutting work needs one record and a decision about who owns it, not four copies that drift.
- **Editing seed data to hide bad news.** The health field has an `off_track` value for a reason.
