# Data model

Thirteen collections, one JSON file each, under `backend/data/`.

Every record carries `id`, `createdAt`, `updatedAt`. Every other field has a Zod default, so a stored record always has every key present and a create only needs the required ones (marked **required** below).

Source of truth: `shared/src/schemas/`. This document explains intent; the schemas are what actually runs.

---

## Relationships

```
Application ──┬─→ Epic ──→ Feature ──→ Task
              ├─→ Release ──→ Milestone
              ├─→ Risk ──────────┐
              ├─→ Bug            │ tasks and tickets can point at a risk
              ├─→ TechnicalDebt  │
              ├─→ Dependency ──→ Application | external system
              └─→ Ticket ────────┘

Stakeholder  ─── many-to-many ──→ Application
Note         ─── many-to-many ──→ Application
```

Rules that matter:

- Everything except risks and milestones requires an `applicationId`. Those two allow `null`, meaning portfolio-level.
- Deleting an application cascades to everything that belongs to it. Stakeholders and notes are only removed if that application was their sole link.
- Cross-references are IDs. Nothing resolves by title.

---

## Controlled vocabularies

Defined once in `shared/src/enums.ts` and rendered by one badge component, which is why a status looks the same everywhere.

| Vocabulary | Values |
| --- | --- |
| Work status | `backlog` `discovery` `ready` `in_progress` `blocked` `testing` `done` |
| Priority | `critical` `high` `medium` `low` |
| Horizon | `now` `next` `later` |
| Lifecycle | `discovery` `build` `live` `sustain` `sunset` |
| Health | `on_track` `at_risk` `off_track` `not_started` `complete` |
| Risk scale | `low` `medium` `high` `critical` (weights 1-4) |
| Risk status | `open` `mitigating` `monitoring` `accepted` `closed` |
| Bug severity | `sev1` `sev2` `sev3` `sev4` |
| Dependency status | `not_started` `in_discussion` `agreed` `in_progress` `blocked` `delivered` |
| Ticket system | `jira` `azure_devops` `servicenow` `cra` `access_request` `change_request` `procurement` `other` |
| Ticket status | `draft` `submitted` `in_review` `approved` `in_progress` `blocked` `done` `rejected` `cancelled` |
| Note source | `meeting` `email` `teams` `onenote` `brain_dump` `workshop` `call` |

The work-status list doubles as the Kanban columns, in that order.

---

## applications.json

The top of the tree.

| Field | Type | Notes |
| --- | --- | --- |
| `key` | string | **required.** Short code, e.g. `USFF` |
| `name` | string | **required** |
| `shortName` | string | **required.** Used in chips and the graph |
| `tagline` | string | One line for cards |
| `description` | string | |
| `lifecycle` | enum | |
| `health` | enum | Drives the colour on the dashboard |
| `color` | string | Hex. The application's accent everywhere |
| `businessOwner` / `technicalOwner` / `deliveryLead` | string | |
| `vendor` / `platform` | string | |
| `vision` | string | Where this is going |
| `currentState` | string | What is true today |
| `futureState` | string | What changes |
| `architectureNotes` | string | |
| `executiveSummary` | string | The paragraph you would read out first |
| `leadershipAttention` | string[] | Decisions someone else has to make |
| `stakeholderIds` | string[] | |
| `startDate` / `targetGoLive` | date, nullable | |
| `sortOrder` | number | Display order |

---

## epics.json

The roadmap unit.

| Field | Type | Notes |
| --- | --- | --- |
| `applicationId` | ref | **required** |
| `title` | string | **required** |
| `goal` | string | What "done" means |
| `problemStatement` | string | Why it exists |
| `businessValue` | string | What changes for the business |
| `status` / `priority` / `horizon` | enum | |
| `owner` | string | |
| `progress` | 0-100 | Manual. Task counts are computed separately |
| `openQuestions` | string[] | Shown as a warning on the roadmap card |
| `dependencyIds` / `riskIds` | ref[] | |
| `quarter` | string | Free text, e.g. `Q4 2026` |
| `startDate` / `targetDate` | date, nullable | |

---

## features.json

| Field | Type | Notes |
| --- | --- | --- |
| `applicationId` | ref | **required** |
| `epicId` | ref, nullable | |
| `title` | string | **required** |
| `problem` / `solution` | string | |
| `acceptanceCriteria` | string[] | |
| `technicalDesign` | string | |
| `estimate` | string | Free text |
| `status` / `priority` / `horizon` | enum | |
| `targetReleaseId` | ref, nullable | |

---

## tasks.json

| Field | Type | Notes |
| --- | --- | --- |
| `title` | string | **required** |
| `applicationId` | ref | **required** |
| `epicId` / `featureId` | ref, nullable | |
| `description` / `notes` | string | |
| `status` / `priority` / `horizon` | enum | |
| `owner` | string | |
| `estimate` | string | Free text (`3d`, `TBC`) |
| `storyPoints` | number, nullable | The numeric one |
| `businessValue` / `technicalValue` | 0-5 | For ranking |
| `acceptanceCriteria` | string[] | |
| `dependencyIds` | ref[] | |
| `riskId` | ref, nullable | |
| `targetReleaseId` | ref, nullable | |
| `dueDate` | date, nullable | Overdue renders red |
| `quarter` | string | |
| `boardOrder` | number | Position in its Kanban column. Rewritten densely on every drop |

---

## releases.json / milestones.json

**Release**: `applicationId` **required**, `name` **required**, `version`, `status`, `targetDate`, `releasedDate`, `quarter`, `scopeSummary`, `notes`.

**Milestone**: `name` **required**, `date` **required**, `applicationId` (nullable — `null` means portfolio-level), `type` (`go_live` `gate` `decision` `governance` `delivery` `external`), `status` (`planned` `at_risk` `hit` `missed` `cancelled`), `owner`, `releaseId`.

Use a milestone of type `decision` for anything the plan is waiting on someone else to decide. Several in the seed data are exactly that.

---

## risks.json

| Field | Type | Notes |
| --- | --- | --- |
| `title` | string | **required** |
| `applicationId` | ref, nullable | `null` = portfolio-level |
| `description` | string | |
| `likelihood` / `impact` | risk scale | Score is `likelihood × impact`, 1-16 |
| `category` | enum | scope, architecture, delivery, security, vendor, governance, resourcing, data, compliance |
| `status` | enum | |
| `mitigation` | string | |
| `decisionNeeded` | string | The decision that would close it |
| `owner` | string | |
| `dueDate` | date, nullable | Review-by date |
| `escalated` | boolean | Raised to leadership |

Score bands: 1-2 low, 3-5 moderate, 6-8 elevated, 9-11 high, 12-16 critical. Anything 9 or above counts as critical in the dashboard rollups.

---

## bugs.json / technicalDebt.json

**Bug**: `applicationId` and `title` **required**, plus `severity`, `status`, `reproductionSteps` (string[]), `expectedResult`, `actualResult`, `owner`, `reportedBy`, `environment`, `foundInRelease`, `ticketId`.

**Technical debt**: `applicationId` and `title` **required**, plus `issue` (what is wrong), `impact` (what it costs), `category`, `priority`, `status`, `estimatedEffort`, `suggestedFix`, `owner`, `targetReleaseId`, `identifiedDate`.

A debt record without `suggestedFix` is a complaint. Fill it in.

---

## dependencies.json

A directed edge. The source is always one of our applications; the target is either another application or a system we do not own.

| Field | Type | Notes |
| --- | --- | --- |
| `fromApplicationId` | ref | **required** |
| `label` | string | **required.** The edge label |
| `toApplicationId` | ref, nullable | Set this **or** `toExternalName` |
| `toExternalName` | string | Free text. Becomes a graph node automatically |
| `type` | enum | internal, external_team, azure_resource, api, infrastructure, security, networking, vendor, data |
| `status` | enum | Drives the edge colour |
| `criticality` | risk scale | Drives the edge thickness |
| `owner` / `team` | string | |
| `neededBy` | date, nullable | |

External nodes are derived from distinct `toExternalName` values, so there is no second list of systems to maintain.

---

## tickets.json

The request tracker: one row per reference in someone else's system.

| Field | Type | Notes |
| --- | --- | --- |
| `applicationId` | ref | **required** |
| `externalId` | string | **required.** `JIRA-1234`, `FINDING-8241` |
| `title` | string | **required** |
| `system` | enum | |
| `type` | enum | story, bug, task, incident, request, approval, governance, change |
| `status` / `priority` | enum | |
| `requester` / `assignee` | string | |
| `url` | string | Link to the real ticket |
| `openedDate` / `dueDate` / `closedDate` | date, nullable | |
| `linkedTaskId` / `linkedEpicId` / `linkedRiskId` | ref, nullable | Ties the external reference to the work |

The seeded rows use `REPLACE-ME-n` placeholders. Replace them with real numbers; they exist to show the shape, not to pretend the references are known.

---

## notes.json

| Field | Type | Notes |
| --- | --- | --- |
| `title` | string | **required** |
| `date` | string | **required** |
| `source` | enum | |
| `applicationIds` | ref[] | Many-to-many |
| `attendees` | string[] | |
| `rawNotes` | string | Verbatim. Never edit this down |
| `summary` | string | |
| `decisions` / `openQuestions` | string[] | |
| `actionItems` | object[] | `{ text, owner, dueDate, status }` |
| `processed` | boolean | Triaged into records yet |
| `linkedEntityIds` | string[] | What came out of it |

---

## stakeholders.json

`name` **required**, plus `role`, `org`, `email`, `type` (executive, business, technical, vendor, governance, delivery), `influence` (low/medium/high), `applicationIds` (many-to-many), `notes`.
