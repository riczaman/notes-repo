# Architecture

Why this is built the way it is, and what to change when the requirements change.

---

## 1. The registry is the spine

`shared/src/registry.ts` holds one descriptor per collection: schema, JSON file, URL path, title field, searchable fields, how it links to an application.

The backend generates routes from it:

```ts
for (const descriptor of ENTITY_DESCRIPTORS) {
  const controller = new CrudController(descriptor.name);
  router.get(`/${descriptor.path}`, asyncHandler(controller.list));
  router.post(`/${descriptor.path}`, asyncHandler(controller.create));
  // …
}
```

Thirteen collections times five verbs is sixty-five endpoints. Hand-written, that is sixty-five near-identical route handlers, and the sixty-sixth would drift from the rest. Generated, adding a collection is a registry entry plus a JSON file.

The frontend reads the same object for its typed API client, global search and reference pickers.

**When to break the pattern:** when a collection needs behaviour the generic path cannot express. Applications already do, and they show the intended escape hatch: `ApplicationService` extends `CrudService` and overrides one hook. The generic path stays generic; the special case is one small class.

---

## 2. Layers, and what each one is allowed to know

```
routes        →  URL shape. Knows nothing else.
controllers   →  HTTP in, HTTP out. No business rules, no file access.
services      →  Validation, filtering, cascade rules, derived views.
repositories  →  Persistence. The only layer that knows data is in JSON files.
```

The dependency arrow only points downward. A controller never touches `JsonFileStore`; a service never touches `req` or `res`.

The payoff is concrete: `InsightsService` computes the dashboard from thirteen repository reads without knowing whether those reads hit a file, SQLite or a network. And a service can be called from a script (the seeder does exactly this) with no HTTP involved.

---

## 3. Storage is swappable on purpose

`repositories/Repository.ts` defines the contract. `JsonRepository` implements it. `repositories/index.ts` is the only file that names an implementation.

To move to SQLite:

1. Write `SqliteRepository<T>` implementing `Repository<T>`.
2. Change the map in `repositories/index.ts`.

Nothing else changes: no service, no controller, no route, no React component. That is the entire reason the interface exists, and it is why the JSON-file decision is not a trap.

### Two properties the JSON driver must have

**Serialised writes.** Node is single threaded, but `await` interleaves. Two concurrent PATCHes could each read the file, apply their own change and write, and the second would silently discard the first. `JsonFileStore.mutate` chains every write to a file through a promise queue, so a read-modify-write is atomic with respect to other writes.

**Atomic file replacement.** Writes go to a temp file and are then renamed. A crash mid-write can leave a stray `.tmp`, never a half-written `tasks.json` that fails to parse on next boot.

**Deliberately absent: caching.** Files are re-read on every request. That is a real cost at scale and the right call here, because hand-editing the JSON while the server runs is a stated requirement. If the dataset ever outgrows it, `InsightsService` is the one class worth memoising.

---

## 4. One schema, validated on both sides

The Zod schemas in `shared/src/schemas/` are imported by the API and by the browser.

- Server: `CrudService.create` parses the body against `createSchema`; `update` against `updateSchema` (the same schema, `.partial()`).
- Client: `EntityFormDialog` parses the form payload against the same schema before sending, and maps failures back onto the form fields.

There is no second copy of the rules to drift. Two details fall out of this for free:

- **Required fields are derived, not declared.** Parsing `{}` against the create schema returns errors only for fields with no Zod default, so the form marks exactly those with an asterisk. There is no `required: true` list to maintain.
- **Defaults are applied once.** The seeder feeds partial rows through the entity schema, so seed data can never drift out of shape with the schema.

`.default()` on nearly every field is what makes this work: a create needs only the genuinely required fields, and a stored record always has every key present.

---

## 5. Config-driven UI

Thirteen collections would normally mean thirteen list pages, thirteen forms and thirteen sets of table columns. Here they are three data files:

| File | Defines |
| --- | --- |
| `features/fields.ts` | The form for each collection |
| `features/columns.tsx` | The table for each collection |
| `features/filters.ts` | Which dimensions each collection filters on |

`EntityListPage` and `EntityFormDialog` render from those. Every route in `pages/entityPages.tsx` is three lines.

**The trade:** a config-driven form is less flexible than a hand-written one. It is the right trade when the forms are genuinely similar, and the wrong one when they are not. `NotesPage` is the counter-example, written by hand because a meeting note is read rather than scanned, and a table was the wrong shape for it. Do the same for any collection that stops fitting.

---

## 6. Server state, not client state

There is no Redux, Zustand or context store for data. TanStack Query holds server state; the only local state is UI state (which dialog is open, which card is being dragged).

Mutations invalidate by collection prefix, so writing a task refreshes every task list regardless of the filters that produced it, plus the derived views (dashboard, overview, graph, search) which are recomputed from many collections.

**Filter state lives in the URL** (`useFilters`). Any filtered view is shareable, survives a refresh, and back/forward behave as expected. It also keeps `FilterBar` stateless and reusable.

**Optimistic updates are used in exactly one place:** the Kanban board. A card must not snap back to its old column while a request is in flight. `useBulkUpdate` writes to the cache first and restores a snapshot if the server rejects the move. Everywhere else, waiting is fine and optimistic updates would only add a rollback path to get wrong.

---

## 7. Derived data is never stored

Progress percentages, risk scores, rollups and counts are computed on read in `InsightsService`.

Storing them would be faster and would eventually be wrong: something updates a task without updating its epic's progress, and the number on screen quietly stops meaning anything. With a dataset this size, recomputation is cheaper than the invalidation logic needed to keep a stored copy honest.

Risk score is `likelihood × impact` over a 1-4 scale, giving 1-16. The bands (`riskBand`) are a display concern and live on the client; the weights live in `shared/src/enums.ts` so both sides agree on the arithmetic.

---

## 8. Design system

Every colour is a CSS custom property in `frontend/src/styles/index.css`, exposed to Tailwind as a semantic name (`bg-card`, `text-muted`, `border-border`). Nothing references a raw hex value except:

- Application accent colours, which are per-record data.
- Chart series colours, because Recharts writes colours into SVG presentation attributes.

Light and dark are the same scale inverted, so a component written once works in both. Dark is the default.

Status, priority, severity and health render through a single `StatusBadge` backed by one tone map (`lib/display.ts`). That is why a status looks identical on a card, in a table and on a board.

---

## 9. What was deliberately left out

| Not built | Why | Where it would go |
| --- | --- | --- |
| Authentication | Single local user | Express middleware + a `users` collection; the registry pattern already fits |
| Tests | Time, and the app is verified end to end manually | Vitest for services and the query pipeline first: they hold the real logic |
| Docker | Runs on Node directly | Two-stage build, API serving `frontend/dist` |
| Jira / ADO sync | Needs credentials this build does not handle | A sync service writing to the `tickets` repository |
| AI summarisation | Governance approvals not in place | A service reading `notes`, writing structured fields back |

None of these are stubbed with dead code. Unused abstraction is a cost paid now for a benefit that may never arrive.
