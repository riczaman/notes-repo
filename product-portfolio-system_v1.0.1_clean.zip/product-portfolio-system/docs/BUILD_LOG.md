# Build log

This system is also the thing you are learning on. The order below is chosen so each step teaches something the next step needs, and so the app is usable at every point.

Work one phase at a time. Branch per phase, review your own diff before merging.

---

## Shipped — v1.0 (August 2026)

- Shared contract layer: Zod schemas, enums, entity registry
- Express API: layered, 13 collections, generated CRUD, validation, error handling
- JSON persistence with serialised atomic writes behind a `Repository` interface
- Derived views: dashboard rollups, application overview, global search, dependency graph
- React client: dashboard, applications index and detail, roadmap, Kanban, timeline, dependency graph, 13 list pages, notes reader, search, settings
- Config-driven CRUD: one form dialog and one list page for every collection
- Dark and light themes, URL-driven filters, global search with ⌘K
- Seed data from the August 2026 portfolio briefings

---

## Phase 1 — Tests

**Why first:** every phase after this changes behaviour. Without tests you are relying on clicking through the UI, which stops scaling around now.

- Vitest in `backend`. Start with `utils/query.ts` (the filter/sort/paginate pipeline) and `services/InsightsService.ts` (the rollup arithmetic). Those hold the real logic.
- One integration test per collection using Supertest against a temp `DATA_DIR`: create, read, update, delete, and a validation failure.
- One test that concurrent PATCHes to the same file do not lose a write. That is the property `JsonFileStore` exists to guarantee, and it should be pinned down.
- React Testing Library for `EntityFormDialog`: required-field detection, list and tag coercion, server error mapping.

**Skill:** knowing what deserves a test. Coverage percentage is not the goal; the query pipeline and the rollups are.

---

## Phase 2 — SQLite

**Why:** it proves the repository abstraction was real rather than decorative, and it is the single best way to learn what an ORM is doing for you.

- `better-sqlite3`. Write `SqliteRepository<T>` implementing `Repository<T>`.
- Migration script: read the JSON files, insert rows, verify counts match.
- Switch via `STORAGE=sqlite|json` in `config/env.ts`, defaulting to JSON.
- Run the Phase 1 integration tests against both implementations. Same tests, both drivers passing, is the proof.

**Watch for:** the JSON store returns whole objects; SQL returns rows. Array fields (`tags`, `acceptanceCriteria`) need either a JSON column or a join table. Pick one deliberately and write down why.

---

## Phase 3 — Task detail pages

The current edit dialog is right for quick changes and wrong for a task with acceptance criteria, dependencies, linked tickets and history.

- Route `/tasks/:id` with a real page: description, criteria, linked epic and feature, linked tickets, related risks.
- Comment thread (a new `comments` collection — one registry entry, and note how little else changes).
- An activity feed. This needs an audit trail, which is the interesting part: a `changes` collection written by a repository decorator, so no service has to remember to log.

**Skill:** the decorator pattern, and recognising when a cross-cutting concern belongs in a wrapper rather than in every call site.

---

## Phase 4 — Saved views

- Save a filter combination with a name; pin it to the sidebar.
- "My work": everything assigned to one owner across all collections.
- Per-user defaults for the board and roadmap grouping.

Small, high value, and it forces a decision about where user preference lives once there is more than the theme toggle.

---

## Phase 5 — Authentication

- Session-based auth, a `users` collection, `req.user` in middleware.
- Roles: viewer, editor, admin. Enforce at the service layer, not the controller — that is where the rule belongs and where tests can reach it.
- Then Azure AD via OIDC, which is what the real environment would use.

**Skill:** authorisation belongs in the domain layer. Once that lands, the UI hiding a button is a convenience, not a control.

---

## Phase 6 — Integrations

Read-only first, in this order:

1. **Azure DevOps** — pull work item status into `tickets`. One direction, one scheduled sync, conflicts resolved by "external system wins".
2. **Jira** — same shape, different client. Extract the shared sync logic only after the second one exists, not before.
3. **Microsoft Graph** — pull meetings into `notes` as empty shells ready to fill.

**Skill:** anti-corruption layers. Their models are not your models; map at the boundary and keep the mapping in one file per integration.

---

## Phase 7 — AI assistance

Only after Phase 6, because the value depends on real data flowing in.

- Paste a note, get proposed records back, with a diff view and explicit accept or reject on each one. Never write automatically.
- Weekly portfolio summary generated from the dashboard snapshot.
- Duplicate detection on create.

**Non-negotiable:** the model proposes, a person accepts. An assistant that silently writes to the risk register is worse than no assistant.

---

## Phase 8 — Deployment

- Dockerfile: build the client, serve `frontend/dist` from Express, one container.
- Compose file adding Postgres when SQLite stops being enough.
- CI running typecheck, lint and tests on push.

---

## Standing rules

**Delete before you add.** If a feature replaces an older one, remove the old one. Backwards-compatible dead paths are how a codebase gets heavy.

**No abstraction before the third case.** Two similar things are a coincidence. The registry exists because there were thirteen.

**Every phase must leave the app runnable.** If a branch cannot demo, it is too big.

**Write down why, not what.** The comments in this codebase explain trade-offs. Diffs already show what changed.
