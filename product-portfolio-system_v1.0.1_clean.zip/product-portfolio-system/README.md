# Product Portfolio Management System

A local full-stack application for running a product portfolio: applications, roadmap, board, epics, features, tasks, releases, milestones, risks, technical debt, bugs, dependencies, external request tracking and meeting notes.

Seeded with the August 2026 portfolio: **USFF Next Gen**, **PETL**, **iManage** and **RFx / Globality**.

```
React + TypeScript + Vite + Tailwind + shadcn-style components
Express + TypeScript, layered architecture
JSON files as the database, swappable for SQLite or Postgres
```

---

## Running it

Node 18.18 or newer. From the project root:

```bash
npm install
```

```bash
npm run dev
```

That starts both processes:

| Process | URL | What it is |
| --- | --- | --- |
| API | http://127.0.0.1:4000/api | Express, reads and writes `backend/data/*.json` |
| Web | http://localhost:5173 | Vite dev server, proxies `/api` to the API |

Open **http://localhost:5173**.

Prefer two terminals? Run `npm run dev:api` in one and `npm run dev:web` in the other.

### Windows

Works the same. Two things to know:

- **Never copy `node_modules` between machines.** `esbuild` and `rollup` ship a compiled binary per platform, and `node_modules/.bin` uses symlinks on macOS and Linux. A copied folder produces `EEXIST`, "refusing to delete … is not a link", and an `esbuild` install failure. Copy the source and run `npm install` on the machine that will run it.
- **Behind a TLS-inspecting proxy**, `npm install` fails while downloading esbuild's binary. Check `npm config get cafile` and the `NODE_EXTRA_CA_CERTS` environment variable point at a certificate file that actually exists on that machine, or set your internal registry with `npm config set registry <url>`.

The root has no runtime dependencies of its own, so `npm install` only has to resolve the API and web client.

### Other commands

| Command | What it does |
| --- | --- |
| `npm run seed` | Fills empty collections from the August 2026 baseline. Leaves existing data alone. |
| `npm run seed:force` | Replaces every collection with the baseline. **Destructive.** |
| `npm run backup` | Copies every JSON file into `backend/data/.backups/<timestamp>/`. |
| `npm run typecheck` | Typechecks the API and the web client. |
| `npm run build` | Production build of the web client into `frontend/dist`. |

The data files are already seeded. `npm run seed` is only needed if you delete one.

---

## Project structure

```
product-portfolio-system/
├── shared/                     Types, Zod schemas and the entity registry (used by BOTH sides)
│   └── src/
│       ├── enums.ts            Every controlled vocabulary, once
│       ├── base.ts             Audit fields and the create/update/entity helper
│       ├── registry.ts         The spine: one descriptor per collection
│       ├── api.ts              Response envelopes and derived-view types
│       └── schemas/            portfolio · delivery · quality · integration
│
├── backend/
│   ├── data/                   The database. 13 JSON files. Hand-editable.
│   └── src/
│       ├── server.ts           Entry point
│       ├── app.ts              Express composition
│       ├── config/             Environment and paths
│       ├── core/               Error types, HTTP helpers
│       ├── data/               JsonFileStore: atomic, serialised writes
│       ├── repositories/       Repository interface + JSON implementation
│       ├── services/           CrudService, ApplicationService, InsightsService
│       ├── controllers/        HTTP adapters only
│       ├── routes/             Generated from the registry
│       ├── middleware/         Validation errors, logging, 404
│       ├── utils/              ids, dates, the generic list query pipeline
│       └── seed/               The August 2026 baseline
│
├── frontend/
│   └── src/
│       ├── components/
│       │   ├── ui/             Button, Card, Dialog, Select, Tabs, Badge…
│       │   ├── layout/         AppShell, Sidebar, Breadcrumbs, Global search
│       │   ├── common/         DataTable, FilterBar, StatCard, PageHeader
│       │   └── charts/         Donut, bars, risk matrix
│       ├── features/           The config-driven CRUD layer
│       │   ├── fields.ts       Form definition per collection
│       │   ├── columns.tsx     Table definition per collection
│       │   ├── filters.ts      Filter definition per collection
│       │   ├── EntityFormDialog.tsx   One dialog, all 13 collections
│       │   ├── EntityListPage.tsx     One list page, all 13 collections
│       │   └── views/          Roadmap, Kanban, Timeline, Dependency graph
│       ├── hooks/              Generic data hooks, filters, theme, debounce
│       ├── lib/                API client, query keys, display tokens, utils
│       └── pages/              Route components
│
├── docs/
│   ├── ARCHITECTURE.md         Why it is built this way
│   ├── DATA_MODEL.md           Every field of every entity
│   ├── INTAKE_PLAYBOOK.md      How to turn a brain dump into records
│   └── BUILD_LOG.md            The app's own roadmap, for building it over months
│
└── scripts/backup-data.mjs
```

---

## The idea behind it

**One registry, thirteen collections.** `shared/src/registry.ts` describes each collection once: its schema, its file, its searchable fields, how it links to an application. The API generates all 65 CRUD endpoints from it. The web client generates its typed API methods, global search and entity pickers from the same object. Adding a collection is one registry entry, one schema and one JSON file.

**The frontend never sees storage.** Everything above `repositories/` is written against a `Repository<T>` interface. Moving to SQLite or Postgres is one new class and one changed line in `repositories/index.ts`.

**Validation is defined once.** The same Zod schemas validate the request body on the server and the form on the client. The client cannot submit something the server would reject for a different reason than the one it displays.

**Filters live in the URL.** Every filtered view is a link you can send to someone.

**Nothing is derived and stored.** Progress percentages, risk scores and rollups are computed on read, so they cannot drift from the records they summarise.

---

## Working with the data

The JSON files are the database and they are meant to be edited by hand. Files are read on every request, so save a file and refresh the browser.

- Seeded records use readable IDs (`app-usff`, `task-usff-014`) so cross-references are legible in a diff.
- Records created through the UI get UUIDs. Both are just opaque strings.
- A malformed JSON file produces a clear error naming the file rather than a silent empty list.
- Deleting an application cascades to everything that belongs to it.

Run `npm run backup` before anything destructive.

---

## Feeding it new information

Paste meeting notes, emails, Azure DevOps items, Jira stories, bug reports or a brain dump into **Meeting Notes**, then triage. `docs/INTAKE_PLAYBOOK.md` sets out the routing rules: what becomes an epic, what becomes a task, what becomes a risk, what becomes technical debt, and which file each one lands in.

---

## What is not built yet

Deliberately out of scope for this first version, and sketched in `docs/BUILD_LOG.md`:

- Authentication (the app assumes a single local user)
- Automated tests
- Docker
- Jira / Azure DevOps / Microsoft Graph integrations
- AI summarisation of meeting notes
- Notifications and email reminders

The architecture leaves room for each; none of them are stubbed out with dead code.
