#!/usr/bin/env node
/**
 * Snapshots backend/data into a timestamped folder under backend/data/.backups.
 *
 * Run it before `npm run seed:force`, before hand-editing a file you care about,
 * or on any schedule you like. Zero dependencies so it works on a locked-down
 * machine with no registry access.
 *
 *   node scripts/backup-data.mjs
 */
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(here, '../backend/data');
const backupRoot = path.join(dataDir, '.backups');

const stamp = new Date()
  .toISOString()
  .replace(/[:.]/g, '-')
  .slice(0, 19);

const target = path.join(backupRoot, stamp);

const run = async () => {
  const entries = await fs.readdir(dataDir).catch(() => {
    throw new Error(`No data directory at ${dataDir}. Run npm run seed first.`);
  });

  const files = entries.filter((name) => name.endsWith('.json'));
  if (files.length === 0) {
    console.log('Nothing to back up.');
    return;
  }

  await fs.mkdir(target, { recursive: true });
  for (const file of files) {
    await fs.copyFile(path.join(dataDir, file), path.join(target, file));
  }

  console.log(`\n  Backed up ${files.length} files to ${target}\n`);
};

run().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
