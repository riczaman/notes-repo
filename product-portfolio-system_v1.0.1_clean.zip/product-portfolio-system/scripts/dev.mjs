#!/usr/bin/env node
/**
 * Runs the API and the web client together, with labelled output.
 *
 * This replaces `concurrently`. It is not that concurrently is a bad package -
 * it is that every dependency at the root is one more thing that has to install
 * cleanly on a locked-down machine, and this needs about forty lines of the
 * Node standard library. Fewer moving parts between you and a running app.
 *
 * Ctrl+C stops both.
 */
import { spawn } from 'node:child_process';

const isWindows = process.platform === 'win32';
const npm = isWindows ? 'npm.cmd' : 'npm';

const RESET = '\x1b[0m';
const TARGETS = [
  { name: 'api', script: 'dev:api', colour: '\x1b[36m' },
  { name: 'web', script: 'dev:web', colour: '\x1b[35m' },
];

const children = [];
let stopping = false;

const write = (target, chunk) => {
  for (const line of chunk.toString().split(/\r?\n/)) {
    if (line.trim()) process.stdout.write(`${target.colour}[${target.name}]${RESET} ${line}\n`);
  }
};

const stopAll = () => {
  if (stopping) return;
  stopping = true;
  for (const child of children) {
    if (child.exitCode === null && child.signalCode === null) child.kill('SIGTERM');
  }
};

for (const target of TARGETS) {
  const child = spawn(npm, ['run', target.script], {
    stdio: ['ignore', 'pipe', 'pipe'],
    // npm on Windows is a .cmd shim, which spawn cannot execute directly.
    shell: isWindows,
  });

  child.stdout.on('data', (chunk) => write(target, chunk));
  child.stderr.on('data', (chunk) => write(target, chunk));

  child.on('error', (error) => {
    process.stdout.write(`${target.colour}[${target.name}]${RESET} failed to start: ${error.message}\n`);
    stopAll();
    process.exitCode = 1;
  });

  child.on('exit', (code) => {
    if (!stopping) {
      process.stdout.write(`${target.colour}[${target.name}]${RESET} exited with code ${code}\n`);
      stopAll();
      process.exitCode = code ?? 0;
    }
  });

  children.push(child);
}

process.on('SIGINT', () => {
  stopAll();
  process.exit(0);
});
process.on('SIGTERM', stopAll);

console.log('\n  Starting API and web client. Press Ctrl+C to stop both.\n');
