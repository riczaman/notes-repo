#!/usr/bin/env python3
"""
dependency-check.py — Validates that all skill prerequisite IDs resolve to real skill files.
Usage: python3 tools/dependency-check.py
"""
import os, re, sys

SKILLS_DIR = os.path.join(os.path.dirname(__file__), '..', 'skills')
ID_PATTERN = re.compile(r'^id:\s+"?([a-z0-9.-]+)"?', re.MULTILINE)
PREREQ_PATTERN = re.compile(r'^\s+-\s+"([a-z0-9.-]+)"', re.MULTILINE)

all_ids = {}
all_prereqs = {}

for root, dirs, files in os.walk(SKILLS_DIR):
    for f in files:
        if not f.endswith('.md'):
            continue
        path = os.path.join(root, f)
        content = open(path).read()
        m = ID_PATTERN.search(content)
        if m:
            skill_id = m.group(1)
            all_ids[skill_id] = path

errors = []
for skill_id, path in all_ids.items():
    content = open(path).read()
    in_prereqs = False
    for line in content.split('\n'):
        if 'prerequisites:' in line:
            in_prereqs = True
        if in_prereqs and line.strip().startswith('-'):
            m = re.match(r'\s+-\s+"?([a-z][a-z0-9.-]+)"?', line)
            if m:
                dep = m.group(1)
                if dep not in all_ids and '.' in dep:
                    errors.append(f"{skill_id} → missing prerequisite: {dep}")
        if in_prereqs and line.strip() and not line.strip().startswith('-') and 'skills:' not in line and 'tools:' not in line and 'certifications:' not in line and 'prerequisites:' not in line:
            if not line.startswith(' ') and not line.startswith('\t'):
                in_prereqs = False

print(f"✅ Found {len(all_ids)} skills")
if errors:
    print(f"\n❌ {len(errors)} broken prerequisite reference(s):")
    for e in errors:
        print(f"  • {e}")
    sys.exit(1)
else:
    print("✅ All prerequisite references resolve correctly")
