#!/usr/bin/env bash
# skill-lint.sh — Validates skill markdown files before PR merge
# Usage: ./tools/skill-lint.sh [file or directory]
# Exit 0 = pass, Exit 1 = failures found

set -euo pipefail

ERRORS=0
WARNINGS=0
TARGET="${1:-skills}"

check_file() {
  local file="$1"
  local name
  name=$(basename "$file")

  echo "  Checking: $file"

  # Required metadata fields
  for field in id title domain role version status author chapter_lead last_reviewed ai_indexable; do
    if ! grep -q "^${field}:" "$file" 2>/dev/null; then
      echo "    ❌ MISSING metadata field: $field"
      ERRORS=$((ERRORS + 1))
    fi
  done

  # Required sections
  for section in "## Overview" "## Maturity Levels" "## Prerequisites" "## Workflow" "## Anti-Patterns" "## Troubleshooting Guide" "## Escalation Patterns" "## KPIs" "## Best Practices" "## AI Prompt Examples"; do
    if ! grep -q "^${section}" "$file" 2>/dev/null; then
      echo "    ⚠️  MISSING section: $section"
      WARNINGS=$((WARNINGS + 1))
    fi
  done

  # Status must be valid
  if grep -q "^status:" "$file"; then
    status=$(grep "^status:" "$file" | awk '{print $2}' | tr -d '"')
    case "$status" in
      DRAFT|REVIEW|ACTIVE|DEPRECATED|ARCHIVED) ;;
      *) echo "    ❌ INVALID status value: $status"; ERRORS=$((ERRORS + 1)) ;;
    esac
  fi

  # File naming convention
  if [[ ! "$name" =~ ^[a-z0-9-]+-[a-z0-9-]+\.md$ ]]; then
    echo "    ⚠️  Filename may not follow convention (expected: role-skill-name.md): $name"
    WARNINGS=$((WARNINGS + 1))
  fi
}

echo "🔍 Enterprise Skills Linter"
echo "============================"
echo "Target: $TARGET"
echo ""

if [[ -f "$TARGET" ]]; then
  check_file "$TARGET"
elif [[ -d "$TARGET" ]]; then
  while IFS= read -r -d '' file; do
    check_file "$file"
  done < <(find "$TARGET" -name "*.md" -not -name "README.md" -print0)
else
  echo "❌ Target not found: $TARGET"
  exit 1
fi

echo ""
echo "============================"
echo "Results: ❌ $ERRORS errors | ⚠️  $WARNINGS warnings"

if [[ $ERRORS -gt 0 ]]; then
  echo "❌ LINT FAILED — fix errors before merging"
  exit 1
else
  echo "✅ LINT PASSED"
  exit 0
fi
