# Enterprise AI-Assisted Software Delivery — Skills Repository

> **Version:** 1.0.0 | **Governance:** Platform Engineering Guild | **Last Updated:** 2026-05-27

## Overview

This repository is the single source of truth for enterprise capability skills across AI-assisted software delivery. Each skill is a structured, machine-readable and human-readable knowledge artifact consumed by AI assistants, onboarding pipelines, performance frameworks, and delivery toolchains.

## Repository Structure

```
enterprise-skills-repo/
├── README.md                        # This file
├── governance/
│   ├── GOVERNANCE.md                # Governance model
│   ├── NAMING_CONVENTIONS.md        # Naming standards
│   ├── AI_USAGE_GUIDANCE.md         # How AI uses these skills
│   └── CONTRIBUTING.md              # Contribution guide
├── templates/
│   ├── SKILL_TEMPLATE.md            # Canonical skill template
│   └── skill-metadata.schema.yaml   # YAML metadata schema
├── skills/
│   ├── architecture/                # Solution & enterprise architecture
│   ├── coding/                      # Software development practices
│   ├── apis/                        # API design & governance
│   ├── cicd/                        # CI/CD pipelines & GitOps
│   ├── terraform/                   # Infrastructure as Code
│   ├── kubernetes/                  # Container orchestration
│   ├── cloud-engineering/           # Cloud platform engineering
│   ├── monitoring/                  # Observability & monitoring
│   ├── incident-response/           # Incident management
│   ├── executive-reporting/         # Executive communications
│   ├── security/                    # AppSec & platform security
│   ├── compliance/                  # Regulatory & audit compliance
│   ├── agile-delivery/              # Agile & product delivery
│   ├── root-cause-analysis/         # RCA & post-mortems
│   ├── ai-engineering/              # AI/ML systems engineering
│   ├── prompt-engineering/          # LLM prompt design
│   ├── technical-writing/           # Docs & knowledge management
│   ├── application-support/         # L1/L2/L3 support
│   ├── system-design/               # System design interviews & practice
│   └── performance-optimization/    # Perf tuning & capacity planning
└── tools/
    ├── skill-lint.sh                # Validate skill markdown
    └── dependency-check.py          # Graph dependency validator
```

## Quick Start

| I am a… | Start here |
|---|---|
| Senior Developer | `skills/coding/`, `skills/apis/`, `skills/system-design/` |
| Architect | `skills/architecture/`, `skills/system-design/`, `skills/cloud-engineering/` |
| Product Manager | `skills/agile-delivery/`, `skills/executive-reporting/` |
| Business Analyst | `skills/agile-delivery/`, `skills/technical-writing/`, `skills/root-cause-analysis/` |
| DevSecOps Engineer | `skills/cicd/`, `skills/terraform/`, `skills/security/`, `skills/kubernetes/` |
| QE Engineer | `skills/coding/`, `skills/cicd/`, `skills/performance-optimization/` |
| Executive Comms Specialist | `skills/executive-reporting/`, `skills/technical-writing/` |
| Support Analyst | `skills/application-support/`, `skills/incident-response/`, `skills/root-cause-analysis/` |
| Engineering Manager | `skills/agile-delivery/`, `skills/executive-reporting/`, `skills/incident-response/` |

## Skill Maturity Levels

| Level | Label | Description |
|---|---|---|
| 1 | **Foundational** | Core concepts, guided execution, heavy AI assistance |
| 2 | **Practitioner** | Independent execution with peer review |
| 3 | **Advanced** | Domain expertise, cross-team influence |
| 4 | **Expert** | Org-wide impact, standard-setting, mentorship |
| 5 | **Distinguished** | Industry-level contribution, innovation leadership |

## Governance

See [`governance/GOVERNANCE.md`](governance/GOVERNANCE.md) for the full governance model including review cadence, ownership, deprecation policy, and escalation paths.
