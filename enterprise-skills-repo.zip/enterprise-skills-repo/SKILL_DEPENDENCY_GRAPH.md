# Skill Dependency Graph

> Read left-to-right: arrows mean "required before". Start at the left of each chain.

## Full Dependency Map (Mermaid)

```mermaid
graph LR
  subgraph FOUNDATION ["🟦 Foundation Layer (No Prerequisites)"]
    F1["coding.senior-dev\nclean-code-practices"]
    F2["prompt-engineering.senior-dev\nprompt-engineering"]
    F3["agile-delivery.pm\nsprint-delivery"]
    F4["root-cause-analysis.ba\nrca-methods"]
    F5["executive-reporting.comms\nstakeholder-comms"]
    F6["technical-writing.comms\ndocumentation"]
    F7["application-support.support\nl1-l3-operations"]
  end

  subgraph INTERMEDIATE ["🟨 Intermediate Layer"]
    I1["apis.senior-dev\napi-design"]
    I2["security.devsecops\nappsec-threat-modeling"]
    I3["cloud-engineering.architect\ncloud-native-patterns"]
    I4["architecture.architect\nsolution-design"]
    I5["ai-engineering.senior-dev\nai-systems-engineering"]
    I6["monitoring.devsecops\nobservability-platform"]
    I7["incident-response.devsecops\nincident-command"]
  end

  subgraph ADVANCED ["🟥 Advanced Layer"]
    A1["cicd.devsecops\npipeline-design"]
    A2["terraform.devsecops\niac-design"]
    A3["kubernetes.devsecops\nk8s-operations"]
    A4["system-design.architect\ndistributed-systems"]
    A5["performance-optimization.senior-dev\nperf-tuning"]
    A6["compliance.devsecops\nregulatory-compliance"]
  end

  %% Foundation → Intermediate
  F1 --> I1
  F1 --> I2
  F1 --> I5
  F2 --> I5
  I1 --> I2

  %% Intermediate → Advanced
  I3 --> A2
  I3 --> A3
  I3 --> A4
  I2 --> A1
  I2 --> A6
  I6 --> A7
  I4 --> A4
  F1 --> A1
  I6 --> A5
  F1 --> A5
  A1 --> A3
  A2 --> A3
  I2 --> A6
  A1 --> A6
  I6 --> I7
```

## Recommended Learning Paths by Role

### 🧑‍💻 Senior Developer
```
Week 1-2:   coding/dev-clean-code-practices
Week 3-4:   apis/dev-api-design
Month 2:    security/devsecops-appsec-threat-modeling (OWASP awareness)
Month 3:    performance-optimization/dev-perf-tuning
Month 4:    prompt-engineering/dev-prompt-engineering
Month 5-6:  ai-engineering/dev-ai-systems-engineering
Month 6+:   system-design/architect-distributed-systems
```

### 🏗️ Architect
```
Month 1:    architecture/architect-solution-design
Month 2:    cloud-engineering/architect-cloud-native-patterns
Month 3:    system-design/architect-distributed-systems
Month 4:    security/devsecops-appsec-threat-modeling
Month 5:    performance-optimization/dev-perf-tuning
Month 6:    monitoring/devsecops-observability-platform
```

### 📦 DevSecOps Engineer
```
Month 1:    coding/dev-clean-code-practices (foundation)
Month 1-2:  cicd/devsecops-pipeline-design
Month 2-3:  terraform/devsecops-iac-design
Month 3-4:  kubernetes/devsecops-k8s-operations
Month 4-5:  security/devsecops-appsec-threat-modeling
Month 5-6:  monitoring/devsecops-observability-platform
Month 6:    compliance/devsecops-regulatory-compliance
Month 7:    incident-response/devsecops-incident-command
```

### 📋 Product Manager
```
Month 1:    agile-delivery/pm-agile-delivery
Month 2:    executive-reporting/comms-exec-reporting
Month 3:    root-cause-analysis/ba-rca-methods
Month 4:    technical-writing/comms-technical-writing
```

### 🔍 Business Analyst
```
Month 1:    root-cause-analysis/ba-rca-methods
Month 2:    agile-delivery/pm-agile-delivery
Month 2:    technical-writing/comms-technical-writing
Month 3:    executive-reporting/comms-exec-reporting
```

### 🔒 QE Engineer
```
Month 1:    coding/dev-clean-code-practices
Month 2:    apis/dev-api-design
Month 2-3:  cicd/devsecops-pipeline-design (pipeline quality gates)
Month 3-4:  performance-optimization/dev-perf-tuning (load testing)
Month 4:    security/devsecops-appsec-threat-modeling (security testing)
```

### 📣 Executive Comms Specialist
```
Month 1:    executive-reporting/comms-exec-reporting
Month 2:    technical-writing/comms-technical-writing
Month 3:    root-cause-analysis/ba-rca-methods (for incident comms)
Month 4:    agile-delivery/pm-agile-delivery (understand delivery context)
```

### 🎧 Support Analyst
```
Month 1:    application-support/support-l1-l3-operations
Month 2:    root-cause-analysis/ba-rca-methods
Month 3:    incident-response/devsecops-incident-command
Month 4:    monitoring/devsecops-observability-platform (read-only, context)
```

### 👔 Engineering Manager
```
Month 1:    agile-delivery/pm-agile-delivery
Month 1:    executive-reporting/comms-exec-reporting
Month 2:    incident-response/devsecops-incident-command
Month 2:    root-cause-analysis/ba-rca-methods
Month 3:    Read ALL skills your team owns (at Foundational level minimum)
```
