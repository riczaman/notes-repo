---
# ============================================================
# SKILL METADATA — Complete ALL fields before submitting PR
# ============================================================
id: "<domain>.<role>.<skill-name>"                 # e.g. architecture.architect.solution-design
title: "<Human Readable Skill Title>"
domain: "<domain-folder-name>"                      # e.g. architecture
role: "<canonical-role-label>"                      # e.g. architect
version: "1.0.0"
status: "DRAFT"                                     # DRAFT | REVIEW | ACTIVE | DEPRECATED | ARCHIVED
maturity_score: 0                                   # 1-5 (set by chapter lead on approval)
author: "<github-handle>"
chapter_lead: "<github-handle>"
last_reviewed: "YYYY-MM-DD"
usage_count: 0                                      # Auto-populated by AI telemetry
endorsements: 0                                     # Incremented by chapter leads
tags:
  - "<tag1>"
  - "<tag2>"
prerequisites:
  skills:
    - "<prerequisite.skill.id>"
  tools:
    - "<Tool Name>"
  certifications:
    - "<Certification Name or 'none'>"
related_skills:
  - "<related.skill.id>"
successor: null                                     # Set when status=DEPRECATED
ai_indexable: true
---

# <Skill Title>

> **Domain:** `<domain>` | **Role:** `<role>` | **Version:** `1.0.0` | **Status:** `DRAFT`

## Overview

One paragraph: what this skill covers, why it matters to the enterprise, and what a practitioner can do with it. Be specific — avoid generic platitudes.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Can describe concepts; executes with step-by-step guidance | Heavy — AI drives, human reviews |
| 2 | Practitioner | Executes independently on standard tasks; needs peer review | Moderate — AI co-pilots |
| 3 | Advanced | Handles ambiguous situations; influences team standards | Light — AI validates |
| 4 | Expert | Shapes org-wide practices; mentors others; handles novel edge cases | Minimal — human drives, AI augments |
| 5 | Distinguished | Industry-recognized; defines new patterns; published standards | AI as research assistant only |

**Current team target level:** `<insert level>`  
**Expected time to Practitioner (L2):** `<X months>`

---

## Prerequisites

### Required Skills
- `<prerequisite.skill.id>` — <why it's needed>

### Required Tools Access
- **<Tool Name>** — <what access level is needed>

### Required Knowledge
- <knowledge item 1>
- <knowledge item 2>

---

## Workflow

### Step 1: <Action>
<Description of what to do, why, and how. Include decision points.>

**AI Assist:** `<Yes | No | Optional>` — <describe what AI can do here>

### Step 2: <Action>
<Description>

**AI Assist:** `<Yes | No | Optional>`

### Step 3: <Action>
<Description>

**Decision Gate:** <Describe what condition must be true to proceed>

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| <Tool Name> | <Purpose> | Required | Yes/No |
| <Tool Name> | <Purpose> | Optional | Yes/No |

---

## Anti-Patterns

> Anti-patterns are explicitly monitored by AI review. If detected in submitted artifacts, AI will flag and recommend remediation.

### ❌ Anti-Pattern 1: <Name>
**What it looks like:** <Description>  
**Why it's harmful:** <Impact>  
**Remediation:** <How to fix>

### ❌ Anti-Pattern 2: <Name>
**What it looks like:** <Description>  
**Why it's harmful:** <Impact>  
**Remediation:** <How to fix>

---

## Troubleshooting Guide

### Problem: <Symptom>
**Root Cause(s):** <Likely causes>  
**Diagnostic Steps:**
1. <Step>
2. <Step>  
**Resolution:** <Fix>  
**Prevention:** <How to avoid in future>

---

## Escalation Patterns

> ⚠️ These scenarios MUST be escalated to a human. AI systems will not attempt resolution.

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| <Trigger condition> | <Role/Team> | <Time> | <Slack/Ticket/Page> |
| <Trigger condition> | <Role/Team> | <Time> | <Slack/Ticket/Page> |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| <Metric Name> | <Baseline value> | <Target value> | <How measured> |
| <Metric Name> | <Baseline value> | <Target value> | <How measured> |

---

## Best Practices

1. **<Practice Name>** — <Description>
2. **<Practice Name>** — <Description>
3. **<Practice Name>** — <Description>

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| <What can be automated> | <How> | L<N> | <S/M/L/XL> |

---

## AI Prompt Examples

### Prompt 1: <Use Case>
```
Role: You are a <role> at an enterprise software company.
Context: <Relevant context about the task>
Task: <Specific ask>
Constraints:
  - <Constraint 1>
  - <Constraint 2>
Output format: <Format specification>
```
**Expected output:** <Description of what a good response looks like>

### Prompt 2: <Use Case>
```
<prompt text>
```

---

## References & Further Reading

- [<Title>](<URL>) — <Why relevant>
- [<Title>](<URL>) — <Why relevant>
