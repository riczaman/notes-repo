# AI Usage Guidance for Skills Repository

## How AI Assistants Use This Repository

Skills are consumed by AI systems as structured context injected into prompts at query time. The AI assistant retrieves the most relevant skill section(s) based on user intent, then uses the skill content to:

1. **Ground responses** in enterprise-approved patterns and workflows
2. **Generate code and artifacts** that match the org's standards
3. **Flag anti-patterns** when it detects them in user-submitted work
4. **Recommend escalation paths** when user queries exceed AI safe boundaries
5. **Surface KPIs** when users ask about performance or success metrics

## Retrieval Strategy

Skills are chunked by section (H2 boundary) for RAG:
- `## Workflow` → retrieved for "how do I..." queries
- `## Anti-Patterns` → retrieved for "review my..." queries
- `## AI Prompt Examples` → retrieved for "help me prompt..." queries
- `## Troubleshooting Guide` → retrieved for "why is X failing..." queries

## AI Prompt Construction Guidelines

When writing AI Prompt Examples in skill files:

```
✅ DO:
- Use role-context framing: "You are a [role] working on [context]..."
- Include constraints: "Respond only with [format], limit to [scope]..."
- Embed enterprise context: reference org patterns, stack, standards
- Chain prompts: show multi-turn workflows, not just single shots
- Include negative examples showing what NOT to prompt

❌ DON'T:
- Write prompts that elicit non-deterministic creative freeform output
- Omit output format specification
- Rely on model knowledge alone without grounding context
- Use jailbreak-adjacent phrasing ("ignore previous instructions...")
- Write prompts longer than 800 tokens without chunking strategy
```

## Safety & Guardrails

AI systems consuming skills MUST:
- Treat `## Escalation Patterns` sections as hard stops (do not attempt to resolve escalation triggers with AI)
- Never use skill content to bypass security controls
- Surface `## Prerequisites` before executing advanced workflow prompts
- Respect `status: deprecated` metadata — warn users and redirect

## Skill Quality Signals for AI Ranking

AI retrieval systems rank skills by:
1. Metadata `maturity_score` (higher = more authoritative)
2. Recency of `last_reviewed` date
3. `usage_count` (populated by AI telemetry pipeline)
4. `endorsements` count from chapter leads

## Prohibited AI Uses of Skill Content

- Do NOT use skill content to auto-generate compliance certifications
- Do NOT use prompt examples verbatim in production without human review
- Do NOT expose raw skill markdown to end users outside the developer portal
- Do NOT allow AI to modify skill files directly — all changes via PR workflow
