# Contributing to the Enterprise Skills Repository

## Quick Start

1. **Fork** this repository
2. **Branch**: `git checkout -b feat/skill-<domain>-<skill-name>`
3. **Copy** `templates/SKILL_TEMPLATE.md` to the right domain folder
4. **Fill out** ALL required metadata fields and ALL required sections
5. **Validate**: `./tools/skill-lint.sh skills/<domain>/<your-file>.md`
6. **PR**: submit against `main` with the Chapter Lead as reviewer

## Requirements Before PR

- [ ] All metadata fields complete (`id`, `title`, `domain`, `role`, `version`, `status: "REVIEW"`, `author`, `chapter_lead`, `last_reviewed`)
- [ ] All 10 required sections present
- [ ] At least 2 AI Prompt Examples included
- [ ] At least 3 Anti-Patterns defined
- [ ] KPIs have measurable baselines
- [ ] `skill-lint.sh` passes with 0 errors
- [ ] `dependency-check.py` passes

## Review Process

| Who | What | SLA |
|---|---|---|
| Author | Self-review against template | Before PR |
| Peer | Technical accuracy | 48 hours |
| Chapter Lead | Content quality + standards | 5 business days |
| Guild Lead | Schema compliance (if changing metadata) | 5 business days |

## Content Standards

- Write for a practitioner, not a PhD — clear, direct, actionable
- Every claim should be specific enough to act on
- Anti-patterns must have concrete remediations, not just warnings  
- AI prompts must be tested before inclusion — copy/paste them, see what you get
- KPI baselines must be realistic — made-up numbers are worse than none

## What NOT to Include

- Vendor-specific content that isn't broadly applicable
- Content that requires NDA or confidential knowledge to understand
- Personal opinions framed as best practices without evidence
- Tool version numbers that will become stale quickly (link to docs instead)

## Getting Help

Questions about content → your Chapter Lead  
Questions about the template or schema → `#platform-guild` Slack  
Something broken → open a GitHub Issue
