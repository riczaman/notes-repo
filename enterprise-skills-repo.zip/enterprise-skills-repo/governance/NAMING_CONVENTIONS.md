# Naming Conventions

## File Naming

```
skills/<domain>/<role>-<skill-name>.md
```

Examples:
- `skills/architecture/architect-solution-design.md`
- `skills/coding/senior-developer-clean-code.md`
- `skills/cicd/devsecops-pipeline-design.md`

## Rules

| Element | Rule | Example |
|---|---|---|
| Domain folder | `kebab-case`, max 2 words | `cloud-engineering` |
| Role prefix | Short canonical role label | `architect`, `dev`, `pm`, `ba`, `devsecops`, `qe`, `comms`, `support`, `mgr` |
| Skill name | `kebab-case`, descriptive verb-noun | `api-design`, `threat-modeling`, `sprint-planning` |
| Metadata ID | `<domain>.<role>.<skill>` dot notation | `architecture.architect.solution-design` |
| Version tag | `vMAJOR.MINOR.PATCH` | `v1.2.0` |

## Canonical Role Labels

| Role | Canonical Label | Used In Filenames |
|---|---|---|
| Senior Developer | `senior-dev` | `dev` |
| Architect | `architect` | `architect` |
| Product Manager | `product-manager` | `pm` |
| Business Analyst | `business-analyst` | `ba` |
| DevSecOps Engineer | `devsecops` | `devsecops` |
| QE Engineer | `qe` | `qe` |
| Executive Comms Specialist | `exec-comms` | `comms` |
| Support Analyst | `support-analyst` | `support` |
| Engineering Manager | `eng-manager` | `mgr` |

## Section Header Conventions

All skill files use H2 (`##`) for top-level sections. No H1 inside skill files (the filename serves as H1 in rendered portals). Subsections use H3 (`###`). Never use H4 or deeper.

## Metadata Key Conventions

- All keys: `snake_case`
- Boolean values: `true` / `false` (not `yes`/`no`)
- Arrays: YAML block style, not inline
- Dates: `YYYY-MM-DD`
