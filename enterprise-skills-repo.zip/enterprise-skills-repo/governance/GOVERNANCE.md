# Governance Model — Enterprise Skills Repository

## 1. Ownership Structure

```
Executive Sponsor: VP Engineering / CTO
  └── Platform Engineering Guild (Guild Lead)
        ├── Architecture Chapter → owns: architecture/, system-design/, cloud-engineering/
        ├── Developer Experience Chapter → owns: coding/, apis/, cicd/, terraform/, kubernetes/
        ├── Reliability Chapter → owns: monitoring/, incident-response/, root-cause-analysis/, performance-optimization/
        ├── Security Chapter → owns: security/, compliance/
        ├── Product & Delivery Chapter → owns: agile-delivery/, executive-reporting/, technical-writing/
        ├── Support Chapter → owns: application-support/
        └── AI Chapter → owns: ai-engineering/, prompt-engineering/
```

## 2. Review Cadence

| Activity | Frequency | Owner |
|---|---|---|
| Skill content review | Quarterly | Chapter Lead |
| Metadata schema updates | Semi-annually | Guild Lead |
| KPI baseline recalibration | Annually | Engineering Manager |
| AI prompt example refresh | Monthly | AI Chapter |
| Anti-pattern additions | As discovered | Any contributor (PR required) |
| Deprecation sweep | Annually | Guild Lead |

## 3. Contribution Workflow

```
1. Fork → branch (feat/skill-<domain>-<name>)
2. Use templates/SKILL_TEMPLATE.md
3. Complete ALL required sections (validated by skill-lint.sh)
4. Submit PR → assign Chapter Lead as reviewer
5. Chapter Lead approves content; Guild Lead approves schema changes
6. Merge → auto-tagged with version bump
7. Notify consuming AI systems via webhook (tools/notify-consumers.sh)
```

## 4. Skill Lifecycle

```
DRAFT → REVIEW → ACTIVE → DEPRECATED → ARCHIVED
```

- **DRAFT**: Author working, not indexed by AI systems
- **REVIEW**: PR open, under chapter review
- **ACTIVE**: Merged, indexed, AI-consumable
- **DEPRECATED**: Successor exists; still readable, AI systems warned
- **ARCHIVED**: Read-only, removed from AI index after 90 days

## 5. Breaking Changes Policy

Skills follow **semantic versioning** (`MAJOR.MINOR.PATCH`):
- `MAJOR`: Workflow changes that invalidate prior AI prompt patterns
- `MINOR`: New sections, new anti-patterns, new KPIs
- `PATCH`: Wording fixes, typo corrections, link updates

Breaking changes require 30-day deprecation notice to consuming teams.

## 6. Escalation Path

```
Contributor concern
  → Chapter Lead (72h SLA)
    → Guild Lead (5 business day SLA)
      → Executive Sponsor (for policy/compliance conflicts)
```

## 7. Quality Gates

Every skill must pass `tools/skill-lint.sh` before merge:
- All required metadata fields present
- All required sections present (≥ 8 of 12 defined sections)
- No broken internal links
- AI prompt examples validated against prompt-engineering skill
- KPIs have measurable baselines defined

## 8. AI System Integration

Skills in `ACTIVE` status are indexed by:
- Internal AI assistant (Claude API integration)
- Developer portal skill browser
- Onboarding automation pipeline
- Performance review tooling

AI systems consume skills READ-ONLY via the `/api/skills` endpoint. Skills are chunked by section for retrieval-augmented generation (RAG).
