# How to Use This Skills Repository — Complete Usage Guide

> Read this first. Everything else makes more sense after.

---

## What Is This Repository?

This is a **structured knowledge system** — not a reading list, not a wiki, not a collection of tips. Each skill file is a precision-engineered artifact that can be used by:

- **You, as an individual** — to self-assess, learn, and level up
- **Your team** — for onboarding, code review checklists, and retrospectives
- **AI assistants** — as injected context to massively improve the quality of AI-generated code, documents, plans, and reviews
- **Engineering managers** — for structured 1-on-1s, growth plans, and hiring criteria
- **Your CI/CD pipeline** — as linting rules, quality gate references, and automation triggers

---

## The 5 Ways to Use These Skills

---

### 📌 WAY 1 — Use Skills as AI Prompt Context (Highest ROI)

**What it does:** Paste a skill's relevant sections into your AI conversation before asking for help. The AI produces dramatically better, org-aligned output because it has your standards, anti-patterns, and constraints.

**How to do it:**

**Step 1.** Find the skill relevant to your task:
```
I need to design an API      → skills/apis/dev-api-design.md
I'm writing a Terraform module → skills/terraform/devsecops-iac-design.md
I'm reviewing code            → skills/coding/dev-clean-code-practices.md
I'm writing a postmortem      → skills/incident-response/devsecops-incident-command.md
```

**Step 2.** Copy the relevant sections — usually:
- `## Workflow` (for how-to tasks)
- `## Anti-Patterns` (for review tasks)
- `## AI Prompt Examples` (as ready-to-use prompts)

**Step 3.** Use the pre-built AI Prompt Examples. Every skill file has 2–3 tested prompts. Copy them verbatim and fill in your context:

```
EXAMPLE — From skills/apis/dev-api-design.md, Prompt 1:

"Role: You are a senior developer designing a REST API.
Context: We need an API for a product catalog service. Products have:
         id, name, description, price, category, stock_quantity, created_at.
Task: Generate a complete OpenAPI 3.1 specification for this API.
Constraints:
  - Auth: Bearer JWT
  - Error responses: RFC 7807 Problem Details format
  - Pagination: cursor-based on list endpoints
Output format: Complete OpenAPI 3.1 YAML"
```

**Step 4.** For code review, paste the Anti-Patterns section as context:

```
"You are reviewing this code. Here are our organisation's anti-patterns — flag any you see:
[PASTE ## Anti-Patterns SECTION]

Here is the code to review:
[PASTE CODE]"
```

**Pro tip:** The more skill context you provide, the more the AI response is grounded in YOUR standards rather than generic internet advice.

---

### 📌 WAY 2 — Self-Assessment & Growth Planning

**What it does:** Use the Maturity Levels table in each skill to honestly assess where you are and build a concrete development plan.

**How to do it:**

**Step 1.** Open the skill for your role and a domain you want to develop.

**Step 2.** Read the Maturity Levels table. For each level, ask: "Can I do this, independently, without looking it up?" Be honest.

**Step 3.** Identify your current level (the last level where the answer is "yes").

**Step 4.** Look at the NEXT level — what's the gap? The Prerequisites section tells you what knowledge/tools you need.

**Step 5.** Build a development plan:
```
Current level: L2 Practitioner (Terraform)
Target level: L3 Advanced
Gap: I don't design module libraries or know OPA policy-as-code
Actions:
  1. Complete HashiCorp Terraform Associate cert (6 weeks)
  2. Build a reusable VPC module and submit for team review
  3. Implement one OPA policy for the team's K8s cluster (pair with @senior-devsecops)
Timeline: 3 months
```

**Step 6.** Bring this to your next 1-on-1 with your manager. It shows initiative and gives your manager something concrete to support.

---

### 📌 WAY 3 — Team Onboarding Acceleration

**What it does:** New team members can onboard to team standards in days instead of weeks by reading the skills relevant to their role.

**How to do it:**

**Week 1 Onboarding Plan for a new Senior Developer:**
```
Day 1-2: Read these skills (get the lay of the land)
  - skills/coding/dev-clean-code-practices.md
  - skills/apis/dev-api-design.md
  
Day 3: Shadow a code review using the Anti-Patterns checklist from both skills

Day 4-5: Read:
  - skills/cicd/devsecops-pipeline-design.md  (understand the pipeline you'll use)
  - skills/system-design/architect-distributed-systems.md (understand the architecture)

Week 2: First PR — self-review against the Anti-Patterns checklist before submitting
```

**Create a role-specific reading list** by looking at the README's Quick Start table and mapping to your team's most relevant domains.

**Use the Prerequisites chain:** Each skill lists `prerequisites.skills`. Follow the chain from foundational to advanced — it tells you the right learning order.

---

### 📌 WAY 4 — Process Improvement & Retrospectives

**What it does:** Use the Anti-Patterns and KPIs sections to run structured retrospectives and identify concrete improvements.

**How to do it — Retrospective with Skills:**

**Step 1.** Choose the skill most relevant to what went wrong (or what you want to improve).

**Step 2.** Read the Anti-Patterns section aloud to the team. Ask: "Which of these did we do this sprint?"

**Step 3.** Look at the KPIs section. For each metric, ask: "Do we even measure this? If yes, are we at baseline or target?"

**Step 4.** Pick ONE anti-pattern to eliminate and ONE KPI to start measuring. Create Jira tickets.

**Example:**
```
Retro theme: Why are our deployments so slow?

Relevant skill: skills/cicd/devsecops-pipeline-design.md
Anti-pattern found: "Snowflake Pipelines" — we have 12 unique pipeline configs
KPI gap: We don't measure pipeline duration at all

Actions:
  - [ ] @devsecops: Instrument pipeline duration in Grafana (1 week)
  - [ ] @devsecops: Consolidate to 1 shared pipeline template (2 sprints)
```

---

### 📌 WAY 5 — Engineering Manager 1-on-1 Framework

**What it does:** Use the Maturity Levels + KPIs + Escalation Patterns as a structured framework for performance conversations.

**How to do it:**

**For growth conversations:**
- Pull the skill file for the area you're discussing
- Maturity Levels table gives you shared language: "You're at L2; let's talk about what L3 looks like"
- Prerequisites section gives you a concrete development path
- Best Practices section gives you specific behaviors to coach toward

**For performance concerns:**
- Anti-Patterns section gives you specific, observable behaviors to reference (not vague "code quality issues")
- KPIs give you measurable targets for a Performance Improvement Plan

**For promotion decisions:**
- A candidate for senior promotion should demonstrate L3+ across their primary skills
- Use the Maturity Level descriptions as evidence criteria

**Template 1-on-1 with skills:**
```
"Let's look at [skill file] together. Based on the Maturity Levels, 
where would you self-assess? I'd put you at [level] because [evidence]. 
To reach [next level], the Prerequisites section says we need [X]. 
What support do you need from me to get there in the next quarter?"
```

---

## How to Add Skills to Your AI System (Advanced)

If your team has an internal AI assistant or uses the Anthropic API, you can build a RAG (Retrieval-Augmented Generation) system on top of this repo so skills are automatically injected based on context.

**Architecture:**

```
1. Ingest all skill markdown files into a vector database (pgvector, Pinecone)
   - Chunk by H2 section (## Workflow, ## Anti-Patterns, etc.)
   - Embed each chunk with a text embedding model
   - Store: chunk text, skill_id, section_name, role, domain

2. At query time:
   - User asks: "Review my Terraform module for security issues"
   - System detects: domain=terraform, intent=review
   - Retrieves: terraform skill § Anti-Patterns + § Best Practices
   - Injects into Claude's context as system prompt additions
   - Claude responds with org-specific standards, not generic advice

3. Result: every AI response is grounded in YOUR skill standards
```

**Quick start with the Anthropic API:**
```python
import anthropic

# Load skill content (simplified — use vector search in production)
with open('skills/terraform/devsecops-iac-design.md') as f:
    skill_content = f.read()

client = anthropic.Anthropic()
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=2000,
    system=f"""You are a senior DevSecOps engineer at this organisation.
    
SKILL STANDARDS YOU MUST APPLY:
{skill_content}

Always flag anti-patterns from the skill standards when you see them.
Always recommend following the workflow in the skill standards.
""",
    messages=[{
        "role": "user",
        "content": "Review this Terraform module: [PASTE MODULE]"
    }]
)
```

---

## How to Contribute New Skills

1. **Copy** `templates/SKILL_TEMPLATE.md` to the right domain folder
2. **Name it** using the convention: `<role>-<skill-name>.md` (e.g., `qe-test-automation.md`)
3. **Fill out every section** — incomplete skills don't get merged
4. **Run the linter**: `./tools/skill-lint.sh skills/<domain>/<your-file>.md`
5. **Submit a PR** — see `governance/CONTRIBUTING.md` for the full process

**Don't have time to write a full skill?** Open a GitHub Issue using the `new-skill` template. Another contributor may pick it up.

---

## Quick Reference: Which Skill for Which Task?

| I want to... | Use this skill | Key section |
|---|---|---|
| Review code for quality issues | `coding/dev-clean-code-practices.md` | Anti-Patterns |
| Design a new API | `apis/dev-api-design.md` | Workflow |
| Set up a CI/CD pipeline | `cicd/devsecops-pipeline-design.md` | Workflow + AI Prompts |
| Write Terraform for a new service | `terraform/devsecops-iac-design.md` | Workflow + Anti-Patterns |
| Deploy to Kubernetes | `kubernetes/devsecops-k8s-operations.md` | Workflow |
| Design a new system | `architecture/architect-solution-design.md` | Workflow |
| Write a postmortem | `incident-response/devsecops-incident-command.md` | AI Prompts |
| Prepare an exec update | `executive-reporting/comms-exec-reporting.md` | Workflow + AI Prompts |
| Onboard a new engineer | Start with role-appropriate skills from README quick start table | Maturity Levels |
| Run a retrospective | Skill for the domain that had issues | Anti-Patterns + KPIs |
| Write a threat model | `security/devsecops-appsec-threat-modeling.md` | AI Prompts |
| Debug a production incident | `incident-response/devsecops-incident-command.md` | Workflow |
| Analyze root cause | `root-cause-analysis/ba-rca-methods.md` | Workflow + AI Prompts |
| Write a runbook | `technical-writing/comms-technical-writing.md` | AI Prompts |
| Build an AI feature | `ai-engineering/dev-ai-systems-engineering.md` | Workflow |
| Write better AI prompts | `prompt-engineering/dev-prompt-engineering.md` | Workflow + Anti-Patterns |

---

## Common Mistakes to Avoid

| Mistake | What to Do Instead |
|---|---|
| Reading the whole skill top-to-bottom | Jump to the section you need (Workflow for how-to, Anti-Patterns for review) |
| Using skills as rigid rules | They are guidelines with documented trade-offs — use judgment |
| Ignoring the Escalation Patterns | These are the hard stops — don't try to resolve escalation triggers with AI |
| Treating AI Prompt Examples as magic | Test them with your specific context; adjust constraints for your situation |
| Only using skills for your own role | Cross-reading (e.g., developer reading the architect skill) builds system thinking |
| Never updating skills | Stale skills are dangerous — file an issue or submit a PR when you see outdated content |

---

## Repository Maintenance Checklist (For Skill Owners)

Run this monthly:
```
[ ] Are the tools and versions in my skills still current?
[ ] Have any Anti-Patterns been resolved by new tooling?
[ ] Are the KPI baselines and targets still realistic?
[ ] Do the AI Prompt Examples still produce good output with current models?
[ ] Are there new patterns from retrospectives or incidents that should be documented?
[ ] Are the Escalation Patterns still routed to the right people/channels?
```

If any answer is "no" → update the skill and bump the PATCH version.
