---
id: "apis.senior-dev.api-design"
title: "API Design & Governance"
domain: "apis"
role: "senior-dev"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "dev-experience-chapter"
last_reviewed: "2026-05-27"
tags:
  - api
  - rest
  - openapi
  - graphql
  - versioning
  - api-governance
prerequisites:
  skills:
    - "coding.senior-dev.clean-code-practices"
    - "security.senior-dev.owasp-top10"
  tools:
    - "Swagger UI / Redoc"
    - "Postman or Bruno"
    - "Spectral (OpenAPI linter)"
  certifications:
    - "none"
related_skills:
  - "architecture.architect.solution-design"
  - "coding.senior-dev.clean-code-practices"
  - "security.devsecops.api-security"
ai_indexable: true
---

# API Design & Governance

> **Domain:** `apis` | **Role:** `senior-dev` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

API Design & Governance is the practice of designing, documenting, and evolving APIs that are intuitive, consistent, secure, and evolvable. Senior Developers own API design for their services; the API Governance chapter sets the org-wide standards. In an AI-augmented development environment, well-designed APIs described in OpenAPI are directly consumable by AI systems for code generation, test generation, and documentation — making API quality a force multiplier for the entire team.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Implements APIs from a spec written by others; basic REST understanding | Heavy — AI generates OpenAPI specs and client stubs |
| 2 | Practitioner | Designs RESTful APIs; writes OpenAPI specs; handles versioning | Moderate — AI generates, human ensures correctness |
| 3 | Advanced | Designs API products (multi-service); sets team API standards; reviews others | Light — AI validates against standards |
| 4 | Expert | Owns org-wide API governance; manages breaking change policy; API platform | Minimal |
| 5 | Distinguished | Publishes API design guides; contributes to API standards bodies | AI as reference tool |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `3–5 months`

---

## Prerequisites

### Required Skills
- `coding.senior-dev.clean-code-practices` — clean design principles translate to APIs
- `security.senior-dev.owasp-top10` — API security vulnerabilities (OWASP API Top 10)

### Required Tools Access
- **Swagger UI / Redoc** — API documentation rendering
- **Postman or Bruno** — API testing and exploration
- **Spectral** — OpenAPI linting and governance enforcement
- **GitHub** — API spec version control

### Required Knowledge
- REST constraints (statelessness, uniform interface, resource-based URLs)
- HTTP semantics: methods (GET/POST/PUT/PATCH/DELETE), status codes, headers
- OpenAPI 3.x specification format
- API versioning strategies: URI path, header, query param
- Pagination patterns: cursor-based, offset-based, keyset
- Authentication: OAuth 2.0, JWT, API keys — when to use which

---

## Workflow

### Step 1: API-First Design (Spec Before Code)
Write the OpenAPI spec BEFORE writing implementation code. This is the API-first principle. The spec is the contract. Implementation fulfils the contract.

**AI Assist:** `Yes` — "Generate an OpenAPI 3.1 spec for an API that [describe resource and operations]"

### Step 2: Resource Modelling
Identify the resources (nouns, not verbs). Define the URL structure:
```
/resources                    → collection
/resources/{id}               → single resource
/resources/{id}/sub-resources → nested collection (max 2 levels deep)
```
Actions that don't map to CRUD: use `POST /resources/{id}/actions/{action}` pattern.

### Step 3: Request/Response Schema Design
Define schemas for all request bodies and responses. Use `$ref` to reuse schemas. Define error response schema consistently across all APIs using `RFC 7807 Problem Details`.

### Step 4: Spectral Linting
Run `spectral lint openapi.yaml` against the org's Spectral ruleset. Fix all ERRORS before proceeding. Address WARNINGS with justification if not fixed.

**Decision Gate:** Spectral lint must pass with 0 errors before spec review.

### Step 5: API Design Review
Submit spec for peer review via PR. Reviewers check: naming consistency, completeness of error cases, security requirements (auth, rate limiting), backward compatibility.

### Step 6: Mock Server Generation
Generate a mock server from the OpenAPI spec (Prism or similar) before implementation. Frontend/consumer teams can develop against the mock in parallel.

**AI Assist:** `Yes` — AI generates realistic mock response data matching the schema

### Step 7: Implementation Against Spec
Implement the API to satisfy the spec. Use contract testing (Pact or Dredd) to verify implementation matches spec automatically in CI.

### Step 8: Versioning & Deprecation
For breaking changes: create a new version (`/v2/`). Maintain previous version for a minimum of 6 months with deprecation headers. Communicate to consumers via API changelog.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| OpenAPI 3.x | API specification format | Required | Yes (AI generates) |
| Spectral | OpenAPI linting/governance | Required | No |
| Swagger UI / Redoc | Documentation hosting | Required | No |
| Prism | Mock server from OpenAPI spec | Recommended | No |
| Pact / Dredd | Contract testing | Recommended | No |
| Postman / Bruno | API testing | Required | No |
| API Gateway (Kong/AWS APIGW) | Rate limiting, auth, routing | Required (prod) | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Verbs in Resource URLs
**What it looks like:** `POST /createUser`, `GET /getUserById`, `POST /deleteOrder`  
**Why it's harmful:** Breaks REST uniform interface. Inconsistent, unpredictable, hard to discover.  
**Remediation:** `POST /users`, `GET /users/{id}`, `DELETE /orders/{id}`

### ❌ Anti-Pattern 2: Using HTTP 200 for All Responses Including Errors
**What it looks like:** `HTTP 200 {"status": "error", "message": "User not found"}`  
**Why it's harmful:** Breaks semantic meaning. Clients can't use HTTP status codes for error handling. Monitoring tools report 100% success.  
**Remediation:** Use correct HTTP status codes. `404` for not found, `422` for validation errors, `409` for conflicts, `500` for server errors.

### ❌ Anti-Pattern 3: Breaking Changes Without Versioning
**What it looks like:** Removing a field or changing a field type in an existing API version  
**Why it's harmful:** All consumers break silently. Discovery is often too late (production outage).  
**Remediation:** Breaking changes always require a new API version. Non-breaking additions (new optional fields) are fine on existing version.

### ❌ Anti-Pattern 4: Returning Entire Domain Model
**What it looks like:** User API returns password hash, internal IDs, audit fields, all relationships in a single response  
**Why it's harmful:** Over-exposure of internal data model, security risk, tight coupling, large payloads.  
**Remediation:** Design response DTOs explicitly. Return only what the consumer needs. Use sparse fieldsets or projections.

### ❌ Anti-Pattern 5: No Pagination on Collection Endpoints
**What it looks like:** `GET /users` returns all 50,000 users  
**Why it's harmful:** Server memory exhaustion, client timeout, unbounded response time.  
**Remediation:** Every collection endpoint must have pagination. Default page size ≤ 100. Max page size ≤ 1000. Return pagination metadata.

---

## Troubleshooting Guide

### Problem: Spectral linting fails with 40+ warnings on existing API spec
**Root Cause(s):** API was designed without a linting standard; inherited spec from another team  
**Diagnostic Steps:**
1. Categorize failures: ERRORS (must fix) vs WARNINGs (should fix)
2. Identify which Spectral rules are generating the most findings  
**Resolution:** Fix errors first. Create a prioritized backlog for warnings. Add `x-spectral-disable` with justification for accepted exceptions.  
**Prevention:** Add Spectral to CI from day one of a new API. Never merge a spec with errors.

### Problem: Breaking change deployed without a version bump — consumers are failing
**Root Cause(s):** Developer made schema change without recognizing it as breaking; no contract test caught it  
**Diagnostic Steps:**
1. Identify the exact change via OpenAPI diff tool (oasdiff)
2. Identify affected consumers from API gateway analytics  
**Resolution:** Immediate: revert or hotfix to restore old field. Then: create v2 with the new design.  
**Prevention:** Implement oasdiff in CI to detect and block breaking changes. Pact contract tests with consumer teams.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Breaking change deployed; multiple consumers failing | Engineering Manager + API Governance Lead | Immediate | `#incidents` |
| API security vulnerability (OWASP API Top 10) | Security Engineer | 2 hours | `#security-escalations` |
| API design disagreement between teams unresolved | API Governance Lead | 3 business days | Architecture review |
| Consumer API rate limit causing production impact | Platform Engineer + EM | 1 hour | `#incidents` |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| API-first compliance rate (spec before code) | 40% of new APIs | >90% of new APIs | PR audit (spec PR before impl PR) |
| Spectral lint error rate | 60% of specs have errors | <5% of specs have errors | Spectral CI reports |
| Breaking change incidents | 3/quarter | 0/quarter | Incident postmortem API tags |
| API documentation coverage | 65% of endpoints documented | 100% | OpenAPI coverage report |
| Time to first mock (new API) | 5 days | <1 day | Spec PR timestamp → mock availability |

---

## Best Practices

1. **API-First Always** — The spec is the source of truth. Code is the implementation. Never reverse this.
2. **Consumer-Driven Design** — Prototype with actual consumers before finalizing the spec. APIs designed in isolation get changed post-launch.
3. **Consistent Error Responses** — Use RFC 7807 Problem Details across every API in the org. One error schema, always.
4. **Pagination from Day One** — Every collection endpoint gets pagination at design time. Retrofitting pagination is a breaking change.
5. **Use HTTP Semantics** — Idempotent operations use PUT. Safe operations use GET. Status codes mean something — use them.
6. **AI-Ready Specs** — Well-structured OpenAPI specs allow AI to generate SDKs, tests, and documentation automatically. Invest in spec quality.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-generate OpenAPI spec from user story | AI + Spectral validation | L2 | S |
| Auto-generate SDK clients from OpenAPI | openapi-generator in CI | L2 | S |
| Breaking change detection in CI | oasdiff + GitHub Actions | L2 | S |
| Contract test stub generation from OpenAPI | Pact + AI | L3 | M |
| API changelog auto-generation from spec diffs | oasdiff + AI | L3 | M |

---

## AI Prompt Examples

### Prompt 1: Generate an OpenAPI Spec
```
Role: You are a senior developer designing a REST API.
Context: We need an API for a product catalog service. Products have: 
         id, name, description, price, category, stock_quantity, created_at.
         Consumers: mobile app, web frontend, third-party partner integrations.
Task: Generate a complete OpenAPI 3.1 specification for this API.
Constraints:
  - Resources: /products (collection), /products/{id}, /products/{id}/variants
  - Operations: CRUD for products, list with filtering (category, price range) and pagination
  - Auth: Bearer JWT
  - Error responses: RFC 7807 Problem Details format for all 4xx/5xx
  - Pagination: cursor-based on list endpoints
  - Include realistic example values for all schemas
Output format: Complete OpenAPI 3.1 YAML
```

### Prompt 2: Review an API Design for Issues
```
Role: You are a senior API architect performing a design review.
Context: [PASTE OPENAPI SPEC OR API DESCRIPTION]
Task: Review this API design and identify issues across these dimensions:
Constraints:
  - Check: REST compliance, naming consistency, HTTP method correctness,
    status code correctness, error handling completeness, security, 
    pagination, versioning, breaking change risks
  - Rate each issue: BLOCKER | WARNING | SUGGESTION
  - Provide specific remediation for each finding
Output format: Severity-grouped table with: Issue, Location, Impact, Remediation
```

---

## References & Further Reading

- [OpenAPI Specification](https://spec.openapis.org/oas/latest.html) — Canonical spec reference
- [Microsoft REST API Guidelines](https://github.com/microsoft/api-guidelines) — Enterprise-grade conventions
- [RFC 7807 Problem Details](https://www.rfc-editor.org/rfc/rfc7807) — Error response standard
- [OWASP API Security Top 10](https://owasp.org/www-project-api-security/) — Security vulnerabilities
- [Spectral](https://docs.stoplight.io/docs/spectral/) — OpenAPI linting
