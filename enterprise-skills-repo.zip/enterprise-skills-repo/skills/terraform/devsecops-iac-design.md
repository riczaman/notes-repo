---
id: "terraform.devsecops.iac-design"
title: "Infrastructure as Code with Terraform"
domain: "terraform"
role: "devsecops"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "dev-experience-chapter"
last_reviewed: "2026-05-27"
tags:
  - terraform
  - iac
  - infrastructure
  - devsecops
  - modules
  - state-management
prerequisites:
  skills:
    - "cloud-engineering.architect.cloud-native-patterns"
  tools:
    - "Terraform >= 1.5"
    - "AWS/GCP/Azure CLI"
    - "Atlantis or Terraform Cloud"
    - "tfsec or Checkov"
  certifications:
    - "HashiCorp Terraform Associate (recommended)"
related_skills:
  - "kubernetes.devsecops.deployment-strategies"
  - "cicd.devsecops.pipeline-design"
  - "security.devsecops.cloud-security-posture"
ai_indexable: true
---

# Infrastructure as Code with Terraform

> **Domain:** `terraform` | **Role:** `devsecops` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Infrastructure as Code (IaC) with Terraform is the practice of defining, provisioning, and managing cloud infrastructure through version-controlled declarative configuration files. This skill enables repeatable, auditable, and safe infrastructure changes across environments. DevSecOps engineers own Terraform practices to ensure infrastructure is consistent with security policies, cost controls, and architectural standards — and that infrastructure changes go through the same review rigor as application code.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Applies existing modules; runs `plan`/`apply` with guidance | Heavy — AI generates resource blocks |
| 2 | Practitioner | Writes new modules; manages state backends; resolves drift | Moderate — AI generates, human reviews |
| 3 | Advanced | Designs module libraries; implements policy-as-code; owns remote state strategy | Light — AI validates security posture |
| 4 | Expert | Defines org-wide IaC platform; builds internal module registry | Minimal |
| 5 | Distinguished | Contributes Terraform providers or modules to OSS | AI as research assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `3–5 months`

---

## Prerequisites

### Required Skills
- `cloud-engineering.architect.cloud-native-patterns` — must understand what you're provisioning

### Required Tools Access
- **Terraform >= 1.5** — local and CI execution
- **Atlantis or Terraform Cloud** — PR-based plan/apply workflow
- **tfsec / Checkov** — IaC security scanning
- **Cloud CLI (aws/gcloud/az)** — state inspection, manual remediation
- **S3 / GCS / Azure Blob** — remote state backend

### Required Knowledge
- Terraform resource, data source, module, provider concepts
- State management: remote backends, state locking, import
- Workspace strategy vs. directory-per-environment
- Terraform Cloud / Atlantis for team workflows
- Policy as Code: Open Policy Agent (OPA) / Sentinel

---

## Workflow

### Step 1: Module Design Before Resource Creation
Before writing any `resource` block, determine if an internal module exists. Check the internal module registry. If no module exists, design the module interface (inputs, outputs, locals) before writing the body.

**AI Assist:** `Yes` — "Generate a Terraform module interface for [resource type] with these requirements: [list]"

### Step 2: Backend & State Configuration
Configure remote state backend before first `init`. Use separate state files per environment. Enable state locking (DynamoDB for AWS, GCS native locking for GCP).

**Decision Gate:** Never use local state in non-local environments. CI/CD must fail if no remote backend is configured.

### Step 3: Variable & Sensitive Data Design
All configurable values as `variable` blocks. Sensitive values (passwords, keys) marked `sensitive = true`. Secrets sourced from Vault or cloud secrets manager — never as Terraform variables.

### Step 4: Security Scan (Pre-Plan)
Run `tfsec` or `Checkov` against all `.tf` files before `plan`. Fail on HIGH/CRITICAL findings. Document justified exceptions with `#tfsec:ignore` with explanation.

**AI Assist:** `Yes` — AI explains tfsec findings and suggests remediations

### Step 5: Plan Review (Atlantis / PR Workflow)
`terraform plan` output is attached to the PR automatically (Atlantis). Reviewers must read the plan, not just approve the code. Specific review checklist:
- Are destroy operations expected?
- Are changes scoped to the correct environment?
- Is sensitive data exposed in plan output?

### Step 6: Apply with Audit Trail
Apply runs via Atlantis (comment `atlantis apply`) or Terraform Cloud. Never apply locally against shared environments. Every apply creates an audit record.

### Step 7: Post-Apply Validation
Run automated validation: does the provisioned resource match the Terraform state? Use `terraform plan` immediately after apply — output should be "No changes."

### Step 8: Drift Detection
Schedule `terraform plan` in read-only mode daily against all environments. Alert on any drift (unexpected changes outside Terraform). Drift is a signal of unauthorized change or a bug.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Terraform CLI | Plan, apply, state management | Required | No |
| Atlantis | PR-based GitOps for Terraform | Required (shared envs) | No |
| tfsec / Checkov | IaC security scanning | Required | No |
| Infracost | Cost estimation from plan | Optional | No |
| Terragrunt | DRY wrapper for modules | Optional | No |
| OPA / Sentinel | Policy as code | Optional (L3+) | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Terraform State in Git
**What it looks like:** `terraform.tfstate` committed to the repository  
**Why it's harmful:** State contains sensitive values in plaintext. Concurrent applies corrupt state. Git is not a state backend.  
**Remediation:** Migrate to remote backend immediately. Add `*.tfstate` to `.gitignore`.

### ❌ Anti-Pattern 2: Environment-Specific Hardcoded Values in Modules
**What it looks like:** `instance_type = "t3.large"` hardcoded inside a module  
**Why it's harmful:** Module is not reusable across environments. Changes require module modification, not variable override.  
**Remediation:** Every environment-specific value must be a variable with a sensible default.

### ❌ Anti-Pattern 3: Manual `terraform apply` Against Production
**What it looks like:** Engineer SSHes into CI machine or runs apply from laptop against prod  
**Why it's harmful:** No audit trail, no peer review, no rollback mechanism, high blast radius.  
**Remediation:** Production applies via Atlantis or Terraform Cloud only. Block direct CLI access at IAM level.

### ❌ Anti-Pattern 4: Monolithic Root Modules
**What it looks like:** Single `main.tf` with 2,000 lines defining all infrastructure for all environments  
**Why it's harmful:** Single blast radius for all changes. Plan/apply takes 20+ minutes. Team conflicts constantly.  
**Remediation:** Decompose by: environment + layer (network, compute, database, application). Each layer has its own state.

---

## Troubleshooting Guide

### Problem: Terraform state lock not released after failed apply
**Root Cause(s):** CI runner crashed mid-apply; network interruption; manual SIGKILL  
**Diagnostic Steps:**
1. Check lock info: `terraform force-unlock --help`; get lock ID from error message
2. Verify the apply is not still running in another process  
**Resolution:** `terraform force-unlock <LOCK_ID>` — requires confirmation this is safe  
**Prevention:** Implement timeouts on CI runners. Use Atlantis which handles lock release on failure.

### Problem: Drift detected — resource exists in cloud but not in state
**Root Cause(s):** Resource created manually (clickops); imported resource not in state  
**Diagnostic Steps:**
1. Identify the resource ARN/ID from the cloud console
2. Check if it was intentionally created outside Terraform  
**Resolution:** Import: `terraform import <resource_type>.<name> <id>` then add resource block  
**Prevention:** Use AWS Config or GCP Policy Intelligence to detect out-of-band changes.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Production destroy detected in plan | Engineering Manager + Architect | Immediate | `#terraform-alerts` + Slack DM |
| State corruption suspected | Senior DevSecOps + Cloud Engineer | 1 hour | `#engineering-ops` |
| tfsec CRITICAL finding in prod module | Security Engineer | 4 hours | `#security-escalations` |
| Unexpected cost spike from Infracost (+>30%) | FinOps + Engineering Manager | 48 hours | Terraform PR comment + `#finops` |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| IaC coverage (% infra managed by Terraform) | 55% | >90% | Cloud asset inventory vs. Terraform state |
| Drift incidents per month | 8 | <2 | Drift detection alerts |
| Plan-to-apply cycle time | 3 days | <4 hours | Atlantis PR analytics |
| tfsec HIGH/CRITICAL findings in production | 12 | 0 | tfsec report |
| Module reuse rate | 30% | >70% | Module registry analytics |

---

## Best Practices

1. **One Module Per Concern** — A module should provision one logical thing. `vpc`, `eks-cluster`, `rds-postgres` — not `all-infrastructure`.
2. **Version Pin Providers and Modules** — Always pin versions. Unpinned dependencies break plans after upstream releases.
3. **Locals for Computed Values** — Use `locals` for computed values, tag maps, and name standardization. Keeps resources readable.
4. **Tagging Strategy in Modules** — Every resource must include standard tags: `environment`, `owner`, `cost-center`, `managed-by = terraform`. Enforce in modules.
5. **Test Your Modules** — Use Terratest or `terraform test` (native, 1.6+). Untested modules are technical debt.
6. **Plan Output is the Deliverable** — In PR review, the plan output is more important than the code. Review what Terraform will DO, not just what it says.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-generate Terraform resource from architecture diagram | AI + template library | L2 | M |
| Automated cost estimation on every PR | Infracost + GitHub Actions | L2 | S |
| Drift detection + auto-ticket creation | Terraform Cloud + Jira API | L3 | M |
| Policy-as-code enforcement (blocking non-compliant resources) | OPA + Atlantis | L3 | L |
| Module documentation auto-generation | terraform-docs in CI | L2 | S |

---

## AI Prompt Examples

### Prompt 1: Generate a Terraform Module
```
Role: You are a DevSecOps engineer designing a reusable Terraform module.
Context: We need a module for provisioning an AWS RDS PostgreSQL instance.
         Our standards: encrypted at rest, enhanced monitoring enabled, 
         automated backups, no public accessibility, parameter group customizable.
Task: Generate a complete Terraform module with variables, outputs, and main.tf.
Constraints:
  - Module inputs: engine_version, instance_class, storage_gb, db_name, 
    subnet_ids, vpc_id, tags (map)
  - All sensitive outputs marked sensitive=true
  - Include: security group, subnet group, parameter group
  - Follow tfsec best practices (no public access, encryption enforced)
  - Include README.md with usage example
Output format: Separate code blocks for each file (main.tf, variables.tf, outputs.tf, README.md)
```

### Prompt 2: Explain a Terraform Plan
```
Role: You are a senior DevSecOps engineer reviewing a Terraform plan.
Context: [PASTE TERRAFORM PLAN OUTPUT]
Task: Explain this plan in plain English for a non-Terraform engineer to review.
Constraints:
  - Highlight any DESTROY operations and explain their impact
  - Flag any changes that could cause downtime
  - Flag any security-relevant changes (security groups, IAM, encryption)
  - Estimate blast radius (low/medium/high)
Output format: Executive summary (3 sentences), then itemized change analysis
```

---

## References & Further Reading

- [Terraform Documentation](https://developer.hashicorp.com/terraform/docs) — Official reference
- [Terraform Best Practices](https://www.terraform-best-practices.com) — Community guide
- [tfsec](https://aquasecurity.github.io/tfsec/) — IaC security scanning
- [Atlantis](https://www.runatlantis.io/docs/) — PR workflow for Terraform
