---
id: "incident-response.devsecops.incident-command"
title: "Incident Response & Command"
domain: "incident-response"
role: "devsecops"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "reliability-chapter"
last_reviewed: "2026-05-27"
tags: [incident-response, on-call, postmortem, runbooks, sre, incident-command]
prerequisites:
  skills: ["monitoring.devsecops.observability-platform"]
  tools: ["PagerDuty", "Slack", "StatusPage", "Jira"]
  certifications: ["none"]
related_skills: ["root-cause-analysis.ba.rca-methods", "monitoring.devsecops.observability-platform"]
ai_indexable: true
---

# Incident Response & Command

> **Domain:** `incident-response` | **Role:** `devsecops` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Incident Response & Command is the structured practice of detecting, responding to, and recovering from production incidents. It covers the full incident lifecycle: detection through alerts or user reports, triage and severity classification, coordinated response via the Incident Command Structure (ICS), communication to stakeholders, resolution, and blameless post-mortem. Effective incident response reduces MTTR (Mean Time To Restore), protects user trust, and generates the learning that prevents recurrence.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Follows runbook steps; participates in incident bridge; escalates appropriately | Heavy — AI summarizes dashboards and suggests runbook steps |
| 2 | Practitioner | Leads P2/P3 incidents; writes postmortems; creates runbooks | Moderate — AI drafts comms and postmortems |
| 3 | Advanced | Commands P0/P1 incidents; improves incident process; mentors responders | Light — AI validates timeline reconstruction |
| 4 | Expert | Designs incident management platform; owns on-call health; trains org | Minimal |
| 5 | Distinguished | Publishes incident management frameworks; SRE community contributor | AI as research assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `3–6 months`

---

## Prerequisites

### Required Skills
- `monitoring.devsecops.observability-platform` — can't respond to what you can't see

### Required Tools Access
- **PagerDuty / OpsGenie** — on-call scheduling and alert routing
- **Slack** — `#incidents` channel, incident bridge
- **StatusPage** — external customer-facing status communication
- **Jira / Linear** — incident tracking and action item management
- **Video conferencing** — incident bridge calls

### Required Knowledge
- Incident severity classification (P0–P4)
- Incident Command Structure (IC, Comms Lead, Operations Lead roles)
- Blameless post-mortem principles
- SLO and error budget concepts
- On-call ergonomics and sustainable on-call practices

---

## Workflow

### Step 1: Detection & Initial Triage (0–5 minutes)
Alert fires or user report received. First responder:
1. Acknowledge the alert in PagerDuty (stops escalation timer)
2. Open `#incidents` Slack channel or create incident thread
3. Check the service's golden dashboard: are the 4 golden signals degraded?
4. Assess scope: one service? multiple? customer-facing?
5. Classify severity:

| Severity | Definition | Example |
|---|---|---|
| P0 | Complete customer-facing outage; revenue impact; data loss | Checkout down; auth down |
| P1 | Significant degradation; >10% of users affected | 5x latency; 20% error rate |
| P2 | Partial degradation; workaround exists; <10% affected | One region slow |
| P3 | Minor issue; no immediate user impact; resolved in business hours | Background job failing |
| P4 | Cosmetic / informational | Dashboard display error |

### Step 2: Incident Bridge Setup (P0/P1 only, <5 minutes)
- Open incident bridge (Zoom/Teams)
- Assign roles: **Incident Commander** (decision authority), **Comms Lead** (stakeholder updates), **Ops Lead** (technical investigation)
- Post initial status to `#incidents`: "P1 declared. [Service X] is degraded. IC: @name. Bridge: [link]"

### Step 3: Investigation (Parallel with Communication)
**Ops Lead drives technical investigation:**
- What changed? (recent deployments, config changes, infrastructure events)
- Check distributed traces for error spike origin
- Check logs: `grep -i error` on the relevant time window
- Hypothesis → test → confirm/reject → next hypothesis

**AI Assist:** `Yes` — "Given these error logs and this trace, what is the most likely root cause?"

**Comms Lead drives stakeholder updates (every 15 minutes for P0/P1):**
- Internal: `#incidents` channel update
- External: StatusPage update for customer-impacting incidents
- Format: "We are investigating [issue]. Impact: [who/what affected]. Next update: [time]."

### Step 4: Mitigation (Restore Before Root Cause)
Restore service first; understand root cause second. Acceptable mitigations:
- Rollback deployment
- Feature flag disable
- Traffic shift / failover
- Increase replicas
- Disable a non-critical component

**Decision Gate:** IC approves all mitigation actions. No unilateral changes during a P0/P1.

### Step 5: Resolution & All-Clear
Confirm resolution: metrics returning to normal (check SLO SLI for 5 minutes of clean data). Post all-clear to `#incidents` and update StatusPage to "Resolved." Capture: start time, end time, duration, impact summary.

### Step 6: Post-Mortem (Within 48 Hours of Resolution)
Blameless post-mortem required for all P0/P1 incidents and any P2 that was novel or had significant learning. Template:
- **Timeline**: minute-by-minute reconstruction
- **Root Cause(s)**: contributing factors, not a single "human error"
- **Impact**: users affected, revenue impact, SLO burn
- **What went well**
- **What went poorly**
- **Action items**: specific, owned, time-bound

**AI Assist:** `Yes` — AI drafts the timeline from Slack thread and alert history; human validates

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| PagerDuty | Alert routing, escalation, on-call scheduling | Required | No |
| Slack | Incident coordination, `#incidents` channel | Required | No |
| StatusPage | External customer communication | Required (P0/P1) | No |
| Grafana | Investigation dashboards | Required | No |
| Jira | Incident ticket and action item tracking | Required | No |
| Zoom / Teams | Incident bridge | Required (P0/P1) | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Hero Culture (One Person Solves Everything)
**What it looks like:** The same senior engineer always saves the day during incidents. No one else knows the system.  
**Why it's harmful:** Single point of failure. Unsustainable for the individual. Organization learns nothing.  
**Remediation:** Enforce IC role rotation. Require the hero to document runbooks while they fix things. Game day exercises for other engineers.

### ❌ Anti-Pattern 2: Root Cause = Human Error
**What it looks like:** Post-mortem concludes "Engineer X pushed bad code."  
**Why it's harmful:** Systems should be designed to prevent humans from easily causing outages. "Human error" as root cause guarantees recurrence.  
**Remediation:** Ask "why" 5 times. Why did the engineer push bad code? Why was there no automated test? Why did it reach production? The system design is the root cause.

### ❌ Anti-Pattern 3: Postmortem Theater
**What it looks like:** Postmortem is written, action items are created, they sit in Jira for months unresolved.  
**Why it's harmful:** The same incident happens again 3 months later.  
**Remediation:** Postmortem action items are tracked in sprint planning with the same priority as features. EM reviews completion at monthly reliability review.

### ❌ Anti-Pattern 4: Silent Incidents (No Customer Communication)
**What it looks like:** P0 outage for 45 minutes; no StatusPage update; customers find out from social media.  
**Why it's harmful:** Destroys customer trust. Customers experience uncertainty on top of impact.  
**Remediation:** First StatusPage update within 10 minutes of P0/P1 declaration. Even "We are investigating" is better than silence.

---

## Troubleshooting Guide

### Problem: On-call engineer can't find the right runbook during incident
**Root Cause(s):** Runbooks not linked from alerts; runbooks outdated; too many runbooks with poor naming  
**Diagnostic Steps:**
1. Check: does the alert description contain a runbook link?
2. Check: was the runbook last updated after the most recent architecture change?  
**Resolution:** Update alert annotations to include runbook link. Runbook URL format: `https://wiki.company.com/runbooks/<service>/<symptom>`  
**Prevention:** Runbook link is a required field in the alert YAML template. Validated in CI.

### Problem: Incident bridge has 20 people but no one is coordinating
**Root Cause(s):** No IC assigned; everyone talking at once; no clear action ownership  
**Diagnostic Steps:**
1. Identify who is most senior on the call
2. Explicitly ask them to take IC role  
**Resolution:** IC immediately: "I'm IC. Ops Lead: [name]. Comms Lead: [name]. Everyone else: observe and respond to directed questions only."  
**Prevention:** IC assignment is step 1 of the incident bridge checklist. Enforce with Slack bot prompt.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| P0 declared | Engineering Manager + VP Engineering | Immediate | PagerDuty escalation + direct call |
| P0 > 30 min unresolved | CTO (if customer data at risk or major revenue impact) | 30 minutes | Direct call |
| Data loss suspected | CISO + Legal + Engineering Manager | Immediate | Private incident channel |
| Media / customer executive escalation | VP Customer Success + VP Engineering | Immediate | Executive escalation bridge |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| MTTR — P0 | 87 minutes | <30 minutes | PagerDuty incident duration |
| MTTR — P1 | 3.5 hours | <1 hour | PagerDuty incident duration |
| Postmortem completion rate (within 48h) | 55% | >95% | Jira postmortem ticket tracking |
| Action item resolution rate (within 2 sprints) | 30% | >80% | Jira sprint tracking |
| On-call pages per shift (p95) | 12 | <5 | PagerDuty analytics |
| Time to first customer communication (P0) | 28 minutes | <10 minutes | StatusPage + incident timestamp |

---

## Best Practices

1. **Restore First, Understand Second** — User impact is the emergency. Root cause analysis can happen after service is restored.
2. **The IC Does Not Debug** — The Incident Commander coordinates; they do not write code or dig through logs. Separation of duties under pressure.
3. **Write the Timeline in Real Time** — Post updates to `#incidents` as events happen. Reconstruction from memory is error-prone.
4. **Blameless = Systemic** — If the post-mortem names a person as the cause, it's not done yet.
5. **Runbooks are Living Documents** — Update runbooks during the incident or immediately after. The next on-call depends on it.
6. **Sustainable On-Call** — No engineer should be paged more than 3 times during a sleep window. Alert tuning is reliability work.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-draft incident postmortem from Slack thread | AI + Slack API | L2 | M |
| Auto-create StatusPage incident from PagerDuty alert | PagerDuty + StatusPage API | L2 | S |
| AI-assisted runbook lookup during incident | AI + runbook RAG | L3 | M |
| On-call health scoring dashboard | PagerDuty API + Grafana | L3 | M |
| Automated timeline reconstruction from logs | AI + log aggregation API | L3 | L |

---

## AI Prompt Examples

### Prompt 1: Draft an Incident Post-Mortem
```
Role: You are a reliability engineer writing a blameless post-mortem.
Context: Here is the incident Slack thread and alert timeline:
  [PASTE SLACK THREAD OR TIMELINE NOTES]
Task: Draft a complete blameless post-mortem document.
Constraints:
  - Sections: Executive Summary, Timeline, Root Causes (5-why analysis), 
    Impact (users, revenue, SLO), What Went Well, What Went Poorly, Action Items
  - Blameless: no individual names as root causes; focus on systemic factors
  - Action items: specific, measurable, assigned (use [OWNER] placeholder), time-bound
  - Timeline: minute-by-minute, past tense, factual only
Output format: Markdown document ready for Confluence publication
```

### Prompt 2: Diagnose Incident from Logs
```
Role: You are an on-call engineer investigating a production incident.
Context: The payment service error rate spiked to 15% starting at 14:32 UTC.
  Recent changes: deployment at 14:15 UTC (diff: [PASTE DIFF])
  Error logs (14:32-14:45 UTC): [PASTE LOG SAMPLE]
  Distributed trace sample: [PASTE TRACE]
Task: Identify the most likely root cause and recommend immediate mitigation steps.
Constraints:
  - Prioritize speed over certainty — this is an active incident
  - Provide: most likely cause, confidence level, mitigation options ranked by speed/risk
  - Flag any data loss or security implications immediately
Output format: DIAGNOSIS (2 sentences), TOP 3 MITIGATIONS (ordered by recommended priority)
```

---

## References & Further Reading
- [Google SRE Book — Incident Management](https://sre.google/sre-book/managing-incidents/) — Canonical ICS reference
- [PagerDuty Incident Response Guide](https://response.pagerduty.com) — Practical playbook
- [Etsy's Debriefing Facilitation Guide](https://extfiles.etsy.com/DebriefingFacilitationGuide.pdf) — Blameless postmortem guide
