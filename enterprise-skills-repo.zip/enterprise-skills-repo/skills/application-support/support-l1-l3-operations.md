---
id: "application-support.support-analyst.l1-l3-operations"
title: "Application Support Operations (L1–L3)"
domain: "application-support"
role: "support-analyst"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "support-chapter"
last_reviewed: "2026-05-27"
tags: [support, l1, l2, l3, triage, ticketing, customer-support, incident-triage]
prerequisites:
  skills: []
  tools: ["Zendesk or ServiceNow", "Jira", "Confluence (runbooks)", "Grafana (read-only)"]
  certifications: ["ITIL Foundation (recommended)"]
related_skills: ["incident-response.devsecops.incident-command", "root-cause-analysis.business-analyst.rca-methods"]
ai_indexable: true
---

# Application Support Operations (L1–L3)

> **Domain:** `application-support` | **Role:** `support-analyst` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Application Support Operations covers the full support lifecycle from first contact triage (L1) through complex technical investigation (L3). Support Analysts are often the first humans to detect emerging issues from customer-reported symptoms, making their triage quality a critical input to incident detection and MTTR. AI transforms support operations by triaging tickets, suggesting resolutions from historical cases, and surfacing trending issues before they become widespread incidents.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | L1 — Triage | Classifies tickets; applies known fixes from runbooks; escalates to L2 | Heavy — AI suggests resolution from knowledge base |
| 2 | L2 — Investigation | Investigates novel issues; queries logs; resolves without escalation | Moderate — AI queries logs, suggests RCA paths |
| 3 | L3 — Engineering Support | Works alongside engineering on complex/systemic issues; writes runbooks | Light — AI assists with log analysis |
| 4 | Expert | Designs support processes; builds knowledge base; trains team | Minimal |
| 5 | Distinguished | Published support engineering practices; ITIL expert | AI as productivity tool |

**Current team target level:** `2`
**Expected time to Practitioner (L2):** `3–6 months`

---

## Prerequisites

### Required Tools Access
- **Zendesk / ServiceNow** — ticket management
- **Jira** — escalation to engineering
- **Confluence** — runbook access
- **Grafana (read-only)** — service health dashboards
- **Log access (Kibana / Grafana Loki)** — investigation

### Required Knowledge
- ITIL service management basics (incident, problem, change)
- Ticket triage and classification methodology
- Escalation criteria by tier
- Application knowledge: business process flows, common failure modes
- Log reading: JSON log format, common error patterns
- SLA awareness: response and resolution time commitments by severity

---

## Workflow

### Step 1: Ticket Receipt & Initial Classification (L1, Target: <5 minutes)
Every ticket classified on receipt:

| Category | Severity | SLA (Response) | SLA (Resolution) |
|---|---|---|---|
| System outage (no access) | P1 | 15 minutes | 2 hours |
| Significant degradation | P2 | 30 minutes | 4 hours |
| Partial impairment, workaround exists | P3 | 2 hours | 8 hours |
| General question, minor issue | P4 | 4 hours | 3 business days |

**AI Assist:** `Yes` — AI classifies ticket severity and suggests category based on description

### Step 2: Knowledge Base Search (L1)
Before any investigation, search the knowledge base for this exact issue or similar symptoms. If a known resolution exists: apply it, document the outcome, close.

**AI Assist:** `Yes` — "Find similar tickets and their resolutions for: [ticket description]"

### Step 3: Impact Assessment
Determine: how many users/accounts are affected? Is this isolated or widespread? Use Grafana to check service-level metrics. If widespread → potential incident → notify on-call team immediately.

**Decision Gate:** If >50 users affected OR a Tier 0 customer affected → escalate to engineering on-call immediately, don't wait for L2.

### Step 4: L1 Resolution Attempt
Apply runbook steps for known issues. Document every step taken (with timestamps). If resolved: document the resolution for knowledge base. If not resolved within 30 minutes: escalate to L2.

### Step 5: L2 Investigation
L2 digs into root cause without necessarily fixing it. Tools: log queries, API testing, database queries (read-only), configuration review.

Investigation log template:
```
Ticket: [ID]
Timeline: [when issue started]
Scope: [affected users/features]
Evidence: [logs, error messages, screenshots]
Hypotheses: [list, tested one by one]
Conclusion: [what was found]
```

**AI Assist:** `Yes` — "Analyze these error logs and identify the most likely cause of the issue"

### Step 6: L2 Resolution or L3 Escalation
If L2 can resolve: document fully and close. If not: escalate to L3 (engineering) with a complete investigation handoff — timeline, evidence, hypotheses tested, current impact.

**Decision Gate:** L3 escalation requires a complete investigation document. No escalation without evidence.

### Step 7: L3 Engineering Resolution
Engineering resolves the issue. Support analyst:
- Remains the customer communication point of contact
- Updates the customer every 30 minutes (P1/P2)
- Confirms resolution with the customer before closing
- Captures the fix as a new runbook if it was a novel issue

### Step 8: Post-Ticket Knowledge Capture
Every novel issue resolved → create or update a runbook in Confluence. This is how the knowledge base grows.

**AI Assist:** `Yes` — "Convert this investigation log into a structured runbook for future reference"

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Zendesk / ServiceNow | Ticket management, SLA tracking | Required | Yes (AI triage/suggestions) |
| Jira | Engineering escalation tracking | Required | No |
| Confluence | Runbook and knowledge base | Required | Yes (AI searches) |
| Grafana (read-only) | Service health context | Required | No |
| Kibana / Loki | Log investigation | Required (L2/L3) | Yes (AI queries) |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Escalating Without Investigation
**What it looks like:** L1 immediately escalates to L2/L3 without checking the knowledge base or attempting any resolution.  
**Why it's harmful:** Engineering is flooded with tickets that have known fixes. Support adds no value.  
**Remediation:** L1 must check knowledge base and attempt known resolution before escalating. Track L1 resolution rate as a KPI.

### ❌ Anti-Pattern 2: Closing Tickets Without Customer Confirmation
**What it looks like:** Analyst resolves the issue (from their perspective) and closes the ticket without verifying the customer agrees.  
**Why it's harmful:** Customer re-opens ticket. CSAT suffers. Issue may not actually be resolved.  
**Remediation:** All P1/P2 tickets: confirm with the customer via call or email. Auto-close policy: P3/P4 can auto-close after 3 business days with no customer response, with a notification.

### ❌ Anti-Pattern 3: Investigation Without Documentation
**What it looks like:** Analyst investigates for 2 hours, resolves the issue, closes the ticket with "Fixed" as the resolution note.  
**Why it's harmful:** The next time this happens, the next analyst starts from zero. Knowledge is lost.  
**Remediation:** Resolution notes must include: root cause (brief), steps taken, resolution applied, prevention recommendation.

### ❌ Anti-Pattern 4: Missing Trending Issues
**What it looks like:** 30 tickets about the same error in one week, each resolved individually. No one identifies the pattern.  
**Why it's harmful:** A systemic issue goes undetected and unfixed. Support load grows.  
**Remediation:** Weekly ticket trend review. AI-powered ticket clustering to surface patterns. Ticket tagging for root cause enables trend reporting.

---

## Troubleshooting Guide

### Problem: High ticket reopen rate (>15%)
**Root Cause(s):** Resolution was temporary workaround only; customer wasn't fully trained; root cause not fixed by engineering  
**Diagnostic Steps:**
1. Sample reopened tickets — what was the original resolution?
2. Are reopens from the same customers or spread across the base?  
**Resolution:** Identify systematic root causes of reopens. Flag to engineering if systemic.  
**Prevention:** Resolution quality gate: analyst must classify resolution type (permanent fix / workaround / known limitation / user error).

### Problem: SLA breach rate increasing
**Root Cause(s):** Ticket volume spike; understaffing; routing misconfiguration; too many tickets bouncing between tiers  
**Diagnostic Steps:**
1. SLA breach by severity: which tier is worst?
2. SLA breach by ticket category: which issue types take longest?
3. Check: is there a volume spike in a specific category?  
**Resolution:** Adjust staffing, improve runbooks for high-volume categories, tune AI triage for accuracy.  
**Prevention:** Weekly SLA trend review; alert when breach rate exceeds 10%.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| >50 users affected by same issue | Engineering On-call + EM | Immediate | PagerDuty + `#incidents` |
| Tier-1 (enterprise) customer P1 | L3 + Customer Success Manager | 15 minutes | Direct call + ticket |
| Potential data loss or security issue | Security Engineer + CISO | Immediate | `#security-incidents` |
| L2 unable to resolve within 2 hours (P1) | Engineering On-call | Immediate | PagerDuty |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| L1 resolution rate (without escalation) | 40% | >65% | Zendesk tier tracking |
| First response SLA compliance | 78% | >95% | Zendesk SLA report |
| Customer Satisfaction Score (CSAT) | 3.4/5 | >4.3/5 | Post-ticket survey |
| Mean time to resolve P2 | 6 hours | <3 hours | Zendesk ticket analytics |
| Ticket reopen rate | 18% | <8% | Zendesk analytics |
| Knowledge base articles per month | 2 | >8 | Confluence article creation tracking |

---

## Best Practices

1. **Acknowledge Before You Investigate** — Customer knows you're on it within the SLA, even if you don't have an answer yet.
2. **Reproduce Before Resolving** — Can you reproduce the issue? If not, you don't understand it yet. Don't guess.
3. **One Ticket, Full History** — All investigation notes, timestamps, and communications in the ticket. No side channels.
4. **Trending Is the Signal** — Individual tickets are events. Patterns are signals. Review trends weekly.
5. **Every Novel Issue Becomes a Runbook** — If you had to figure it out, the next analyst shouldn't have to.
6. **Empathy First** — The customer's perception of urgency matters, even if the technical severity is low. Acknowledge their experience.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI ticket triage and severity classification | AI + Zendesk API | L2 | M |
| AI-suggest resolution from knowledge base | AI + Confluence RAG | L2 | M |
| Automated ticket clustering for trend detection | AI + Zendesk analytics | L3 | M |
| Auto-create Jira escalation from Zendesk ticket | Zendesk + Jira integration | L2 | S |
| AI-generate runbook from investigation log | AI + Confluence API | L2 | M |

---

## AI Prompt Examples

### Prompt 1: Triage a Support Ticket
```
Role: You are an L1 support analyst triaging an incoming ticket.
Context: Our application is a B2B SaaS project management platform.
Ticket content: [PASTE TICKET TEXT]
Task: Triage this ticket.
Constraints:
  - Classify: severity (P1-P4), category (access, performance, data, billing, feature, bug)
  - Search for similar resolved tickets: [PASTE 3 SIMILAR HISTORICAL TICKETS]
  - Suggest: most likely resolution based on history
  - Identify: any escalation triggers (security, data loss, major customer)
Output format: Triage summary with severity, category, suggested resolution, escalation recommendation
```

### Prompt 2: Generate a Runbook from an Investigation Log
```
Role: You are a support engineer creating a runbook from a resolved investigation.
Context: Here is the investigation log from a ticket we just resolved:
  [PASTE INVESTIGATION LOG]
Task: Convert this into a structured runbook for future support analysts.
Constraints:
  - Sections: Issue Description, Symptoms, Diagnostic Steps (with expected outputs), 
    Resolution Steps, Verification, Escalation Criteria, Prevention
  - Write for an L1 analyst who is not a technical expert
  - Include: exact log patterns to search for, exact resolution steps
  - Note: what does a successful resolution look like?
Output format: Markdown runbook ready for Confluence
```

---

## References & Further Reading
- [ITIL 4 Foundation](https://www.axelos.com/certifications/itil-service-management/itil-4-foundation) — Service management framework
- [Zendesk Support Guide](https://support.zendesk.com/hc/en-us) — Platform documentation
- [The Art of Support](https://www.helpscout.com/blog/) — Customer support best practices
