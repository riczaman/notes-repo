---
id: "ai-engineering.senior-dev.ai-systems-engineering"
title: "AI Systems Engineering"
domain: "ai-engineering"
role: "senior-dev"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "ai-chapter"
last_reviewed: "2026-05-27"
tags: [ai, llm, rag, embeddings, fine-tuning, ai-engineering, mlops, langchain]
prerequisites:
  skills: ["coding.senior-dev.clean-code-practices", "apis.senior-dev.api-design"]
  tools: ["Python", "OpenAI/Anthropic SDK", "LangChain or LlamaIndex", "Vector DB (Pinecone/Weaviate/pgvector)"]
  certifications: ["none (AWS/GCP AI certifications recommended for L3+)"]
related_skills: ["prompt-engineering.senior-dev.prompt-engineering", "cicd.devsecops.pipeline-design"]
ai_indexable: true
---

# AI Systems Engineering

> **Domain:** `ai-engineering` | **Role:** `senior-dev` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

AI Systems Engineering is the practice of designing, building, deploying, and operating production-grade AI-powered applications. This goes beyond using LLM APIs — it covers retrieval-augmented generation (RAG) pipelines, evaluation frameworks, model selection, observability for AI systems, cost management, and the engineering discipline needed to make AI features reliable, safe, and maintainable. Senior Developers with this skill can ship AI features that work in production, not just in demos.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Calls LLM API; builds a basic chatbot with prompt templating | Heavy — uses AI to help build AI |
| 2 | Practitioner | Builds RAG pipelines; implements evaluation; manages costs; ships to production | Moderate |
| 3 | Advanced | Designs multi-agent systems; implements fine-tuning; owns AI platform | Light |
| 4 | Expert | Defines AI engineering standards; AI safety governance; model selection framework | Minimal |
| 5 | Distinguished | Published AI systems research; contributes to OSS AI frameworks | Research-level |

**Current team target level:** `2`
**Expected time to Practitioner (L2):** `4–8 months`

---

## Prerequisites

### Required Skills
- `coding.senior-dev.clean-code-practices` — clean engineering discipline applies to AI code
- `apis.senior-dev.api-design` — AI systems expose and consume APIs

### Required Tools Access
- **Python** — primary language for AI engineering
- **Anthropic Claude or OpenAI API** — LLM inference
- **LangChain or LlamaIndex** — AI application frameworks
- **Vector database** — Pinecone, Weaviate, or pgvector
- **LangSmith or Langfuse** — AI observability and tracing

### Required Knowledge
- LLM fundamentals: tokens, context window, temperature, top-p, stop sequences
- Embedding models and vector similarity search (cosine similarity, ANN algorithms)
- RAG pipeline: chunking, embedding, retrieval, re-ranking, generation
- Prompt engineering basics (see `prompt-engineering.senior-dev.prompt-engineering`)
- AI safety: prompt injection, jailbreaks, PII leakage, hallucination
- Token costs and optimization strategies
- Evaluation metrics: BLEU, ROUGE, semantic similarity, human eval, LLM-as-judge

---

## Workflow

### Step 1: Problem Suitability Assessment
Before building an AI feature, assess: is AI the right tool?

| Use AI when... | Don't use AI when... |
|---|---|
| Output is hard to specify as a rule | Output can be defined by deterministic rules |
| Natural language input/output | Structured data, SQL queries, calculations |
| Semantic understanding required | Exact pattern matching (use regex) |
| Personalization at scale needed | Single deterministic answer exists |

**AI Assist:** `Yes` — "Given this feature requirement, assess whether an LLM or a rule-based system is more appropriate"

### Step 2: Architecture Selection

| Pattern | When to Use | Complexity |
|---|---|---|
| Direct LLM call | Single-turn Q&A, classification, generation | Low |
| RAG pipeline | Q&A over private documents, knowledge bases | Medium |
| Conversational agent | Multi-turn with memory, user sessions | Medium |
| Tool-calling agent | When LLM needs to take actions (API calls, DB queries) | High |
| Multi-agent system | Complex workflows requiring specialization | Very High |

### Step 3: RAG Pipeline Design (if applicable)
RAG pipeline stages:
1. **Document ingestion** — load, clean, and parse source documents
2. **Chunking** — split into chunks (strategy: fixed-size, sentence, semantic, recursive)
3. **Embedding** — convert chunks to vector representations
4. **Indexing** — store in vector database with metadata
5. **Retrieval** — query-time: embed query, ANN search, filter by metadata
6. **Re-ranking** — cross-encoder re-ranking for precision (optional but recommended)
7. **Generation** — inject retrieved context into LLM prompt
8. **Post-processing** — validate, format, cite sources

**Decision Gate:** Chunk size and overlap must be validated with retrieval evaluation before production. Default chunk size (512 tokens, 50 overlap) is a starting point, not a universal truth.

### Step 4: Evaluation Framework (Before Ship, Always)
Build evals before shipping any AI feature. Types:
- **Unit evals**: test individual prompt templates with golden test cases
- **Retrieval evals**: precision@k, recall@k, MRR for RAG retrieval stage
- **End-to-end evals**: full pipeline quality (RAGAS framework for RAG)
- **LLM-as-judge**: use a separate LLM to score output quality
- **Human evals**: for high-stakes outputs, always include a human eval phase

**AI Assist:** `Yes` — AI generates test cases and evaluation harnesses

**Decision Gate:** No AI feature ships without a documented eval baseline. No regressions allowed (eval score must not drop on release).

### Step 5: Observability Integration
Instrument every AI call with:
- Input tokens, output tokens, cost per call
- Latency (model response time, total pipeline time)
- Model version used
- Retrieved document IDs (RAG)
- User feedback signal (thumbs up/down if available)

Use LangSmith or Langfuse for AI-specific tracing. Feed metrics to Grafana.

### Step 6: Safety & Guardrails
Implement input and output guardrails:
- **Input**: detect and block prompt injection attempts, PII in inputs (use NER or regex)
- **Output**: detect and filter PII in outputs, hallucinations (factual grounding check), toxicity
- **Rate limiting**: per-user and per-tenant token limits
- **Content policy**: align with org's AI usage policy

### Step 7: Cost Management
Estimate token costs per feature at design time. Implement:
- Token counting before calls (don't let users send 100K-token inputs)
- Caching for identical or semantically similar queries (semantic cache)
- Model selection by task: use cheaper/faster models for simple tasks, expensive models for complex
- Streaming for UX (don't make users wait for full completion)

### Step 8: MLOps & Model Management
Track: model version, prompt version, eval scores, cost per query in a model card. Implement prompt versioning alongside code. Changes to production prompts go through PR review and eval validation.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Anthropic / OpenAI SDK | LLM inference | Required | — |
| LangChain / LlamaIndex | AI application framework | Required | — |
| Pinecone / pgvector | Vector storage | Required (RAG) | — |
| LangSmith / Langfuse | AI observability and tracing | Required | — |
| RAGAS | RAG evaluation framework | Required (RAG) | — |
| Guardrails AI / NeMo Guardrails | Safety guardrails | Recommended | — |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Shipping AI Features Without Evals
**What it looks like:** "It looks good in my testing" — no structured evaluation, no baseline, no regression test.  
**Why it's harmful:** LLM outputs are non-deterministic. Quality silently degrades with model updates, prompt changes, or data drift. You won't know until users complain.  
**Remediation:** Eval framework is built before the feature ships. Evals run in CI on every prompt or retrieval change.

### ❌ Anti-Pattern 2: Using a Single Large Model for Everything
**What it looks like:** Every AI call uses GPT-4 Turbo or Claude Opus — even for simple classification tasks.  
**Why it's harmful:** Costs 10–50× more than necessary. Latency is unnecessarily high.  
**Remediation:** Match model to task. Classification, extraction, and simple generation → small/fast model. Complex reasoning, nuanced generation → large model.

### ❌ Anti-Pattern 3: Prompt Injection Blindness
**What it looks like:** User input is placed directly into the system prompt or injected into document context without sanitization.  
**Why it's harmful:** Attackers can override system instructions, exfiltrate context, or make the model take unintended actions.  
**Remediation:** Separate user input from system instructions structurally. Use guardrails to detect injection attempts. Never trust user-provided content in privileged prompt positions.

### ❌ Anti-Pattern 4: Hallucination as Acceptable Risk
**What it looks like:** AI feature outputs facts that aren't in the source data; no grounding check; shipped anyway.  
**Why it's harmful:** Users act on false information. Trust is destroyed. In regulated domains (legal, medical, financial), this is a liability.  
**Remediation:** For factual outputs, implement grounding checks: every claim must be traceable to retrieved source material. Display citations. Use self-consistency checks.

---

## Troubleshooting Guide

### Problem: RAG retrieval returning irrelevant documents
**Root Cause(s):** Chunk size too large (semantic dilution); wrong embedding model; insufficient metadata filtering; query-document embedding space mismatch  
**Diagnostic Steps:**
1. Inspect retrieved chunks for a sample of queries — what's being returned?
2. Check retrieval metrics: precision@5 in your eval set
3. Test: does the answer exist in the corpus at all? (retrieval ceiling test)  
**Resolution:** Tune chunk size (smaller chunks = more precise retrieval). Add metadata pre-filtering. Try a domain-specific embedding model.  
**Prevention:** Evaluate retrieval quality separately from generation quality. Fix retrieval before fixing generation.

### Problem: LLM costs 3× higher than projected
**Root Cause(s):** Context window growing unbounded (conversation history); users submitting very long inputs; wrong model selected for task  
**Diagnostic Steps:**
1. Check average input + output token count per call (LangSmith traces)
2. Identify which features drive the highest token consumption  
**Resolution:** Implement conversation summarization (compress old history). Set max input token limit with graceful truncation. Downgrade to cheaper model for identified tasks.  
**Prevention:** Cost estimate per feature at design time. Token budget as a non-functional requirement.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| AI output causes user harm or regulatory concern | CISO + Legal + EM | Immediate | Incident bridge |
| Prompt injection attack detected in production | Security Engineer + EM | Immediate | `#security-incidents` |
| AI costs exceed 200% of budget | EM + FinOps | 48 hours | `#finops-escalations` |
| Eval score regression >10% on production | AI Chapter Lead + EM | 24 hours | `#ai-engineering` |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Eval score (task-specific) | Defined at launch | Non-regression; quarterly improvement | Eval CI pipeline |
| P99 AI pipeline latency | Service-specific | Within UX SLO (<3s for interactive) | LangSmith + Grafana |
| Cost per AI-assisted action | Unknown | Defined and within budget | LangSmith token tracking |
| Hallucination rate (grounding check) | Unknown | <2% for factual features | Grounding eval |
| User satisfaction (AI feature) | Unknown | >4/5 thumbs-up ratio | In-product feedback |

---

## Best Practices

1. **Evals are Tests — Treat Them as Such** — AI evals belong in CI. A prompt change without an eval run is a change without a test.
2. **Retrieval Quality is the Ceiling** — A RAG system can't generate a correct answer from wrongly retrieved context. Fix retrieval first.
3. **Prompt Versioning is Code Versioning** — Prompts change model behavior like code changes application behavior. Version, review, and test them.
4. **Show Your Sources** — For factual AI features, always cite the source of information. It enables verification and builds user trust.
5. **Cost is a First-Class NFR** — Token cost is a non-functional requirement. Define it at design time like latency or availability.
6. **Fail Gracefully** — When the AI pipeline fails (model down, timeout, bad output), degrade gracefully. Never show raw error messages or hallucinated content to users.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| Eval CI pipeline (evals on every PR touching prompts) | RAGAS + GitHub Actions | L2 | M |
| AI cost dashboard and alerts | LangSmith API + Grafana | L2 | M |
| Semantic cache for repeated queries | GPTCache / custom | L3 | M |
| Automated prompt regression testing | LangSmith datasets | L2 | S |
| PII detection in AI inputs/outputs | Presidio + guardrails | L2 | M |

---

## AI Prompt Examples

### Prompt 1: Design a RAG Pipeline
```
Role: You are an AI systems engineer designing a RAG pipeline.
Context: Use case: internal HR policy Q&A. Source: 200 PDF documents (HR policies, 
         employee handbook). Users: 2,000 employees asking policy questions. 
         Stack: Python, Anthropic Claude, pgvector on PostgreSQL.
Task: Design the complete RAG pipeline architecture.
Constraints:
  - Cover: ingestion, chunking strategy, embedding model selection, 
    retrieval strategy, re-ranking, generation, citation of source documents
  - Address: how to handle tables and structured content in PDFs
  - Address: how to handle queries that span multiple documents
  - Include: evaluation strategy for retrieval and generation quality
  - Estimate: cost per query at 500 queries/day
Output format: Architecture sections with rationale for each design decision
```

### Prompt 2: Write an Eval Suite
```
Role: You are an AI engineer writing evaluations for a RAG system.
Context: RAG system answers questions about our software documentation.
         Here are 5 sample question-answer pairs from our golden test set:
         [PASTE Q&A PAIRS]
Task: Generate a comprehensive eval suite for this RAG system.
Constraints:
  - Generate: 20 additional diverse test cases (including edge cases, 
    multi-hop questions, out-of-scope questions)
  - Define: retrieval eval metrics (precision@5, recall@5, MRR)
  - Define: generation eval metrics (faithfulness, relevance, completeness)
  - Provide: LLM-as-judge prompt for automated quality scoring
Output format: Test cases in JSON, then metric definitions, then judge prompt
```

---

## References & Further Reading
- [Building LLM Apps — Anthropic Cookbook](https://github.com/anthropics/anthropic-cookbook) — Practical AI engineering patterns
- [RAGAS](https://docs.ragas.io) — RAG evaluation framework
- [LangChain Documentation](https://python.langchain.com) — AI application framework
- [LLM Security](https://llmsecurity.net) — Prompt injection and AI security
