---
id: "kubernetes.devsecops.k8s-operations"
title: "Kubernetes Operations & Deployment Strategies"
domain: "kubernetes"
role: "devsecops"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "dev-experience-chapter"
last_reviewed: "2026-05-27"
tags:
  - kubernetes
  - k8s
  - helm
  - argocd
  - deployments
  - devsecops
prerequisites:
  skills:
    - "cicd.devsecops.pipeline-design"
    - "terraform.devsecops.iac-design"
    - "cloud-engineering.architect.cloud-native-patterns"
  tools:
    - "kubectl"
    - "Helm >= 3"
    - "ArgoCD or Flux"
    - "Kustomize"
    - "Falco or Aqua (runtime security)"
  certifications:
    - "CKA (Certified Kubernetes Administrator) recommended"
    - "CKAD (Certified Kubernetes Application Developer) for devs"
related_skills:
  - "monitoring.devsecops.observability-platform"
  - "security.devsecops.cloud-security-posture"
  - "incident-response.devsecops.incident-command"
ai_indexable: true
---

# Kubernetes Operations & Deployment Strategies

> **Domain:** `kubernetes` | **Role:** `devsecops` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Kubernetes Operations covers the design, configuration, and ongoing management of containerized workloads on Kubernetes clusters. DevSecOps engineers own cluster security hardening, deployment strategy selection, resource governance, and GitOps reconciliation. This skill bridges the gap between infrastructure provisioning (Terraform) and application delivery (CI/CD), ensuring workloads run reliably, securely, and cost-efficiently at scale.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Applies existing Helm charts; basic `kubectl` commands; reads pod logs | Heavy — AI explains manifests and errors |
| 2 | Practitioner | Writes Helm charts; configures HPA/VPA; implements rolling deployments | Moderate — AI generates YAML, human validates |
| 3 | Advanced | Designs multi-cluster strategy; implements canary/blue-green; owns RBAC policy | Light — AI as reference |
| 4 | Expert | Defines cluster governance platform; capacity planning; FinOps for K8s | Minimal |
| 5 | Distinguished | Contributes to CNCF projects; publishes K8s patterns | AI as research assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `4–6 months`

---

## Prerequisites

### Required Skills
- `cicd.devsecops.pipeline-design` — understand the delivery pipeline feeding the cluster
- `terraform.devsecops.iac-design` — cluster provisioning via IaC
- `cloud-engineering.architect.cloud-native-patterns` — cloud provider integration (EKS/GKE/AKS)

### Required Tools Access
- **kubectl** — cluster interaction
- **Helm >= 3** — application packaging
- **ArgoCD or Flux** — GitOps operator
- **Kustomize** — environment-specific manifest patching
- **Falco** — runtime threat detection
- **Prometheus + Grafana** — cluster metrics

### Required Knowledge
- Kubernetes core objects: Pod, Deployment, Service, Ingress, ConfigMap, Secret, HPA, VPA, PDB
- RBAC model: ClusterRole, Role, RoleBinding, ServiceAccount
- Network policies: ingress/egress rules, CNI plugins (Calico, Cilium)
- Resource requests and limits; QoS classes
- Persistent storage: StorageClass, PVC, PV, CSI drivers

---

## Workflow

### Step 1: Workload Onboarding Assessment
Before deploying a new workload, complete the K8s Onboarding Checklist:
- Resource requests/limits defined?
- Liveness and readiness probes configured?
- Non-root user in Dockerfile?
- Read-only root filesystem where possible?
- Secrets sourced from Vault (not ConfigMap)?
- NetworkPolicy defined?
- PodDisruptionBudget defined (for HA workloads)?

**AI Assist:** `Yes` — "Review this Kubernetes manifest and identify any missing security or reliability configurations"

### Step 2: Namespace & RBAC Design
Each team owns a namespace (or set of namespaces). Define RoleBindings per team. Principle of least privilege: no ClusterAdmin for application workloads.

**Decision Gate:** No workload may run in the `default` namespace in non-development environments.

### Step 3: Deployment Strategy Selection

| Strategy | When to Use | Rollback Speed | Blast Radius |
|---|---|---|---|
| Rolling Update | Standard deployments, stateless | Medium (new pods drain) | Partial (mixed versions briefly) |
| Blue/Green | Zero-downtime requirement, stateful | Instant (swap selector) | Full (all traffic to one version) |
| Canary | High-risk changes, A/B testing | Fast (redirect traffic) | Controlled (% of traffic) |
| Recreate | Dev/test, batch jobs, breaking DB migrations | Fast | Full downtime |

**AI Assist:** `Yes` — "Given these requirements, recommend a deployment strategy and generate the Helm chart values"

### Step 4: Helm Chart Authoring
Structure: `Chart.yaml`, `values.yaml` (defaults), `values-dev.yaml`, `values-staging.yaml`, `values-prod.yaml`, `templates/`. Environment-specific values override defaults via Kustomize or `helm install -f`.

### Step 5: ArgoCD Application Manifest
Define an ArgoCD `Application` or `ApplicationSet` pointing to the GitOps config repo. Set sync policy: automated sync for dev/staging, manual sync gate for production.

### Step 6: Resource Quota & LimitRange Configuration
Per-namespace: set `ResourceQuota` (total CPU/memory ceiling) and `LimitRange` (default requests/limits for pods without explicit settings). Prevents noisy-neighbour problems.

### Step 7: HPA & Scaling Configuration
Configure HPA targeting 60–70% CPU/memory utilization. Set `minReplicas` based on HA requirements (minimum 2 for prod). Set `maxReplicas` based on cost ceiling and load test results.

### Step 8: Network Policy Hardening
Default-deny all ingress and egress per namespace. Explicitly allow only required traffic. Use Cilium network policy for L7 visibility where needed.

### Step 9: Falco Runtime Security
Deploy Falco DaemonSet. Configure alert rules for: privileged container execution, unexpected process spawning, unexpected file writes to sensitive paths, unexpected outbound connections.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| kubectl | Cluster interaction | Required | No |
| Helm 3 | Application packaging | Required | Yes (AI generates charts) |
| ArgoCD | GitOps reconciliation | Required | No |
| Kustomize | Manifest patching | Required | No |
| Falco | Runtime security | Required (prod) | No |
| Kube-bench | CIS benchmark scanner | Required (audit) | No |
| Goldilocks | VPA resource right-sizing recommendations | Optional | No |
| Kubecost | K8s cost visibility | Optional | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Running Containers as Root
**What it looks like:** No `securityContext.runAsNonRoot: true` in pod spec; `USER root` in Dockerfile  
**Why it's harmful:** If an attacker escapes the container, they have root on the node. Container breakouts are rare but real.  
**Remediation:** Add `securityContext: { runAsNonRoot: true, runAsUser: 1000 }`. Add `USER 1000` in Dockerfile.

### ❌ Anti-Pattern 2: No Resource Requests or Limits
**What it looks like:** Pods with no `resources` block in the container spec  
**Why it's harmful:** A runaway pod can consume all node resources, evicting healthy workloads. Scheduler cannot make optimal placement decisions.  
**Remediation:** Set `LimitRange` as namespace default. Require resources block in Helm chart template via linting.

### ❌ Anti-Pattern 3: Secrets in ConfigMaps or Environment Variables (Plaintext)
**What it looks like:** `DATABASE_PASSWORD: "hunter2"` in a ConfigMap  
**Why it's harmful:** ConfigMaps are not encrypted at rest (by default). They appear in `kubectl describe`. Any pod reader can access them.  
**Remediation:** Use Vault Agent Injector or External Secrets Operator to inject secrets at runtime from Vault/AWS Secrets Manager.

### ❌ Anti-Pattern 4: Deploying Directly with kubectl in Production
**What it looks like:** `kubectl apply -f deployment.yaml` run manually against prod  
**Why it's harmful:** Bypasses ArgoCD; creates drift; no audit trail; no peer review; no rollback via Git.  
**Remediation:** Block direct `kubectl apply` on prod via RBAC (no write access for humans on production namespaces). All changes via GitOps PR.

### ❌ Anti-Pattern 5: Single Replica for Production Workloads
**What it looks like:** `replicas: 1` in production Deployment  
**Why it's harmful:** Any pod eviction, node drain, or crash results in downtime.  
**Remediation:** Minimum 2 replicas for all production workloads. Use PodDisruptionBudget to protect during node drain.

---

## Troubleshooting Guide

### Problem: Pod stuck in `CrashLoopBackOff`
**Root Cause(s):** Application startup failure; missing environment variable; missing secret; misconfigured readiness probe; OOM kill  
**Diagnostic Steps:**
1. `kubectl describe pod <pod-name> -n <namespace>` — check events and last state
2. `kubectl logs <pod-name> -n <namespace> --previous` — get logs from crashed container
3. Check exit code: `137` = OOM kill; `1` = app crash; `2` = misuse of shell command  
**Resolution:** Address root cause from logs. If OOM: increase memory limit. If missing secret: check External Secrets sync.  
**Prevention:** Validate environment config in staging before prod promotion. Add startup probes for slow-starting apps.

### Problem: ArgoCD shows `OutOfSync` but no changes in Git
**Root Cause(s):** Drift caused by manual `kubectl` edit; operator-mutated field; admission webhook mutation  
**Diagnostic Steps:**
1. ArgoCD UI → App → "Diff" view — shows exact field difference
2. Check if the diffed field is managed by an operator (e.g., HPA modifying replicas)  
**Resolution:** For operator-managed fields: add to ArgoCD `ignoreDifferences`. For manual drift: sync ArgoCD to restore Git state.  
**Prevention:** Enforce no manual kubectl writes to prod. Document operator-managed fields in ArgoCD app spec.

### Problem: HPA not scaling up under load
**Root Cause(s):** Metrics server not running; resource requests not set (HPA can't calculate %); cooldown period active  
**Diagnostic Steps:**
1. `kubectl get hpa <name> -n <namespace>` — check `TARGETS` column; `<unknown>` means metrics unavailable
2. `kubectl top pods -n <namespace>` — verify metrics-server is returning data  
**Resolution:** Deploy/fix metrics-server. Ensure all containers have `resources.requests` set.  
**Prevention:** Validate HPA in staging under load test before production.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Node pool at >90% capacity (risk of eviction) | Cloud Engineer + EM | 1 hour | `#k8s-alerts` |
| Falco critical alert (privilege escalation, container escape attempt) | Security Engineer + CISO | Immediate | `#security-incidents` + PagerDuty |
| Production namespace full (ResourceQuota exceeded, pods pending) | DevSecOps On-call | 15 minutes | PagerDuty |
| ArgoCD control plane down (no GitOps reconciliation) | Platform Team | 30 minutes | `#incidents` |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Pod restart rate (prod, p95) | 8/day | <2/day | Prometheus `kube_pod_container_status_restarts_total` |
| Resource utilization efficiency (requests vs. actual) | 35% efficiency | >65% efficiency | Goldilocks / Kubecost |
| Deployment success rate | 88% | >98% | ArgoCD sync status |
| Mean time to detect K8s incident | 18 minutes | <5 minutes | Alert timestamp vs. incident creation |
| CIS benchmark score (kube-bench) | 68% | >90% | kube-bench weekly scan |
| Workloads with no resource limits | 40% | <5% | Prometheus query |

---

## Best Practices

1. **Namespaces as Trust Boundaries** — One team = one namespace. Apply NetworkPolicy default-deny. No cross-namespace secret sharing.
2. **Image Tag Discipline** — Never use `latest` tag in production. Pin to immutable digest (`image@sha256:...`) for audit trail.
3. **Graceful Shutdown** — Every container must handle `SIGTERM` and drain connections. Set `terminationGracePeriodSeconds` appropriately.
4. **Readiness ≠ Liveness** — Readiness probe gates traffic; liveness probe restarts the container. Misconfiguring both causes cascading restarts.
5. **GitOps as the Audit Log** — Git history of the `gitops-config` repo IS the production change history. Protect the branch.
6. **Right-Size Before You Scale** — Use Goldilocks VPA recommendations before adding replicas. Oversized requests waste money and reduce scheduling efficiency.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| Auto-generate Helm chart from Dockerfile + env vars | AI + chart template | L2 | M |
| Automated resource right-sizing recommendations PR | Goldilocks + GitHub Actions | L3 | M |
| CIS benchmark remediation suggestions | kube-bench + AI | L3 | M |
| Cost anomaly detection + Slack alert | Kubecost + alerting | L3 | S |
| Progressive delivery (canary) automation | Argo Rollouts | L3 | L |

---

## AI Prompt Examples

### Prompt 1: Generate a Production-Ready Helm Chart
```
Role: You are a DevSecOps engineer creating a Helm chart for a production workload.
Context: A Node.js REST API, ~200 RPS peak, stateless, needs high availability.
         Stack: EKS, ArgoCD, External Secrets Operator (Vault backend).
Task: Generate a production-ready Helm chart for this workload.
Constraints:
  - Include: Deployment, Service, HPA, PDB, ServiceAccount, NetworkPolicy
  - SecurityContext: non-root, read-only root filesystem, dropped capabilities
  - Resources: requests AND limits for CPU and memory
  - Liveness and readiness probes defined
  - Secrets via External Secrets Operator (not hardcoded)
  - minReplicas: 2, maxReplicas: 10, target CPU: 65%
Output format: One code block per file (Chart.yaml, values.yaml, templates/*.yaml)
```

### Prompt 2: Diagnose a Kubernetes Issue
```
Role: You are a senior DevSecOps engineer diagnosing a Kubernetes incident.
Context: Production pods are in CrashLoopBackOff. Here is the output:
  kubectl describe pod: [PASTE OUTPUT]
  kubectl logs --previous: [PASTE OUTPUT]
Task: Diagnose the root cause and provide step-by-step remediation.
Constraints:
  - Identify primary root cause and contributing factors
  - Provide kubectl commands for each diagnostic/remediation step
  - Estimate time to resolution
  - Suggest post-incident prevention measures
Output format: Diagnosis, Root Cause, Remediation Steps (numbered), Prevention
```

---

## References & Further Reading

- [Kubernetes Documentation](https://kubernetes.io/docs/) — Official reference
- [CKA Curriculum](https://www.cncf.io/certification/cka/) — Certification study guide
- [ArgoCD Documentation](https://argo-cd.readthedocs.io/) — GitOps operator
- [Falco Rules](https://falco.org/docs/rules/) — Runtime security rules reference
- [CNCF Landscape](https://landscape.cncf.io/) — Cloud native tooling ecosystem
