---
id: "architecture.architect.solution-design"
title: "Solution Architecture Design"
domain: "architecture"
role: "architect"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "architecture-chapter"
last_reviewed: "2026-05-27"
usage_count: 0
endorsements: 0
tags:
  - architecture
  - solution-design
  - adr
  - system-design
  - enterprise
prerequisites:
  skills:
    - "system-design.architect.fundamentals"
    - "cloud-engineering.architect.cloud-native-patterns"
  tools:
    - "Structurizr or Mermaid (diagramming)"
    - "Confluence (documentation)"
    - "GitHub (ADR storage)"
  certifications:
    - "AWS/GCP/Azure Solutions Architect Associate or higher"
    - "TOGAF Foundation (recommended)"
related_skills:
  - "system-design.architect.distributed-systems"
  - "coding.senior-dev.clean-architecture"
  - "security.architect.threat-modeling"
ai_indexable: true
---

# Solution Architecture Design

> **Domain:** `architecture` | **Role:** `architect` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Solution Architecture Design is the practice of translating business requirements into a coherent, implementable technical blueprint. It encompasses component selection, integration patterns, data flows, non-functional requirements (NFRs), and trade-off analysis. Enterprise architects own this skill to ensure new systems align with the target state architecture, security posture, and cost envelopes. Effective solution design prevents rework, enables safe AI-assisted development, and creates the foundation for reliable delivery.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Draws basic component diagrams; copies existing patterns | Heavy — AI generates first-draft ADRs |
| 2 | Practitioner | Designs solutions for single bounded contexts; identifies NFRs | Moderate — AI validates against patterns |
| 3 | Advanced | Handles cross-domain integration; leads architecture reviews | Light — AI surfaces edge cases |
| 4 | Expert | Defines org-wide reference architectures; governs enterprise patterns | Minimal — AI as research assistant |
| 5 | Distinguished | Publishes industry patterns; advises cross-org architectural strategy | AI as search augmentation only |

**Current team target level:** `3`  
**Expected time to Practitioner (L2):** `6–9 months`

---

## Prerequisites

### Required Skills
- `system-design.architect.fundamentals` — foundational distributed systems reasoning
- `cloud-engineering.architect.cloud-native-patterns` — cloud-specific design vocabulary

### Required Tools Access
- **Structurizr/Mermaid** — C4 model diagrams, sequence diagrams
- **Confluence** — Architecture Decision Records (ADRs) and design docs
- **GitHub** — ADR-as-code storage in `docs/architecture/decisions/`
- **Draw.io or Lucidchart** — whiteboard-style design sessions

### Required Knowledge
- C4 Model (Context, Container, Component, Code)
- Domain-Driven Design (bounded contexts, aggregates, events)
- CAP theorem and distributed systems trade-offs
- Enterprise integration patterns (EIP)
- Cost modelling basics (FinOps awareness)

---

## Workflow

### Step 1: Requirements Intake & Constraint Discovery
Gather functional requirements from the Product Manager. Explicitly surface NFRs: availability targets, latency SLOs, data residency constraints, regulatory requirements, scalability ceilings, and budget envelopes.

**Deliverable:** Completed Architecture Requirements Questionnaire (ARQ)  
**AI Assist:** `Yes` — AI can draft the ARQ from meeting notes or a Jira epic  
**Anti-pattern watch:** Skipping NFR elicitation; treating all requirements as functional

### Step 2: Current State Assessment
Map the existing landscape: relevant services, databases, integrations, and their known limitations. Pull the service dependency graph from monitoring tooling.

**AI Assist:** `Optional` — AI can parse existing API specs and generate dependency summaries

### Step 3: Pattern Selection & Trade-off Analysis
Select the primary architectural pattern (event-driven, microservices, modular monolith, CQRS, etc.) based on requirements. Document at least 2 alternative patterns considered and why they were rejected.

**Decision Gate:** At least one senior engineer and one security engineer must review pattern selection before proceeding.

### Step 4: Component Design (C4 Level 2–3)
Produce Container and Component diagrams. Define service boundaries, APIs between components, data stores, and external dependencies.

**AI Assist:** `Yes` — AI can generate Mermaid or PlantUML from prose descriptions

### Step 5: Data Architecture
Define data models, ownership per service, consistency model (eventual vs. strong), and migration strategy if applicable.

### Step 6: Security Architecture Review
Co-design with a Security Engineer. Complete a threat model (STRIDE). Identify authentication/authorization boundaries, secrets management, network segmentation, and encryption requirements.

**Escalation Gate:** Any finding rated HIGH or CRITICAL from threat model blocks design approval until remediated.

### Step 7: ADR Authoring
Write Architecture Decision Records for every significant decision. Use the MADR (Markdown Any Decision Record) format. Store in `docs/architecture/decisions/NNNN-<title>.md`.

**AI Assist:** `Yes` — Use AI Prompt Example #1 below

### Step 8: Architecture Review Board (ARB) Presentation
Present to ARB. Capture feedback as GitHub issues tagged `arch-review`. Revisions required within 5 business days.

### Step 9: Design Handoff to Engineering
Produce the Solution Design Document (SDD). Ensure the development team can implement without ambiguity. Hold a design walkthrough session.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Structurizr | C4 model as code | Required | No |
| Mermaid | Diagrams in Markdown | Required | Yes (AI generates) |
| Confluence | SDD & ADR publishing | Required | Yes (AI drafts) |
| GitHub | ADR version control | Required | No |
| draw.io | Whiteboard diagramming | Optional | No |
| AWS Well-Architected Tool | NFR validation | Optional | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Architecture by Diagram Only
**What it looks like:** Architect produces a beautiful diagram but no ADRs, no NFR documentation, no threat model.  
**Why it's harmful:** Engineers make implementation decisions in a vacuum; security gaps emerge post-deployment; knowledge is lost when the architect leaves.  
**Remediation:** Mandate ADRs as a PR requirement for all significant design decisions. No merge without ADR.

### ❌ Anti-Pattern 2: Gold-Plating for Hypothetical Scale
**What it looks like:** Designing for 1M RPS when current load is 500 RPS with no growth data.  
**Why it's harmful:** Over-engineering increases cost, complexity, and delivery time. Premature optimization is the root of significant enterprise waste.  
**Remediation:** Design to the 95th percentile of projected load (3–6 month horizon), with documented scale-out path. Use load test data, not intuition.

### ❌ Anti-Pattern 3: Architect as Ivory Tower
**What it looks like:** Architecture is handed down without engineering team input. Architects don't attend sprint reviews or engineering standups.  
**Why it's harmful:** Design assumptions don't survive contact with implementation. Engineers work around impractical designs, creating undocumented divergence.  
**Remediation:** Architects must attend at least one sprint review per team per quarter for systems they designed. Design reviews are collaborative, not presentations.

### ❌ Anti-Pattern 4: Ignoring Operational Architecture
**What it looks like:** Solution design has no section on observability, deployment topology, runbooks, or DR strategy.  
**Why it's harmful:** The system is unmaintainable in production. Ops teams inherit systems they can't understand or recover.  
**Remediation:** Add mandatory SDD sections: Observability Design, Deployment Architecture, DR Strategy, Runbook Stubs.

---

## Troubleshooting Guide

### Problem: Stakeholders reject architecture for cost reasons
**Root Cause(s):** Cost was not surfaced early; no FinOps review during design  
**Diagnostic Steps:**
1. Generate a cost estimate using cloud pricing calculator
2. Identify the top 3 cost drivers in the design
3. Model two cost-optimized alternatives  
**Resolution:** Present cost vs. capability trade-off matrix to stakeholders  
**Prevention:** Include FinOps Engineer in Step 3 (Pattern Selection) going forward

### Problem: Engineering team diverges from approved design during implementation
**Root Cause(s):** Design had unresolvable ambiguity; implementation discovered a constraint the architect didn't know about  
**Diagnostic Steps:**
1. Hold a design retrospective with the engineering team
2. Identify which specific design element was impractical
3. Review original ADR for the decision  
**Resolution:** Create an amendment ADR documenting the change and rationale. Update diagrams.  
**Prevention:** Architects must be accessible (async Slack, weekly office hours) during implementation sprints.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| HIGH/CRITICAL threat model finding blocks delivery | VP Engineering + CISO | 24 hours | `#security-escalations` + email |
| ARB rejects design; architect and ARB disagree | CTO / Principal Architect | 5 business days | Formal architecture review ticket |
| Cost estimate exceeds approved budget by >20% | Engineering Manager + FinOps | 48 hours | `#finops-escalations` |
| Cross-domain integration requires another team's system change | Cross-team Architecture Review | 1 week | Joint ADR + ARB session |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| ADR completion rate | 60% of decisions | 95% of decisions | GitHub ADR count vs. design decisions in Jira |
| Design-to-implementation divergence rate | 35% of features | <10% of features | Sprint retrospective flags |
| Architecture review cycle time | 12 days | 5 days | ARB ticket open→close date |
| NFR coverage (% of requirements with measurable NFRs) | 40% | 90% | ARQ audit |
| Post-launch architecture-related incidents | 4/quarter | 0/quarter | Incident postmortem tags |

---

## Best Practices

1. **ADR-First Design** — Write the ADR title and context before drawing any diagram. It forces clarity about what problem you're actually solving.
2. **Two-Pager Rule** — Any design that cannot be summarized in 2 pages of prose is too complex. Decompose it.
3. **Name Your Constraints Explicitly** — Every design should have a "Constraints and Assumptions" section. Undocumented assumptions are future incidents.
4. **Design for Operability** — Every component must have a defined owner, a runbook stub, and alerting strategy before design is approved.
5. **Use Reference Architectures as Starting Points** — Never design from a blank page. Start with the closest reference architecture and document deviations.
6. **Fitness Functions** — Define automated architecture fitness functions (e.g. "no service may have >5 synchronous upstream dependencies") that are tested in CI.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| Auto-generate C4 diagrams from service mesh telemetry | Structurizr + Istio service graph | L3 | M |
| ADR template pre-fill from Jira epic | AI + Confluence API | L2 | S |
| Architecture drift detection (code vs. design) | Arch Unit / Deptrac in CI | L3 | L |
| Cost estimate generation from component diagram | Cloud Pricing API + AI | L3 | M |
| Threat model auto-draft from component diagram | AI + STRIDE framework | L2 | M |

---

## AI Prompt Examples

### Prompt 1: Draft an Architecture Decision Record
```
Role: You are a solution architect at an enterprise software company.
Context: We are deciding whether to use Apache Kafka or AWS SQS+SNS for our 
         event-driven order processing system. The system processes ~50,000 
         orders/day with peak bursts of 500 orders/minute. We use AWS and have 
         no existing Kafka expertise on the team.
Task: Write a complete ADR in MADR format for this decision.
Constraints:
  - Include: title, status, context, decision drivers, considered options, 
    decision outcome, pros/cons of each option, links to evidence
  - The team has 3 engineers; no Kafka operational experience
  - Budget: operational cost must stay under $2,000/month
  - SLA: 99.9% availability required
Output format: Markdown, MADR format exactly
```

### Prompt 2: Generate a C4 Container Diagram in Mermaid
```
Role: You are a solution architect.
Context: I am designing a B2B SaaS platform with: React frontend, 
         Node.js BFF (Backend for Frontend), Python FastAPI microservices 
         (orders, inventory, notifications), PostgreSQL per service, 
         Redis cache, and Auth0 for identity.
Task: Generate a C4 Container Diagram in Mermaid syntax showing all containers, 
      their technologies, and the relationships between them including protocols.
Constraints:
  - Use Mermaid C4 context diagram syntax
  - Label all relationships with protocol and data direction
  - Include external systems (Auth0, email provider)
Output format: Mermaid code block only, no prose
```

### Prompt 3: NFR Elicitation from Meeting Notes
```
Role: You are a solution architect reviewing a project brief.
Context: [PASTE MEETING NOTES OR JIRA EPIC DESCRIPTION HERE]
Task: Extract and formalize all implied and explicit non-functional requirements.
Constraints:
  - Organize by NFR category: Performance, Availability, Scalability, 
    Security, Compliance, Maintainability, Cost
  - For each NFR, state: requirement, measurement method, threshold/SLO, 
    and priority (Must/Should/Could)
  - Flag any NFRs that are missing and need stakeholder clarification
Output format: Markdown table per NFR category
```

---

## References & Further Reading

- [C4 Model](https://c4model.com) — Canonical reference for C4 diagramming
- [MADR](https://adr.github.io/madr/) — Markdown Architectural Decision Records format
- [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/) — NFR validation lens
- [Enterprise Integration Patterns](https://www.enterpriseintegrationpatterns.com) — Messaging and integration pattern catalog
