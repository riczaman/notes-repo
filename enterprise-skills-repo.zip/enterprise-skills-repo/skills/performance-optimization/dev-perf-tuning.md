---
id: "performance-optimization.senior-dev.perf-tuning"
title: "Performance Optimization & Capacity Planning"
domain: "performance-optimization"
role: "senior-dev"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "reliability-chapter"
last_reviewed: "2026-05-27"
tags: [performance, optimization, profiling, load-testing, capacity-planning, caching]
prerequisites:
  skills: ["coding.senior-dev.clean-code-practices", "monitoring.devsecops.observability-platform"]
  tools: ["k6 or Gatling", "async-profiler / py-spy", "Grafana", "FlameGraph"]
  certifications: ["none"]
related_skills: ["system-design.architect.distributed-systems", "monitoring.devsecops.observability-platform"]
ai_indexable: true
---

# Performance Optimization & Capacity Planning

> **Domain:** `performance-optimization` | **Role:** `senior-dev` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Performance Optimization is the practice of identifying, measuring, and reducing latency, resource consumption, and throughput bottlenecks in software systems. Capacity Planning ensures systems can handle projected load growth within acceptable cost and SLO boundaries. Senior Developers own performance optimization for their services; architects own capacity planning at the system level. The golden rule: measure first, optimize second. AI accelerates analysis of profiling data, log patterns, and load test results to surface root causes faster.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Understands Big O notation; can identify obvious N+1 queries | Heavy — AI identifies bottlenecks from code |
| 2 | Practitioner | Runs load tests; uses profiler; fixes identified bottlenecks | Moderate — AI analyzes flamegraphs and query plans |
| 3 | Advanced | Designs performance test strategy; owns caching architecture; capacity models | Light — AI validates analysis |
| 4 | Expert | Defines org performance standards; perf regression CI strategy | Minimal |
| 5 | Distinguished | Published performance engineering; open source perf tooling | AI as analysis assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `4–6 months`

---

## Prerequisites

### Required Skills
- `coding.senior-dev.clean-code-practices` — write code worth profiling
- `monitoring.devsecops.observability-platform` — observability platform to measure from

### Required Tools Access
- **k6 or Gatling** — load testing
- **async-profiler (JVM) / py-spy (Python) / pprof (Go)** — CPU profiling
- **Grafana** — metrics visualization during load tests
- **Query analysis** — EXPLAIN ANALYZE (PostgreSQL), MongoDB query profiler
- **FlameGraph** — CPU profile visualization

### Required Knowledge
- Big O notation and algorithmic complexity
- CPU, memory, I/O, and network bottleneck characteristics
- Database query optimization (indexes, query plans, N+1)
- Caching patterns: cache-aside, write-through, write-behind
- Load testing types: smoke, load, stress, spike, soak
- Amdahl's Law: the theoretical limit of parallelization speedup

---

## Workflow

### Step 1: Define Performance Requirements
Before any optimization, define what "good" looks like:
- Target P50, P95, P99 latency per operation
- Target throughput (RPS) at baseline and peak
- Target resource utilization ceiling (CPU <70%, memory <80%)
- Regression threshold: what % degradation triggers an alert?

**AI Assist:** `Yes` — "Given this service's business SLO, suggest appropriate latency budgets for each tier of the call chain"

### Step 2: Baseline Measurement
Capture current performance under realistic load before any change. Without a baseline, you can't prove an improvement. Use k6 to generate consistent load; capture Grafana dashboards.

**Decision Gate:** No optimization work starts without a documented baseline.

### Step 3: Profile, Don't Guess
Run a profiler against the target system under load. Never optimize based on intuition. Common profiling approaches:
- **CPU profiling**: identify hot functions (flamegraph)
- **Memory profiling**: identify allocation hotspots and leaks
- **Database profiling**: slow query log, EXPLAIN ANALYZE
- **Network profiling**: TCP retransmits, connection pool wait times

**AI Assist:** `Yes` — "Analyze this flamegraph and identify the top optimization opportunities" / "Explain this PostgreSQL EXPLAIN ANALYZE output"

### Step 4: Identify the Bottleneck (Amdahl's Law Awareness)
The system's performance is constrained by its slowest component. Fix the actual bottleneck, not the second-slowest component. Common bottlenecks by category:

| Bottleneck Type | Signal | Fix |
|---|---|---|
| N+1 query | DB query count ≫ request count | Eager loading, join optimization |
| Missing index | EXPLAIN shows Seq Scan on large table | Add appropriate index |
| Synchronous call chain | High P99, low throughput | Async processing, caching |
| Memory leak | RSS grows over time without release | Heap dump analysis, fix allocation |
| Connection pool exhaustion | Wait time in pool metrics | Pool size tuning (with DB capacity awareness) |
| GC pressure | CPU spikes correlate with GC events | Allocation reduction, GC tuning |

### Step 5: Implement Optimization
Fix the highest-impact bottleneck first. Implement the minimum change needed. Do not refactor unrelated code during performance work — changes must be attributable.

### Step 6: Verify Improvement
Re-run the same load test from Step 2. Compare: latency P99, throughput, resource utilization. Improvement must be measurable and statistically significant (not within noise margin).

**Decision Gate:** If the optimization doesn't produce measurable improvement, revert it. Don't leave speculative changes in the codebase.

### Step 7: Regression Prevention
Add a performance test to the CI pipeline (k6 smoke test on every PR; full load test on merge to main). Set regression thresholds. Alert on degradation before it reaches production.

### Step 8: Capacity Planning
Given current growth rate and baseline performance data:
- Project load at 3 months, 6 months, 12 months
- Identify when each resource (compute, database, storage, bandwidth) will hit capacity
- Plan scaling actions with 30% headroom buffer before capacity limit

**AI Assist:** `Yes` — "Given these growth metrics, project when our database will require vertical scaling or sharding"

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| k6 | Load and performance testing | Required | Yes (AI generates scripts) |
| Gatling | Load testing (Scala DSL, CI integration) | Optional | No |
| async-profiler | JVM CPU/memory profiling | Required (JVM) | No |
| py-spy | Python profiling | Required (Python) | No |
| pprof | Go profiling | Required (Go) | No |
| FlameGraph | CPU profile visualization | Required | No |
| Grafana | Metrics during load test | Required | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Optimize Without Measuring
**What it looks like:** "I think this loop is slow, let me rewrite it." Rewrite takes 3 days; no measurable improvement.  
**Why it's harmful:** Engineer time wasted. Code complexity increased. The actual bottleneck is still there.  
**Remediation:** Profile first. Always. The bottleneck is almost never where you think it is.

### ❌ Anti-Pattern 2: Adding Cache as the First Response to Every Performance Problem
**What it looks like:** Every performance complaint is solved with "add a Redis cache."  
**Why it's harmful:** Cache adds complexity: invalidation bugs, stale data, thundering herd on cold start. Sometimes the fix is a missing index.  
**Remediation:** Profile first to find the actual bottleneck. Cache is one tool, not the only tool.

### ❌ Anti-Pattern 3: Load Testing Only in Isolation
**What it looks like:** Service passes load test in isolation but fails in integration because it calls 3 other services that also degrade under load.  
**Why it's harmful:** Production load distributes across the entire call graph. Isolated tests miss cascading bottlenecks.  
**Remediation:** Run integration-level load tests. Profile the critical end-to-end path, not just individual services.

### ❌ Anti-Pattern 4: Premature Optimization
**What it looks like:** Spending 2 weeks micro-optimizing a code path that handles 0.1% of traffic.  
**Why it's harmful:** Developer time is more expensive than compute. Optimization that doesn't impact user experience or cost is waste.  
**Remediation:** Optimize the P99 path for high-traffic operations first. Use profiling to identify what actually matters.

---

## Troubleshooting Guide

### Problem: Service P99 latency spiking intermittently, not reproducible in load test
**Root Cause(s):** GC pause; external dependency timeout; scheduled job competing for resources; database lock contention during peak  
**Diagnostic Steps:**
1. Correlate spike timestamps with: GC logs, deployment events, scheduled jobs, database slow query log
2. Check if spikes correlate with specific operations (one endpoint only?)
3. Check if spikes correlate with traffic patterns (specific time of day)  
**Resolution:** Fix the correlated root cause. For GC: tune heap/GC algorithm. For lock: optimize query or add index.  
**Prevention:** Trace all requests. Distributed traces expose which component contributes to P99 latency.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| SLO breach caused by performance regression | On-call + EM | Immediate | `#incidents` |
| Capacity ceiling within 30 days at current growth | Architect + EM + FinOps | 1 week | `#engineering-ops` |
| Performance regression in CI blocks all deployments | Senior Dev + EM | 4 hours | `#engineering-ops` |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| P99 latency for top 5 endpoints (prod) | Service-specific | Within SLO | Prometheus / Grafana |
| Performance regression in CI (% PRs triggering perf alert) | Not measured | <5% of PRs | k6 CI report |
| Max throughput before SLO breach (load test) | Not measured | 3× current peak | Quarterly load test |
| DB query P99 (slow query log) | 340ms | <100ms | DB slow query log |
| Cache hit rate | 55% | >80% | Redis / CDN metrics |

---

## Best Practices

1. **Measure First, Always** — Profile before optimizing. The bottleneck is not where you think it is.
2. **Fix the Slowest Thing** — Optimizing the second-slowest thing gives diminishing returns until the slowest is fixed.
3. **Performance Tests in CI** — Catch regressions before production. A performance regression is a bug.
4. **Define SLOs Before Optimizing** — "Fast enough" requires a definition. Without SLOs, optimization has no stopping condition.
5. **Load Test at 3× Expected Peak** — Design headroom into the system. Traffic always spikes more than expected.
6. **Caching Has a Cost** — Cache invalidation is hard. Stale cache causes incorrect behavior. Add caches deliberately, not reflexively.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| Performance regression detection in CI | k6 + GitHub Actions + threshold alerts | L2 | M |
| AI analysis of slow query logs | AI + DB log pipeline | L3 | M |
| Flamegraph generation on-demand in CI | async-profiler + GitHub Actions | L3 | M |
| Capacity planning projection from metrics | AI + Prometheus data | L3 | L |
| Auto-scale pre-warming before predicted peak | Predictive scaling (AWS/GCP) | L4 | L |

---

## AI Prompt Examples

### Prompt 1: Analyze a Slow Query
```
Role: You are a senior developer optimizing a PostgreSQL query.
Context: This query runs on a table with 50M rows. Average execution time: 4.2 seconds.
  Query: [PASTE QUERY]
  EXPLAIN ANALYZE output: [PASTE EXPLAIN OUTPUT]
  Indexes currently defined: [LIST INDEXES]
Task: Identify why this query is slow and recommend optimizations.
Constraints:
  - Explain each EXPLAIN ANALYZE node and what it reveals
  - Identify the costliest operation
  - Recommend: index changes, query rewrites, or schema changes
  - Estimate expected improvement for each recommendation
Output format: Analysis section, then ordered recommendations with estimated improvement
```

### Prompt 2: Generate a k6 Load Test Script
```
Role: You are a performance engineer writing a load test.
Context: API endpoint: POST /api/v1/orders. 
         Auth: Bearer JWT (static test token provided).
         Request body: { "product_id": "uuid", "quantity": integer, "address": {...} }
         Expected production load: 200 RPS peak, typical 80 RPS.
Task: Write a k6 load test script for this endpoint.
Constraints:
  - Test stages: ramp up 0→200 RPS over 2min, hold 200 RPS for 5min, ramp down 2min
  - Thresholds: p95 < 300ms, error rate < 1%
  - Randomize product_id and quantity per request
  - Log: stage transitions, threshold breaches, p50/p95/p99 per stage
Output format: Complete k6 JavaScript file with inline comments
```

---

## References & Further Reading
- [Systems Performance — Brendan Gregg](https://www.brendangregg.com/systems-performance.html) — Definitive performance engineering reference
- [k6 Documentation](https://k6.io/docs/) — Load testing tool
- [Use-the-Index-Luke](https://use-the-index-luke.com) — SQL indexing guide
- [FlameGraph](https://www.brendangregg.com/flamegraphs.html) — CPU profiling visualization
