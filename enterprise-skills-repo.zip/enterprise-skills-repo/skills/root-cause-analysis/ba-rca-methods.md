---
id: "root-cause-analysis.business-analyst.rca-methods"
title: "Root Cause Analysis Methods"
domain: "root-cause-analysis"
role: "business-analyst"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "product-delivery-chapter"
last_reviewed: "2026-05-27"
tags: [rca, root-cause-analysis, 5-why, fishbone, postmortem, problem-solving]
prerequisites:
  skills: []
  tools: ["Confluence", "Jira", "Miro (fishbone diagrams)"]
  certifications: ["none"]
related_skills: ["incident-response.devsecops.incident-command", "agile-delivery.product-manager.sprint-delivery"]
ai_indexable: true
---

# Root Cause Analysis Methods

> **Domain:** `root-cause-analysis` | **Role:** `business-analyst` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Root Cause Analysis (RCA) is the structured practice of identifying the fundamental causes of problems — incidents, delivery failures, quality issues, or recurring defects — so that effective corrective actions prevent recurrence. Business Analysts lead RCA for process and delivery problems; engineers lead RCA for technical incidents (see `incident-response.devsecops.incident-command`). AI accelerates RCA by rapidly synthesizing large volumes of data, logs, and feedback to surface patterns that humans would miss.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Can follow a 5-Why template; documents symptoms | Heavy — AI structures the analysis |
| 2 | Practitioner | Facilitates RCA sessions; writes RCA reports; tracks action items | Moderate — AI drafts, BA validates |
| 3 | Advanced | Selects appropriate RCA method for context; identifies systemic patterns across multiple RCAs | Light — AI surfaces patterns from historical data |
| 4 | Expert | Designs org-wide problem management process; trains teams | Minimal |
| 5 | Distinguished | Published RCA methodology contributions | AI as data analyst |

**Current team target level:** `2`
**Expected time to Practitioner (L2):** `2–4 months`

---

## Prerequisites

### Required Tools Access
- **Confluence** — RCA document publishing
- **Jira** — corrective action tracking
- **Miro** — fishbone (Ishikawa) diagram facilitation

### Required Knowledge
- 5-Why technique
- Fishbone (Ishikawa) diagram
- Fault Tree Analysis (FTA) basics
- Distinction between symptom, contributing factor, and root cause
- Corrective vs. preventive action (CAPA framework)
- Blameless culture principles

---

## Workflow

### Step 1: Problem Statement Definition
Before starting any RCA, write a precise problem statement:
> "On [date/time], [what happened], resulting in [impact]. This should NOT happen because [expected behavior]."

Ambiguous problem statements produce ambiguous RCAs. The AI can help sharpen this.

**AI Assist:** `Yes` — "Refine this problem statement to be specific, measurable, and bounded"

### Step 2: Method Selection

| Method | Best For | Complexity |
|---|---|---|
| 5-Why | Single-thread problems; process failures; quick analysis | Low |
| Fishbone (Ishikawa) | Multi-causal problems; people/process/technology intersection | Medium |
| Fault Tree Analysis | Safety-critical systems; formal documentation required | High |
| Change Analysis | Problem correlated with a recent change | Low |
| FMEA | Proactive risk analysis before a problem occurs | High |

**Decision Gate:** Incidents classified P0/P1 require Fishbone or FTA. P2/P3 can use 5-Why.

### Step 3: Evidence Collection
Gather: incident timeline, logs, metrics, configuration changes, deployment records, user reports, team observations. Create a factual timeline before the analysis session.

**AI Assist:** `Yes` — "Reconstruct a factual timeline from these Slack messages, PagerDuty alerts, and deployment records"

### Step 4: RCA Facilitation Session
Facilitated session with stakeholders (keep to <8 people; too many voices = no signal):
- Present the evidence timeline
- Apply chosen RCA method collaboratively
- Separate data from opinions
- Stop asking "who?" — ask "what?" and "why?"
- Reach consensus on root causes before ending session

### Step 5: Cause Validation
For each proposed root cause: if we fix this, would the problem be prevented? If "no" or "maybe," it's not the root cause — keep digging.

### Step 6: Corrective Action Development
For each root cause: define a corrective action (fixes the cause) and a preventive action (prevents recurrence). Every action must have: owner, due date, success criterion, verification method.

**AI Assist:** `Yes` — "For this root cause, suggest corrective and preventive actions used in similar systems"

### Step 7: RCA Report Publication
Publish to Confluence using the RCA template. Link from the incident ticket. Share with stakeholders within 48 hours of completing analysis.

### Step 8: Action Item Tracking
Track corrective actions in Jira. Review completion at monthly reliability review. An unresolved corrective action from an RCA is a risk indicator.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Confluence | RCA document template and publishing | Required | Yes (AI drafts) |
| Jira | Corrective action tracking | Required | No |
| Miro | Fishbone diagram facilitation | Recommended | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Stopping at the First Why
**What it looks like:** "Root cause: developer pushed buggy code." That's a symptom, not a root cause.  
**Why it's harmful:** The action item becomes "be more careful," which is not actionable.  
**Remediation:** Keep asking why until you reach something systemic and actionable. "Why was there no test? Why was the test suite not covering this case? Why was coverage not enforced?"

### ❌ Anti-Pattern 2: RCA as Blame Document
**What it looks like:** RCA names individuals as the cause. "John configured the server incorrectly."  
**Why it's harmful:** Culture of fear prevents honest reporting of future problems. People hide issues.  
**Remediation:** Never name individuals in RCA root causes. The system allowed John to make the error. Fix the system.

### ❌ Anti-Pattern 3: Action Items with No Owner or Due Date
**What it looks like:** "Improve monitoring" assigned to "Team" with no due date.  
**Why it's harmful:** Nothing gets done. The same incident happens again.  
**Remediation:** Every action item: one named owner, a specific deliverable, a specific due date.

---

## Troubleshooting Guide

### Problem: RCA session goes in circles with no consensus on root cause
**Root Cause(s):** Insufficient evidence; too many people with conflicting opinions; problem statement too broad  
**Diagnostic Steps:**
1. Check: is the problem statement specific enough?
2. Check: is there sufficient factual evidence, or are people theorizing?  
**Resolution:** Pause session. Assign evidence collection tasks. Return in 24 hours with data.  
**Prevention:** Never run an RCA session without a factual timeline prepared in advance.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Root cause implicates a third-party vendor | Legal + Vendor Manager | 48 hours | Formal communication |
| Root cause implicates a compliance control failure | CISO + Compliance Lead | 24 hours | Secure channel |
| Corrective actions require budget approval | Engineering Manager + Finance | 1 week | Budget request process |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| RCA completion rate (P0/P1 within 48h) | 60% | >95% | Jira RCA ticket tracking |
| Corrective action completion rate (within agreed date) | 45% | >85% | Jira tracking |
| Repeat incident rate (same root cause within 90 days) | 25% | <5% | Incident tag analysis |
| Average time from incident to RCA published | 5 days | <48 hours | Jira timestamps |

---

## Best Practices

1. **Facts Before Analysis** — Build the timeline first. Analysis without facts is speculation.
2. **Small Room, Right People** — RCA with 15 people produces consensus-driven mediocrity. 5–7 knowledgeable people is optimal.
3. **Separate Data from Interpretation** — In the fishbone session, capture observations separately from theories. Label them clearly.
4. **Systemic Causes Beat Individual Causes** — A root cause that can be fixed once to prevent the problem for everyone is better than one that requires ongoing individual vigilance.
5. **Close the Loop** — Follow up on corrective actions. An RCA with no completed actions is worse than no RCA (false assurance).

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI timeline reconstruction from Slack/logs | AI + Slack API + log aggregation | L2 | M |
| AI-draft RCA document from incident data | AI + Confluence API | L2 | M |
| Pattern detection across multiple RCAs | AI + RCA database | L3 | L |
| Auto-create corrective action Jira tickets from RCA | AI + Jira API | L2 | S |

---

## AI Prompt Examples

### Prompt 1: Facilitate a 5-Why Analysis
```
Role: You are a business analyst facilitating a 5-Why root cause analysis.
Context: Problem statement: "On 2026-05-20, the nightly data export job failed, 
         causing 3 downstream reports to contain stale data. Business impact: 
         2 client reports delivered with incorrect data."
  Known facts: [PASTE TIMELINE AND EVIDENCE]
Task: Guide a 5-Why analysis for this problem.
Constraints:
  - Start from the immediate cause and drill down 5 levels
  - Each "why" must be grounded in evidence, not speculation
  - Flag any level where more investigation is needed
  - End with: root cause statement, corrective action, preventive action
Output format: Numbered 5-Why chain, then Root Cause Statement, then CAPA table
```

---

## References & Further Reading
- [Toyota 5-Why](https://www.lean.org/lexicon-terms/5-whys/) — Original 5-Why methodology
- [Ishikawa Diagram](https://asq.org/quality-resources/fishbone/) — Fishbone diagram guide
- [Blameless Postmortems](https://sre.google/sre-book/postmortem-culture/) — Google SRE blameless culture
