---
id: "technical-writing.exec-comms.documentation"
title: "Technical Writing & Knowledge Management"
domain: "technical-writing"
role: "exec-comms"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "product-delivery-chapter"
last_reviewed: "2026-05-27"
tags: [technical-writing, documentation, runbooks, adr, knowledge-management, confluence]
prerequisites:
  skills: []
  tools: ["Confluence", "GitHub (docs-as-code)", "Grammarly or LanguageTool"]
  certifications: ["none (Google Technical Writing certificate recommended)"]
related_skills: ["architecture.architect.solution-design", "incident-response.devsecops.incident-command"]
ai_indexable: true
---

# Technical Writing & Knowledge Management

> **Domain:** `technical-writing` | **Role:** `exec-comms` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Technical Writing & Knowledge Management is the practice of creating, organizing, and maintaining documentation that enables engineers, support analysts, and business stakeholders to understand and operate complex systems. High-quality documentation reduces onboarding time, decreases incident MTTR, reduces support ticket volume, and preserves institutional knowledge. AI is a powerful accelerator for first-draft generation, documentation gap analysis, and keeping docs in sync with system changes.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Documents features and processes when directed; uses templates | Heavy — AI generates first drafts |
| 2 | Practitioner | Independently creates runbooks, API docs, and design documents | Moderate — AI drafts, writer edits for accuracy |
| 3 | Advanced | Designs documentation architecture; creates style guides; measures doc quality | Light — AI handles drafts, human validates technical accuracy |
| 4 | Expert | Defines knowledge management strategy; drives docs-as-code adoption | Minimal |
| 5 | Distinguished | Published technical writing community contributor; documentation toolchain builder | AI as productivity multiplier |

**Current team target level:** `2`
**Expected time to Practitioner (L2):** `2–4 months`

---

## Prerequisites

### Required Tools Access
- **Confluence** — primary documentation platform
- **GitHub** — docs-as-code for technical documentation alongside code
- **Mermaid / PlantUML** — diagrams in documentation

### Required Knowledge
- Docs-as-code philosophy (documentation lives with the code)
- Documentation types: reference, tutorial, how-to guide, explanation (Diátaxis framework)
- Audience analysis: developer, operator, end-user, executive
- Plain English principles: active voice, short sentences, one idea per paragraph
- Semantic versioning for documentation

---

## Workflow

### Step 1: Document Type Classification (Diátaxis Framework)
Before writing, classify the document type — this determines structure and tone:

| Type | User Goal | Structure |
|---|---|---|
| Tutorial | "I want to learn" | Step-by-step, learning-focused, hand-holding |
| How-To Guide | "I need to accomplish X" | Task-focused, assumes knowledge, practical |
| Reference | "I need to look up X" | Information-focused, complete, structured for scanning |
| Explanation | "I want to understand X" | Conceptual, context-rich, no steps |

### Step 2: Audience Definition
Write for one primary audience. "Developers and executives" is not an audience. If you need to reach both, write two documents or two clearly separated sections.

**AI Assist:** `Yes` — "Rewrite this technical runbook for a support analyst with no infrastructure knowledge"

### Step 3: Outline Before Writing
Create a heading outline (H2 and H3 only). Review the outline: does the structure tell the story? Are there gaps? Get SME sign-off on the outline before writing the full document.

**AI Assist:** `Yes` — "Generate a documentation outline for a runbook covering [system and scenario]"

### Step 4: First Draft
Write for clarity, not impressiveness. Principles:
- Active voice: "The system sends a notification" not "A notification is sent by the system"
- Short sentences: maximum 25 words
- One idea per paragraph
- Lead with the most important information
- Use numbered lists for steps; bullet lists for options/items; prose for explanation

**AI Assist:** `Yes` — AI generates first draft; writer validates technical accuracy and adds specific context

### Step 5: Diagrams & Visuals
Every system or process document should have at least one diagram. Use Mermaid for diagrams in code repositories (version-controlled). Use Confluence diagram macros for wiki-hosted docs.

Types to include:
- System context diagram (who talks to what)
- Sequence diagram (for processes and APIs)
- Decision tree (for troubleshooting guides)

### Step 6: SME Technical Review
All technical documentation requires review by a subject matter expert before publication. Track review status in the doc header. No publication without SME sign-off.

**Decision Gate:** No runbook goes live without: SME sign-off, a test walkthrough (did following the runbook actually work?), link from relevant alert.

### Step 7: Publication & Discoverability
Publish to the designated location. Add labels/tags for search. Link from: the relevant code README, the relevant Jira epic, the relevant Confluence space index.

### Step 8: Maintenance Cadence
Every document has an owner and a review date. Review triggers:
- System change that affects the documented behavior
- Scheduled quarterly review (for runbooks)
- Post-incident: did the runbook help or mislead?

**AI Assist:** `Yes` — "Identify which sections of this runbook are outdated given these recent system changes"

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Confluence | Primary documentation wiki | Required | Yes (AI generates) |
| GitHub (Markdown) | Docs-as-code alongside code | Required | Yes (AI generates) |
| Mermaid | Diagrams in Markdown | Required | Yes (AI generates) |
| Grammarly / LanguageTool | Writing quality | Recommended | No |
| Docusaurus / MkDocs | External developer docs portal | Optional | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Documentation That Describes What, Not Why
**What it looks like:** "Press button X to restart the service." Why does it need restarting? What are the symptoms that indicate a restart is needed? What happens after?  
**Why it's harmful:** Operators follow the steps without understanding, making the next incident harder.  
**Remediation:** Add context: symptoms, root cause (brief), what the step does, expected outcome, what to do if it doesn't work.

### ❌ Anti-Pattern 2: Stale Runbooks
**What it looks like:** Runbook says "SSH to server app-01" — that server was decommissioned 6 months ago.  
**Why it's harmful:** During an incident, a stale runbook wastes precious time and can cause additional errors.  
**Remediation:** Runbooks must be updated as part of system changes (docs-as-code enforces this). Post-incident: verify runbook was accurate; update if not.

### ❌ Anti-Pattern 3: Documentation in One Person's Head
**What it looks like:** "Ask Sarah, she knows how the billing integration works." Sarah leaves. System breaks.  
**Why it's harmful:** Key person dependency. Knowledge is organizational IP, not personal IP.  
**Remediation:** Identify knowledge-at-risk areas. Schedule documentation sessions with key knowledge holders. AI can accelerate transcription from interviews.

### ❌ Anti-Pattern 4: Documentation Desert (No Docs) and Documentation Swamp (Too Many)
**What it looks like:** Either no documentation exists, or 500 Confluence pages with no ownership, no index, and half of them outdated.  
**Why it's harmful:** Both are equally unusable. People stop looking for docs; they ask someone instead.  
**Remediation:** Define the documentation taxonomy. Archive stale docs. Create a "golden path" — one authoritative source per topic.

---

## Troubleshooting Guide

### Problem: Engineers refuse to maintain documentation (it's always out of date)
**Root Cause(s):** Documentation is perceived as extra work separate from "real work"; no tooling incentive; no consequence for non-maintenance  
**Diagnostic Steps:**
1. Where does documentation currently live? Is it close to the code?
2. How long does it take to update a doc when code changes?  
**Resolution:** Move to docs-as-code. Documentation PRs are part of the definition of done. AI generates first drafts, removing the "blank page" barrier.  
**Prevention:** Add documentation quality to the Definition of Done. Make it a PR checklist item.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Runbook inaccuracy causes incident escalation | Engineering Manager + Reliability Chapter | Post-incident | Retrospective |
| Documentation contains sensitive/confidential information inappropriately | Legal + Security | Immediate | Secure channel |
| Knowledge at risk (key person leaving with undocumented knowledge) | Engineering Manager | 2 weeks before departure | Sprint planning |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Runbook coverage (% alerts with linked runbook) | 35% | >90% | Alert annotation audit |
| Documentation freshness (last updated <90 days) | 40% | >80% | Confluence page metadata |
| Support ticket deflection by docs | Unknown | >30% deflection | Zendesk category tracking |
| Onboarding doc satisfaction (new hire survey) | 2.8/5 | >4/5 | Onboarding survey |
| Time to find information (user research) | 12 minutes avg | <3 minutes | Usability testing |

---

## Best Practices

1. **Diátaxis First** — Know the document type before you write. Mixing types creates documents that are good at nothing.
2. **Docs as Code** — Documentation lives in the same repository as the code it describes. It's reviewed in the same PR.
3. **One Source of Truth** — Never have two docs describing the same thing. If they exist, one will be wrong.
4. **Tested Runbooks** — A runbook that hasn't been tested isn't a runbook — it's a hope.
5. **The Curse of Knowledge** — Writers know too much. Always get someone unfamiliar with the system to attempt to follow the doc and report where they got stuck.
6. **AI for First Drafts, Humans for Accuracy** — AI is excellent at structure and language; it cannot verify technical accuracy. Always validate AI-generated technical content with SMEs.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-generate runbook from system description | AI + Confluence API | L2 | S |
| Auto-detect stale docs (code changed, doc not updated) | GitHub Actions + Confluence API | L3 | M |
| AI-generate API reference from OpenAPI spec | Redoc / Stoplight | L2 | S |
| Documentation gap analysis from support tickets | AI + Zendesk API | L3 | M |
| AI-translate technical docs to plain English | AI + Confluence | L2 | S |

---

## AI Prompt Examples

### Prompt 1: Generate a Runbook
```
Role: You are a technical writer creating an operational runbook.
Context: System: Redis cache cluster. Alert: "Redis memory usage >85%".
  System details: Redis 7.x on AWS ElastiCache; used for session storage and 
  API response caching; accessed by 3 services: auth-service, api-gateway, user-service.
Task: Write a complete runbook for responding to this alert.
Constraints:
  - Sections: Alert Description, Symptoms, Immediate Actions, Investigation Steps, 
    Resolution Options, Escalation, Prevention, Glossary
  - Include: exact commands, expected outputs, decision points
  - Audience: on-call engineer with general AWS knowledge but not a Redis expert
  - Every step must have: action, expected outcome, what to do if outcome is unexpected
Output format: Markdown runbook ready for Confluence publication
```

### Prompt 2: Simplify Technical Documentation
```
Role: You are a technical writer making documentation accessible to non-technical users.
Context: Here is documentation written for engineers:
  [PASTE TECHNICAL DOCUMENTATION]
Task: Rewrite this documentation for a business analyst or product manager audience.
Constraints:
  - Remove or explain all technical jargon
  - Replace command-line instructions with UI-based instructions where possible
  - Add context: why does this matter? what is the business impact?
  - Keep: accuracy, completeness
  - Target reading level: intelligent non-technical professional
Output format: Rewritten documentation in the same structure as the original
```

---

## References & Further Reading
- [Diátaxis Framework](https://diataxis.fr) — Documentation type classification
- [Google Developer Documentation Style Guide](https://developers.google.com/style) — Industry-standard style reference
- [Docs for Developers](https://docsfordevelopers.com) — Practical technical writing guide
