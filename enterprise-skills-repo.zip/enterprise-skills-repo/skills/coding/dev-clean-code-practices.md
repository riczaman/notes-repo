---
id: "coding.senior-dev.clean-code-practices"
title: "Clean Code & Software Craftsmanship"
domain: "coding"
role: "senior-dev"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "dev-experience-chapter"
last_reviewed: "2026-05-27"
tags:
  - clean-code
  - refactoring
  - code-review
  - solid-principles
  - testing
prerequisites:
  skills:
    - "coding.senior-dev.version-control"
  tools:
    - "SonarQube or similar SAST"
    - "IDE with linting (VS Code, IntelliJ)"
  certifications:
    - "none"
related_skills:
  - "coding.senior-dev.test-driven-development"
  - "architecture.architect.clean-architecture"
  - "cicd.devsecops.pipeline-design"
ai_indexable: true
---

# Clean Code & Software Craftsmanship

> **Domain:** `coding` | **Role:** `senior-dev` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Clean Code practices define how Senior Developers write, review, and evolve code that is readable, maintainable, and reliably correct. This skill covers naming conventions, function design, SOLID principles, refactoring techniques, and effective code review. In an AI-assisted delivery environment, clean code practices are doubly important: AI-generated code must be reviewed with the same rigor as human-written code, and well-structured codebases enable significantly more effective AI code generation.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Follows existing patterns; needs guidance on naming and structure | Heavy — AI generates boilerplate, suggests refactors |
| 2 | Practitioner | Writes readable code independently; identifies code smells in review | Moderate — AI pair-programs, generates tests |
| 3 | Advanced | Leads refactoring initiatives; mentors L1/L2; defines team standards | Light — AI validates; human reviews AI output critically |
| 4 | Expert | Owns code quality strategy; establishes automated quality gates | Minimal — AI as refactoring assistant |
| 5 | Distinguished | Publishes coding standards; trains org-wide; contributes to OSS | AI as research/documentation assistant |

**Current team target level:** `3`  
**Expected time to Practitioner (L2):** `3–6 months`

---

## Prerequisites

### Required Skills
- `coding.senior-dev.version-control` — Git workflow competency required

### Required Tools Access
- **SonarQube** — Static analysis, code smell detection, complexity metrics
- **IDE with language-native linter** — ESLint, Pylint, Checkstyle, ReSharper, etc.
- **GitHub / GitLab** — Code review via pull requests

### Required Knowledge
- SOLID principles (Single Responsibility, Open/Closed, Liskov, Interface Segregation, Dependency Inversion)
- DRY (Don't Repeat Yourself), YAGNI (You Aren't Gonna Need It), KISS
- Basic design patterns: Factory, Strategy, Observer, Repository
- Unit testing fundamentals (Arrange-Act-Assert)

---

## Workflow

### Step 1: Pre-Coding — Understand Before You Type
Read the requirement until you can explain it to a non-technical stakeholder. Write a brief intent comment or function signature stub before writing implementation. This forces interface design before implementation.

**AI Assist:** `Yes` — "Given this user story, generate the function signatures for the service layer (no implementation, interfaces only)"

### Step 2: Write the Simplest Thing That Works
Implement the minimum to pass the test (TDD) or satisfy the acceptance criteria. Resist adding "future flexibility" not required by the current ticket.

**Anti-pattern watch:** Gold-plating, over-abstraction

### Step 3: Naming Review Pass
After first implementation, re-read every variable, function, and class name. Ask: does this name reveal intent without a comment? Rename until it does.

**AI Assist:** `Yes` — "Review this code block and suggest better names for variables and functions that more clearly reveal intent"

### Step 4: Function Size & Single Responsibility Check
No function should exceed 20 lines (hard guideline; justified exceptions documented). Each function does one thing. Extract until you can't extract further without absurdity.

### Step 5: Test Coverage
Write unit tests for all public interfaces. Aim for branch coverage >80%. For complex business logic, target >90%. Tests must be fast (<5s for unit test suite), isolated, and deterministic.

**AI Assist:** `Yes` — AI generates test stubs; developer adds meaningful assertions

### Step 6: Code Review Submission
Open a PR with: description of what changed and why, link to ticket, test evidence (screenshot or CI link), self-review checklist completed.

**Decision Gate:** CI must be green (all tests pass, linter clean, SonarQube quality gate passed) before requesting review.

### Step 7: Code Review Response
Address all reviewer comments within 24 hours (business hours). "Resolved" means either fixed or replied with a counterargument. No comment should be silently dismissed.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| SonarQube | Complexity, duplication, security hotspots | Required | No |
| ESLint / Pylint | Language-specific linting | Required | No |
| GitHub Copilot / Claude | Code generation, test writing, review | Optional | Yes |
| Danger.js | PR rule enforcement (PR size, missing tests) | Optional | No |
| CodeClimate | Technical debt tracking | Optional | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Magic Numbers & Strings
**What it looks like:** `if (status === 3)` or `setTimeout(fn, 86400000)`  
**Why it's harmful:** Code is unreadable; meaning is lost; changes require grep across the codebase.  
**Remediation:** Extract to named constants: `const STATUS_PENDING = 3`, `const ONE_DAY_MS = 86_400_000`

### ❌ Anti-Pattern 2: Comment-Driven Code (instead of Self-Documenting Code)
**What it looks like:** Comments explaining WHAT code does rather than WHY. `// increment i` above `i++`  
**Why it's harmful:** Comments lie (they get out of sync with code). Code can't lie.  
**Remediation:** Rename until comments are unnecessary. Reserve comments for non-obvious WHY explanations only.

### ❌ Anti-Pattern 3: Swallowing Exceptions
**What it looks like:** `try { ... } catch (e) {}` or logging and continuing as if nothing happened  
**Why it's harmful:** Silent failures cause data corruption and are nearly impossible to debug.  
**Remediation:** Either handle the exception meaningfully or let it propagate. Log with full context. Never suppress.

### ❌ Anti-Pattern 4: Accepting AI-Generated Code Without Review
**What it looks like:** Developer pastes AI output directly into PR without reading it  
**Why it's harmful:** AI generates plausible-looking but logically incorrect, insecure, or untested code with regularity.  
**Remediation:** Treat AI code as a junior developer's first draft. Perform the same review you'd give any untested code.

### ❌ Anti-Pattern 5: God Class / God Function
**What it looks like:** A `UserService` with 40 methods spanning authentication, billing, notifications, and reporting  
**Why it's harmful:** Every change is a risk. Testing is impossible. The class can't be owned by one person or team.  
**Remediation:** Apply SRP. Decompose by responsibility. Apply Domain-Driven Design bounded context thinking.

---

## Troubleshooting Guide

### Problem: SonarQube quality gate failing on cognitive complexity
**Root Cause(s):** Functions with deep nesting, multiple loops, complex conditional chains  
**Diagnostic Steps:**
1. Identify the specific function(s) flagged (SonarQube links directly)
2. Map the control flow paths  
**Resolution:** Extract nested blocks to well-named private functions; replace complex conditionals with guard clauses or strategy pattern  
**Prevention:** Set IDE plugin to warn on complexity >10 before commit

### Problem: Test suite is slow (>2 min for unit tests)
**Root Cause(s):** Tests calling real databases, external APIs, or file systems; no mocking strategy  
**Diagnostic Steps:**
1. Profile test suite: `jest --verbose` or equivalent
2. Identify tests that take >100ms — these are integration tests masquerading as unit tests  
**Resolution:** Mock all I/O boundaries. Move true integration tests to a separate suite run less frequently.  
**Prevention:** Define the test pyramid contract in the repo's CONTRIBUTING.md

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| SonarQube flags security vulnerability (BLOCKER/CRITICAL) | Security Engineer | Immediate | `#security-alerts` |
| PR review disagreement unresolved after 2 rounds | Engineering Manager | 48 hours | Sync meeting |
| Technical debt exceeds threshold (SonarQube debt ratio >5%) | Architect + EM | Sprint planning | Debt backlog ticket |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| SonarQube quality gate pass rate | 70% | 98% | SonarQube dashboard |
| Code review turnaround time | 3 days | <1 business day | GitHub PR analytics |
| Unit test coverage (branch) | 55% | >80% | Coverage report in CI |
| Cyclomatic complexity (avg per function) | 12 | <7 | SonarQube |
| PR size (lines changed) | 600 lines avg | <300 lines avg | GitHub analytics |

---

## Best Practices

1. **Boy Scout Rule** — Always leave the code cleaner than you found it. Every PR should include at least one small cleanup unrelated to the feature.
2. **PR Size Discipline** — PRs over 400 lines are rarely reviewed well. Break features into smaller, reviewable slices.
3. **Test Names as Documentation** — `test_should_return_404_when_user_not_found()` is documentation. Name tests to describe behavior, not implementation.
4. **Fail Fast** — Validate inputs at system boundaries. Don't let bad data propagate deep into the call stack.
5. **Immutability by Default** — Prefer immutable data structures. Mutation is the leading cause of unexpected state bugs.
6. **AI Code Review Mindset** — When reviewing AI-generated code, explicitly check: correctness (does it handle edge cases?), security (any injection vectors?), performance (any N+1 queries?), and testability.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| Auto-generate unit test stubs from function signatures | AI + CI hook | L2 | S |
| PR quality gate enforcement (size, coverage, linter) | Danger.js + GitHub Actions | L2 | S |
| AI-assisted code review comments on PR | GitHub Copilot Code Review / custom | L3 | M |
| Automated refactoring suggestions on merge to main | SonarQube + Jira integration | L3 | M |
| Tech debt burn-down tracking dashboard | SonarQube + Grafana | L3 | L |

---

## AI Prompt Examples

### Prompt 1: Refactor for Readability
```
Role: You are a senior software engineer focused on clean code principles.
Context: Here is a JavaScript function that works but is difficult to read:
  [PASTE FUNCTION]
Task: Refactor this function to improve readability and maintainability.
Constraints:
  - Do not change external behavior (inputs/outputs must remain identical)
  - Apply SOLID principles where applicable
  - No function should exceed 20 lines
  - Add JSDoc comments for the public interface only
  - Explain each refactoring decision in a comment above the change
Output format: Refactored code followed by a bullet list of changes made
```

### Prompt 2: Generate Unit Tests
```
Role: You are a senior developer writing tests for the following function.
Context: [PASTE FUNCTION AND ITS INTERFACE/TYPES]
Task: Write comprehensive unit tests using [Jest/pytest/JUnit].
Constraints:
  - Use Arrange-Act-Assert pattern
  - Test: happy path, edge cases, error cases, boundary values
  - Mock all external dependencies (database, HTTP calls, filesystem)
  - Test names must describe behavior: "should_return_X_when_Y"
  - No test should take longer than 100ms
Output format: Complete test file, ready to run
```

### Prompt 3: Code Review AI Assistant
```
Role: You are a staff engineer performing a code review.
Context: [PASTE PR DIFF OR CODE BLOCK]
Task: Review this code for quality, correctness, security, and maintainability.
Constraints:
  - Flag: BLOCKER (must fix), WARNING (should fix), SUGGESTION (nice to have)
  - Check for: security issues, logic errors, missing error handling, 
    poor naming, missing tests, performance concerns
  - Assume the team uses [LANGUAGE] with [FRAMEWORK]
  - Be specific: reference line numbers and explain why, not just what
Output format: Grouped list by severity, then category
```

---

## References & Further Reading

- [Clean Code — Robert C. Martin](https://www.oreilly.com/library/view/clean-code-a/9780136083238/) — Foundational text
- [Refactoring — Martin Fowler](https://refactoring.com) — Catalog of refactoring patterns
- [Google Engineering Practices](https://google.github.io/eng-practices/review/) — Code review standards
