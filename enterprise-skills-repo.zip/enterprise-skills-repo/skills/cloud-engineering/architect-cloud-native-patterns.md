---
id: "cloud-engineering.architect.cloud-native-patterns"
title: "Cloud Engineering & Cloud Native Patterns"
domain: "cloud-engineering"
role: "architect"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "architecture-chapter"
last_reviewed: "2026-05-27"
tags:
  - cloud
  - aws
  - gcp
  - azure
  - cloud-native
  - well-architected
  - finops
prerequisites:
  skills:
    - "architecture.architect.solution-design"
    - "networking.architect.fundamentals"
  tools:
    - "AWS/GCP/Azure CLI"
    - "AWS Well-Architected Tool"
    - "Infracost"
    - "Cloud provider cost explorer"
  certifications:
    - "AWS Solutions Architect Professional OR GCP Professional Cloud Architect OR Azure Solutions Architect Expert"
related_skills:
  - "terraform.devsecops.iac-design"
  - "kubernetes.devsecops.k8s-operations"
  - "security.devsecops.cloud-security-posture"
  - "monitoring.devsecops.observability-platform"
ai_indexable: true
---

# Cloud Engineering & Cloud Native Patterns

> **Domain:** `cloud-engineering` | **Role:** `architect` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Cloud Engineering covers the design and operation of cloud infrastructure and cloud-native applications. Architects own the cloud strategy, reference architectures, and landing zone design. Cloud-native patterns — managed services over custom solutions, event-driven architectures, serverless where appropriate, auto-scaling, and ephemeral infrastructure — enable organizations to build resilient, cost-efficient systems that can scale without proportional operational overhead.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Uses cloud console to provision resources; understands core services | Heavy — AI explains services and generates configs |
| 2 | Practitioner | Designs solutions using cloud-managed services; uses IaC; understands cost model | Moderate — AI generates IaC and architecture options |
| 3 | Advanced | Designs multi-region, multi-account architectures; owns FinOps practice | Light — AI validates against Well-Architected |
| 4 | Expert | Defines cloud strategy and landing zone; owns cloud governance | Minimal |
| 5 | Distinguished | Publishes cloud patterns; recognized cloud architect community contributor | AI as research assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `6–9 months`

---

## Prerequisites

### Required Skills
- `architecture.architect.solution-design` — cloud design is a specialization of solution design
- Networking fundamentals — VPC, subnets, routing, DNS, load balancing

### Required Tools Access
- **AWS/GCP/Azure CLI** — infrastructure management
- **AWS Well-Architected Tool** — NFR review framework
- **Cloud cost explorer + Infracost** — cost visibility
- **Cloud provider IAM console** — identity and access management

### Required Knowledge
- Cloud provider landing zones and account/project structures
- Networking: VPC design, subnets (public/private/isolated), NAT, Transit Gateway, VPC Peering
- Identity: IAM roles, policies, least privilege, identity federation
- Compute options: VM, containers (ECS/GKE/AKS), serverless (Lambda/Cloud Functions), managed K8s
- Data services: managed relational (RDS/CloudSQL), NoSQL (DynamoDB/Firestore), data warehouse (Redshift/BigQuery)
- FinOps: Reserved Instances/Committed Use Discounts, Savings Plans, right-sizing, tagging for cost allocation

---

## Workflow

### Step 1: Cloud Strategy Alignment
Confirm the organization's cloud strategy: primary cloud provider, multi-cloud or cloud-agnostic stance, hybrid cloud requirements. All designs must align with the approved cloud strategy.

### Step 2: Well-Architected Review (Framework Selection)
Apply the relevant cloud provider's Well-Architected Framework pillars to every design:
- **Operational Excellence** — runbooks, monitoring, CI/CD
- **Security** — least privilege, encryption, network segmentation
- **Reliability** — redundancy, recovery targets (RTO/RPO), chaos engineering
- **Performance Efficiency** — right-sized compute, caching, CDN
- **Cost Optimization** — reserved capacity, autoscaling, lifecycle policies
- **Sustainability** — resource efficiency, serverless where possible (AWS: 6th pillar)

**AI Assist:** `Yes` — "Review this architecture against the AWS Well-Architected Framework and identify gaps"

### Step 3: Account / Project Structure Design
Define account/project boundaries: one account/project per environment (dev/staging/prod) minimum. Use AWS Organizations or GCP Resource Hierarchy. Enable SCPs (Service Control Policies) to enforce guardrails.

### Step 4: Network Architecture
Design VPC layout:
- Public subnets: load balancers, NAT gateways only
- Private subnets: application workloads
- Isolated/data subnets: databases, caches — no route to internet
- Shared services VPC with Transit Gateway for cross-account connectivity

### Step 5: Managed Service Selection
Prefer managed services over self-managed equivalents. Decision matrix:

| Self-Managed | Managed Alternative | When to Choose Self-Managed |
|---|---|---|
| PostgreSQL on EC2 | RDS / CloudSQL | Almost never for standard use cases |
| Kafka on VMs | MSK / Confluent Cloud | If cost at scale justifies; team has expertise |
| Elasticsearch on EC2 | OpenSearch Service | Rarely; compliance edge cases |
| Redis on VMs | ElastiCache / Memorystore | Almost never |

### Step 6: FinOps Design Pass
For every architecture: estimate monthly cost using the cloud pricing calculator. Identify the top 3 cost drivers. Document reserved capacity opportunities. Define auto-scaling policy to prevent runaway spend.

**AI Assist:** `Yes` — "Estimate the monthly AWS cost for this architecture and identify the top optimization opportunities"

### Step 7: Disaster Recovery Design
Define RTO (Recovery Time Objective) and RPO (Recovery Point Objective) per tier. Map to DR strategy:

| Tier | RTO | RPO | Strategy |
|---|---|---|---|
| Tier 0 (Critical) | <15 min | <1 min | Active-Active multi-region |
| Tier 1 (Important) | <1 hour | <15 min | Active-Passive warm standby |
| Tier 2 (Standard) | <4 hours | <1 hour | Backup and restore + pre-warmed AMI |
| Tier 3 (Non-critical) | <24 hours | <24 hours | Backup and restore |

### Step 8: Cloud Security Baseline
Apply cloud security baseline (see `security.devsecops.cloud-security-posture`):
- Enable CloudTrail / Cloud Audit Logs (all regions, all services)
- Enable GuardDuty / Security Command Center
- Encrypt all storage at rest (KMS customer-managed keys for sensitive data)
- Block public access to S3 / GCS buckets at the account level
- Enable MFA for all human IAM users

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| AWS CLI / gcloud / az | Infrastructure management | Required | No |
| Terraform | IaC for all cloud resources | Required | Yes (AI generates) |
| AWS Well-Architected Tool | NFR framework review | Required | No |
| Infracost | Cost estimation | Required | No |
| AWS Trusted Advisor / GCP Recommender | Optimization recommendations | Optional | No |
| Prowler / ScoutSuite | Cloud security posture | Required (audit) | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Lift and Shift Without Cloud-Native Refactoring
**What it looks like:** On-premise application moved to cloud VMs with zero architectural change. No auto-scaling, no managed services, no cloud-native resilience patterns.  
**Why it's harmful:** Pays cloud prices for on-premise architecture. No resilience improvement. Higher cost and lower agility than staying on-premise.  
**Remediation:** Perform a 6R assessment (Rehost, Replatform, Repurchase, Refactor, Retire, Retain). Design a target state that exploits cloud-native capabilities.

### ❌ Anti-Pattern 2: Single-Account Everything
**What it looks like:** All environments (dev, staging, prod) and all teams sharing one AWS account / GCP project.  
**Why it's harmful:** No blast radius isolation. A dev experiment can impact production. Cost attribution is impossible. IAM becomes a mess.  
**Remediation:** Use AWS Organizations + multi-account strategy (minimum: separate prod account with SCPs).

### ❌ Anti-Pattern 3: Ignoring Data Egress Costs
**What it looks like:** Architecture that transfers terabytes between regions or to the internet without any cost modelling  
**Why it's harmful:** Egress can dominate a cloud bill. Cross-region data transfer and internet egress are expensive.  
**Remediation:** Design data locality (process where data lives). Use CDN for egress to clients. Model egress cost in FinOps review.

### ❌ Anti-Pattern 4: Hardcoded AWS Credentials in Application Code
**What it looks like:** `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` in environment variables or `.env` files in containers  
**Why it's harmful:** Long-lived credentials in code are the #1 cause of cloud account compromise.  
**Remediation:** Use IAM roles for EC2/ECS/EKS (instance profile / pod identity). Applications should never hold static credentials.

---

## Troubleshooting Guide

### Problem: Cloud bill 40% higher than estimated
**Root Cause(s):** Unexpected data transfer; un-rightsized compute; forgotten dev resources left running; NAT gateway costs  
**Diagnostic Steps:**
1. Open Cost Explorer → group by Service → identify top 3 cost drivers
2. Enable Cost Anomaly Detection alerts
3. Check for untagged resources (no owner = no accountability)  
**Resolution:** Right-size identified resources. Remove unused resources. Set up budget alerts at 80% and 100% of projected spend.  
**Prevention:** Infracost in every Terraform PR. Monthly FinOps review. Auto-shutdown dev environments overnight.

### Problem: Cross-account IAM role assumption failing
**Root Cause(s):** Trust policy misconfiguration; missing `sts:AssumeRole` permission; MFA condition blocking automation  
**Diagnostic Steps:**
1. Check the trust policy on the target role — does it trust the source account/role?
2. Check the source identity has `sts:AssumeRole` on the target role ARN
3. Check CloudTrail for `AccessDenied` events with full error context  
**Resolution:** Fix trust policy and/or permission policy as indicated.  
**Prevention:** Test cross-account role assumption in dev environment before prod.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Cloud bill exceeds budget by >20% | FinOps Lead + VP Engineering | 48 hours | `#finops-escalations` |
| GuardDuty / SCC CRITICAL finding | Security Engineer + CISO | Immediate | `#security-incidents` |
| Region outage (cloud provider) affecting production | Engineering Manager + On-call | 15 minutes | Incident bridge + `#incidents` |
| Data residency/compliance violation detected | CISO + Legal | Immediate | Private channel + email |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Cloud cost per unit of business value | Unknown | Defined and trending down | Kubecost / cost allocation tags |
| Reserved/committed coverage | 20% | >60% of steady-state compute | Cloud provider console |
| Multi-AZ coverage (prod) | 60% of services | 100% of Tier 0/1 services | Architecture audit |
| Well-Architected high-risk issues | 14 | <3 | Well-Architected Tool report |
| Cloud security benchmark score | 65% | >85% | Prowler / Security Hub score |

---

## Best Practices

1. **Design for Failure** — Every component will fail. Design assuming failure, not hoping for success. Multi-AZ is not optional for production.
2. **Managed Services First** — The organization's core competency is not running databases. Use managed services and focus engineering on differentiated work.
3. **Tag Everything** — Cost center, owner, environment, application. Untagged resources are unaccountable resources.
4. **Immutable Infrastructure** — Don't patch running servers. Replace them. Build AMIs/container images in CI; deploy; destroy old.
5. **FinOps is an Architecture Concern** — Cost decisions are architecture decisions. FinOps review happens at design time, not at the end of the month.
6. **Assume Zero Trust** — No implicit trust based on network location. All service-to-service calls authenticated and authorized. mTLS where possible.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| Auto-shutdown non-prod environments overnight | Lambda scheduler + IaC | L2 | S |
| Budget alert → Slack notification | CloudWatch Budgets + SNS | L2 | S |
| Well-Architected review automation | AWS WA Tool API + reporting | L3 | M |
| Cloud security posture continuous scan | Prowler in CI/CD | L2 | M |
| Spot instance auto-failover for stateless workloads | Spot Fleet / Karpenter | L3 | M |

---

## AI Prompt Examples

### Prompt 1: Well-Architected Review
```
Role: You are a cloud architect performing a Well-Architected Review.
Context: We are building a multi-tenant SaaS application on AWS. Here is the architecture:
  [PASTE ARCHITECTURE DESCRIPTION OR DIAGRAM DESCRIPTION]
Task: Evaluate this architecture against all 6 AWS Well-Architected pillars.
Constraints:
  - For each pillar: identify High Risk Issues (HRIs) and Medium Risk Issues
  - Provide specific remediation steps, not just identification
  - Prioritize findings by risk level and implementation effort
  - Reference specific AWS services that address each finding
Output format: One section per pillar, with Risk Level | Finding | Remediation table
```

### Prompt 2: Cloud Cost Optimization Analysis
```
Role: You are a FinOps architect analyzing cloud costs.
Context: Our AWS monthly bill is $85,000. Cost breakdown:
  EC2: $42,000 | RDS: $18,000 | Data Transfer: $12,000 | 
  S3: $6,000 | NAT Gateway: $4,500 | Other: $2,500
Task: Identify the top optimization opportunities and estimate savings.
Constraints:
  - Assume: 70% of EC2 is steady-state (not bursty)
  - Assume: RDS instances are running 24/7 in dev/staging too
  - Do not recommend changes that increase operational complexity significantly
Output format: Opportunity, Estimated Monthly Saving, Implementation Effort (S/M/L), Risk
```

---

## References & Further Reading

- [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/) — Primary reference
- [GCP Architecture Framework](https://cloud.google.com/architecture/framework) — GCP equivalent
- [FinOps Foundation](https://www.finops.org) — Cloud financial management practices
- [Cloud Native Patterns](https://cloudnativepatterns.com) — Pattern catalog
