---
id: "system-design.architect.distributed-systems"
title: "Distributed System Design"
domain: "system-design"
role: "architect"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "architecture-chapter"
last_reviewed: "2026-05-27"
tags: [system-design, distributed-systems, scalability, consistency, cap-theorem, microservices]
prerequisites:
  skills: ["architecture.architect.solution-design", "cloud-engineering.architect.cloud-native-patterns"]
  tools: ["Mermaid / Structurizr", "AWS/GCP architecture tools"]
  certifications: ["AWS Solutions Architect Professional (recommended)"]
related_skills: ["performance-optimization.senior-dev.perf-tuning", "monitoring.devsecops.observability-platform"]
ai_indexable: true
---

# Distributed System Design

> **Domain:** `system-design` | **Role:** `architect` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Distributed System Design is the practice of architecting systems that run across multiple nodes, services, or geographic locations to achieve scalability, resilience, and performance goals that a single server cannot provide. Architects own this skill to ensure systems are designed with appropriate consistency models, partition tolerance strategies, failure handling, and data distribution patterns. It is the foundation of cloud-native architecture and directly impacts system reliability and user experience at scale.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Understands CAP theorem; can describe microservices vs. monolith | Heavy — AI explains concepts and trade-offs |
| 2 | Practitioner | Designs services with defined consistency models and failure handling | Moderate — AI validates design decisions |
| 3 | Advanced | Designs systems handling 100K+ RPS; owns sharding and replication strategy | Light — AI as reference |
| 4 | Expert | Designs global-scale systems; defines org-wide distributed systems standards | Minimal |
| 5 | Distinguished | Published distributed systems research; open source contributions | AI as research assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `9–12 months`

---

## Prerequisites

### Required Skills
- `architecture.architect.solution-design` — prerequisite foundation
- `cloud-engineering.architect.cloud-native-patterns` — cloud infrastructure context

### Required Knowledge
- CAP Theorem (Consistency, Availability, Partition Tolerance — pick 2)
- PACELC model (extending CAP with latency trade-offs)
- Consistency models: strong, sequential, causal, eventual
- Consensus algorithms: Raft, Paxos basics
- Data partitioning: hash, range, directory-based sharding
- Replication: leader-follower, multi-leader, leaderless
- Distributed transactions: 2PC, SAGA pattern, outbox pattern
- Message queues: point-to-point, pub/sub, ordering guarantees, at-least-once vs. exactly-once

---

## Workflow

### Step 1: Requirements Clarification
For any system design, clarify before designing:
- Scale: users, RPS, data volume (current and 3-year projection)
- Latency SLO: read p99, write p99
- Consistency requirement: can we tolerate stale reads? by how much?
- Availability requirement: 99.9% vs. 99.99% (each 9 has a cost)
- Geographic distribution: single region, multi-region, global?
- Read/write ratio: read-heavy (cache aggressively) or write-heavy (optimize write path)

**AI Assist:** `Yes` — "Given these requirements, what are the key trade-offs I should address in this system design?"

### Step 2: High-Level Architecture
Sketch the major components: clients, load balancers, application servers, caches, databases, message queues, CDN. Identify the critical path for the most latency-sensitive operation.

### Step 3: Data Model Design
Design the data model for the primary access patterns first, not normalized first:
- What are the top 5 read queries?
- What are the top 3 write operations?
- Which queries require consistency? Which can be eventually consistent?

### Step 4: Consistency Model Selection
For each data store/service boundary, explicitly choose the consistency model:

| Model | When to Use | Trade-off |
|---|---|---|
| Strong consistency | Financial transactions, inventory | Higher latency, lower availability |
| Eventual consistency | Social feeds, analytics, read replicas | Lower latency, possible stale reads |
| Causal consistency | Collaboration features, comments | Medium complexity |
| Read-your-writes | User profile, settings | Session-scoped consistency |

### Step 5: Failure Mode Analysis
For every component: what happens when it fails? Design the recovery:
- **Retry with exponential backoff + jitter** — for transient failures
- **Circuit breaker** — for persistent downstream failures
- **Bulkhead** — isolate failures so one component doesn't exhaust shared resources
- **Fallback/degraded mode** — serve cached/partial data when a dependency is down
- **Idempotency keys** — for safe retries on write operations

### Step 6: Scalability Strategy
Identify bottlenecks at 10x current load. Apply the appropriate scaling pattern:

| Bottleneck | Strategy |
|---|---|
| Database reads | Read replicas + caching (Redis) |
| Database writes | Horizontal sharding, CQRS write path |
| Compute | Horizontal auto-scaling, stateless services |
| API | Rate limiting, request coalescing, async processing |
| Data size | Tiered storage, archival, compression |

### Step 7: Caching Strategy
Design the cache hierarchy:
- Client-side (browser cache, CDN) → Gateway cache → Application cache (Redis) → Database cache
- Define TTL per cache layer
- Define cache invalidation strategy (TTL expiry, event-driven invalidation, cache-aside)
- Document what happens on cache miss at each layer (thundering herd protection)

### Step 8: Distributed Transaction Strategy
Where you need multi-service consistency:
- **SAGA pattern** — choreography (events) or orchestration (workflow engine); each step has a compensating transaction
- **Outbox pattern** — transactionally write events with the state change, consume from message broker
- **Avoid 2PC** — distributed transactions with 2PC are fragile and slow; prefer SAGA in most cases

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Mermaid | Sequence/architecture diagrams | Required | Yes (AI generates) |
| Structurizr | C4 model | Required | No |
| AWS DynamoDB / Cassandra | Eventually consistent distributed DB | Optional | No |
| Redis | Caching, distributed locks, pub/sub | Required (most designs) | No |
| Kafka / SQS | Distributed messaging | Required (event-driven) | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Distributed Monolith
**What it looks like:** Multiple services that must all be deployed together and share a database.  
**Why it's harmful:** Worst of both worlds: operational complexity of microservices, coupling of a monolith.  
**Remediation:** Each service owns its data. Deploy independently. Communicate via well-defined APIs or events.

### ❌ Anti-Pattern 2: Synchronous Everything
**What it looks like:** Service A calls Service B calls Service C — all synchronously for every user request.  
**Why it's harmful:** Latency adds up. Any service failure cascades. P99 latency = P99(A) + P99(B) + P99(C).  
**Remediation:** Identify operations that don't need to be synchronous. Move to async (message queue) where possible. Cache aggressively.

### ❌ Anti-Pattern 3: No Idempotency on Writes
**What it looks like:** Payment endpoint can double-charge if the client retries on timeout.  
**Why it's harmful:** Duplicate operations in a distributed system are common (at-least-once delivery). Without idempotency, they cause data corruption.  
**Remediation:** All write endpoints accept an `idempotency-key`. Deduplicate using that key in the database.

### ❌ Anti-Pattern 4: Global State Without a Leader
**What it looks like:** Multiple services write to the same counter/inventory without coordination.  
**Why it's harmful:** Race conditions under concurrent writes cause incorrect values.  
**Remediation:** Designate a single leader for globally consistent state. Use optimistic locking, distributed locks (Redis Redlock), or reservation patterns for inventory.

---

## Troubleshooting Guide

### Problem: Service latency spikes under load but baseline is fine
**Root Cause(s):** Connection pool exhaustion; lock contention in database; noisy neighbor on shared infrastructure; GC pauses  
**Diagnostic Steps:**
1. Check p99 vs. p50 latency gap — large gap suggests tail latency issue
2. Check DB connection pool wait time metric
3. Check GC pause time (Java/Go applications)
4. Check CPU steal time (virtualization contention)  
**Resolution:** Increase connection pool (with caution — too large causes DB overload). Add read replicas. Tune GC.  
**Prevention:** Load test to 3x expected peak. Instrument connection pool metrics from day one.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| System not meeting agreed SLO at design-time scale | Architect + VP Engineering | 1 week | Architecture review |
| Data consistency violation discovered in production | Architect + EM + Data team | Immediate | `#incidents` |
| Capacity ceiling reached unexpectedly | Cloud Architect + EM | 48 hours | `#engineering-ops` |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| P99 API latency at peak load | Defined per service | Within SLO at 2x load | Load test results |
| System availability (rolling 30 days) | 99.5% | Per-tier SLO | Uptime monitoring |
| Failure mode coverage (% components with defined failure handling) | 40% | >90% | Architecture review checklist |
| Cache hit rate (primary cache) | 55% | >80% | Redis / CDN metrics |

---

## Best Practices

1. **Design for the P99, Not the Average** — Average latency is a lie. P99 and P999 are what users experience during peak.
2. **Make Failure a First-Class Concern** — Design failure handling before you design the happy path.
3. **Prefer Async Over Sync** — Synchronous calls create coupling. Async communication decouples timing.
4. **Idempotency Everywhere** — Assume every request will be retried. Design accordingly.
5. **Measure Before Optimizing** — Profile before adding a cache or shard. Premature optimization creates complexity without benefit.
6. **Start with the Data Model** — In distributed systems, the data model determines everything: access patterns, consistency model, sharding strategy.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI system design reviewer | AI + architecture checklist | L2 | M |
| Load test scenario generation from API spec | AI + k6 | L3 | M |
| Capacity planning model from metrics | AI + time series data | L3 | L |
| Architecture fitness function CI tests | ArchUnit / Deptrac | L3 | M |

---

## AI Prompt Examples

### Prompt 1: System Design Review
```
Role: You are a distributed systems architect reviewing a design.
Context: [PASTE SYSTEM DESIGN DESCRIPTION OR DIAGRAM DESCRIPTION]
Task: Review this design for distributed systems correctness and scalability.
Constraints:
  - Check: consistency model appropriateness, failure handling completeness, 
    scalability bottlenecks, data model access pattern alignment, 
    missing idempotency, synchronous call chains under load
  - At each issue: state the risk, failure scenario, and recommended fix
  - Scale assumption: 10x current stated load
Output format: Findings table (severity, component, issue, recommendation) then prioritized action list
```

---

## References & Further Reading
- [Designing Data-Intensive Applications — Martin Kleppmann](https://dataintensive.net) — The definitive distributed systems book
- [System Design Interview — Alex Xu](https://bytebytego.com) — Practical design patterns
- [The Google SRE Book](https://sre.google/sre-book/table-of-contents/) — Production distributed systems
- [AWS Architecture Center](https://aws.amazon.com/architecture/) — Cloud distributed system patterns
