---
id: "executive-reporting.exec-comms.stakeholder-comms"
title: "Executive Reporting & Stakeholder Communications"
domain: "executive-reporting"
role: "exec-comms"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "product-delivery-chapter"
last_reviewed: "2026-05-27"
tags: [executive-comms, reporting, stakeholders, presentations, status-updates, metrics]
prerequisites:
  skills: []
  tools: ["PowerPoint / Google Slides", "Confluence", "Tableau or Power BI (optional)"]
  certifications: ["none"]
related_skills: ["agile-delivery.product-manager.sprint-delivery", "technical-writing.comms.documentation"]
ai_indexable: true
---

# Executive Reporting & Stakeholder Communications

> **Domain:** `executive-reporting` | **Role:** `exec-comms` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Executive Reporting & Stakeholder Communications is the practice of translating complex technical and delivery information into clear, decision-enabling communications for senior leadership and non-technical stakeholders. Executive Communications Specialists bridge the gap between engineering teams and business leadership — ensuring executives have the right information to make informed decisions, allocate resources, and maintain confidence in the delivery organization. AI dramatically accelerates first-draft creation, data synthesis, and narrative construction.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Populates status report templates; compiles metrics from inputs provided | Heavy — AI drafts reports from data inputs |
| 2 | Practitioner | Creates executive presentations independently; manages reporting cadence | Moderate — AI drafts, human shapes narrative |
| 3 | Advanced | Advises senior leaders on communication strategy; manages crisis comms | Light — AI handles drafts, human adds insight |
| 4 | Expert | Defines org-wide communication framework; executive coaching | Minimal |
| 5 | Distinguished | Published communication leadership; C-suite advisory | AI as productivity tool |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `3–5 months`

---

## Prerequisites

### Required Tools Access
- **PowerPoint / Google Slides** — executive presentations
- **Confluence** — written reports and status pages
- **Data source access** — Jira, Grafana, PagerDuty (for metrics extraction)

### Required Knowledge
- Pyramid Principle (conclusion-first communication)
- Executive audience needs: decisions, risks, resources, timeline
- Metrics literacy: can interpret DORA metrics, SLOs, financial metrics
- Crisis communication principles
- Storytelling frameworks (Situation-Complication-Resolution)

---

## Workflow

### Step 1: Audience Analysis
Before writing anything, define:
- **Who**: specific individuals, their role, what they care about
- **What decision** they need to make (or what they need to understand)
- **What they already know** (avoid over-explaining; avoid assuming too much)
- **What action** you need from them (approve, fund, unblock, note)

**AI Assist:** `Yes` — "For a CTO audience reviewing a security incident, what are the top 5 questions they will want answered?"

### Step 2: Data Collection & Synthesis
Gather: sprint metrics, incident data, SLO status, budget tracking, risk register, key decisions pending. AI synthesizes raw data into executive-ready summaries.

**AI Assist:** `Yes` — "Summarize this sprint report and these 3 incident postmortems into a 3-bullet executive update"

### Step 3: Message Architecture (Pyramid Principle)
Structure all executive communication:
1. **Lead with the conclusion** — the most important message first
2. **Supporting arguments** — 3 key points that support the conclusion
3. **Evidence** — data, details, appendix

Never bury the headline. If you're telling an executive that a delivery is at risk, say it in the first sentence.

### Step 4: Draft Creation
Written reports: maximum 1 page for weekly updates; 2–3 pages for monthly; 5–7 pages for quarterly business reviews. Presentations: 1 key message per slide; maximum 10 slides for a 30-minute executive review.

**AI Assist:** `Yes` — AI generates first draft; human refines tone, accuracy, and strategic framing

### Step 5: Data Visualization Selection
Match visualization to the message:
- Trend over time → line chart
- Comparison between items → bar chart
- Part of a whole → pie/donut (use sparingly; max 5 segments)
- Status at a glance → RAG (Red/Amber/Green) table
- Single important number → large metric callout

Avoid: 3D charts, dual-axis charts unless absolutely necessary, tables with >7 rows in a slide.

### Step 6: Review & Calibration
Before any executive delivery: have the Engineering Manager review for technical accuracy; have the PM review for business accuracy. No single person should review their own executive communication without a second pair of eyes.

### Step 7: Delivery & Feedback Loop
For live presentations: send materials 24 hours in advance. Arrive early. Lead with the ask/decision needed. Leave 40% of time for questions.

For async reports: post to Confluence + summary in Slack. Follow up within 24 hours to confirm receipt.

Capture executive feedback and questions as institutional knowledge — they reveal what matters.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| PowerPoint / Google Slides | Executive presentations | Required | Yes (AI drafts) |
| Confluence | Written reports, status pages | Required | Yes (AI drafts) |
| Tableau / Power BI | Data visualization | Optional | No |
| Canva | Visual design for non-technical audiences | Optional | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Data Dumps Instead of Insights
**What it looks like:** Executive report contains 12 metrics tables with no interpretation. "Here are the numbers."  
**Why it's harmful:** Executives don't have time to interpret raw data. If you don't tell them what it means, they'll conclude something you didn't intend.  
**Remediation:** Every metric must have: the number, the trend (↑↓), and a one-sentence interpretation. "P99 latency increased 40% this week due to the database migration — we expect it to normalize by Wednesday."

### ❌ Anti-Pattern 2: Technical Jargon for Non-Technical Audiences
**What it looks like:** "Our P99 latency SLO burn rate hit 14x, triggering our fast-burn alert threshold."  
**Why it's harmful:** Audience disengages. They either tune out or ask questions that derail the meeting.  
**Remediation:** Translate to impact: "Our checkout page was significantly slower than normal for about 2% of users over the past week. We've identified the cause and fixed it."

### ❌ Anti-Pattern 3: Status Reports with Only Green Status
**What it looks like:** Every project is GREEN, every metric is on target, every quarter. Executives learn to distrust the reports.  
**Why it's harmful:** Creates false confidence. When a real problem emerges, no one saw it coming because the signal was always green.  
**Remediation:** If something is AMBER, say so early. If it's RED, say so immediately and with a plan. Honest reporting builds trust.

### ❌ Anti-Pattern 4: Delivering Bad News Late
**What it looks like:** A significant delivery risk is discovered on Monday and reported at the Friday executive review.  
**Why it's harmful:** Executives have no time to respond. They feel blindsided. Trust erodes.  
**Remediation:** Bad news travels immediately. A brief Slack message or email the same day as discovery, with more detail to follow.

---

## Troubleshooting Guide

### Problem: Executive keeps asking for more detail than the report contains
**Root Cause(s):** Mismatch between what the executive wants vs. the report design; the executive doesn't trust the summary level  
**Diagnostic Steps:**
1. Ask: "What specific additional information would be helpful?"
2. Determine if this is a one-time deep-dive or a recurring need  
**Resolution:** For one-time: schedule a deeper briefing. For recurring: add a data appendix to the standard report.  
**Prevention:** In the first report to a new executive, explicitly ask: "What format and level of detail works best for you?"

### Problem: Executive presentation runs over time and key decisions don't get made
**Root Cause(s):** Too much content; no clear ask; discussion went off-topic  
**Diagnostic Steps:**
1. Count slides — >1 slide per 3 minutes is too many
2. Check: was the ask/decision clear on slide 1?  
**Resolution:** Cut to the ask. Put backup slides in an appendix.  
**Prevention:** Every executive meeting has a pre-shared agenda with: time for each topic, what decision is needed.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Significant delivery risk (>1 sprint off track) | EM → VP Engineering | Same day | Slack + email |
| Security or compliance incident | CISO → Executive Sponsor | Immediate | Call + email |
| Budget overrun >15% | Engineering Manager + Finance | 48 hours | Email + meeting request |
| Media/customer escalation reaching C-suite | VP Comms + CEO | Immediate | Direct call |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Executive report on-time delivery rate | 75% | >98% | Report publish timestamp vs. cadence |
| Stakeholder satisfaction with reporting (survey) | 3.2/5 | >4.2/5 | Quarterly stakeholder survey |
| Average report creation time | 4 hours | <1.5 hours (with AI) | Time tracking |
| Decision rate from executive presentations | 55% | >80% | Meeting follow-up audit |
| Bad news escalation timeliness | 2.5 days avg | Same day | Incident vs. report timestamp |

---

## Best Practices

1. **Conclusion First, Always** — The busiest person in the room shouldn't have to read to page 3 to understand the point.
2. **One Slide, One Message** — If a slide has three key messages, it has zero key messages.
3. **Know Your Ask** — Every executive communication should end with a clear "Here's what I need from you."
4. **Red/Amber/Green Discipline** — Define what R/A/G means before you use it. Inconsistent RAG definitions are meaningless.
5. **Pre-brief Key Stakeholders** — For important reviews, brief the most influential stakeholder 24 hours in advance. No executive should be surprised in a meeting.
6. **Feedback Is Data** — Executive questions and pushback reveal misalignment. Capture and address them.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-generate weekly status update from Jira data | AI + Jira API | L2 | S |
| Auto-populate executive dashboard from multiple data sources | BI tool + data pipeline | L3 | L |
| AI-draft executive incident communication | AI + incident template | L2 | S |
| Presentation first draft from bullet points | AI + slides API | L2 | M |
| Automated metric trending alerts to exec | BI tool + Slack | L3 | M |

---

## AI Prompt Examples

### Prompt 1: Draft a Weekly Executive Status Update
```
Role: You are an executive communications specialist writing a weekly update 
      for the VP of Engineering and CTO.
Context: This week's data:
  - Sprint: completed 18 of 22 planned stories; 4 carried over (dependency on external API)
  - Incidents: 1 P2 (payment service timeout, resolved in 2h, postmortem drafted)
  - SLOs: checkout service at 99.3% (target 99.5%); all others green
  - Upcoming: production deployment of new search feature on Thursday
  - Risk: contractor contract expires June 1; replacement not yet hired
Task: Write a weekly executive status update.
Constraints:
  - Maximum 250 words
  - Pyramid Principle: lead with most important item
  - Include: Progress, Risks (with RAG), Next Week, Decisions Needed
  - Translate technical terms to business impact
  - Tone: direct, confident, transparent
Output format: Structured email body (no subject line needed)
```

### Prompt 2: Create an Executive Incident Communication
```
Role: You are drafting an executive communication about a production incident.
Context: Incident: The customer data export feature was unavailable for 3 hours 
         this morning (08:00–11:00 EST). Affected: ~2,400 enterprise customers 
         who attempted exports during that window. Root cause: database 
         migration script locked the export table. Fix: migration rolled back; 
         permanent fix scheduled for Saturday maintenance window.
Task: Write two communications: 
  1. Internal executive briefing (CTO, VP Eng, VP Customer Success)
  2. External customer-facing status page update
Constraints:
  - Internal: factual, complete, includes root cause, impact, remediation, next steps
  - External: empathetic, clear, no jargon, no blame, focus on customer impact and resolution
  - Both: transparent but not alarmist
Output format: Two separate sections clearly labeled
```

---

## References & Further Reading
- [The Pyramid Principle — Barbara Minto](https://www.barbaraminto.com) — Executive communication structure
- [Storytelling with Data — Cole Nussbaumer Knaflic](https://www.storytellingwithdata.com) — Data visualization for executives
- [High Output Management — Andy Grove](https://www.penguinrandomhouse.com/books/72467/high-output-management-by-andrew-s-grove/) — Management communication principles
