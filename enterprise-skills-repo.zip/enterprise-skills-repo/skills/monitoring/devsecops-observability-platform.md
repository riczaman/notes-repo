---
id: "monitoring.devsecops.observability-platform"
title: "Observability & Monitoring Platform"
domain: "monitoring"
role: "devsecops"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "reliability-chapter"
last_reviewed: "2026-05-27"
tags: [monitoring, observability, prometheus, grafana, opentelemetry, slo, alerting]
prerequisites:
  skills: ["cloud-engineering.architect.cloud-native-patterns", "kubernetes.devsecops.k8s-operations"]
  tools: ["Prometheus", "Grafana", "OpenTelemetry SDK", "PagerDuty"]
  certifications: ["none"]
related_skills: ["incident-response.devsecops.incident-command", "performance-optimization.senior-dev.perf-tuning"]
ai_indexable: true
---

# Observability & Monitoring Platform

> **Domain:** `monitoring` | **Role:** `devsecops` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Observability is the capability to understand the internal state of a system from its external outputs — logs, metrics, and traces (the three pillars). This skill covers designing and operating an observability platform that gives engineering teams real-time insight into system health, user experience, and business impact. Effective observability reduces MTTR, enables proactive incident prevention, and supports data-driven capacity planning.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Reads dashboards; queries logs; understands alerts | Heavy — AI explains queries and dashboards |
| 2 | Practitioner | Writes PromQL; builds dashboards; instruments services with OTel | Moderate — AI generates queries and configs |
| 3 | Advanced | Designs SLO framework; owns alerting strategy; builds platform | Light — AI validates coverage |
| 4 | Expert | Defines org observability standards; capacity planning; cost optimization | Minimal |
| 5 | Distinguished | Contributes to OpenTelemetry; publishes observability patterns | AI as research assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `3–5 months`

---

## Prerequisites

### Required Skills
- `cloud-engineering.architect.cloud-native-patterns` — understand what you're monitoring
- `kubernetes.devsecops.k8s-operations` — Kubernetes metrics and workload context

### Required Tools Access
- **Prometheus** — metrics collection and storage
- **Grafana** — dashboards and alerting
- **OpenTelemetry** — vendor-neutral instrumentation SDK
- **Loki or Elasticsearch** — log aggregation
- **Tempo or Jaeger** — distributed tracing
- **PagerDuty or OpsGenie** — on-call and incident routing

### Required Knowledge
- The three pillars: metrics, logs, traces — and when to use each
- RED method (Rate, Errors, Duration) for services
- USE method (Utilization, Saturation, Errors) for resources
- SLI/SLO/SLA/Error Budget concepts
- PromQL fundamentals
- Distributed tracing: trace context propagation, spans, sampling

---

## Workflow

### Step 1: Define Service Level Objectives (SLOs)
Before writing any alerting, define SLOs with the product and engineering teams:
- **SLI** (what to measure): e.g., "% of requests completing in <500ms and with 2xx status"
- **SLO** (the target): e.g., "99.5% of requests meet the SLI over a 28-day rolling window"
- **Error Budget**: `100% - SLO% = 0.5%` of requests may fail — this is the budget for risk-taking

**AI Assist:** `Yes` — "Help me define SLOs for a payment processing API given these business requirements"

### Step 2: Instrumentation Strategy
Instrument all services with OpenTelemetry SDK. Emit:
- **Metrics**: RED metrics per endpoint, resource utilization
- **Traces**: all inbound/outbound calls with trace context propagated
- **Logs**: structured JSON, with `trace_id` and `span_id` for correlation

**Decision Gate:** No service goes to production without at minimum: request rate, error rate, and latency metrics instrumented.

### Step 3: Dashboard Design (Four Golden Signals per Service)
Build a standard service dashboard with: Latency (p50, p95, p99), Traffic (RPS), Errors (rate and %), Saturation (CPU, memory, connection pool). Use the org's Grafana dashboard template.

### Step 4: Alert Design — Signal Over Noise
Alert on symptoms (user impact), not causes (low-level metrics). Alert design rules:
- Every alert must have a runbook link
- Every alert must be actionable (if you can't do something about it, it's not an alert — it's a dashboard)
- Alert on SLO burn rate, not raw thresholds
- Use multi-window, multi-burn-rate alerting for SLOs (fast burn + slow burn)

### Step 5: On-Call Routing Configuration
Route alerts to the owning team in PagerDuty. Escalation: L1 → L2 → Engineering Manager. Off-hours pages must be for Tier 0/1 severity only.

### Step 6: Log Management
Structured logging standard: JSON, mandatory fields: `timestamp`, `level`, `service`, `trace_id`, `correlation_id`, `message`. Ship to Loki/ELK. Set retention policies: 30 days hot, 90 days warm, 1 year cold (compliance-driven).

### Step 7: Distributed Tracing
Deploy Tempo/Jaeger. Sample at 100% for errors, 10% for success in production. Ensure trace context (`traceparent` header) is propagated across all service-to-service calls.

### Step 8: Runbook Maintenance
Every production alert has a linked runbook. Runbooks reviewed after every incident. AI-assist: runbooks searchable and summarizable by AI during incidents.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Prometheus | Metrics collection, storage, alerting | Required | No |
| Grafana | Dashboards, SLO tracking | Required | No |
| OpenTelemetry | Vendor-neutral instrumentation | Required | No |
| Loki | Log aggregation | Required | No |
| Tempo / Jaeger | Distributed tracing | Required | No |
| PagerDuty / OpsGenie | On-call routing | Required | No |
| Alertmanager | Alert routing, deduplication | Required | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Alert on Everything, Tune Nothing
**What it looks like:** 300 alerts configured; on-call engineer receives 80 pages per shift; most are noise  
**Why it's harmful:** Alert fatigue causes real incidents to be ignored. On-call becomes unsustainable. Engineers burn out.  
**Remediation:** Audit all alerts. Delete any alert that has never triggered a meaningful action in 90 days. Switch to SLO-based alerting.

### ❌ Anti-Pattern 2: Logs Without Structure
**What it looks like:** `print(f"Processing order {order_id}")` — unstructured plaintext log lines  
**Why it's harmful:** Unstructured logs can't be reliably queried. Correlation across services is impossible without trace IDs.  
**Remediation:** Enforce structured JSON logging via the org's logging library. Validate in CI with a log format linter.

### ❌ Anti-Pattern 3: Monitoring the Tool, Not the User
**What it looks like:** Alerting on CPU > 80% but no alert on "checkout success rate < 99%"  
**Why it's harmful:** CPU at 80% may not impact users at all. A 2% drop in checkout success is a business emergency.  
**Remediation:** Define SLIs from the user's perspective first. Infrastructure alerts are secondary signals.

### ❌ Anti-Pattern 4: Dashboards Nobody Uses
**What it looks like:** 200 dashboards in Grafana; most last viewed 6+ months ago; nobody knows which is authoritative  
**Why it's harmful:** During incidents, teams waste time finding the right dashboard. Stale dashboards mislead.  
**Remediation:** Designate one "golden dashboard" per service. Archive unused dashboards quarterly.

---

## Troubleshooting Guide

### Problem: Prometheus scrape targets showing as DOWN
**Root Cause(s):** Service not exposing `/metrics` endpoint; network policy blocking scrape port; wrong port in ServiceMonitor  
**Diagnostic Steps:**
1. `kubectl port-forward <pod> 8080:8080` → `curl localhost:8080/metrics` — is the endpoint reachable?
2. Check ServiceMonitor selector labels match pod labels
3. Check NetworkPolicy allows Prometheus namespace to scrape  
**Resolution:** Fix whichever layer is broken. Update ServiceMonitor or NetworkPolicy.  
**Prevention:** Add a smoke test in CI that verifies the `/metrics` endpoint returns valid Prometheus format.

### Problem: Too many alerts firing simultaneously — alert storm
**Root Cause(s):** Cascading failure; noisy alert design; missing alert grouping/inhibition  
**Diagnostic Steps:**
1. In Alertmanager UI, check inhibition rules — is a parent alert suppressing children?
2. Identify the root cause alert (the first one to fire)  
**Resolution:** Acknowledge root cause alert. Implement inhibition rules so child alerts suppress when parent fires.  
**Prevention:** Design alert hierarchy. Implement `inhibit_rules` in Alertmanager config.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| SLO error budget exhausted (>100% burned) | Engineering Manager + Product Manager | Immediate | `#incidents` + PagerDuty |
| Observability platform itself down (no metrics) | Platform Team On-call | 15 minutes | PagerDuty P1 |
| Undetected production incident (found by user, not alerts) | EM + Reliability chapter | Post-incident | Retrospective + alert gap ticket |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Alert noise ratio (actionable / total pages) | 35% actionable | >80% actionable | PagerDuty analytics |
| Mean time to detect (MTTD) | 18 minutes | <5 minutes | Incident timeline audit |
| SLO coverage (% services with defined SLOs) | 30% | 100% Tier 0/1; >80% Tier 2 | SLO registry audit |
| Dashboard freshness (last updated <90 days) | 40% | >90% | Grafana API audit |
| P99 latency tracked for all prod services | 45% | 100% | Prometheus coverage report |

---

## Best Practices

1. **SLOs Before Alerts** — Define what "good" looks like before defining what "bad" looks like.
2. **Trace ID in Every Log Line** — Correlation is the killer feature of observability. Always log `trace_id`.
3. **Runbook Links are Mandatory** — Every alert description must include a runbook URL. Non-negotiable.
4. **Error Budget as a Policy Tool** — When error budget is exhausted, freeze new feature work until reliability is restored.
5. **Review On-Call Load Monthly** — If any engineer is paged >5 times per on-call shift, the alerting needs fixing.
6. **Instrument in the Application, Not Just the Infra** — Infrastructure metrics tell you the system is sick; application metrics tell you why.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-generate PromQL queries from plain English | AI + Prometheus API | L2 | M |
| Auto-create Grafana dashboard from OpenAPI spec | API → dashboard generator | L3 | L |
| Runbook AI assistant during incidents | AI + runbook RAG | L3 | M |
| SLO report auto-generation for stakeholders | Prometheus API + AI | L2 | M |
| Anomaly detection for business metrics | ML-based alerting (AWS Lookout) | L4 | L |

---

## AI Prompt Examples

### Prompt 1: Generate PromQL for an SLO
```
Role: You are a reliability engineer writing PromQL for SLO tracking.
Context: Service: payment-api. SLI: HTTP requests that return 2xx and complete 
         in <500ms. Metric names available: http_requests_total (labels: status_code, 
         endpoint, method), http_request_duration_seconds (histogram).
Task: Write PromQL expressions for:
  1. The SLI success rate over a 28-day rolling window
  2. A fast burn rate alert (1-hour window, 14x burn rate)
  3. A slow burn rate alert (6-hour window, 6x burn rate)
Constraints:
  - SLO target: 99.5%
  - Use recording rules format where appropriate for performance
  - Include comments explaining each expression
Output format: PromQL code blocks with explanations
```

### Prompt 2: Design an SLO for a Service
```
Role: You are a reliability engineer defining SLOs.
Context: Service: user-authentication. Business context: users cannot log in if 
         this service is down. Current p99 latency: 320ms. Current error rate: 0.8%.
Task: Propose a complete SLO framework for this service.
Constraints:
  - Define: SLI (what to measure), SLO target, error budget, alert thresholds
  - Consider: business hours vs. 24/7, user impact severity
  - Propose burn rate alert windows (fast + slow)
  - Suggest error budget policy (what happens when budget is exhausted)
Output format: Structured SLO document with all fields completed
```

---

## References & Further Reading
- [Google SRE Book — SLOs](https://sre.google/sre-book/service-level-objectives/) — Canonical SLO reference
- [OpenTelemetry Documentation](https://opentelemetry.io/docs/) — Instrumentation SDK
- [Prometheus Best Practices](https://prometheus.io/docs/practices/) — Metrics naming and design
- [The Art of SLOs](https://docs.google.com/document/d/11qMVVdn95tyGvYiVA5HwjlIV750-gYiT-dJCNS0ZPE0/) — Google workshop guide
