---
id: "security.devsecops.appsec-threat-modeling"
title: "Application Security & Threat Modeling"
domain: "security"
role: "devsecops"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "security-chapter"
last_reviewed: "2026-05-27"
tags: [security, appsec, threat-modeling, sast, dast, owasp, devsecops]
prerequisites:
  skills: ["coding.senior-dev.clean-code-practices", "apis.senior-dev.api-design"]
  tools: ["OWASP ZAP", "SonarQube", "Snyk or Trivy", "Burp Suite (optional)"]
  certifications: ["none (OSCP or CEH valued for L3+)"]
related_skills: ["cicd.devsecops.pipeline-design", "compliance.devsecops.regulatory-compliance"]
ai_indexable: true
---

# Application Security & Threat Modeling

> **Domain:** `security` | **Role:** `devsecops` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Application Security (AppSec) is the practice of identifying, preventing, and remediating security vulnerabilities across the software delivery lifecycle — from design through production. Threat modeling is the systematic process of identifying threats before they become vulnerabilities. DevSecOps engineers own security integration in the pipeline ("shift left") and provide engineering teams with the tooling, patterns, and guidance to build secure software without slowing delivery.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Understands OWASP Top 10; fixes SAST findings with guidance | Heavy — AI explains vulnerabilities and suggests fixes |
| 2 | Practitioner | Runs threat models; integrates SAST/DAST in pipelines; triages CVEs | Moderate — AI generates threat models, human validates |
| 3 | Advanced | Leads security reviews; designs secure reference architectures; pen testing | Light — AI as research assistant |
| 4 | Expert | Owns AppSec program; security champion network; red team coordination | Minimal |
| 5 | Distinguished | Publishes vulnerability research; contributes to OWASP; speaks at conferences | AI as research assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `6–9 months`

---

## Prerequisites

### Required Skills
- `coding.senior-dev.clean-code-practices` — understand code well enough to spot vulnerabilities
- `apis.senior-dev.api-design` — API attack surface awareness

### Required Tools Access
- **SonarQube** — SAST (Static Application Security Testing)
- **Snyk or Trivy** — SCA (Software Composition Analysis) — dependency CVEs
- **OWASP ZAP** — DAST (Dynamic Application Security Testing)
- **Gitleaks** — secrets detection
- **Threat modeling tool** (OWASP Threat Dragon, Microsoft Threat Modeling Tool, or draw.io)

### Required Knowledge
- OWASP Top 10 (Web) and OWASP API Security Top 10
- STRIDE threat modeling framework (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege)
- Common vulnerability classes: SQL injection, XSS, SSRF, IDOR, broken authentication
- CVE/CVSS scoring and triage
- Secrets management (Vault, cloud secrets managers)

---

## Workflow

### Step 1: Threat Model at Design Time
Before any code is written for a significant feature, conduct a threat model. STRIDE framework:

For each component/data flow in the architecture diagram, ask:
- **S** — Can an attacker spoof the identity of another user or service?
- **T** — Can an attacker tamper with data in transit or at rest?
- **R** — Can an attacker deny having performed an action (non-repudiation)?
- **I** — Can an attacker access data they shouldn't?
- **D** — Can an attacker cause the service to become unavailable?
- **E** — Can an attacker gain higher privileges than intended?

**AI Assist:** `Yes` — "Perform a STRIDE threat model on this architecture diagram [description]"

### Step 2: SAST Integration in CI
SonarQube scans run on every PR. Policy:
- **BLOCKER**: Build fails. Must fix before merge.
- **CRITICAL**: Build fails. Must fix before merge.
- **MAJOR**: Warning in PR. Must be reviewed by security-aware engineer. Fix within 1 sprint.
- **MINOR/INFO**: Logged. Fix as part of tech debt.

### Step 3: Dependency Scanning (SCA)
Snyk or Trivy scans all dependencies on every build. Policy:
- **CRITICAL CVE**: Build fails if a fix is available. Exemption requires security engineer sign-off.
- **HIGH CVE**: Warning. Fix within 5 business days. Ticket required.
- **MEDIUM/LOW**: Fix within next sprint cycle.

### Step 4: Secret Scanning
Gitleaks pre-commit hook and CI stage. Policy: any secret detected = **immediate build failure and security team notification**. Rotate the secret before any other action.

### Step 5: DAST Against Staging
OWASP ZAP active scan against the staging environment on every deployment. Review findings and triage:
- Automated: ZAP baseline scan (passive, non-destructive) on every deploy
- Periodic: ZAP full scan (active) weekly against staging

**Decision Gate:** No promotion to production if ZAP active scan returns HIGH/CRITICAL unfixed findings.

### Step 6: Security Review for High-Risk Features
Features touching auth, payments, PII, or file uploads require a security design review by a Security Engineer before implementation begins.

### Step 7: Penetration Testing
Annual third-party penetration test for Tier 0/1 systems. Findings tracked to remediation with SLAs by severity.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| SonarQube | SAST | Required | No |
| Snyk / Trivy | SCA — dependency CVEs | Required | No |
| Gitleaks | Secret scanning | Required | No |
| OWASP ZAP | DAST | Required (staging) | No |
| OWASP Threat Dragon | Threat modeling | Recommended | No |
| Burp Suite Pro | Manual/advanced DAST | Optional (L3+) | No |
| Vault / AWS Secrets Manager | Secrets management | Required | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Security as a Gate at the End of the SDLC
**What it looks like:** Security review happens in the week before release. 20 findings are returned. Delivery is delayed or findings are waived.  
**Why it's harmful:** Security findings discovered late are expensive to fix. They either block delivery or get waived under pressure.  
**Remediation:** Shift left. Threat model at design. SAST in CI. Security review for high-risk features at the ticket stage, not the release stage.

### ❌ Anti-Pattern 2: Suppressing SAST Findings Without Documentation
**What it looks like:** Developer adds `// NOSONAR` or `#nosec` comment to suppress a security finding without explanation  
**Why it's harmful:** Legitimate suppression is fine; silent suppression is a security debt that's invisible.  
**Remediation:** Require suppression comments to include: reason, ticket reference, and security engineer approval. Enforce with linting rule.

### ❌ Anti-Pattern 3: Storing Secrets in Environment Variables in Container Images
**What it looks like:** `ENV DB_PASSWORD=prod_password_123` in a Dockerfile  
**Why it's harmful:** Secrets baked into images appear in layer history. Anyone with image pull access has the secret.  
**Remediation:** Inject secrets at runtime via Vault Agent, External Secrets Operator, or cloud-native secrets. Never in the image.

### ❌ Anti-Pattern 4: Trusting User Input Without Validation
**What it looks like:** SQL queries built by string concatenation with user input; HTML rendered without encoding  
**Why it's harmful:** SQL injection and XSS — the oldest and most exploited vulnerability classes.  
**Remediation:** Parameterized queries always. Output encoding always. NEVER string-concatenate user input into SQL, HTML, or shell commands.

---

## Troubleshooting Guide

### Problem: Snyk reports 200+ CVEs blocking pipelines
**Root Cause(s):** Dependency tree hasn't been audited in months; using EOL package versions  
**Diagnostic Steps:**
1. Run `snyk test --severity-threshold=critical` — how many are actually critical?
2. Use `snyk wizard` or Dependabot to identify fixable vs. unfixable
3. Check if indirect (transitive) dependencies can be resolved by updating a direct dependency  
**Resolution:** Fix CRITICAL first (pipeline blocker). Triage HIGH within 5 days. Create tech debt tickets for MEDIUM/LOW.  
**Prevention:** Enable Dependabot weekly PRs. Add `snyk monitor` to production deployments for ongoing tracking.

### Problem: ZAP DAST scan returning hundreds of false positives
**Root Cause(s):** ZAP scanning authenticated paths without authentication context; scanning API endpoints not designed for browser interaction  
**Diagnostic Steps:**
1. Check ZAP context configuration — is the auth token configured?
2. Identify which finding categories are highest volume  
**Resolution:** Configure ZAP authentication context. Add `zap-baseline.conf` with known false-positive suppression.  
**Prevention:** Maintain a ZAP config file in the repo alongside the pipeline config.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Secret leaked to Git (any branch) | Security Engineer + EM + Vault Admin | Immediate | `#security-incidents` |
| CRITICAL CVE in production with no fix available | CISO + Security Engineer + Architect | 4 hours | `#security-escalations` |
| Active exploit detected (WAF alert, anomaly) | Security Engineer + CISO + Incident Commander | Immediate | Incident bridge + `#security-incidents` |
| Third-party pen test CRITICAL finding | CISO + Engineering Manager + CTO | 24 hours | Secure channel |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Mean time to remediate CRITICAL CVE | 18 days | <5 days | Snyk/Jira tracking |
| SAST BLOCKER findings reaching production | 3/quarter | 0 | SonarQube audit |
| % of services with completed threat model | 20% | 100% Tier 0/1; >70% Tier 2 | Threat model registry |
| Secret leak incidents | 2/quarter | 0 | Gitleaks / Git history audit |
| OWASP Top 10 coverage in security tests | 40% | 100% | Security test coverage report |

---

## Best Practices

1. **Security Champions Network** — Embed a security-aware engineer in each team. They are the first line of defence, not a gate.
2. **Fix Vulnerabilities in the Sprint They Are Found** — Security debt compounds. A finding added to the backlog has a 30% chance of never being fixed.
3. **Automate the Boring Parts** — SAST, SCA, secret scanning should be fully automated. Human security review focuses on what automation can't catch.
4. **OWASP Top 10 Literacy for All Developers** — Every developer should be able to explain SQL injection, XSS, and broken authentication. Make it part of onboarding.
5. **Immutable Audit Logs** — Security-relevant events (auth, privilege change, data access) must be in an append-only, tamper-evident audit log.
6. **Least Privilege Always** — Every service account, IAM role, and database user should have exactly the permissions it needs and no more. Review quarterly.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-generate STRIDE threat model from architecture | AI + threat model template | L2 | M |
| Auto-create Jira tickets from SAST/SCA findings | SonarQube/Snyk + Jira API | L2 | S |
| Dependency auto-update PRs | Dependabot / Renovate | L2 | S |
| Security posture dashboard (all services) | Snyk API + Grafana | L3 | M |
| AI-explain CVE impact and remediation | AI + Snyk API | L2 | M |

---

## AI Prompt Examples

### Prompt 1: STRIDE Threat Model
```
Role: You are a security engineer performing a STRIDE threat model.
Context: System: e-commerce checkout flow. Components: React frontend → 
         Node.js BFF → Payment Service (internal) → Stripe API (external) → 
         Order DB (PostgreSQL). Data flows: user submits card details → BFF 
         tokenizes with Stripe.js → BFF calls Payment Service with token → 
         Payment Service charges Stripe → writes order record.
Task: Perform a complete STRIDE threat analysis on this system.
Constraints:
  - Analyze each component and each data flow
  - For each threat: identify STRIDE category, attack scenario, likelihood (H/M/L), 
    impact (H/M/L), and recommended control
  - Prioritize by risk score (likelihood × impact)
Output format: Table per component/data flow, then prioritized risk register
```

### Prompt 2: Security Code Review
```
Role: You are an application security engineer reviewing code for vulnerabilities.
Context: [PASTE CODE BLOCK — function, endpoint handler, or class]
Task: Identify all security vulnerabilities in this code.
Constraints:
  - Check for: injection (SQL, command, LDAP), authentication/authorization flaws,
    sensitive data exposure, insecure deserialization, XXE, SSRF, path traversal,
    cryptographic weaknesses, missing input validation
  - For each finding: vulnerability class, OWASP category, severity (CRITICAL/HIGH/MEDIUM/LOW),
    exact location, exploit scenario, remediation with corrected code
Output format: Findings table then corrected code snippet
```

---

## References & Further Reading
- [OWASP Top 10](https://owasp.org/www-project-top-ten/) — Web application vulnerability classes
- [OWASP API Security Top 10](https://owasp.org/www-project-api-security/) — API-specific vulnerabilities
- [Microsoft STRIDE](https://learn.microsoft.com/en-us/azure/security/develop/threat-modeling-tool-threats) — Threat modeling framework
- [NIST Secure Software Development Framework](https://csrc.nist.gov/Projects/ssdf) — Enterprise AppSec framework
