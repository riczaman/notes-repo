---
id: "compliance.devsecops.regulatory-compliance"
title: "Regulatory Compliance & Audit Readiness"
domain: "compliance"
role: "devsecops"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "security-chapter"
last_reviewed: "2026-05-27"
tags: [compliance, soc2, iso27001, gdpr, pci-dss, audit, policy-as-code]
prerequisites:
  skills: ["security.devsecops.appsec-threat-modeling", "cicd.devsecops.pipeline-design"]
  tools: ["Drata or Vanta (compliance automation)", "AWS Config / GCP Policy", "OPA"]
  certifications: ["CISA or CRISC (valued for L3+)"]
related_skills: ["security.devsecops.appsec-threat-modeling", "monitoring.devsecops.observability-platform"]
ai_indexable: true
---

# Regulatory Compliance & Audit Readiness

> **Domain:** `compliance` | **Role:** `devsecops` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Regulatory Compliance ensures that the organization's software systems, infrastructure, and processes meet applicable legal, contractual, and industry-standard requirements. This skill covers common frameworks (SOC 2 Type II, ISO 27001, GDPR, PCI-DSS, HIPAA), continuous compliance monitoring, evidence collection, audit preparation, and policy-as-code implementation. In modern DevSecOps, compliance is not an annual checkbox — it is a continuous state verified by automation.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Understands compliance frameworks at a conceptual level; can collect evidence when directed | Heavy — AI maps controls to evidence |
| 2 | Practitioner | Implements controls in CI/CD; prepares evidence packages; manages compliance platform | Moderate — AI drafts policies and maps controls |
| 3 | Advanced | Designs compliance-as-code program; manages auditor relationship; owns control framework | Light — AI validates control coverage |
| 4 | Expert | Defines enterprise compliance strategy; multi-framework management | Minimal |
| 5 | Distinguished | Contributes to compliance standard bodies; published compliance architecture | AI as research assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `6–9 months`

---

## Prerequisites

### Required Skills
- `security.devsecops.appsec-threat-modeling` — security controls underpin compliance
- `cicd.devsecops.pipeline-design` — compliance evidence generated via pipeline

### Required Tools Access
- **Drata or Vanta** — continuous compliance monitoring and evidence automation
- **AWS Config / GCP Security Command Center** — cloud configuration compliance
- **OPA (Open Policy Agent)** — policy-as-code enforcement
- **Jira** — compliance remediation tracking

### Required Knowledge
- SOC 2 Trust Service Criteria (Security, Availability, Confidentiality, Processing Integrity, Privacy)
- ISO 27001 Annex A controls
- GDPR data subject rights and processor/controller obligations
- PCI-DSS scope and cardholder data environment (CDE) definition
- Evidence collection principles: timestamps, chain of custody, completeness
- Control types: preventive, detective, corrective

---

## Workflow

### Step 1: Framework Selection & Scoping
Identify applicable frameworks based on: customer contractual requirements, geographic data handling, industry (healthcare → HIPAA; payments → PCI-DSS), and business objectives (SOC 2 for SaaS B2B sales). Define scope clearly — which systems, which data types, which locations.

**AI Assist:** `Yes` — "Given this business model and customer profile, which compliance frameworks are likely required and what is the typical scope?"

### Step 2: Control Mapping
Map each framework requirement to a technical or process control. Use a control matrix:

| Framework | Control Requirement | Our Control | Evidence Type | Owner | Status |
|---|---|---|---|---|---|
| SOC 2 CC6.1 | Logical access restricted | RBAC + MFA enforced | IAM config export, MFA report | DevSecOps | ✅ |

**AI Assist:** `Yes` — "Map SOC 2 CC6 controls to our Kubernetes RBAC and AWS IAM configuration"

### Step 3: Continuous Compliance Monitoring
Implement Drata/Vanta to continuously test controls. Every control should have an automated test that runs daily. Manual controls (e.g., security training completion) tracked in the compliance platform.

**Decision Gate:** No new production system goes live without its controls mapped in the compliance platform.

### Step 4: Policy-as-Code
Implement OPA policies for cloud and Kubernetes compliance:
- No public S3 buckets
- No unencrypted EBS volumes
- No containers running as root
- MFA required for all human IAM users

Enforce policies in the Terraform pipeline (pre-apply) and via admission controllers (Kubernetes).

### Step 5: Evidence Collection Automation
Configure Drata/Vanta integrations to auto-pull evidence from:
- GitHub (access reviews, branch protection, PR review enforcement)
- AWS/GCP (CloudTrail, Config rules, IAM)
- CI/CD (pipeline security gate results)
- HR system (security training completion, background checks)

### Step 6: Annual Risk Assessment
Complete a formal risk assessment annually. Document threats, likelihood, impact, and mitigating controls. Risk register maintained and reviewed quarterly.

### Step 7: Audit Preparation (30–60 Days Before Audit)
- Export evidence from compliance platform
- Identify any control gaps (failing automated tests)
- Remediate gaps or document compensating controls
- Prepare auditor portal access (read-only Drata/Vanta access)
- Brief key stakeholders on their interview topics

### Step 8: Auditor Interaction
Point of contact: Compliance Lead. Engineers respond to evidence requests within 2 business days. All communication via the designated audit portal. No ad-hoc responses to auditors without Compliance Lead awareness.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Drata / Vanta | Continuous compliance monitoring | Required | No |
| AWS Config | Cloud config compliance rules | Required | No |
| OPA / Kyverno | Policy-as-code for K8s and Terraform | Required (L3+) | No |
| Jira | Remediation tracking | Required | No |
| GRC tool (Archer, ServiceNow) | Enterprise risk management | Optional (L4) | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Annual Compliance Sprint
**What it looks like:** Compliance is ignored for 11 months; 4 weeks before the audit, everything is a fire drill.  
**Why it's harmful:** Evidence gaps discovered under time pressure. Remediation corners cut. Auditors notice.  
**Remediation:** Continuous compliance platform. Monthly control review. Treat compliance failures like production incidents.

### ❌ Anti-Pattern 2: Scope Creep Without Governance
**What it looks like:** A new service is deployed; it processes cardholder data; nobody updates the PCI scope.  
**Why it's harmful:** Unscoped systems are uncontrolled. An audit finding here can invalidate the entire certification.  
**Remediation:** Change management process includes compliance scope impact assessment. New service onboarding checklist includes data classification and scope assessment.

### ❌ Anti-Pattern 3: Compliance Theater (Controls That Don't Actually Work)
**What it looks like:** Policy says "MFA is required for all users." IAM config shows 30% of users have no MFA.  
**Why it's harmful:** The policy creates false assurance. An auditor or attacker finds the gap.  
**Remediation:** Every control must be tested by automation. Policy without enforcement is not a control.

---

## Troubleshooting Guide

### Problem: Drata/Vanta showing 15 failing controls 3 weeks before audit
**Root Cause(s):** Controls drifted; recent infrastructure change broke a previously passing control; control configuration not updated after a tool change  
**Diagnostic Steps:**
1. Categorize failures: which framework? which control domain?
2. Triage: can this be fixed in time? is there a compensating control?  
**Resolution:** Fix high-impact controls first. Document compensating controls for those that can't be fixed in time. Brief auditor proactively.  
**Prevention:** Monthly control review. Alert on any control moving from PASS to FAIL.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Audit finding rated HIGH/CRITICAL | CISO + Legal + VP Engineering | 24 hours | Secure channel + email |
| GDPR data subject request not fulfilled within 30 days | DPO + Legal | Immediate | Legal escalation |
| PCI scope creep discovered (uncontrolled CDE system) | CISO + PCI QSA | 48 hours | `#compliance-escalations` |
| Evidence of unauthorized access to cardholder data | CISO + Legal + Forensics | Immediate | Incident bridge |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Continuous compliance score (Drata/Vanta) | 72% | >95% | Compliance platform dashboard |
| Audit findings (major) | 3 per audit | 0 major findings | Audit report |
| Control test automation rate | 40% | >80% | Compliance platform |
| Mean time to remediate compliance gap | 45 days | <10 days | Jira tracking |
| Evidence collection time (pre-audit) | 3 weeks manual | <2 days automated | Audit prep timeline |

---

## Best Practices

1. **Continuous Compliance Over Periodic Audits** — Compliance is a state, not an event.
2. **Evidence Must Be Tamper-Evident** — Audit logs must be in append-only storage (AWS CloudTrail to S3 with Object Lock).
3. **Data Classification First** — You can't protect what you don't know you have. Data classification drives compliance scope.
4. **Compensating Controls Are Legitimate** — If a control can't be implemented as specified, a compensating control (documented, risk-accepted, auditor-approved) is acceptable.
5. **Auditors Are Not Adversaries** — Proactive transparency about gaps and remediation plans builds auditor trust.
6. **Policy-as-Code Is Your Best Auditor** — Automated policy enforcement never sleeps and never forgets.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-map controls to evidence sources | AI + control matrix | L2 | M |
| Auto-generate compliance report for stakeholders | Drata API + AI | L2 | M |
| Policy-as-code for all cloud resources | OPA + CI/CD | L3 | L |
| GDPR data subject request workflow automation | Custom + AI | L3 | L |

---

## AI Prompt Examples

### Prompt 1: Map SOC 2 Controls to Technical Implementation
```
Role: You are a compliance engineer mapping SOC 2 requirements to technical controls.
Context: We are a SaaS company using: AWS (EKS, RDS, S3), GitHub, Okta (SSO/MFA), 
         Drata for compliance monitoring, Vault for secrets.
Task: Map the SOC 2 Type II Common Criteria (CC) 6.x series (Logical and Physical Access) 
      to our specific technical controls.
Constraints:
  - For each CC requirement: state our control, evidence source, automated test (Y/N), owner
  - Flag any gaps where we have no control
  - Suggest remediation for gaps
Output format: Markdown table with columns: CC Ref | Requirement | Our Control | Evidence Source | Automated | Gap?
```

---

## References & Further Reading
- [AICPA SOC 2 Criteria](https://www.aicpa.org/resources/landing/system-and-organization-controls-soc-suite-of-services) — SOC 2 trust service criteria
- [ISO 27001:2022](https://www.iso.org/standard/27001) — Information security management standard
- [GDPR Full Text](https://gdpr.eu/what-is-gdpr/) — EU data protection regulation
- [PCI DSS v4.0](https://www.pcisecuritystandards.org) — Payment card industry standard
