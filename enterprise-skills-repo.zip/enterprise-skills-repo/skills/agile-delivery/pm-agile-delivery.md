---
id: "agile-delivery.product-manager.sprint-delivery"
title: "Agile Product Delivery"
domain: "agile-delivery"
role: "product-manager"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "product-delivery-chapter"
last_reviewed: "2026-05-27"
tags: [agile, scrum, kanban, product-management, backlog, roadmap, sprint]
prerequisites:
  skills: []
  tools: ["Jira", "Confluence", "Miro or FigJam"]
  certifications: ["CSPO or PSPO (recommended)"]
related_skills: ["executive-reporting.exec-comms.stakeholder-comms", "technical-writing.comms.documentation"]
ai_indexable: true
---

# Agile Product Delivery

> **Domain:** `agile-delivery` | **Role:** `product-manager` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

Agile Product Delivery is the practice of managing the continuous discovery, prioritization, and delivery of value in an iterative, feedback-driven model. Product Managers own the product backlog, roadmap, stakeholder alignment, and delivery cadence. In AI-augmented delivery environments, PMs leverage AI to accelerate story writing, stakeholder communication, data analysis, and retrospective facilitation — compressing administrative overhead so more time goes to strategy and customer engagement.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Writes user stories with guidance; manages sprint board reactively | Heavy — AI drafts stories, acceptance criteria, reports |
| 2 | Practitioner | Owns backlog independently; facilitates ceremonies; communicates roadmap | Moderate — AI drafts, PM edits |
| 3 | Advanced | Manages multi-team delivery; defines metrics; strategic roadmap ownership | Light — AI handles admin, PM focuses strategy |
| 4 | Expert | Defines product operating model; coaches other PMs; org-level prioritization | Minimal |
| 5 | Distinguished | Published product leadership; industry PM community contributor | AI as productivity amplifier |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `3–6 months`

---

## Prerequisites

### Required Tools Access
- **Jira** — backlog, sprint, and capacity management
- **Confluence** — PRDs, roadmaps, retrospective notes
- **Miro or FigJam** — refinement workshops, user journey mapping

### Required Knowledge
- Scrum framework (sprints, ceremonies, artifacts, roles)
- Kanban principles (WIP limits, flow, throughput)
- User story format and acceptance criteria writing (Gherkin/BDD)
- Prioritization frameworks: RICE, MoSCoW, Opportunity Scoring
- OKR framework (Objectives and Key Results)
- Basic DORA metrics (deployment frequency, lead time, change failure rate, MTTR)

---

## Workflow

### Step 1: Discovery & Opportunity Identification
Continuously run discovery in parallel with delivery. Sources: user interviews, support tickets, NPS feedback, usage analytics, stakeholder input, market research. Document opportunities in a structured opportunity backlog.

**AI Assist:** `Yes` — "Analyze these 50 support tickets and identify the top 5 user pain points with frequency counts"

### Step 2: Opportunity Prioritization
Apply RICE scoring to the opportunity backlog: Reach × Impact × Confidence ÷ Effort. Review and re-prioritize monthly with the team and stakeholders.

**AI Assist:** `Yes` — "Given these 8 opportunities and these RICE inputs, rank them and flag any scoring inconsistencies"

### Step 3: Roadmap Maintenance
Maintain a rolling 3-horizon roadmap:
- **Now** (current quarter): committed, detailed stories, sprint-ready
- **Next** (next quarter): shaped, sequenced, dependencies identified
- **Later** (6+ months): strategic bets, directional only

**AI Assist:** `Yes` — AI generates roadmap slide drafts and initiative summaries from backlog data

### Step 4: Story Writing & Refinement
User story format: "As a [user type], I want to [action] so that [outcome]." Every story requires: acceptance criteria (GIVEN/WHEN/THEN format), definition of done, size estimate, dependency flags.

**AI Assist:** `Yes` — "Write a complete user story with acceptance criteria for: [feature description]"

**Decision Gate:** No story enters a sprint without: acceptance criteria, technical approach agreed with engineering, estimated, no unresolved dependencies.

### Step 5: Sprint Planning
Select stories from the top of the prioritized backlog up to team capacity. Ensure: mix of value delivery and tech debt, runway for unplanned work (20% buffer), clear sprint goal.

### Step 6: Sprint Ceremonies (Facilitation Responsibilities)
- **Daily standup** (15 min): PM attends; unblocks, doesn't manage
- **Refinement** (2×/sprint, 1 hour each): PM leads; engineers estimate
- **Review/Demo** (end of sprint): PM facilitates; stakeholders attend
- **Retrospective** (end of sprint): PM participates, EM may facilitate

**AI Assist:** `Yes` — AI generates retrospective summary and action items from notes

### Step 7: Stakeholder Reporting
Weekly: brief async update (3 bullets: progress, risks, next week). Monthly: roadmap review with leadership. Quarterly: OKR review.

**AI Assist:** `Yes` — AI drafts stakeholder updates from sprint data

### Step 8: Metrics Review
Review monthly: velocity (trend, not target), lead time, deployment frequency, user satisfaction (NPS/CSAT), feature adoption metrics.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| Jira | Backlog, sprint, metrics | Required | Yes (AI generates stories) |
| Confluence | PRDs, roadmaps, retrospectives | Required | Yes (AI drafts) |
| Miro / FigJam | Discovery workshops, journey maps | Optional | No |
| Amplitude / Mixpanel | Product usage analytics | Recommended | No |
| Productboard | Opportunity backlog management | Optional | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Story Factory (Stories Without Outcomes)
**What it looks like:** Backlog has 400 stories. None have business outcome context. Delivery is measured in stories completed, not value delivered.  
**Why it's harmful:** Teams optimize for story count. Users don't get meaningfully better outcomes.  
**Remediation:** Every epic must have a measurable outcome. Stories link to outcomes. Delivery reviews measure outcome progress, not velocity.

### ❌ Anti-Pattern 2: Sprint as a Feature Commitment
**What it looks like:** Stakeholders treat the sprint plan as a delivery promise. Scope changes = drama. Engineers skip quality to hit "commitments."  
**Why it's harmful:** Agile becomes waterfall with 2-week deadlines.  
**Remediation:** Sprint goal is the commitment; the story list is a plan. Train stakeholders: plan may flex, goal should not.

### ❌ Anti-Pattern 3: PM as Scribe for Engineering Decisions
**What it looks like:** PM writes tickets for every micro-technical task. PM is in every technical discussion. Engineers can't ship without PM sign-off.  
**Why it's harmful:** Bottleneck. Engineers not empowered. PM has no time for strategy.  
**Remediation:** PM owns: epics, user stories, priority. Engineers own: tasks, technical approach, sub-tasks. PM is a collaborator on tech decisions, not gatekeeper.

### ❌ Anti-Pattern 4: Roadmap as a Promise Schedule
**What it looks like:** Roadmap shows specific features with specific dates 12 months out. Leadership holds PM accountable to those dates.  
**Why it's harmful:** Roadmaps this specific 12 months out are fiction. Teams work to the date, not the outcome.  
**Remediation:** Now/Next/Later roadmap. Dates only for committed quarter. Communicate uncertainty explicitly.

---

## Troubleshooting Guide

### Problem: Velocity declining sprint-over-sprint with no clear cause
**Root Cause(s):** Increasing unplanned work; story quality degradation (oversized stories); team capacity change; growing technical debt load  
**Diagnostic Steps:**
1. Review last 3 sprint cycle times and unplanned work %
2. Check average story size (story points or cycle time per story)
3. Check team capacity (holidays, attrition, meetings load)  
**Resolution:** Address identified root cause. If tech debt: carve 20% sprint capacity for debt reduction.  
**Prevention:** Track velocity AND unplanned work %. Set unplanned work alert at >25%.

### Problem: Sprint review with no stakeholder engagement
**Root Cause(s):** Wrong audience invited; review too technical; no business value narrative; wrong time  
**Diagnostic Steps:**
1. Check attendee list vs. decision-maker list
2. Review format: is it a demo or a slideshow?  
**Resolution:** Reframe sprint review as "value delivered" session. Demo working software. Connect each demo to business outcome.  
**Prevention:** Sprint review format: 10min business outcomes recap → demo → feedback → next sprint preview.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Delivery commitment at risk (>1 sprint behind) | Engineering Manager + Sponsor | 48 hours | Weekly status + Slack |
| Stakeholder disagreement on priority blocking work | Product Director | 1 week | Roadmap review meeting |
| Engineering team capacity issue (attrition, illness) | Engineering Manager | Immediate | Slack + sprint replanning |
| Compliance/legal requirement discovered mid-sprint | EM + Legal + Security | Immediate | `#compliance-escalations` |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Lead time (idea to production) | 6 weeks | <2 weeks | Jira ticket creation → deployment |
| Feature adoption rate (30-day) | 25% | >50% | Product analytics |
| Unplanned work ratio | 35% | <20% | Sprint retrospective data |
| Stakeholder satisfaction (NPS) | 28 | >50 | Quarterly stakeholder survey |
| OKR completion rate (quarterly) | 55% | >70% | OKR review |

---

## Best Practices

1. **Outcomes Over Output** — Measure features by impact, not by count.
2. **Continuous Discovery** — At least 20% of PM time is discovery. Delivery without discovery is building the wrong thing faster.
3. **Dual-Track Agile** — Run discovery and delivery tracks simultaneously. Discovery feeds the next quarter's delivery.
4. **Structured Backlog** — Epics (outcomes) → Features (capabilities) → Stories (deliverables). Three levels maximum.
5. **Short Feedback Loops** — Get something in front of real users every sprint, even if it's a prototype.
6. **Transparent Roadmap** — Engineering teams do better work when they understand where the product is going.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-generate user stories from PRD | AI + Jira API | L2 | S |
| AI-draft sprint review notes from Jira data | AI + Jira API | L2 | S |
| Automated velocity and lead time dashboard | Jira + Grafana | L2 | M |
| AI-summarize user feedback themes | AI + Zendesk/Intercom API | L2 | M |
| Roadmap slide auto-generation from Jira epics | AI + presentation API | L3 | M |

---

## AI Prompt Examples

### Prompt 1: Write User Stories from a Feature Description
```
Role: You are a product manager writing user stories for an engineering team.
Context: Feature: Allow users to export their account data in CSV format. 
         Users: business account admins. Constraint: must comply with GDPR 
         data portability. Engineering stack: React frontend, REST API.
Task: Write 3–5 user stories covering the full feature scope.
Constraints:
  - Format: "As a [user], I want to [action] so that [outcome]"
  - Each story must have: acceptance criteria (GIVEN/WHEN/THEN), 
    definition of done, dependencies, edge cases
  - Stories must be independently deliverable
  - Include a non-happy-path story (error handling, permission edge case)
Output format: One story per section, with all fields completed
```

### Prompt 2: Analyze Sprint Retrospective Themes
```
Role: You are a product manager facilitating a retrospective.
Context: Here are the anonymous retrospective responses from 8 engineers:
  [PASTE RETROSPECTIVE STICKY NOTES / RESPONSES]
Task: Analyze these responses and produce a structured retrospective summary.
Constraints:
  - Identify top 3 themes in "What went well"
  - Identify top 3 themes in "What could improve"
  - Propose 2–3 specific, actionable improvement items with owners
  - Keep the blameless, forward-looking tone
Output format: Retrospective summary document ready for Confluence
```

---

## References & Further Reading
- [Continuous Discovery Habits — Teresa Torres](https://www.producttalk.org/2021/05/continuous-discovery-habits/) — Discovery framework
- [Shape Up — Basecamp](https://basecamp.com/shapeup) — Alternative to Scrum for product teams
- [DORA Metrics](https://dora.dev) — Engineering delivery metrics for PMs
