---
id: "cicd.devsecops.pipeline-design"
title: "CI/CD Pipeline Design & GitOps"
domain: "cicd"
role: "devsecops"
version: "1.0.0"
status: "ACTIVE"
maturity_score: 5
author: "platform-guild"
chapter_lead: "dev-experience-chapter"
last_reviewed: "2026-05-27"
tags:
  - cicd
  - gitops
  - github-actions
  - pipeline
  - devsecops
  - shift-left
prerequisites:
  skills:
    - "coding.senior-dev.version-control"
    - "security.devsecops.sast-sca"
  tools:
    - "GitHub Actions or GitLab CI or Jenkins"
    - "Docker"
    - "SonarQube"
    - "Artifactory or ECR"
  certifications:
    - "none"
related_skills:
  - "kubernetes.devsecops.deployment-strategies"
  - "terraform.devsecops.iac-pipeline"
  - "security.devsecops.supply-chain-security"
ai_indexable: true
---

# CI/CD Pipeline Design & GitOps

> **Domain:** `cicd` | **Role:** `devsecops` | **Version:** `1.0.0` | **Status:** `ACTIVE`

## Overview

CI/CD Pipeline Design is the practice of building automated software delivery pipelines that take code from commit to production reliably, securely, and quickly. DevSecOps Engineers own this skill to ensure that quality gates, security scans, and compliance checks are integrated into the delivery flow ("shift left") rather than bolted on at the end. GitOps extends this by using Git as the single source of truth for both application and infrastructure state.

---

## Maturity Levels

| Level | Label | What It Looks Like | AI Assistance Level |
|---|---|---|---|
| 1 | Foundational | Configures existing pipeline templates; understands stage concepts | Heavy — AI generates YAML pipeline configs |
| 2 | Practitioner | Designs pipelines from scratch; integrates SAST/DAST/SCA | Moderate — AI generates, human reviews |
| 3 | Advanced | Designs multi-env GitOps flows; owns pipeline as code standards | Light — AI suggests optimizations |
| 4 | Expert | Defines org-wide pipeline platform; sets security gate policies | Minimal |
| 5 | Distinguished | Contributes to pipeline tooling OSS; publishes GitOps patterns | AI as research assistant |

**Current team target level:** `3`
**Expected time to Practitioner (L2):** `4–6 months`

---

## Prerequisites

### Required Skills
- `coding.senior-dev.version-control` — Git branching strategy mastery
- `security.devsecops.sast-sca` — understanding security scan integration

### Required Tools Access
- **GitHub Actions / GitLab CI** — pipeline execution platform
- **Docker** — container image building
- **SonarQube** — SAST and quality gate
- **Trivy or Snyk** — container and dependency scanning
- **Artifactory / ECR** — artifact registry

### Required Knowledge
- Git branching strategies (trunk-based, GitFlow, GitHub Flow)
- Container image layering and build optimization
- SAST, DAST, SCA concepts and tools
- Pipeline as Code (YAML-first, no clickops)
- Secrets management (Vault, AWS Secrets Manager, GitHub Secrets)

---

## Workflow

### Step 1: Branching Strategy Alignment
Agree on branching strategy with the development team before designing the pipeline. The pipeline must enforce the agreed strategy.

**AI Assist:** `Yes` — "Compare trunk-based development vs GitFlow for a team of [N] with [deployment frequency]"

### Step 2: Pipeline Stage Design
Define stages in order: Source → Build → Test → Security Scan → Artifact Publish → Deploy (dev) → Integration Test → Deploy (staging) → Smoke Test → Deploy (prod) → Post-deploy validation.

Every stage must have: a defined pass/fail condition, a timeout, and artifact handoff to the next stage.

### Step 3: Security Gate Integration (Shift Left)
Integrate in this order (earliest possible in pipeline):
1. Pre-commit hooks: secret scanning (Gitleaks), linting
2. Build stage: SCA (dependency vulnerabilities)
3. Post-build: SAST (SonarQube), container scan (Trivy)
4. Pre-prod: DAST (OWASP ZAP) against staging

**Decision Gate:** Pipeline must FAIL on: CRITICAL/HIGH CVEs (configurable policy), SAST BLOCKER findings, secrets detected in code.

### Step 4: Environment Promotion Strategy
Define promotion rules: dev → staging (automatic on main branch merge), staging → prod (manual approval gate + automated smoke test passage).

**AI Assist:** `Yes` — AI generates environment-specific GitHub Actions workflow files

### Step 5: GitOps Configuration (Kubernetes targets)
Use ArgoCD or Flux for Kubernetes deployment. Application manifests live in a separate `gitops-config` repo. The CI pipeline writes image tags; the GitOps operator syncs to cluster.

### Step 6: Secrets Management Integration
All secrets sourced from Vault or cloud secrets manager. No secrets in pipeline YAML. Use dynamic secrets where possible.

### Step 7: Pipeline Performance Optimization
Target: total pipeline time < 10 minutes for feature branches, < 15 minutes including integration tests. Use caching (dependency cache, Docker layer cache), parallelization, and test splitting.

### Step 8: Observability Integration
Emit pipeline metrics (duration, pass/fail, stage times) to Datadog or Grafana. Alert on pipeline failure rate >5% in a rolling 24-hour window.

---

## Tools & Integrations

| Tool | Purpose | Required/Optional | AI-Native? |
|---|---|---|---|
| GitHub Actions | Pipeline execution | Required | Yes (AI generates YAML) |
| SonarQube | SAST + quality gate | Required | No |
| Trivy | Container + IaC scanning | Required | No |
| Gitleaks | Pre-commit secret scanning | Required | No |
| ArgoCD / Flux | GitOps Kubernetes operator | Required (K8s targets) | No |
| HashiCorp Vault | Secrets management | Required | No |
| Artifactory / ECR | Artifact registry | Required | No |
| OWASP ZAP | DAST | Optional | No |

---

## Anti-Patterns

### ❌ Anti-Pattern 1: Secrets in Pipeline YAML
**What it looks like:** `API_KEY: "sk-prod-abc123"` hardcoded in `.github/workflows/deploy.yml`  
**Why it's harmful:** Secrets are committed to Git history permanently. Exposure is catastrophic.  
**Remediation:** Immediately rotate the secret. Use GitHub Secrets + Vault integration. Scan all history with Gitleaks.

### ❌ Anti-Pattern 2: Skipping Security Gates on Hotfix Branches
**What it looks like:** A `skip-security-scan` label or conditional that bypasses SAST/SCA during urgent fixes  
**Why it's harmful:** Hotfixes under pressure are when vulnerabilities are most likely introduced.  
**Remediation:** Security gates run always. Speed comes from fixing SAST findings proactively, not skipping scans.

### ❌ Anti-Pattern 3: Snowflake Pipelines (Per-App Handcrafted YAML)
**What it looks like:** 40 microservices each with a completely unique pipeline YAML, maintained separately  
**Why it's harmful:** Updates (e.g., a new security gate) must be applied to 40 files manually. Drift is guaranteed.  
**Remediation:** Build reusable pipeline templates (GitHub Actions reusable workflows, shared GitLab CI components). Apps call the template, override only what's unique.

### ❌ Anti-Pattern 4: Manual Environment Promotion
**What it looks like:** Developers SSH into staging servers and run `docker pull && docker run` manually  
**Why it's harmful:** No audit trail, no rollback, no consistency. Environments drift apart.  
**Remediation:** All deployments via pipeline only. Human approval gates are fine; manual execution is not.

---

## Troubleshooting Guide

### Problem: Pipeline flaky — intermittently fails on network-dependent tests
**Root Cause(s):** Test environment instability; external service dependencies in unit tests; race conditions  
**Diagnostic Steps:**
1. Identify the specific failing step and its error pattern
2. Check if failure correlates with time of day (shared resource contention)
3. Check if the test makes real HTTP calls  
**Resolution:** Mock external dependencies. Move integration tests to a dedicated test environment. Add retry logic (with limit) for infra-level failures.  
**Prevention:** Define "unit test contract": no real I/O. Enforce with CI timeout of 30s per test.

### Problem: SonarQube quality gate failing on new code coverage requirement
**Root Cause(s):** New gate threshold higher than existing coverage; AI-generated code not tested  
**Diagnostic Steps:**
1. Check SonarQube "New Code" tab — only new code is gated
2. Identify which files have low coverage  
**Resolution:** Add tests for the uncovered new code before merging.  
**Prevention:** Write tests before or alongside the code (TDD). AI generates test stubs.

---

## Escalation Patterns

| Trigger | Escalate To | SLA | Channel |
|---|---|---|---|
| Secret detected in any branch | Security Engineer + EM | Immediate | `#security-incidents` |
| Production deployment pipeline fails | On-call DevSecOps + EM | 15 minutes | PagerDuty + `#incidents` |
| Critical CVE in base image blocks all pipelines | Security Engineer + Architect | 4 hours | `#security-escalations` |
| Pipeline platform (GitHub Actions) outage | Engineering Manager | 30 minutes | Status page + `#engineering-ops` |

---

## KPIs & Success Metrics

| Metric | Baseline | Target | Measurement Method |
|---|---|---|---|
| Deployment frequency | 2/week | Daily | DORA metrics dashboard |
| Change failure rate | 15% | <5% | Incident postmortems |
| Pipeline success rate | 80% | >95% | CI analytics |
| Mean time to restore (pipeline) | 4 hours | <30 minutes | Incident tracking |
| Pipeline duration (p95) | 22 minutes | <12 minutes | Pipeline analytics |
| Security gate coverage | 60% of pipelines | 100% | Pipeline audit |

---

## Best Practices

1. **Pipeline as Code, Always** — Zero clickops. Every pipeline change is a PR with review.
2. **Fail Fast, Fail Cheap** — Put the fastest and most likely-to-fail checks first (lint, unit tests). Don't run 20-minute integration tests before linting.
3. **Artifact Immutability** — Never rebuild artifacts. Build once, promote the same artifact through environments.
4. **One Source of Truth per Environment** — Use GitOps: Git is the desired state. Reconciliation loops keep reality in sync.
5. **Blast Radius Reduction** — Use canary and blue/green deployments to limit the impact of bad deployments.
6. **Alert on Pipeline Health, Not Just App Health** — Pipeline degradation is a delivery risk signal.

---

## Automation Opportunities

| Opportunity | Tool/Approach | Maturity Required | Effort |
|---|---|---|---|
| AI-generated pipeline YAML from service manifest | AI + pipeline template library | L2 | M |
| Auto-create rollback PR on deployment failure | GitHub Actions + ArgoCD webhook | L3 | M |
| SBOM (Software Bill of Materials) auto-generation | Syft in pipeline | L2 | S |
| Auto-remediation of fixable CVEs via PR | Dependabot + Snyk autofix | L2 | S |
| Pipeline cost optimization (runner sizing) | Custom analytics | L4 | L |

---

## AI Prompt Examples

### Prompt 1: Generate a GitHub Actions Pipeline
```
Role: You are a DevSecOps engineer designing a CI/CD pipeline.
Context: We have a Node.js Express API that deploys to AWS EKS. 
         We use: Docker, ECR, ArgoCD, SonarQube, Trivy.
         Branching strategy: trunk-based (main = prod, PRs for features).
Task: Generate a complete GitHub Actions workflow file for the CI pipeline.
Constraints:
  - Stages: lint → unit test → build image → SonarQube scan → Trivy scan → push to ECR → update ArgoCD image tag
  - Fail pipeline on: test failure, SonarQube BLOCKER, Trivy CRITICAL CVE
  - Cache: npm dependencies, Docker layers
  - Secrets via GitHub Secrets (not hardcoded)
  - Target: pipeline completes in <10 minutes
Output format: Complete YAML file with inline comments explaining each stage
```

### Prompt 2: Diagnose Pipeline Performance
```
Role: You are a DevSecOps engineer optimizing a slow pipeline.
Context: Our pipeline takes 28 minutes. Here is the stage breakdown:
  - Checkout: 30s
  - npm install: 4 min (no cache)
  - Unit tests: 8 min (500 tests, sequential)
  - Docker build: 7 min (no layer cache)
  - SonarQube: 5 min
  - Trivy: 3 min
  - Deploy: 30s
Task: Identify the top 3 optimization opportunities and provide implementation steps.
Constraints:
  - Target: <10 minutes total
  - Must not skip any security gates
  - Implementation must be GitHub Actions YAML
Output format: Prioritized list with current time → target time and YAML snippets
```

---

## References & Further Reading

- [DORA State of DevOps Report](https://dora.dev) — Industry benchmarks for delivery metrics
- [GitOps Principles](https://opengitops.dev) — OpenGitOps specification
- [GitHub Actions Documentation](https://docs.github.com/en/actions) — Official reference
