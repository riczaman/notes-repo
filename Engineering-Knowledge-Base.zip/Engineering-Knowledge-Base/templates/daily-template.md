# 📅 Daily Log — YYYY-MM-DD

> **Day:** Monday | **Week:** WXX | **Sprint:** SXX
> **Focus Areas:** _Brief summary of today's primary focus_

---

## ⚡ Day at a Glance

| Category | Count |
|---|---|
| 🔥 Completed Items | 0 |
| 🎯 New Action Items | 0 |
| 🧠 Decisions Made | 0 |
| 🚧 Blockers Raised | 0 |
| ⚠️ Risks Identified | 0 |

---

<!-- ============================================================
     DUPLICATE THIS BLOCK FOR EACH PROJECT TOUCHED TODAY
     The H2 heading (## Project Name) is how Copilot links
     notes to the correct project summary file.
     ============================================================ -->

## Azure Data Pipeline

### 📌 Meeting / Activity

> _e.g., Architecture Review | Standup | Design Session | 1:1 | Incident Call_

**Attendees:** _Name, Name, Name_
**Time:** _HH:MM – HH:MM_

---

### 💬 Notes

-
-
-

---

### 🔥 Completed

-
-

---

### 🟡 In Progress

-
-

---

### 🧠 Decisions

> _Record decisions made today. These will be extracted to `decisions/decisions.md`._

| # | Decision | Rationale | Made By | Date |
|---|---|---|---|---|
| D-XXX | | | | YYYY-MM-DD |

---

### 🎯 Action Items

> _Record new action items. These will be extracted to `action-items/action-items.md`._

| # | Action Item | Owner | Due Date | Status |
|---|---|---|---|---|
| A-XXX | | | YYYY-MM-DD | 🟡 Open |

---

### 🚧 Blockers

-
-

---

### ⚠️ Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| | Medium | High | |

---

### 🔗 Links

- [Azure Portal](https://portal.azure.com)
- [Confluence](https://your-confluence-url.com)
- [JIRA Board](https://your-jira-url.com)

---

<!-- ============================================================
     ADD MORE PROJECT SECTIONS BELOW AS NEEDED
     ============================================================ -->

## Unified Storefront

### 📌 Meeting / Activity

**Attendees:**
**Time:**

---

### 💬 Notes

-

---

### 🔥 Completed

-

---

### 🟡 In Progress

-

---

### 🧠 Decisions

| # | Decision | Rationale | Made By | Date |
|---|---|---|---|---|
| D-XXX | | | | YYYY-MM-DD |

---

### 🎯 Action Items

| # | Action Item | Owner | Due Date | Status |
|---|---|---|---|---|
| A-XXX | | | YYYY-MM-DD | 🟡 Open |

---

### 🚧 Blockers

-

---

### ⚠️ Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| | | | |

---

### 🔗 Links

-

---

## 🗒️ General Notes

> _Notes not tied to a specific project — team observations, process improvements, personal reminders._

-

---

## 🌙 End of Day Summary

> _Written at the end of the day. Used by Copilot to generate weekly summaries._

**What I accomplished today:**
-

**What I'm carrying into tomorrow:**
-

**Mood / Energy:** 🟢 Good | 🟡 Okay | 🔴 Rough

---

*Log closed: YYYY-MM-DD HH:MM*
