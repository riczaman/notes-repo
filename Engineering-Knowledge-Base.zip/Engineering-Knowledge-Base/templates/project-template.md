# 🗂️ Project: [PROJECT NAME]

> ⚠️ **This file is AI-maintained.** Do not edit manually.
> It is auto-generated and refreshed by GitHub Copilot Agent Mode from daily logs.
> Last refreshed: _YYYY-MM-DD_

---

## 📊 Project Overview

| Field | Value |
|---|---|
| **Project Name** | [PROJECT NAME] |
| **Status** | 🟡 In Progress |
| **Owner** | [Engineering Manager Name] |
| **Team** | [Team Members] |
| **Start Date** | YYYY-MM-DD |
| **Target Date** | YYYY-MM-DD |
| **Priority** | 🔴 High / 🟡 Medium / 🟢 Low |
| **Stakeholders** | [Stakeholder Names] |

---

## 🎯 Objective

> _One paragraph describing the purpose of this project, what problem it solves, and the expected outcome._

---

## 🚀 Milestones

| Milestone | Target Date | Status | Notes |
|---|---|---|---|
| | YYYY-MM-DD | 🟡 In Progress | |
| | YYYY-MM-DD | ⬜ Not Started | |
| | YYYY-MM-DD | ✅ Complete | |

---

## 🔥 Completed

> _Significant accomplishments extracted from daily logs._

- **YYYY-MM-DD** —
- **YYYY-MM-DD** —
- **YYYY-MM-DD** —

---

## 🟡 In Progress

> _Work currently underway._

- **YYYY-MM-DD** —
- **YYYY-MM-DD** —

---

## 🎯 Open Action Items

> _Sourced from `action-items/action-items.md`. Filtered to this project._

| # | Action Item | Owner | Due Date | Status |
|---|---|---|---|---|
| A-XXX | | | YYYY-MM-DD | 🟡 Open |

---

## 🧠 Decisions

> _Sourced from `decisions/decisions.md`. Filtered to this project._

| # | Decision | Rationale | Made By | Date |
|---|---|---|---|---|
| D-XXX | | | | YYYY-MM-DD |

---

## 🚧 Blockers

> _Current blockers preventing progress._

| Blocker | Raised Date | Owner | Status |
|---|---|---|---|
| | YYYY-MM-DD | | 🔴 Active |

---

## ⚠️ Risks

> _Known risks and current mitigation strategies._

| Risk | Likelihood | Impact | Mitigation | Status |
|---|---|---|---|---|
| | Medium | High | | 🟡 Monitoring |

---

## 🏛️ Architecture Notes

> _Key architecture decisions, diagrams referenced, or technical context._

-
-

---

## 🚢 Deployment History

> _Record of deployments, their outcomes, and any incidents._

| Date | Environment | Version | Outcome | Notes |
|---|---|---|---|---|
| YYYY-MM-DD | Production | v0.0.0 | ✅ Success | |
| YYYY-MM-DD | Staging | v0.0.0 | ⚠️ Issues | |

---

## 📅 Meeting & Activity Log

> _Chronological list of significant meetings and activities. Full notes live in daily logs._

| Date | Meeting / Activity | Key Outcome | Daily Log Link |
|---|---|---|---|
| YYYY-MM-DD | | | [View](../daily-logs/YYYY/MM/YYYY-MM-DD.md) |

---

## 🔗 Key References

- [Project Confluence Page](https://your-confluence-url.com)
- [JIRA Board](https://your-jira-url.com)
- [Architecture Diagram](https://your-diagram-url.com)
- [Azure Portal](https://portal.azure.com)
- [Repository](https://github.com/your-org/your-repo)

---

## 📝 Executive Summary

> _2-3 paragraph summary suitable for leadership. Refreshed weekly by Copilot._

**Current State:**
_[Auto-generated summary of project health, recent progress, and near-term focus]_

**Key Risks:**
_[Top 1-2 risks requiring leadership awareness]_

**Asks / Decisions Needed:**
_[Anything requiring escalation or executive decision]_

---

*Auto-refreshed from daily logs by GitHub Copilot Agent Mode.*
*Last updated: YYYY-MM-DD*
