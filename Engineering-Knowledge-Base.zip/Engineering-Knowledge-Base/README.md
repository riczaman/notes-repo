# 🧠 Engineering Knowledge Base

> Personal engineering memory system for an Engineering Manager — optimized for GitHub Copilot in VS Code.

---

## 📁 Repository Structure

```
Engineering-Knowledge-Base/
├── daily-logs/          # Source of truth — one file per day, organized by project
│   └── YYYY/MM/YYYY-MM-DD.md
├── projects/            # AI-maintained project summaries (generated from daily logs)
│   └── project-name.md
├── decisions/           # Centralized decision log
│   └── decisions.md
├── action-items/        # Open and completed action items
│   └── action-items.md
├── templates/           # Reusable markdown templates
│   ├── daily-template.md
│   └── project-template.md
├── .skills/             # Copilot skill definitions
│   └── knowledge-manager-skill.md
├── .github/             # Copilot behavior instructions
│   └── copilot-instructions.md
└── copilot/             # Reusable Copilot prompts and automation
    └── prompts.md
```

---

## 🚀 Active Projects

| Project | Summary File | Status |
|---|---|---|
| Azure Data Pipeline | [azure-data-pipeline.md](projects/azure-data-pipeline.md) | 🟡 In Progress |
| Unified Storefront | [unified-storefront.md](projects/unified-storefront.md) | 🟡 In Progress |
| iManage | [imanage.md](projects/imanage.md) | 🟡 In Progress |
| Vulnerabilities | [vulnerabilities.md](projects/vulnerabilities.md) | 🟡 In Progress |
| Infrastructure Initiatives | [infrastructure-initiatives.md](projects/infrastructure-initiatives.md) | 🟡 In Progress |
| Security Remediation | [security-remediation.md](projects/security-remediation.md) | 🟡 In Progress |
| Production Support | [production-support.md](projects/production-support.md) | 🟡 In Progress |
| Automation Projects | [automation-projects.md](projects/automation-projects.md) | 🟡 In Progress |

---

## ⚡ Quick Copilot Prompts

Open GitHub Copilot Chat (`Ctrl+Shift+I`) and paste any of these:

```
Summarize this week's daily logs and generate an executive update.
```

```
What decisions were made regarding Azure Data Pipeline in the last 90 days?
```

```
Show all open action items across all projects.
```

```
What risks and blockers are currently active?
```

```
Generate a performance review summary of accomplishments from the last 6 months.
```

---

## 📋 Core Workflows

| Workflow | Frequency | Description |
|---|---|---|
| New Daily Log | Daily | Copy `templates/daily-template.md` → `daily-logs/YYYY/MM/YYYY-MM-DD.md` |
| Project Sync | Daily | Ask Copilot to update project summaries from today's log |
| Weekly Summary | Weekly | Ask Copilot to generate weekly accomplishment/risk/action report |
| Decision Capture | As needed | Add decisions to `decisions/decisions.md` |
| Action Item Review | Weekly | Ask Copilot to reconcile `action-items/action-items.md` |

---

## 🧭 Design Principles

1. **Daily logs are the source of truth.** Everything starts here.
2. **Project files are AI-maintained summaries.** Never edit manually — regenerate from logs.
3. **Use H2 headings (`## Project Name`) in daily logs.** This is how Copilot associates notes with projects.
4. **One daily log per day.** Never one file per meeting.
5. **Decisions and action items are extracted to dedicated files.** Keep them current.

---

*Last updated: auto-maintained by GitHub Copilot Agent Mode*
