# 🤖 Copilot Reusable Prompts

> Copy and paste these prompts directly into GitHub Copilot Chat or Agent Mode.
> Replace bracketed placeholders with actual values before running.

---

## 🔧 Daily Maintenance

### Daily Sync Prompt

```
Review today's daily log at daily-logs/[YYYY]/[MM]/[YYYY-MM-DD].md.

Perform the following tasks:

1. Update all relevant project summary files in projects/ based on today's log entries.
2. Extract any new decisions and add them to decisions/decisions.md using the next available D-XXX ID.
3. Extract any new action items and add them to action-items/action-items.md using the next available A-XXXX ID.
4. Mark any action items referenced as completed in today's log as complete in action-items.md and move them to the archive section.
5. Identify any blockers mentioned and flag them in the relevant project file.
6. Identify any risks mentioned and add them to the relevant project file's risk table.
7. Produce a structured end-of-day summary using the standard markdown format.

Do not invent information. Only use content present in today's log.
Cite the daily log file for each extracted item.
```

---

## 📅 Weekly Summary

### Weekly Summary Prompt

```
Review all daily logs from the week of [YYYY-MM-DD] through [YYYY-MM-DD].
Files are located in daily-logs/[YYYY]/[MM]/.

Generate a complete weekly summary containing:

### 🔥 Accomplishments
List all completed work items, grouped by project.

### 🟡 In Progress
List all work items currently underway, grouped by project.

### 🎯 Action Items
Table of all open action items from the week, with owner and due date.

### 🚧 Blockers
All blockers raised this week, with current status.

### ⚠️ Risks
All risks identified this week, with likelihood and impact.

### 🧠 Key Decisions
All decisions made this week, with rationale.

### 📊 Executive Summary
A 2-3 paragraph leadership-ready summary of the week suitable for a VP or Director audience.
Lead with outcomes. Include risks requiring attention and decisions needed.

Do not invent information. Only synthesize from the daily logs.
```

---

## 📊 Project Summary Refresh

### Single Project Refresh

```
Review all daily logs that contain the heading ## [PROJECT NAME].
Logs are located in daily-logs/ organized by YYYY/MM/YYYY-MM-DD.md.

Update the project summary file at projects/[project-filename].md with:

1. Refresh the "Completed" section with work completed since the last refresh.
2. Update the "In Progress" section with current active work.
3. Add any new milestones with their status.
4. Update the deployment history with any deployments logged.
5. Refresh the open action items table (sourced from action-items/action-items.md).
6. Refresh the decisions table (sourced from decisions/decisions.md).
7. Update the blockers table — close any blockers resolved in recent logs.
8. Update the risks table.
9. Regenerate the Executive Summary section with current project state.
10. Update the "Last refreshed" date at the top of the file.

Do not remove historical entries. Only add and update.
Cite source daily log files for significant updates.
```

### All Projects Refresh

```
Refresh all project summary files in projects/.

For each project file, follow the same procedure as the single project refresh.
Projects to refresh:
- Azure Data Pipeline → projects/azure-data-pipeline.md
- Unified Storefront → projects/unified-storefront.md
- iManage → projects/imanage.md
- Vulnerabilities → projects/vulnerabilities.md
- Infrastructure Initiatives → projects/infrastructure-initiatives.md
- Security Remediation → projects/security-remediation.md
- Production Support → projects/production-support.md
- Automation Projects → projects/automation-projects.md

Process each project sequentially. Confirm each file is updated before proceeding.
```

---

## 🧠 Decision Extraction

```
Review all daily logs in daily-logs/ from [START DATE] to [END DATE].

For each daily log:
1. Scan for decisions under "### 🧠 Decisions" sections.
2. Scan for decision language in notes: "decided", "agreed", "chose", "approved", "selected", "will use", "going with".
3. Scan for architecture choices in "### 🏛️ Architecture Notes" sections.

For each new decision found:
- Assign the next available D-XXX ID (check decisions/decisions.md for last used ID).
- Add it to decisions/decisions.md under the correct project section.
- Include: ID, date, project, status, context, decision text, rationale, and link to source daily log.

Do not duplicate decisions already present in decisions/decisions.md.
Do not invent rationale — only capture what is documented in the logs.
```

---

## 🎯 Action Item Extraction and Reconciliation

```
Review all daily logs in daily-logs/ from [START DATE] to [END DATE].

For each daily log:
1. Extract all rows from "### 🎯 Action Items" tables.
2. Scan for action language: "TODO", "follow up", "need to", "will", "assigned to", "action:".
3. Check the "End of Day Summary" section for carry-forward items.

Then:
1. Add new action items to action-items/action-items.md with the next available A-XXXX ID.
2. Update the status of existing action items referenced as completed in the logs.
3. Move completed items to the archive section.
4. Flag items with due dates in the past as overdue.
5. Update the project summary table at the bottom of action-items.md.

Do not duplicate existing action items.
Cite the source daily log for each new item.
```

---

## 📈 Executive Update (Biweekly)

```
Review all daily logs from the past two weeks: [START DATE] to [END DATE].

Generate a biweekly executive update with the following format:

## Biweekly Engineering Update — [Date Range]

### Summary
[2-sentence overall summary]

### 🔥 Key Accomplishments — By Project
[Grouped accomplishments with business context]

### 🟡 Active Initiatives
[What is in flight and expected completion]

### ⚠️ Risks Requiring Leadership Awareness
[Risk table: Risk | Project | Impact | Recommendation]

### 🚧 Escalations / Blockers Needing Resolution
[Items requiring leadership action or decision]

### 🎯 Top 3 Focus Areas Next Two Weeks
[What the engineering team will be focused on]

Keep the total length under 500 words.
Use professional, outcome-focused language.
Quantify impact where the data is available in logs.
```

---

## 🏆 Performance Review Accomplishments

```
Review all daily logs from [START DATE] to [END DATE].
This covers my performance review period.

Generate a comprehensive accomplishments summary for a performance review, formatted as follows:

## Performance Accomplishments — [Year / Period]

### 🚀 Delivery & Project Execution
[Completed projects and deliverables with impact]

### 🏛️ Architecture & Technical Leadership
[Architecture decisions, technical guidance, design contributions]

### 🔒 Security & Compliance
[Security remediations, vulnerability resolutions, compliance work]

### 👥 Leadership, Collaboration & Communication
[Cross-team work, stakeholder management, team support]

### ⚙️ Process Improvement & Automation
[Process changes, automation built, efficiency gains]

### 📊 Key Metrics (where available from logs)
[Any quantitative outcomes mentioned in logs]

Extract only what is documented in daily logs.
Use outcome-focused language: "Delivered X, resulting in Y" rather than "Worked on X."
Group related items together even if spread across multiple months.
```

---

## 🔍 Knowledge Query Prompts

### Architecture Decision Query

```
Search all daily logs and decisions/decisions.md for references to [PROJECT NAME].

What architecture decisions were made regarding [PROJECT NAME] in the last [90 days / 6 months / year]?

For each decision, provide:
- The decision made
- The date
- The rationale (if documented)
- The source daily log

Present results in a markdown table sorted by date descending.
```

### Open Action Items Query

```
Search action-items/action-items.md and all daily logs for open action items related to [PROJECT NAME].

List all items with status "Open", "Overdue", or "Waiting".
Include: ID, description, owner, due date, and current status.
Flag any items that are overdue.
```

### Deployment History Query

```
Search all daily logs for deployment-related notes for [PROJECT NAME].
Look for keywords: deploy, deployment, release, rollout, hotfix, rollback, pipeline, production.

Produce a deployment history table:
| Date | Environment | Description | Outcome | Notes |

Include any incidents, rollbacks, or post-deployment issues mentioned in logs.
```

### Risk History Query

```
Search all daily logs and projects/[project-filename].md for risks identified related to [PROJECT NAME].

List all risks, including:
- Risks that were resolved (with resolution date if available)
- Risks that are still active

Present as a risk register table with likelihood, impact, and current status.
```

### Full Project Intelligence Brief

```
Generate a comprehensive project intelligence brief for [PROJECT NAME].

Search:
1. All daily logs containing ## [PROJECT NAME]
2. projects/[project-filename].md
3. decisions/decisions.md for D-XXX entries tagged to this project
4. action-items/action-items.md for A-XXXX entries tagged to this project

Include:
- Project overview and current status
- Milestone progress
- Architecture decisions and their rationale
- Deployment history
- Open action items
- Active blockers and risks
- Key stakeholders mentioned in logs
- Executive summary

Cite source files throughout.
```

---

## 🌐 External Reference Integration Prompts

### Compare Repository vs External Architecture Document

```
Review the repository history for [PROJECT NAME] by searching all relevant daily logs and decisions/decisions.md.

Then review the following architecture document: [PASTE DOCUMENT OR URL]

Identify:
1. Decisions documented in the repository that are inconsistent with the architecture document.
2. Architecture patterns in the document not yet reflected in daily logs or decisions.
3. Risks implied by the architecture document not yet captured in the repository.
4. Action items implied by any gaps between repository knowledge and the document.

Present findings in four clearly labeled sections.
```

### Ingest Meeting Notes from Email

```
Review the following email from [SENDER] dated [DATE] about [SUBJECT]:

[PASTE EMAIL CONTENT]

Cross-reference this email against the existing daily logs and project files for [PROJECT NAME].

Extract:
1. Any decisions mentioned — check if they are already in decisions/decisions.md.
2. Any action items mentioned — check if they are already in action-items/action-items.md.
3. Any risks or blockers mentioned not yet captured.
4. Any context that contradicts or updates existing repository knowledge.

Produce a structured list of net-new items ready to be added to the repository.
```

### Ingest Confluence Page Export

```
Review the following Confluence page export for [SPACE / PAGE TITLE]:

[PASTE CONFLUENCE CONTENT]

Compare against the repository knowledge for [PROJECT NAME].

Identify:
1. Decisions on the Confluence page not in decisions/decisions.md.
2. Action items on the page not in action-items/action-items.md.
3. Architecture notes not captured in the project summary or daily logs.
4. Risks documented in Confluence not in the repository.

List all items to be added, formatted and ready to paste into the appropriate repository files.
```

### Ingest PDF / Document Summary

```
Review the following document summary:

[PASTE DOCUMENT TEXT OR SUMMARY]

This document relates to [PROJECT NAME].

Extract all:
- Decisions
- Action items
- Risks
- Architecture notes
- Milestones

Cross-reference each against existing repository files.
List only net-new items that are not already captured.
Format them ready to paste into the appropriate repository files.
```

---

*All prompts designed for use in GitHub Copilot Chat and Agent Mode.*
*Replace all bracketed values before use.*
*Prompts version: 1.0*
