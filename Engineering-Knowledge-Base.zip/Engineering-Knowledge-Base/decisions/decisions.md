# 🧠 Decision Log

> ⚠️ **This file is AI-maintained.** Decisions are extracted from daily logs by GitHub Copilot Agent Mode.
> Do not delete old decisions. Append only.
> Last refreshed: _YYYY-MM-DD_

---

## 📋 Decision Index

| # | Project | Decision Summary | Date | Made By |
|---|---|---|---|---|
| [D-001](#d-001) | Azure Data Pipeline | Example: Selected Azure Data Factory over SSIS | YYYY-MM-DD | [Name] |

---

## How to Read This Log

- **ID** — Unique decision identifier. Reference in daily logs as `D-XXX`.
- **Status** — `✅ Final` | `🟡 Under Review` | `⏮️ Reversed`
- **Context** — What problem or question prompted this decision.
- **Decision** — What was decided.
- **Rationale** — Why this decision was made.
- **Alternatives Considered** — What else was evaluated.
- **Consequences** — Known tradeoffs or implications.

---

## Azure Data Pipeline

### D-001

| Field | Value |
|---|---|
| **ID** | D-001 |
| **Date** | YYYY-MM-DD |
| **Status** | ✅ Final |
| **Made By** | [Name / Group] |
| **Project** | Azure Data Pipeline |

**Context:**
_What situation or question prompted this decision._

**Decision:**
_What was decided._

**Rationale:**
_Why this approach was selected._

**Alternatives Considered:**
- Option A — Rejected because...
- Option B — Rejected because...

**Consequences / Tradeoffs:**
-

**References:**
- [Daily Log YYYY-MM-DD](../daily-logs/YYYY/MM/YYYY-MM-DD.md)

---

## Unified Storefront

> _Decisions will be added here as they are extracted from daily logs._

---

## iManage

> _Decisions will be added here as they are extracted from daily logs._

---

## Vulnerabilities

> _Decisions will be added here as they are extracted from daily logs._

---

## Infrastructure Initiatives

> _Decisions will be added here as they are extracted from daily logs._

---

## Security Remediation

> _Decisions will be added here as they are extracted from daily logs._

---

## Production Support

> _Decisions will be added here as they are extracted from daily logs._

---

## Automation Projects

> _Decisions will be added here as they are extracted from daily logs._

---

## Cross-Project / General

> _Decisions that span multiple projects or apply broadly._

---

*Auto-maintained by GitHub Copilot Agent Mode.*
*All decisions sourced from daily logs.*
