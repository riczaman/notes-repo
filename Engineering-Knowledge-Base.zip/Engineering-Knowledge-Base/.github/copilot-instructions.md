# GitHub Copilot Instructions — Engineering Knowledge Base

> This file configures how GitHub Copilot Chat and Agent Mode behave inside this repository.
> Copilot must follow all instructions below consistently across every session.

---

## 🧠 Repository Identity

This repository is a **personal engineering knowledge management system** for an Engineering Manager.

It functions as a **long-term professional memory** — capturing projects, decisions, architecture discussions, deployments, risks, action items, and meeting notes.

The operator is responsible for:
- Multiple engineering applications and infrastructure initiatives
- Security remediation and vulnerability management
- Production support and deployment activities
- Architecture discussions and technical documentation
- Engineering leadership and team management

---

## 📁 Repository Structure Rules

### Daily Logs are the Source of Truth

- All knowledge originates in `daily-logs/YYYY/MM/YYYY-MM-DD.md`
- **Always search daily logs first** before answering any question
- Daily logs are organized by project using H2 headings (`## Project Name`)
- The H2 heading is the primary metadata linking a note to its project
- Meeting notes are embedded inside daily logs — there are no separate meeting folders

### Project Files are AI-Maintained Summaries

- Files in `projects/` are summaries derived from daily logs
- Project files should never contradict daily logs
- When daily logs and project files conflict, **daily logs win**
- Project files should be refreshed from daily logs, not edited manually

### Decisions and Action Items are Extracted Files

- `decisions/decisions.md` contains decisions extracted from daily logs
- `action-items/action-items.md` contains action items extracted from daily logs
- These files are append-only for history preservation
- Completed action items are archived, never deleted

---

## 🤖 Copilot Behavioral Rules

### Always Do

- ✅ Search all daily logs before answering any historical question
- ✅ Use `decisions/decisions.md` as a secondary reference for decision queries
- ✅ Use `action-items/action-items.md` as a secondary reference for task queries
- ✅ Use `projects/` files for project overview context
- ✅ Cite the source daily log file when referencing specific facts
- ✅ Use professional engineering language appropriate for leadership communication
- ✅ Format all output using the markdown styling standards defined below
- ✅ Preserve decision history — never remove or overwrite past decisions
- ✅ Preserve action item history — archive completed items, never delete
- ✅ When generating summaries, distinguish between facts (from logs) and inferences (your synthesis)

### Never Do

- ❌ Never invent information not present in the repository
- ❌ Never assume a decision was made unless it appears in daily logs or `decisions/decisions.md`
- ❌ Never delete historical entries from `decisions.md` or `action-items.md`
- ❌ Never overwrite a project file without regenerating from daily logs
- ❌ Never answer questions about this repository from general knowledge alone — always search the logs
- ❌ Never create files outside the defined folder structure

---

## 📋 Markdown Styling Standards

All generated markdown must use the following emoji section headers:

| Emoji | Section |
|---|---|
| 🔥 | Completed |
| 🟡 | In Progress |
| 🚧 | Blockers |
| 🎯 | Action Items |
| 🧠 | Decisions |
| 💬 | Notes |
| 🔗 | Links |
| ⚠️ | Risks |
| 🚀 | Milestones |
| 📅 | Dates / Timeline |
| 🏛️ | Architecture |
| 🚢 | Deployments |

Use **markdown tables** for structured data (action items, decisions, risks, milestones).
Use **hyperlink syntax** for all URLs: `[Label](https://url.com)`
Use **bold** for names, dates, and key terms.
Keep language concise and professional. Avoid filler phrases.

---

## 🗂️ Known Projects

When searching logs, recognize these project names as primary identifiers:

- `Azure Data Pipeline`
- `Unified Storefront`
- `iManage`
- `Vulnerabilities`
- `Infrastructure Initiatives`
- `Security Remediation`
- `Production Support`
- `Automation Projects`

If a new project appears in daily logs that is not in this list, flag it and suggest adding a project summary file.

---

## 📆 Daily Workflow

### Morning Setup (5 minutes)

1. Open `daily-logs/YYYY/MM/` and create today's log from `templates/daily-template.md`
2. Name the file `YYYY-MM-DD.md`
3. Fill in the Day at a Glance header section
4. Review yesterday's open action items in `action-items/action-items.md`

### Throughout the Day

1. For each meeting or activity, add a project section (`## Project Name`) to today's log
2. Capture notes, decisions, and action items under the relevant project heading
3. Use decision IDs (`D-XXX`) and action item IDs (`A-XXXX`) consistently
4. Add links to referenced artifacts (JIRA tickets, Confluence pages, PRs)

### End of Day (10 minutes)

1. Complete the **End of Day Summary** section in today's log
2. Run the **Daily Maintenance** agent prompt (see `copilot/prompts.md`)
3. Review the Copilot output and confirm updates to project files, decisions, and action items

---

## 📅 Weekly Workflow

### Monday Morning (15 minutes)

1. Review last week's daily logs for any missed action items or decisions
2. Run the **Weekly Summary** agent prompt
3. Review generated summary and send to stakeholders as needed

### Friday Afternoon (20 minutes)

1. Run **Action Item Extraction** prompt to reconcile `action-items/action-items.md`
2. Run **Decision Extraction** prompt to reconcile `decisions/decisions.md`
3. Run **Weekly Summary** prompt to generate the week's accomplishments
4. Update priority project summary files with any major changes

---

## 🗓️ Monthly Workflow

### First Monday of the Month (30 minutes)

1. Run **Project Summary Refresh** for each active project
2. Review all open risks across projects
3. Generate a monthly accomplishments summary for performance records
4. Archive completed action items older than 30 days
5. Review and update project statuses in `README.md`

### Mid-Month Check (15 minutes)

1. Review overdue action items and escalate or reschedule
2. Check risk log for items requiring executive awareness
3. Refresh any project files with major activity since last refresh

---

## 🔍 How to Answer Questions

When a user asks a question about the repository:

1. **Identify the time range** — Does the question specify a period (last 90 days, this quarter, etc.)?
2. **Identify the project** — Which project(s) does the question relate to?
3. **Search daily logs** — Scan all relevant daily log files for the project H2 heading
4. **Check reference files** — Check `decisions.md`, `action-items.md`, and the relevant `projects/` file
5. **Synthesize** — Combine findings into a structured response using the markdown standards above
6. **Cite sources** — Reference specific daily log files for key facts

---

## 📝 Response Format for Summaries

When generating any summary (weekly, executive, leadership, project), use this structure:

```
## [Summary Title] — [Date Range]

### 🔥 Accomplishments
[Bullet list of completed work]

### 🟡 In Progress
[Bullet list of active work]

### 🎯 Action Items
[Table of open action items]

### 🚧 Blockers
[List of active blockers]

### ⚠️ Risks
[Risk table with likelihood and impact]

### 🧠 Key Decisions
[List of decisions made]

### 📊 Executive Summary
[2-3 paragraph leadership-ready summary]
```

---

*These instructions apply to all Copilot Chat and Agent Mode sessions within this repository.*
*Version: 1.0 | Maintained by repository owner.*
