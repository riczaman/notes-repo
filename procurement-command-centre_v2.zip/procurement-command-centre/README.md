# Procurement Command Centre

A local dashboard for the Procurement TPMM portfolio: initiatives, application workspaces with daily notes, AI ideas, lifecycle and capability maps, overlap and gap analysis, data flows, current vs future state, opportunities, model governance and an executive presentation.

There is no database and no cloud service. Everything you enter is saved as plain JSON and Markdown files in the `data/` folder of this project.

---

## 1. How it works (read this once)

```
Browser (the app you click around in)
      │  every Save, Add, Edit or Delete
      ▼
Small local server (starts with npm run dev, runs only on your computer)
      │  writes the file
      ▼
data/ folder on your disk  ◄── you can also edit these files in VS Code
```

- **The app and the server start together** with one command. There is no separate "backend" to start.
- **Every change you make in the app is written to a file immediately.** Close the app, shut down the laptop, come back tomorrow: it is all there.
- **Editing a file in VS Code also works.** The open browser page refreshes itself within a second.
- **The server only listens on your own computer** (`localhost`). Nobody else can reach it.

---

## 2. Set up on a new computer

### What you need

| Requirement | How to check | Where to get it |
|---|---|---|
| Node.js 22 (or 20.19 and later) | `node -v` | nodejs.org (LTS installer), or your company software centre |
| npm (comes with Node) | `npm -v` | Installed with Node |

### Steps

1. Copy the whole `procurement-command-centre` folder to the new computer. **Do not copy `node_modules`** if it exists; it is large and specific to each computer. The transfer zip already leaves it out.
2. Open a terminal in the folder:
   - Windows: open the folder in File Explorer, click the address bar, type `cmd`, press Enter.
   - Mac: right-click the folder in Finder, choose New Terminal at Folder.
3. Install the dependencies (once per computer, takes about a minute):

   ```bash
   npm install
   ```

4. Start the app:

   ```bash
   npm run dev
   ```

   Your browser opens at http://localhost:5173. If it does not, open that address yourself.

5. To stop it, close the terminal window or press `Ctrl + C` in it.

**Shortcut after the first install:** double-click `start.bat` (Windows) or `start.command` (Mac). It installs if needed and starts the app.

### If `npm install` fails at work

| Message | Likely cause | Fix |
|---|---|---|
| `ETIMEDOUT`, `ECONNREFUSED`, `self signed certificate` | Company network blocks the public npm registry | Ask your team for the internal registry URL, then run `npm config set registry <that URL>` and retry |
| `Unsupported engine` | Node is too old | Install Node 22 LTS |
| `EACCES` / permission denied | Folder is in a protected location | Move the project into your Documents or home folder |
| Port 5173 already in use | The app is already running in another window | Use that window, or close it first. Vite will also pick the next free port and print it |

---

## 3. Daily use: where to enter what

You never need to open the code. Use the app, or edit files in `data/` if you prefer typing in VS Code.

| You want to | In the app | File it changes |
|---|---|---|
| Add today's meeting notes or a context dump | App → **Notes** → 09 Meeting Notes → **Add meeting note** | `data/apps/<ID>/notes.md` |
| Add an action, risk, decision, date, contact, how-to | App → **Notes** → that section → **Add row** | same `notes.md` |
| Edit or delete a row or a meeting note | Hover the row → pencil or bin icon | same `notes.md` |
| Change status, phase, "This week" | App → **Notes** → **Edit page header** | front matter of `notes.md` |
| Add, edit, delete an AI idea | App → **AI ideas** | `data/apps/<ID>/ai-ideas.md` |
| Create, edit, delete an initiative | **Workboard** → New initiative, or open a card → **Edit** | `data/portfolio/initiatives.json` |
| Add a new application | **Applications** → **New application** | `data/apps/<NEW-ID>/` (profile, notes, AI ideas) |
| Edit or delete an application | App → **Architecture profile** → **Edit fields** | `data/apps/<ID>/profile.json` |
| Add, edit, delete an integration | **Ecosystem map** → Add integration, or click a line → **Edit** | `data/landscape/integrations.json` |
| Lifecycle stages | **Lifecycle** → Add stage (also assigns apps) | `data/landscape/lifecycle.json` + app profiles |
| Capabilities, overlaps, gaps, data entities | Their pages → Add, or click a card to edit or delete | `data/landscape/*.json` |
| Future-state proposals, opportunities | **Current vs future**, **Opportunities** | `data/strategy/*.json` |
| Model risk obligations | **Model governance** | `data/governance/model-governance.json` |
| Paste a summary from your research agent | **Data ingestion** → paste or drop → review → approve | `data/apps/<ID>/profile.json` + `data/history/` |
| Feed Copilot | **Build Copilot context** (bottom left) | `context/<ID>.md` and `context/PORTFOLIO.md` |
| Present to leadership | **Executive view** → Present, or Export PDF (Save as PDF, landscape) | Nothing; generated from the data |

### Rules the app follows

- One record per application, keyed by its ID (for example `USFF`). Names can change; IDs cannot.
- Risks, decisions, key dates and actions live only in each app's `notes.md`. The Overview and Executive view roll them up.
- Imports never overwrite data with empty values and never merge two apps just because the names look alike.
- Deleting an application is blocked while other records still point at it.
- Every import keeps a before and after snapshot in `data/history/snapshots/`.

### Editing `notes.md` by hand

Keep the nine `## 0N Title` headings and each table's header row. Extra columns are fine; the app matches columns by header name. Dates use `YYYY-MM-DD`, or `YYYY-MM` when only the month is known. Meeting notes are `### YYYY-MM-DD · Title` followed by bullets, newest on top.

---

## 4. Backups

Your data is only as safe as the folder it sits in. Two easy options:

1. **Git (recommended).** Once:

   ```bash
   git init
   git add -A
   git commit -m "Baseline"
   ```

   Then at the end of each day:

   ```bash
   git add -A
   git commit -m "Daily update"
   ```

   This gives you the full history of every note and lets you undo any delete.

2. **OneDrive or a shared drive.** Keep the project inside a synced folder, but exclude `node_modules` if your sync tool allows it.

---

## 5. Moving to another computer again

Copy the folder **without** `node_modules`, then repeat section 2. On a Mac you can make the zip with:

```bash
cd ..
zip -r procurement-command-centre.zip procurement-command-centre -x "*/node_modules/*" "*/dist/*" "*.DS_Store"
```

On Windows: copy the folder, delete `node_modules` from the copy, then right-click → Send to → Compressed (zipped) folder.

---

## 6. Commands

| Command | Purpose |
|---|---|
| `npm install` | Install dependencies (once per computer) |
| `npm run dev` | Start the app |
| `npm run typecheck` | Check the code for type errors |
| `npm run schema` | Regenerate `schemas/application-summary.schema.json` after changing `src/domain/schemas.ts` |

## 7. More documentation

- `docs/ARCHITECTURE.md`: design, data model, decisions
- `docs/RESEARCH_AGENT_PROMPT.md`: instructions to give your research agent, with `schemas/application-summary.schema.json`
- `docs/examples/`: an example summary file
