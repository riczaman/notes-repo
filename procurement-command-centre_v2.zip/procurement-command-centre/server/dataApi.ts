import fs from 'node:fs/promises';
import path from 'node:path';
import type { Plugin, ViteDevServer } from 'vite';
import type { IncomingMessage, ServerResponse } from 'node:http';

/**
 * Local file API for the Command Centre.
 * The data/ folder is the source of truth. The browser reads every data file in one
 * call and writes through atomic batches. Edits made outside the app (VS Code, git)
 * are pushed to the browser as a "data:changed" event.
 */

const ROOT = process.cwd();
const READ_DIRS = ['data'];
const WRITE_DIRS = ['data', 'context', 'schemas'];
const ALLOWED_EXT = new Set(['.json', '.md']);

function resolveSafe(rel: string, dirs: string[]): string {
  if (typeof rel !== 'string' || rel.includes('\0')) throw new Error('Invalid path');
  const normalised = path.posix.normalize(rel.replace(/\\/g, '/'));
  if (normalised.startsWith('..') || path.isAbsolute(normalised)) throw new Error(`Path escapes project: ${rel}`);
  const top = normalised.split('/')[0];
  if (!dirs.includes(top)) throw new Error(`Path not in an allowed folder: ${rel}`);
  if (!ALLOWED_EXT.has(path.extname(normalised))) throw new Error(`Only .json and .md files: ${rel}`);
  const abs = path.resolve(ROOT, normalised);
  if (!abs.startsWith(ROOT + path.sep)) throw new Error(`Path escapes project: ${rel}`);
  return abs;
}

async function walk(dir: string): Promise<string[]> {
  const out: string[] = [];
  let entries: import('node:fs').Dirent[];
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const e of entries) {
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...(await walk(abs)));
    else if (ALLOWED_EXT.has(path.extname(e.name))) out.push(abs);
  }
  return out;
}

async function readAll(): Promise<Record<string, string>> {
  const files: Record<string, string> = {};
  for (const d of READ_DIRS) {
    for (const abs of await walk(path.join(ROOT, d))) {
      const rel = path.relative(ROOT, abs).split(path.sep).join('/');
      files[rel] = await fs.readFile(abs, 'utf8');
    }
  }
  return files;
}

interface BatchBody {
  writes?: { path: string; content: string }[];
  deletes?: string[];
}

/** Writes every file to a temp sibling first, then renames. Either all land or none do. */
async function applyBatch(body: BatchBody) {
  const writes = (body.writes ?? []).map((w) => ({ abs: resolveSafe(w.path, WRITE_DIRS), content: String(w.content) }));
  const deletes = (body.deletes ?? []).map((p) => resolveSafe(p, WRITE_DIRS));
  for (const w of writes) {
    if (w.abs.endsWith('.json')) JSON.parse(w.content); // refuse to write broken JSON
  }
  const temps: { tmp: string; abs: string }[] = [];
  try {
    for (const w of writes) {
      await fs.mkdir(path.dirname(w.abs), { recursive: true });
      const tmp = `${w.abs}.${process.pid}.${Date.now()}.tmp`;
      await fs.writeFile(tmp, w.content, 'utf8');
      temps.push({ tmp, abs: w.abs });
    }
  } catch (err) {
    await Promise.all(temps.map((t) => fs.rm(t.tmp, { force: true })));
    throw err;
  }
  for (const t of temps) await fs.rename(t.tmp, t.abs);
  for (const d of deletes) await fs.rm(d, { force: true });
  return { written: writes.length, deleted: deletes.length };
}

function send(res: ServerResponse, status: number, payload: unknown) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(payload));
}

async function readBody(req: IncomingMessage): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const c of req) chunks.push(c as Buffer);
  return Buffer.concat(chunks).toString('utf8');
}

export function dataApi(): Plugin {
  return {
    name: 'command-centre-data-api',
    configureServer(server: ViteDevServer) {
      let timer: NodeJS.Timeout | undefined;
      const dataDir = path.join(ROOT, 'data') + path.sep;
      server.watcher.add(path.join(ROOT, 'data'));
      server.watcher.on('all', (_event, file) => {
        if (!file.startsWith(dataDir) || file.endsWith('.tmp')) return;
        clearTimeout(timer);
        timer = setTimeout(() => server.ws.send({ type: 'custom', event: 'data:changed' }), 150);
      });

      server.middlewares.use(async (req, res, next) => {
        if (!req.url?.startsWith('/api/')) return next();
        try {
          if (req.method === 'GET' && req.url.startsWith('/api/files')) {
            return send(res, 200, { files: await readAll(), readAt: new Date().toISOString() });
          }
          if (req.method === 'POST' && req.url.startsWith('/api/batch')) {
            const body = JSON.parse(await readBody(req)) as BatchBody;
            return send(res, 200, await applyBatch(body));
          }
          return send(res, 404, { error: 'Unknown endpoint' });
        } catch (err) {
          return send(res, 400, { error: (err as Error).message });
        }
      });
    },
  };
}
