import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { buildModel, type Model } from '../domain/model';

export interface FileWrite {
  path: string;
  content: string;
}

interface DataState {
  model: Model | null;
  loading: boolean;
  error: string | null;
  readAt: string | null;
  save: (writes: FileWrite[], deletes?: string[]) => Promise<void>;
  reload: () => Promise<void>;
  toast: (msg: string, tone?: 'ok' | 'error') => void;
}

const Ctx = createContext<DataState | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const [model, setModel] = useState<Model | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [readAt, setReadAt] = useState<string | null>(null);
  const [toasts, setToasts] = useState<{ id: number; msg: string; tone: 'ok' | 'error' }[]>([]);
  const seq = useRef(0);

  const toast = useCallback((msg: string, tone: 'ok' | 'error' = 'ok') => {
    const id = ++seq.current;
    setToasts((t) => [...t, { id, msg, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const reload = useCallback(async () => {
    try {
      const res = await fetch('/api/files');
      if (!res.ok) throw new Error(`Data API returned ${res.status}`);
      const body = (await res.json()) as { files: Record<string, string>; readAt: string };
      setModel(buildModel(body.files));
      setReadAt(body.readAt);
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  const save = useCallback(
    async (writes: FileWrite[], deletes: string[] = []) => {
      const res = await fetch('/api/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ writes, deletes }),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error ?? 'Save failed');
      await reload();
    },
    [reload],
  );

  useEffect(() => {
    reload();
    // Live refresh when files change on disk (VS Code edits, git pulls, other tabs).
    const hot = import.meta.hot;
    if (!hot) return;
    const onChange = () => reload();
    hot.on('data:changed', onChange);
    return () => hot.off?.('data:changed', onChange);
  }, [reload]);

  const value = useMemo(() => ({ model, loading, error, readAt, save, reload, toast }), [model, loading, error, readAt, save, reload, toast]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.tone}`}>
            {t.msg}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function useData() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useData outside DataProvider');
  return ctx;
}

/** Use inside pages that render only after the model has loaded. */
export function useModel(): Model {
  const { model } = useData();
  if (!model) throw new Error('Model not loaded');
  return model;
}
