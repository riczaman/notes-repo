import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Star, Sparkles, CalendarDays, Layers, Plus } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { STATUS, STATUS_ORDER } from '../../domain/meta';
import type { Initiative, InitiativeStatus } from '../../domain/schemas';
import { PageHead, AppChip, AiTag, tone, useReveal, Empty } from '../../components/ui';
import { InitiativeDrawer, InitiativeEditor } from './InitiativeDrawer';
import { todayIso } from '../../domain/model';

export function Workboard() {
  const m = useModel();
  const [params, setParams] = useSearchParams();
  const [q, setQ] = useState('');
  const [aiOnly, setAiOnly] = useState(false);
  const [focusOnly, setFocusOnly] = useState(false);
  const [hideDone, setHideDone] = useState(false);
  const [open, setOpen] = useState<Initiative | null>(null);
  const [creating, setCreating] = useState(false);
  const ws = params.get('ws');
  const app = params.get('app');
  const statusParam = params.get('status') as InitiativeStatus | null;

  const setParam = (k: string, v: string | null) => {
    const next = new URLSearchParams(params);
    if (v) next.set(k, v);
    else next.delete(k);
    setParams(next, { replace: true });
  };

  const items = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return m.initiatives.filter(
      (i) =>
        (!ws || i.workstream === ws) &&
        (!app || i.appIds.includes(app)) &&
        (!aiOnly || i.aiEnabled) &&
        (!focusOnly || i.leadershipFocus) &&
        (!needle || `${i.id} ${i.title} ${i.summary} ${i.appIds.join(' ')}`.toLowerCase().includes(needle)),
    );
  }, [m.initiatives, ws, app, aiOnly, focusOnly, q]);

  const columns = STATUS_ORDER.filter((s) => (!statusParam || s === statusParam) && !(hideDone && s === 'done'));
  const ref = useReveal<HTMLDivElement>([columns.length]);
  const apps = [...new Set(m.initiatives.flatMap((i) => i.appIds))].filter((id) => m.apps[id]?.profile.portfolio !== 'external');

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Portfolio"
        title="Workboard"
        sub={`${items.length} of ${m.initiatives.length} initiatives. Grouped by status so the items needing you sit on the left.`}
        actions={
          <button className="btn btn-primary" onClick={() => setCreating(true)}>
            <Plus size={15} /> New initiative
          </button>
        }
      />

      <div className="row-wrap reveal" style={{ marginBottom: 12, gap: 8 }}>
        <div className="search">
          <Search size={15} />
          <input className="input" placeholder="Search initiatives" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <select className="select" value={app ?? ''} onChange={(e) => setParam('app', e.target.value || null)} aria-label="Filter by application">
          <option value="">All applications</option>
          {apps.map((id) => (
            <option key={id} value={id}>
              {m.apps[id]?.profile.name ?? id}
            </option>
          ))}
        </select>
        <button className={`filter-chip ${focusOnly ? 'on' : ''}`} onClick={() => setFocusOnly((v) => !v)}>
          <Star size={13} /> Leadership focus
        </button>
        <button className={`filter-chip ${aiOnly ? 'on' : ''}`} onClick={() => setAiOnly((v) => !v)}>
          <Sparkles size={13} /> AI-enabled
        </button>
        <button className={`filter-chip ${hideDone ? 'on' : ''}`} onClick={() => setHideDone((v) => !v)}>
          Hide done
        </button>
        {statusParam && (
          <button className="filter-chip on" onClick={() => setParam('status', null)}>
            {STATUS[statusParam]?.label} ✕
          </button>
        )}
      </div>
      <div className="row-wrap reveal" style={{ marginBottom: 18 }}>
        <button className={`filter-chip ${!ws ? 'on' : ''}`} onClick={() => setParam('ws', null)}>
          All workstreams
        </button>
        {m.workstreams.map((w) => (
          <button key={w.id} className={`filter-chip ${ws === w.id ? 'on' : ''}`} onClick={() => setParam('ws', ws === w.id ? null : w.id)}>
            {w.name}
            <span className="mono faint">{m.initiatives.filter((i) => i.workstream === w.id).length}</span>
          </button>
        ))}
      </div>

      <div className="board">
        {columns.map((s) => {
          const list = items.filter((i) => i.status === s).sort((a, b) => Number(b.leadershipFocus) - Number(a.leadershipFocus) || a.priority.localeCompare(b.priority));
          return (
            <section key={s} className="col reveal" style={tone(STATUS[s].color)} aria-label={STATUS[s].label}>
              <div className="col-head">
                <span className="pill-dot" style={{ background: STATUS[s].color, width: 8, height: 8 }} />
                {STATUS[s].label}
                <span className="n">{list.length}</span>
              </div>
              <div className="col-bar" />
              {list.length === 0 && <div className="faint" style={{ fontSize: 12.5, padding: '6px 8px 10px' }}>Nothing here</div>}
              {list.map((i) => (
                <Card key={i.id} i={i} onOpen={() => setOpen(i)} />
              ))}
            </section>
          );
        })}
      </div>
      {items.length === 0 && <Empty title="No initiatives match these filters" />}
      {open && <InitiativeDrawer initiative={open} onClose={() => setOpen(null)} />}
      {creating && (
        <InitiativeEditor
          isNew
          initial={{ status: 'not-started', priority: 'P2', workstream: ws ?? m.workstreams[0]?.id, appIds: app ? [app] : [], target: { label: 'Not set' }, progress: [], nextSteps: [], dependencies: [], tags: [], updated: todayIso() }}
          onClose={() => setCreating(false)}
        />
      )}
    </div>
  );
}

function Card({ i, onOpen }: { i: Initiative; onOpen: () => void }) {
  const bundle = i.tags.find((t) => t.startsWith('bundle:'));
  return (
    <article className="icard" onClick={onOpen} tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && onOpen()}>
      <div className="icard-top">
        <span className="mono faint" style={{ fontSize: 10.5 }}>
          {i.id}
        </span>
        <span style={{ marginLeft: 'auto' }} className="row">
          {i.leadershipFocus && <Star size={13} className="star" fill="currentColor" />}
          <span className="chip" style={{ height: 19, fontSize: 10.5, padding: '0 6px' }}>
            {i.priority}
          </span>
        </span>
      </div>
      <div className="icard-title">{i.title}</div>
      <div className="icard-sum">{i.summary}</div>
      <div className="icard-target">
        <CalendarDays size={12} /> {i.target.label}
      </div>
      <div className="icard-foot">
        {i.appIds.map((a) => (
          <AppChip key={a} id={a} />
        ))}
        {i.aiEnabled && <AiTag />}
        {bundle && (
          <span className="chip" title="Bundled items">
            <Layers size={11} /> {bundle.slice(7)}
          </span>
        )}
      </div>
    </article>
  );
}
