import { Link } from 'react-router-dom';
import { useState } from 'react';
import { Star, Target, HelpCircle, ArrowRight, CheckCircle2, Circle, PencilLine } from 'lucide-react';
import { RecordEditor, useCollection, INITIATIVE_FIELDS } from '../../components/RecordEditor';
import { Initiative as InitiativeSchema, FILES } from '../../domain/schemas';
import { todayIso } from '../../domain/model';
import { Drawer, StatusPill, AppChip, AiTag, Pill, tone } from '../../components/ui';
import { useModel } from '../../store/DataProvider';
import { allRisks, fmtDate } from '../../domain/model';
import type { Initiative } from '../../domain/schemas';
import { noteTone } from '../../domain/meta';

export function InitiativeEditor({ initial, isNew, onClose }: { initial: Partial<Initiative>; isNew: boolean; onClose: () => void }) {
  const m = useModel();
  const col = useCollection(FILES.initiatives, m.initiatives);
  return (
    <RecordEditor
      title={isNew ? 'New initiative' : `${initial.id}: ${initial.title}`}
      fields={INITIATIVE_FIELDS(m.workstreams.map((w) => w.id))}
      initial={initial}
      isNew={isNew}
      schema={InitiativeSchema}
      onSave={(rec) => col.upsert({ ...rec, updated: todayIso() }, isNew ? undefined : initial.id)}
      onDelete={() => col.remove(initial.id!)}
      onClose={onClose}
    />
  );
}

export function InitiativeDrawer({ initiative: i, onClose }: { initiative: Initiative; onClose: () => void }) {
  const m = useModel();
  const [editing, setEditing] = useState(false);
  const live = m.initiatives.find((x) => x.id === i.id);
  if (!live) return null;
  if (editing) return <InitiativeEditor initial={live} isNew={false} onClose={() => setEditing(false)} />;
  i = live;
  const risks = allRisks(m).filter((r) => r.initiative === i.id);
  const ws = m.workstreams.find((w) => w.id === i.workstream);
  const bundle = i.tags.find((t) => t.startsWith('bundle:'));
  const conflict = i.tags.find((t) => t.startsWith('conflict:'));

  return (
    <Drawer
      onClose={onClose}
      head={
        <>
          <div className="row-wrap" style={{ marginBottom: 8 }}>
            <span className="chip chip-mono">{i.id}</span>
            <StatusPill status={i.status} />
            <span className="chip">{i.priority}</span>
            {i.leadershipFocus && (
              <Pill color="var(--st-amber)" dot={false}>
                <Star size={11} /> Leadership focus
              </Pill>
            )}
            {i.aiEnabled && <AiTag />}
            <button className="btn btn-sm" style={{ marginLeft: 'auto' }} onClick={() => setEditing(true)}>
              <PencilLine size={13} /> Edit
            </button>
          </div>
          <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 21, letterSpacing: '-0.02em', lineHeight: 1.25 }}>{i.title}</h2>
          <div className="muted" style={{ fontSize: 13, marginTop: 6 }}>
            {ws?.name} · updated {fmtDate(i.updated)}
          </div>
        </>
      }
    >
      <section>
        <p style={{ margin: 0, fontSize: 14.5, lineHeight: 1.6 }}>{i.summary}</p>
      </section>

      <section className="row-wrap" style={{ gap: 10 }}>
        <div className="callout" style={{ ...tone('var(--accent)'), flex: 1, minWidth: 220 }}>
          <Target size={16} />
          <div>
            <b>Target</b>
            <div className="muted">{i.target.label}</div>
          </div>
        </div>
        {i.phase && (
          <div className="callout" style={{ ...tone('var(--st-sky)'), flex: 1, minWidth: 180 }}>
            <ArrowRight size={16} />
            <div>
              <b>Phase</b>
              <div className="muted">{i.phase}</div>
            </div>
          </div>
        )}
      </section>

      {i.decision && (
        <div className="callout" style={tone('var(--st-amber)')}>
          <HelpCircle size={16} />
          <div>
            <b>Open decision</b>
            <div className="muted">{i.decision}</div>
          </div>
        </div>
      )}

      {i.problem && (
        <section>
          <h4>Problem</h4>
          <p className="muted" style={{ margin: 0, fontSize: 13.5, lineHeight: 1.6 }}>{i.problem}</p>
        </section>
      )}

      {i.progress.length > 0 && (
        <section>
          <h4>Progress{bundle ? ` · ${bundle.slice(7)}` : ''}</h4>
          <ul className="check-list">
            {i.progress.map((p, k) => (
              <li key={k}>
                <CheckCircle2 size={15} color="var(--st-teal)" />
                {p}
              </li>
            ))}
          </ul>
        </section>
      )}

      {i.nextSteps.length > 0 && (
        <section>
          <h4>Next steps</h4>
          <ul className="check-list">
            {i.nextSteps.map((p, k) => (
              <li key={k}>
                <Circle size={15} color="var(--text-3)" />
                {p}
              </li>
            ))}
          </ul>
        </section>
      )}

      {risks.length > 0 && (
        <section>
          <h4>Risks and issues from notes ({risks.length})</h4>
          <div className="stack" style={{ gap: 8 }}>
            {risks.map((r) => (
              <div key={r.appId + r.id} className="card card-pad" style={{ padding: '11px 14px', boxShadow: 'none' }}>
                <div className="row-wrap" style={{ marginBottom: 5 }}>
                  <span className="chip chip-mono">
                    {r.appId} {r.id}
                  </span>
                  {r.type && <Pill color={noteTone(r.type)?.color ?? 'var(--st-grey)'}>{r.type}</Pill>}
                  {r.impact && <Pill color={noteTone(r.impact)?.color ?? 'var(--st-grey)'}>Impact {r.impact}</Pill>}
                </div>
                <div style={{ fontSize: 13 }}>{r.description}</div>
                {r.mitigation && <div className="faint" style={{ fontSize: 12.5, marginTop: 5 }}>↳ {r.mitigation}</div>}
              </div>
            ))}
          </div>
        </section>
      )}

      {i.dependencies.length > 0 && (
        <section>
          <h4>Dependencies</h4>
          <div className="row-wrap">
            {i.dependencies.map((d, k) => (
              <span key={k} className="chip">
                {d}
              </span>
            ))}
          </div>
        </section>
      )}

      {conflict && (
        <div className="callout" style={tone('var(--st-orange)')}>
          <HelpCircle size={16} />
          <div>
            <b>Conflicting information</b>
            <div className="muted">{conflict.slice(9)}. Confirm and update the record.</div>
          </div>
        </div>
      )}

      <section>
        <h4>Applications</h4>
        <div className="stack" style={{ gap: 6 }}>
          {i.appIds.map((id) => (
            <Link key={id} to={`/apps/${id}`} className="row" style={{ fontSize: 13.5 }} onClick={onClose}>
              <AppChip id={id} /> <span>{m.apps[id]?.profile.name ?? id}</span>
              <ArrowRight size={14} className="faint" />
            </Link>
          ))}
        </div>
      </section>
    </Drawer>
  );
}
