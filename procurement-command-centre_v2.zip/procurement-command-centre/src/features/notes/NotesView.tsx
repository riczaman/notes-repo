import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Plus, PencilLine, Save, X, CalendarPlus, Link2, Trash2, Settings2 } from 'lucide-react';
import { useData, useModel } from '../../store/DataProvider';
import { SECTION_DEFS, insertTableRow, insertEntry, parseNotes, updateTableRow, updateEntry, updateMetaField, type NotesSection, type NotesMeta } from '../../domain/markdown';
import { FILES } from '../../domain/schemas';
import { todayIso } from '../../domain/model';
import { Empty, Md, NoteValue } from '../../components/ui';

const DEFAULT_HEADERS: Record<string, string[]> = {
  dates: ['Date', 'Milestone / deadline', 'Owner', 'Status', 'Notes'],
  actions: ['ID', 'Action', 'Owner', 'Due', 'Status', 'Source'],
  requests: ['Received', 'From', 'Request', 'Due', 'Status', 'Outcome'],
  risks: ['ID', 'Type', 'Initiative', 'Description', 'Impact', 'Likelihood', 'Owner', 'Mitigation / next step', 'Status'],
  decisions: ['Date', 'Decision', 'Status', 'Decided by', 'Why'],
  backlog: ['Item', 'Value', 'Depends on', 'Target'],
  contacts: ['Name', 'Role', 'Team / company', 'Email / Teams', 'Owns / go to for'],
  howto: ['Task', 'Steps', 'Where / link', 'Last used'],
};

const DATE_COLS = /^(date|due|received|last used)/i;
const ID_COLS = /^(id|initiative)$/i;
const WIDE_COLS = /(description|action|request|decision|mitigation|steps|why|notes|outcome|milestone|item|value|owns)/i;
const SELECT_OPTIONS: Record<string, string[]> = {
  status: ['Not started', 'In progress', 'At risk', 'Blocked', 'Pending', 'Open', 'Done', 'Decided', 'Not yet discussed'],
  impact: ['Critical', 'High', 'Medium', 'Low'],
  likelihood: ['High', 'Medium', 'Low'],
  type: ['Risk', 'Issue'],
};

export function NotesView({ id }: { id: string }) {
  const m = useModel();
  const { save, toast } = useData();
  const a = m.apps[id];
  const { hash } = useLocation();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');
  const [header, setHeader] = useState(false);

  useEffect(() => {
    if (!hash) return;
    const t = setTimeout(() => document.getElementById(`sec-${hash.slice(1)}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 250);
    return () => clearTimeout(t);
  }, [hash]);

  const raw = a.notesRaw ?? starterNotes(id, a.profile.name);
  const doc = a.notes ?? parseNotes(raw);

  const write = async (content: string, msg: string) => {
    try {
      await save([{ path: FILES.notes(id), content }]);
      toast(msg);
      return true;
    } catch (e) {
      toast((e as Error).message, 'error');
      return false;
    }
  };

  if (editing) {
    return (
      <div className="stack">
        <div className="row">
          <div className="muted grow" style={{ fontSize: 13 }}>
            Editing <span className="mono">data/apps/{id}/notes.md</span>. Keep the <span className="mono">## 01 … ## 09</span> headings and table headers so rollups keep working.
          </div>
          <button className="btn" onClick={() => setEditing(false)}>
            <X size={14} /> Cancel
          </button>
          <button
            className="btn btn-primary"
            onClick={async () => {
              const withDate = draft.replace(/^updated: .*$/m, `updated: ${todayIso()}`);
              if (await write(withDate, 'Notes saved')) setEditing(false);
            }}
          >
            <Save size={14} /> Save notes
          </button>
        </div>
        <div className="editor-split">
          <textarea className="textarea" value={draft} onChange={(e) => setDraft(e.target.value)} spellCheck={false} aria-label="Notes markdown" />
          <div className="card card-pad preview-pane">
            <Md>{draft.replace(/^---[\s\S]*?---\n/, '')}</Md>
          </div>
        </div>
      </div>
    );
  }

  const sections = SECTION_DEFS.map((def) => doc.sections.find((s) => s.key === def.key) ?? ({ key: def.key, num: def.num, title: def.title, hint: def.hint, table: null, prose: '', entries: [] } as NotesSection));
  const extra = doc.sections.filter((s) => s.key === 'other');

  return (
    <div className="notes-layout">
      <aside className="notes-toc">
        {sections.map((s) => (
          <button key={s.key} className="toc-link" onClick={() => document.getElementById(`sec-${s.key}`)?.scrollIntoView({ behavior: 'smooth' })}>
            <span className="toc-num">{s.num}</span>
            {s.title}
            <span className="toc-count">{(s.table?.rows.length ?? 0) + s.entries.length || ''}</span>
          </button>
        ))}
        <div className="divider" style={{ margin: '10px 0' }} />
        <button className="btn btn-sm" style={{ marginBottom: 6 }} onClick={() => setHeader(true)}>
          <Settings2 size={13} /> Edit page header
        </button>
        <button
          className="btn btn-sm"
          onClick={() => {
            setDraft(raw);
            setEditing(true);
          }}
        >
          <PencilLine size={13} /> Edit markdown
        </button>
        {doc.meta.links && doc.meta.links.length > 0 && (
          <div className="stack" style={{ gap: 4, marginTop: 12 }}>
            {doc.meta.links.map((l, k) =>
              l.url ? (
                <a key={k} href={l.url} target="_blank" rel="noreferrer" className="toc-link">
                  <Link2 size={13} /> {l.label}
                </a>
              ) : (
                <span key={k} className="toc-link faint" title="Add a url in the notes front matter">
                  <Link2 size={13} /> {l.label}
                </span>
              ),
            )}
          </div>
        )}
      </aside>

      <div className="stack" style={{ gap: 14 }}>
        {header && <HeaderEditor meta={doc.meta} onCancel={() => setHeader(false)} onSave={async (patch) => (await write(updateMetaField(raw, { ...patch, updated: todayIso() }), 'Page header saved')) && setHeader(false)} />}
        {sections.map((s) => (
          <Section key={s.key} s={s} raw={raw} onWrite={write} />
        ))}
        {extra.map((s) => (
          <div key={s.title} className="card note-sec reveal">
            <div className="note-sec-head">
              <span className="note-num">+</span>
              <h3 className="card-title">{s.title}</h3>
            </div>
            <div className="note-body">
              <Md>{s.prose}</Md>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Section({ s, raw, onWrite }: { s: NotesSection; raw: string; onWrite: (c: string, msg: string) => Promise<boolean> }) {
  const [adding, setAdding] = useState(false);
  const [editRow, setEditRow] = useState<number | null>(null);
  const [editEntry, setEditEntry] = useState<number | null>(null);
  const headers = s.table?.headers ?? DEFAULT_HEADERS[s.key] ?? [];
  const isMeetings = s.key === 'meetings';

  return (
    <section id={`sec-${s.key}`} className="card note-sec reveal">
      <div className="note-sec-head">
        <span className="note-num">{s.num}</span>
        <h3 className="card-title grow">{s.title}</h3>
        <button className="btn btn-sm btn-ghost" onClick={() => setAdding((v) => !v)}>
          {isMeetings ? <CalendarPlus size={14} /> : <Plus size={14} />} {isMeetings ? 'Add meeting note' : 'Add row'}
        </button>
      </div>
      {s.hint && <div className="note-hint">{s.hint}</div>}
      <div className="note-body">
        {adding && (isMeetings ? <AddEntry onCancel={() => setAdding(false)} onSubmit={async (h, b) => (await onWrite(insertEntry(raw, 'meetings', h, b), 'Meeting note added')) && setAdding(false)} /> : <AddRow headers={headers} onCancel={() => setAdding(false)} onSubmit={async (v) => (await onWrite(insertTableRow(raw, s.key, headers, v), `Added to ${s.title}`)) && setAdding(false)} />)}

        {s.table && s.table.rows.length > 0 ? (
          <div className="table-wrap" style={{ marginTop: adding ? 12 : 0 }}>
            <table className="table">
              <thead>
                <tr>
                  {s.table.headers.map((h) => (
                    <th key={h}>{h}</th>
                  ))}
                  <th style={{ width: 64 }} aria-label="Row actions" />
                </tr>
              </thead>
              <tbody>
                {s.table.rows.map((r, k) =>
                  editRow === k ? (
                    <tr key={k}>
                      <td colSpan={s.table!.headers.length + 1}>
                        <AddRow
                          headers={s.table!.headers}
                          initial={r}
                          submitLabel="Save row"
                          onCancel={() => setEditRow(null)}
                          onSubmit={async (v) => (await onWrite(updateTableRow(raw, s.key, k, v), 'Row updated')) && setEditRow(null)}
                        />
                      </td>
                    </tr>
                  ) : (
                    <tr key={k} className="row-hover">
                      {s.table!.headers.map((h) => (
                        <td key={h} className={DATE_COLS.test(h) ? 'date' : ID_COLS.test(h) ? 'mono nowrap' : ''} style={WIDE_COLS.test(h) ? { minWidth: 220 } : undefined}>
                          <NoteValue value={r[h]} column={h} />
                        </td>
                      ))}
                      <td className="row-actions">
                        <button className="btn btn-ghost icon-btn btn-sm" title="Edit row" aria-label="Edit row" onClick={() => setEditRow(k)}>
                          <PencilLine size={13} />
                        </button>
                        <button
                          className="btn btn-ghost icon-btn btn-sm"
                          title="Delete row"
                          aria-label="Delete row"
                          onClick={async () => {
                            if (window.confirm('Delete this row from the notes file?')) await onWrite(updateTableRow(raw, s.key, k, null), 'Row deleted');
                          }}
                        >
                          <Trash2 size={13} />
                        </button>
                      </td>
                    </tr>
                  ),
                )}
              </tbody>
            </table>
          </div>
        ) : !isMeetings && !adding ? (
          <div className="table-empty">Nothing recorded yet.</div>
        ) : null}

        {s.entries.length > 0 && (
          <div style={{ marginTop: 6 }}>
            {s.entries.map((e, k) => (
              <div key={k} className="entry row-hover">
                <span className="entry-dot" />
                {editEntry === k ? (
                  <AddEntry
                    initial={e}
                    submitLabel="Save note"
                    onCancel={() => setEditEntry(null)}
                    onSubmit={async (h, b) => (await onWrite(updateEntry(raw, s.key, k, { heading: h, body: b }), 'Note updated')) && setEditEntry(null)}
                  />
                ) : (
                  <div>
                    <div className="row">
                      <div className="entry-head grow">{e.heading}</div>
                      <span className="row-actions">
                        <button className="btn btn-ghost icon-btn btn-sm" title="Edit note" aria-label="Edit note" onClick={() => setEditEntry(k)}>
                          <PencilLine size={13} />
                        </button>
                        <button
                          className="btn btn-ghost icon-btn btn-sm"
                          title="Delete note"
                          aria-label="Delete note"
                          onClick={async () => {
                            if (window.confirm(`Delete "${e.heading}"?`)) await onWrite(updateEntry(raw, s.key, k, null), 'Note deleted');
                          }}
                        >
                          <Trash2 size={13} />
                        </button>
                      </span>
                    </div>
                    <Md>{e.body}</Md>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
        {!s.entries.length && s.prose && !isMeetings && <Md>{s.prose}</Md>}
        {isMeetings && !s.entries.length && !adding && <Empty title="No meeting notes yet" />}
      </div>
    </section>
  );
}

function AddRow({ headers, onSubmit, onCancel, initial, submitLabel = 'Add to top' }: { headers: string[]; onSubmit: (v: Record<string, string>) => void; onCancel: () => void; initial?: Record<string, string>; submitLabel?: string }) {
  const [v, setV] = useState<Record<string, string>>(() => {
    if (initial) return { ...initial };
    const init: Record<string, string> = {};
    for (const h of headers) {
      if (/^(date|received)$/i.test(h)) init[h] = todayIso();
      if (/^owner$/i.test(h)) init[h] = 'Me';
      if (/^status$/i.test(h)) init[h] = 'Open';
    }
    return init;
  });
  const opts = (h: string) => SELECT_OPTIONS[Object.keys(SELECT_OPTIONS).find((k) => h.toLowerCase().startsWith(k)) ?? ''];
  return (
    <form
      className="add-row"
      onSubmit={(e) => {
        e.preventDefault();
        if (Object.values(v).some((x) => x.trim())) onSubmit(v);
      }}
    >
      <div className="add-grid">
        {headers.map((h) => {
          const o = opts(h);
          return (
            <label key={h} style={WIDE_COLS.test(h) ? { gridColumn: 'span 2' } : undefined}>
              <span className="field-label">{h}</span>
              {o ? (
                <select className="select" style={{ width: '100%' }} value={v[h] ?? ''} onChange={(e) => setV({ ...v, [h]: e.target.value })}>
                  <option value="" />
                  {[...o, ...(v[h] && !o.includes(v[h]) ? [v[h]] : [])].map((x) => (
                    <option key={x}>{x}</option>
                  ))}
                </select>
              ) : (
                <input
                  className="input"
                  style={{ width: '100%' }}
                  type={DATE_COLS.test(h) ? 'date' : 'text'}
                  value={v[h] ?? ''}
                  onChange={(e) => setV({ ...v, [h]: e.target.value })}
                />
              )}
            </label>
          );
        })}
      </div>
      <div className="row" style={{ justifyContent: 'flex-end' }}>
        <button type="button" className="btn btn-sm" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn btn-sm btn-primary">
          {initial ? <Save size={13} /> : <Plus size={13} />} {submitLabel}
        </button>
      </div>
    </form>
  );
}

function AddEntry({ onSubmit, onCancel, initial, submitLabel = 'Add note' }: { onSubmit: (heading: string, body: string) => void; onCancel: () => void; initial?: { heading: string; body: string }; submitLabel?: string }) {
  const parts = initial?.heading.match(/^(\d{4}-\d{2}-\d{2})\s*·\s*(.*)$/);
  const [date, setDate] = useState(parts?.[1] ?? todayIso());
  const [title, setTitle] = useState(parts?.[2] ?? initial?.heading ?? '');
  const [body, setBody] = useState(initial?.body ?? '- ');
  return (
    <form
      className="add-row"
      style={{ flex: 1 }}
      onSubmit={(e) => {
        e.preventDefault();
        if (title.trim() || body.trim().length > 2) onSubmit(`${date} · ${title.trim() || 'Notes'}`, body);
      }}
    >
      <div className="add-grid">
        <label>
          <span className="field-label">Date</span>
          <input className="input" type="date" style={{ width: '100%' }} value={date} onChange={(e) => setDate(e.target.value)} />
        </label>
        <label style={{ gridColumn: 'span 3' }}>
          <span className="field-label">Meeting</span>
          <input className="input" style={{ width: '100%' }} placeholder="Weekly sync with EMS team" value={title} onChange={(e) => setTitle(e.target.value)} />
        </label>
      </div>
      <label>
        <span className="field-label">Key points (Markdown bullets)</span>
        <textarea className="textarea" rows={6} style={{ width: '100%' }} value={body} onChange={(e) => setBody(e.target.value)} />
      </label>
      <div className="row" style={{ justifyContent: 'flex-end' }}>
        <button type="button" className="btn btn-sm" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn btn-sm btn-primary">
          {initial ? <Save size={13} /> : <Plus size={13} />} {submitLabel}
        </button>
      </div>
    </form>
  );
}

export function starterNotes(id: string, name: string): string {
  const body = SECTION_DEFS.map((d) => {
    const h = DEFAULT_HEADERS[d.key];
    const table = h ? `\n| ${h.join(' | ')} |\n|${h.map(() => '---').join('|')}|\n` : '';
    return `## ${d.num} ${d.title}\n\n> ${d.hint}\n${table}`;
  }).join('\n');
  return `---\napp: ${id}\ntitle: ${name}\nupdated: ${todayIso()}\n---\n\n${body}`;
}

function HeaderEditor({ meta, onSave, onCancel }: { meta: NotesMeta; onSave: (p: Partial<NotesMeta>) => void; onCancel: () => void }) {
  const [f, setF] = useState({
    title: meta.title ?? '',
    tagline: meta.tagline ?? '',
    status: meta.status ?? '',
    phase: meta.phase ?? '',
    sponsor: meta.sponsor ?? '',
    role: meta.role ?? '',
    nextMilestone: meta.nextMilestone ?? '',
    goLive: meta.goLive ?? '',
    thisWeek: (meta.thisWeek ?? []).join('\n'),
    links: (meta.links ?? []).map((l) => (l.url ? `${l.label} | ${l.url}` : l.label)).join('\n'),
  });
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const input = (k: keyof typeof f, label: string, span = 1) => (
    <label style={span > 1 ? { gridColumn: `span ${span}` } : undefined}>
      <span className="field-label">{label}</span>
      <input className="input" style={{ width: '100%' }} value={f[k]} onChange={set(k)} />
    </label>
  );
  return (
    <form
      className="card card-pad stack"
      onSubmit={(e) => {
        e.preventDefault();
        onSave({
          title: f.title || undefined,
          tagline: f.tagline || undefined,
          status: f.status || undefined,
          phase: f.phase || undefined,
          sponsor: f.sponsor || undefined,
          role: f.role || undefined,
          nextMilestone: f.nextMilestone || undefined,
          goLive: f.goLive || undefined,
          thisWeek: f.thisWeek.split('\n').map((x) => x.trim()).filter(Boolean),
          links: f.links
            .split('\n')
            .map((x) => x.trim())
            .filter(Boolean)
            .map((l) => {
              const [label, url] = l.split('|').map((x) => x.trim());
              return url ? { label, url } : { label };
            }),
        });
      }}
    >
      <h3 className="card-title">Page header</h3>
      <div className="add-grid">
        {input('title', 'Title', 2)}
        {input('tagline', 'One-line description', 2)}
        <label>
          <span className="field-label">Overall status</span>
          <select className="select" style={{ width: '100%' }} value={f.status} onChange={set('status')}>
            {['', 'On track', 'In progress', 'At risk', 'Blocked', 'Not started', 'Done', ...(f.status && !['On track', 'In progress', 'At risk', 'Blocked', 'Not started', 'Done'].includes(f.status) ? [f.status] : [])].map((o) => (
              <option key={o}>{o}</option>
            ))}
          </select>
        </label>
        {input('phase', 'Phase')}
        {input('sponsor', 'Sponsor')}
        {input('role', 'My role')}
        {input('nextMilestone', 'Next milestone', 2)}
        {input('goLive', 'Target go-live')}
      </div>
      <label>
        <span className="field-label">This week (one per line, top 3 show)</span>
        <textarea className="textarea" rows={3} style={{ width: '100%', fontFamily: 'var(--font-ui)' }} value={f.thisWeek} onChange={set('thisWeek')} />
      </label>
      <label>
        <span className="field-label">Links (Label | URL, one per line)</span>
        <textarea className="textarea" rows={3} style={{ width: '100%' }} value={f.links} onChange={set('links')} />
      </label>
      <div className="row" style={{ justifyContent: 'flex-end' }}>
        <button type="button" className="btn btn-sm" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn btn-sm btn-primary">
          <Save size={13} /> Save header
        </button>
      </div>
    </form>
  );
}
