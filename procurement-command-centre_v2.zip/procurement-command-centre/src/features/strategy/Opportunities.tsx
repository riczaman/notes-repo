import { useState } from 'react';
import { Plus, LayoutGrid, CalendarRange } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { Opportunity, FILES } from '../../domain/schemas';
import { PageHead, AppChip, Pill, tone, useReveal, Empty } from '../../components/ui';
import { RecordEditor, useCollection, nextId, type FieldSpec } from '../../components/RecordEditor';

export const OPP_CATEGORY: Record<string, string> = {
  consolidation: 'Application consolidation',
  rationalisation: 'Functional rationalisation',
  automation: 'Process automation',
  integration: 'Integration modernisation',
  data: 'Data standardisation',
  reporting: 'Improved reporting',
  ai: 'AI and generative AI',
  'user-experience': 'User experience',
  complexity: 'Reduced complexity',
  governance: 'Governance',
};
const PRIORITY: Record<string, string> = { high: 'var(--st-orange)', medium: 'var(--st-amber)', low: 'var(--st-sage)' };
const STATUS: Record<string, string> = { idea: 'var(--st-grey)', assessing: 'var(--st-sky)', planned: 'var(--st-teal)', 'in-progress': 'var(--st-teal)', done: 'var(--st-green)', parked: 'var(--st-grey)' };

export function Opportunities() {
  const m = useModel();
  const col = useCollection(FILES.opportunities, m.opportunities);
  const [edit, setEdit] = useState<{ rec: Partial<Opportunity>; isNew: boolean } | null>(null);
  const [view, setView] = useState<'roadmap' | 'cards'>('roadmap');
  const [cat, setCat] = useState<string | null>(null);
  const ref = useReveal<HTMLDivElement>([view]);
  const list = m.opportunities.filter((o) => !cat || o.category === cat);
  const quarters = [...new Set(list.map((o) => o.quarter).filter((q): q is string => Boolean(q)))].sort();
  const linkTargets = [...m.overlaps.map((o) => o.id), ...m.gaps.map((g) => g.id), ...m.initiatives.map((i) => i.id)];

  const fields: FieldSpec[] = [
    { key: 'id', label: 'Opportunity ID', readOnlyOnEdit: true },
    { key: 'category', label: 'Category', type: 'select', options: Object.keys(OPP_CATEGORY) },
    { key: 'title', label: 'Title', wide: true },
    { key: 'priority', label: 'Priority', type: 'select', options: ['high', 'medium', 'low'] },
    { key: 'complexity', label: 'Complexity', type: 'select', options: ['low', 'medium', 'high'] },
    { key: 'status', label: 'Status', type: 'select', options: ['idea', 'assessing', 'planned', 'in-progress', 'done', 'parked'] },
    { key: 'quarter', label: 'Target quarter', hint: 'e.g. F27 Q1. Use one convention so the roadmap sorts. Blank = unscheduled' },
    { key: 'effort', label: 'Estimated effort', hint: 'Only if known' },
    { key: 'appIds', label: 'Related applications', type: 'apps' },
    { key: 'problem', label: 'Business problem', type: 'textarea' },
    { key: 'improvement', label: 'Proposed improvement', type: 'textarea' },
    { key: 'benefit', label: 'Expected benefit', type: 'textarea', hint: 'Qualitative. Do not add savings figures you cannot evidence' },
    { key: 'dependencies', label: 'Dependencies', type: 'lines' },
    { key: 'links', label: 'Linked overlaps, gaps, initiatives', type: 'lines', hint: `IDs such as ${linkTargets.slice(0, 3).join(', ')}` },
    { key: 'evidence', label: 'Supporting evidence', type: 'evidence' },
  ];

  const Card = ({ o }: { o: Opportunity }) => (
    <article className="card card-pad card-link reveal" onClick={() => setEdit({ isNew: false, rec: o })} style={{ borderLeft: `3px solid ${PRIORITY[o.priority]}` }}>
      <div className="row-wrap" style={{ marginBottom: 6 }}>
        <span className="chip chip-mono">{o.id}</span>
        <Pill color={STATUS[o.status]}>{o.status}</Pill>
        <span className="chip">{OPP_CATEGORY[o.category]}</span>
      </div>
      <div style={{ fontWeight: 600, fontSize: 14, lineHeight: 1.35 }}>{o.title}</div>
      {o.improvement && <div className="muted" style={{ fontSize: 12.5, marginTop: 5 }}>{o.improvement}</div>}
      <div className="row-wrap" style={{ marginTop: 8 }}>
        {o.appIds.map((a) => (
          <AppChip key={a} id={a} />
        ))}
        {o.links.map((l, k) => (
          <span key={k} className="chip chip-mono" style={tone(linkTargets.includes(l) ? 'var(--st-sky)' : 'var(--st-red)')} title={linkTargets.includes(l) ? undefined : 'Unknown ID'}>
            {l}
          </span>
        ))}
      </div>
      <div className="faint" style={{ fontSize: 11.5, marginTop: 8 }}>
        {o.priority} priority · {o.complexity} complexity{o.effort ? ` · ${o.effort}` : ''}
      </div>
    </article>
  );

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Strategy"
        title="Opportunities and roadmap"
        sub="Ways to simplify, consolidate, automate and modernise, linked to the overlaps, gaps and initiatives that justify them."
        actions={
          <button className="btn btn-primary" onClick={() => setEdit({ isNew: true, rec: { id: nextId('OPP', m.opportunities), category: 'automation', priority: 'medium', complexity: 'medium', status: 'idea', appIds: [], dependencies: [], links: [], evidence: [] } })}>
            <Plus size={15} /> Add opportunity
          </button>
        }
      />
      {edit && (
        <RecordEditor
          title={edit.isNew ? 'New opportunity' : `${edit.rec.id}: ${edit.rec.title}`}
          fields={fields}
          initial={edit.rec}
          isNew={edit.isNew}
          schema={Opportunity}
          onSave={(rec) => col.upsert(rec, edit.isNew ? undefined : edit.rec.id)}
          onDelete={() => col.remove(edit.rec.id!)}
          onClose={() => setEdit(null)}
        />
      )}

      <div className="row-wrap reveal" style={{ marginBottom: 16 }}>
        <button className={`filter-chip ${view === 'roadmap' ? 'on' : ''}`} onClick={() => setView('roadmap')}>
          <CalendarRange size={13} /> Roadmap
        </button>
        <button className={`filter-chip ${view === 'cards' ? 'on' : ''}`} onClick={() => setView('cards')}>
          <LayoutGrid size={13} /> All cards
        </button>
        <span style={{ width: 12 }} />
        <button className={`filter-chip ${!cat ? 'on' : ''}`} onClick={() => setCat(null)}>
          All categories
        </button>
        {Object.entries(OPP_CATEGORY)
          .filter(([k]) => m.opportunities.some((o) => o.category === k))
          .map(([k, l]) => (
            <button key={k} className={`filter-chip ${cat === k ? 'on' : ''}`} onClick={() => setCat(cat === k ? null : k)}>
              {l}
            </button>
          ))}
      </div>

      {list.length === 0 ? (
        <Empty title="No opportunities yet" />
      ) : view === 'cards' ? (
        <div className="grid g-3">
          {list.map((o) => (
            <Card key={o.id} o={o} />
          ))}
        </div>
      ) : (
        <div className="board">
          {[...quarters, ''].map((q) => {
            const items = list.filter((o) => (o.quarter ?? '') === q);
            if (!items.length) return null;
            return (
              <section key={q || 'none'} className="col" style={tone(q ? 'var(--accent)' : 'var(--st-grey)')}>
                <div className="col-head">
                  {q || 'Not yet scheduled'}
                  <span className="n">{items.length}</span>
                </div>
                <div className="col-bar" />
                <div className="stack" style={{ gap: 9 }}>
                  {items.map((o) => (
                    <Card key={o.id} o={o} />
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
}
