import type { Model } from '../../domain/model';
import type { GNode, GEdge } from '../../components/FlowGraph';
import { INTEGRATION_STATUS } from '../../domain/meta';

/**
 * Builds the current-state and future-state graphs.
 * Current: integrations that exist today (live, degraded, manual, in delivery).
 * Future: current minus proposed retirements, plus planned integrations and proposed additions.
 * Everything added or changed in the future view is a proposal unless its change record is approved.
 */
const CURRENT = new Set(['live', 'degraded', 'manual', 'in-delivery', 'retiring']);

export function currentGraph(m: Model): { nodes: GNode[]; edges: GEdge[] } {
  const ints = m.integrations.filter((i) => CURRENT.has(i.status));
  const ids = [...new Set(ints.flatMap((i) => [i.source, i.target]))];
  return {
    nodes: ids.map((id) => node(m, id, 'normal')),
    edges: ints.map((i) => ({ id: i.id, source: i.source, target: i.target, color: INTEGRATION_STATUS[i.status].color, animated: i.status === 'live' })),
  };
}

function node(m: Model, id: string, variant: GNode['variant'], badge?: string): GNode {
  const p = m.apps[id]?.profile;
  return { id, label: p?.name ?? id, sub: id, category: p?.category, variant: p?.portfolio === 'external' && variant === 'normal' ? 'external' : variant, badge };
}

export function futureGraph(m: Model): { nodes: GNode[]; edges: GEdge[] } {
  const active = m.futureState.filter((c) => c.status !== 'rejected');
  const retiredApps = new Set(active.filter((c) => c.kind === 'retire-app' && c.appId).map((c) => c.appId!));
  const modified = new Set(active.filter((c) => ['modify-app', 'ai-capability', 'automation', 'add-capability', 'data-improvement'].includes(c.kind) && c.appId).map((c) => c.appId!));
  const retiredInts = new Set(active.filter((c) => c.kind === 'retire-integration' && c.integrationId).map((c) => c.integrationId!));
  const newApps = active.filter((c) => c.kind === 'add-app');
  const newAppId = (c: (typeof newApps)[number]) => `NEW-${c.id}`;

  const edges: GEdge[] = [];
  for (const i of m.integrations) {
    if (!CURRENT.has(i.status) && i.status !== 'planned') continue;
    const retiring = retiredInts.has(i.id) || retiredApps.has(i.source) || retiredApps.has(i.target);
    edges.push({
      id: i.id,
      source: i.source,
      target: i.target,
      color: retiring ? 'var(--st-red)' : i.status === 'planned' ? 'var(--st-green)' : INTEGRATION_STATUS[i.status].color,
      dashed: retiring || i.status === 'planned',
      faded: retiring,
      label: retiring ? 'retire' : i.status === 'planned' ? 'proposed' : undefined,
    });
  }
  const resolve = (ref?: string) => {
    if (!ref) return undefined;
    if (m.apps[ref]) return ref;
    const n = newApps.find((c) => c.newAppName === ref || c.id === ref);
    return n ? newAppId(n) : undefined;
  };
  for (const c of active.filter((x) => x.kind === 'add-integration')) {
    const s = resolve(c.source);
    const t = resolve(c.target);
    if (s && t) edges.push({ id: c.id, source: s, target: t, color: 'var(--st-green)', dashed: true, label: 'proposed' });
  }
  const ids = new Set(edges.flatMap((e) => [e.source, e.target]));
  for (const id of [...retiredApps, ...modified]) if (m.apps[id]) ids.add(id);
  const nodes: GNode[] = [...ids].map((id) => {
    const n = newApps.find((c) => newAppId(c) === id);
    if (n) return { id, label: n.newAppName ?? n.title, sub: 'proposed', category: 'saas', variant: 'proposed', badge: 'New' };
    if (retiredApps.has(id)) return node(m, id, 'retiring', 'Retire');
    if (modified.has(id)) return node(m, id, 'modified', 'Changes');
    return node(m, id, 'normal');
  });
  return { nodes, edges };
}
