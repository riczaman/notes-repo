import { useMemo, useState } from 'react';
import { Plus, AlertTriangle, Columns2, Square } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { FutureChange, FILES } from '../../domain/schemas';
import { PageHead, AppChip, Pill, tone, useReveal, Empty } from '../../components/ui';
import { RecordEditor, useCollection, nextId, type FieldSpec } from '../../components/RecordEditor';
import { FlowGraph } from '../../components/FlowGraph';
import { currentGraph, futureGraph } from './futureModel';

export const CHANGE_KIND: Record<string, { label: string; color: string }> = {
  'add-app': { label: 'New application', color: 'var(--st-green)' },
  'retire-app': { label: 'Retire application', color: 'var(--st-red)' },
  'modify-app': { label: 'Modify application', color: 'var(--st-amber)' },
  'add-integration': { label: 'New integration', color: 'var(--st-green)' },
  'retire-integration': { label: 'Retire integration', color: 'var(--st-red)' },
  'add-capability': { label: 'New capability', color: 'var(--st-teal)' },
  automation: { label: 'Automation', color: 'var(--st-sky)' },
  'ai-capability': { label: 'AI capability', color: 'var(--st-teal)' },
  'data-improvement': { label: 'Data improvement', color: 'var(--st-sky)' },
};
const STATUS_COLOR: Record<string, string> = { proposed: 'var(--st-amber)', 'under-review': 'var(--st-sky)', approved: 'var(--st-green)', rejected: 'var(--st-grey)' };

export function FutureState() {
  const m = useModel();
  const col = useCollection(FILES.futureState, m.futureState);
  const [edit, setEdit] = useState<{ rec: Partial<FutureChange>; isNew: boolean } | null>(null);
  const [layout, setLayout] = useState<'side' | 'future' | 'current'>('future');
  const ref = useReveal<HTMLDivElement>();
  const cur = useMemo(() => currentGraph(m), [m]);
  const fut = useMemo(() => futureGraph(m), [m]);
  const approved = m.futureState.filter((c) => c.status === 'approved').length;

  const fields: FieldSpec[] = [
    { key: 'id', label: 'Change ID', readOnlyOnEdit: true },
    { key: 'kind', label: 'Type of change', type: 'select', options: Object.keys(CHANGE_KIND) },
    { key: 'title', label: 'Title', wide: true },
    { key: 'status', label: 'Status', type: 'select', options: ['proposed', 'under-review', 'approved', 'rejected'], hint: 'Approved only when a decision is documented' },
    { key: 'appId', label: 'Application affected', type: 'app' },
    { key: 'newAppName', label: 'New application name', hint: 'Only for "add-app"' },
    { key: 'integrationId', label: 'Integration to retire', type: 'select', options: m.integrations.map((i) => i.id) },
    { key: 'source', label: 'New integration from', hint: 'App ID, or the name of a proposed new app' },
    { key: 'target', label: 'New integration to', hint: 'App ID, or the name of a proposed new app' },
    { key: 'description', label: 'Description', type: 'textarea' },
    { key: 'rationale', label: 'Rationale', type: 'textarea' },
    { key: 'outcome', label: 'Expected business outcome', type: 'textarea', hint: 'Qualitative. No invented savings' },
    { key: 'evidence', label: 'Evidence', type: 'evidence' },
  ];

  const Legend = () => (
    <div className="row-wrap faint" style={{ fontSize: 12, gap: 14 }}>
      {[
        ['Existing', 'var(--border-strong)'],
        ['Proposed', 'var(--st-green)'],
        ['Modified', 'var(--st-amber)'],
        ['Proposed retirement', 'var(--st-red)'],
      ].map(([l, c]) => (
        <span key={l} className="row" style={{ gap: 6 }}>
          <span className="legend-swatch" style={tone(c)} /> {l}
        </span>
      ))}
    </div>
  );

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Strategy"
        title="Current vs future state"
        sub="Today's documented architecture next to the proposed target. Every future-state element is a proposal until its change record is marked approved."
        actions={
          <button className="btn btn-primary" onClick={() => setEdit({ isNew: true, rec: { id: nextId('FUT', m.futureState), status: 'proposed', kind: 'modify-app', evidence: [] } })}>
            <Plus size={15} /> Propose change
          </button>
        }
      />
      {edit && (
        <RecordEditor
          title={edit.isNew ? 'New future-state change' : `${edit.rec.id}: ${edit.rec.title}`}
          fields={fields}
          initial={edit.rec}
          isNew={edit.isNew}
          schema={FutureChange}
          onSave={(rec) => col.upsert(rec, edit.isNew ? undefined : edit.rec.id)}
          onDelete={() => col.remove(edit.rec.id!)}
          onClose={() => setEdit(null)}
        />
      )}

      <div className="callout reveal" style={{ ...tone('var(--st-amber)'), marginBottom: 14 }}>
        <AlertTriangle size={16} />
        <div>
          <b>Proposals, not decisions.</b> <span className="muted">{m.futureState.length - approved} of {m.futureState.length} changes are still proposed or under review.</span>
        </div>
      </div>

      <div className="row-wrap reveal" style={{ marginBottom: 12 }}>
        <button className={`filter-chip ${layout === 'future' ? 'on' : ''}`} onClick={() => setLayout('future')}>
          <Square size={13} /> Future state
        </button>
        <button className={`filter-chip ${layout === 'current' ? 'on' : ''}`} onClick={() => setLayout('current')}>
          <Square size={13} /> Current state
        </button>
        <button className={`filter-chip ${layout === 'side' ? 'on' : ''}`} onClick={() => setLayout('side')}>
          <Columns2 size={13} /> Side by side
        </button>
        <span className="grow" />
        <Legend />
      </div>

      <div className={`grid ${layout === 'side' ? 'g-2' : ''} reveal`}>
        {(layout === 'side' || layout === 'current') && (
          <div className="card">
            <div className="card-head">
              <h3 className="card-title">Current state</h3>
              <span className="card-sub">{cur.edges.length} integrations in use</span>
            </div>
            <div className="card-body">
              <FlowGraph nodes={cur.nodes} edges={cur.edges} height={layout === 'side' ? 440 : 520} />
            </div>
          </div>
        )}
        {(layout === 'side' || layout === 'future') && (
          <div className="card">
            <div className="card-head">
              <h3 className="card-title">Proposed future state</h3>
              <span className="card-sub">{m.futureState.length} changes</span>
            </div>
            <div className="card-body">
              <FlowGraph nodes={fut.nodes} edges={fut.edges} height={layout === 'side' ? 440 : 520} />
            </div>
          </div>
        )}
      </div>

      <h3 className="card-title reveal" style={{ margin: '22px 0 12px' }}>
        Change register
      </h3>
      {m.futureState.length === 0 ? (
        <Empty title="No proposed changes yet" />
      ) : (
        <div className="grid g-3">
          {m.futureState.map((c) => (
            <article key={c.id} className="card card-pad card-link reveal" onClick={() => setEdit({ isNew: false, rec: c })}>
              <div className="row-wrap" style={{ marginBottom: 8 }}>
                <span className="chip chip-mono">{c.id}</span>
                <Pill color={CHANGE_KIND[c.kind].color}>{CHANGE_KIND[c.kind].label}</Pill>
                <Pill color={STATUS_COLOR[c.status]}>{c.status}</Pill>
              </div>
              <div className="app-name" style={{ fontSize: 15 }}>
                {c.title}
              </div>
              {c.description && <div className="muted" style={{ fontSize: 13, marginTop: 6 }}>{c.description}</div>}
              {c.outcome && <div style={{ fontSize: 12.5, marginTop: 8 }}>Outcome: {c.outcome}</div>}
              <div className="row-wrap" style={{ marginTop: 10 }}>
                {[c.appId, c.source, c.target].filter((x): x is string => Boolean(x && m.apps[x])).map((a, k) => (
                  <AppChip key={k} id={a} />
                ))}
                {c.integrationId && <span className="chip chip-mono">{c.integrationId}</span>}
                {c.newAppName && <span className="chip">{c.newAppName}</span>}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
