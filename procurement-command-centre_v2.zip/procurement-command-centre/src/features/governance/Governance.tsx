import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, ShieldCheck, Sparkles } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { GovernanceItem, FILES } from '../../domain/schemas';
import { fmtDate, parseLooseDate, today } from '../../domain/model';
import { PageHead, AppChip, Pill, tone, useReveal, AppTile, Empty } from '../../components/ui';
import { RecordEditor, useCollection, nextId, type FieldSpec } from '../../components/RecordEditor';

const STATUS: Record<string, { label: string; color: string }> = {
  'not-started': { label: 'Not started', color: 'var(--st-grey)' },
  'in-progress': { label: 'In progress', color: 'var(--st-sky)' },
  ongoing: { label: 'Ongoing', color: 'var(--st-teal)' },
  blocked: { label: 'Blocked', color: 'var(--st-red)' },
  'needs-info': { label: 'Needs info', color: 'var(--st-amber)' },
  done: { label: 'Done', color: 'var(--st-green)' },
};
const TYPES = ['testing', 'artifact', 'approval', 'monitoring', 'finding', 'onboarding', 'security'];

export function Governance() {
  const m = useModel();
  const col = useCollection(FILES.governance, m.governance);
  const [edit, setEdit] = useState<{ rec: Partial<GovernanceItem>; isNew: boolean } | null>(null);
  const [type, setType] = useState<string | null>(null);
  const [hideDone, setHideDone] = useState(true);
  const ref = useReveal<HTMLDivElement>();

  const aiApps = m.appList.filter((a) => a.profile.category === 'ai-model' || m.initiatives.some((i) => i.aiEnabled && i.appIds[0] === a.id) || m.governance.some((g) => g.appId === a.id));
  const items = m.governance.filter((g) => (!type || g.type === type) && (!hideDone || g.status !== 'done'));
  const soon = new Date(today());
  soon.setDate(soon.getDate() + 30);
  const dueSoon = m.governance.filter((g) => {
    const d = g.due ? parseLooseDate(g.due) : null;
    return d && g.status !== 'done' && d.when <= soon;
  });

  const fields: FieldSpec[] = [
    { key: 'id', label: 'Item ID', readOnlyOnEdit: true },
    { key: 'appId', label: 'Application or model', type: 'app' },
    { key: 'item', label: 'Obligation', wide: true },
    { key: 'type', label: 'Type', type: 'select', options: TYPES },
    { key: 'status', label: 'Status', type: 'select', options: Object.keys(STATUS) },
    { key: 'cadence', label: 'Cadence', hint: 'Quarterly, Annual, One-off…' },
    { key: 'due', label: 'Due', hint: 'YYYY-MM-DD or YYYY-MM' },
    { key: 'owner', label: 'Owner' },
    { key: 'notes', label: 'Notes', type: 'textarea' },
  ];

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Governance"
        title="Model governance"
        sub="Model risk obligations for every AI model and AI-enabled initiative: testing cadence, MRM artifacts, approvals, monitoring and findings."
        actions={
          <button className="btn btn-primary" onClick={() => setEdit({ isNew: true, rec: { id: nextId('GOV', m.governance), type: 'testing', status: 'not-started' } })}>
            <Plus size={15} /> Add obligation
          </button>
        }
      />
      {edit && (
        <RecordEditor
          title={edit.isNew ? 'New governance obligation' : `${edit.rec.id}: ${edit.rec.item}`}
          fields={fields}
          initial={edit.rec}
          isNew={edit.isNew}
          schema={GovernanceItem}
          onSave={(rec) => col.upsert(rec, edit.isNew ? undefined : edit.rec.id)}
          onDelete={() => col.remove(edit.rec.id!)}
          onClose={() => setEdit(null)}
        />
      )}

      <div className="grid g-3">
        {aiApps.map((a) => {
          const g = m.governance.filter((x) => x.appId === a.id);
          const open = g.filter((x) => x.status !== 'done');
          return (
            <Link key={a.id} to={`/apps/${a.id}`} className="card card-link card-pad reveal">
              <div className="row">
                <AppTile app={a.profile} size={36} />
                <div className="grow">
                  <div className="app-name" style={{ fontSize: 14.5 }}>
                    {a.profile.name}
                  </div>
                  <div className="faint" style={{ fontSize: 12 }}>
                    {a.profile.myRole ?? 'Role not set'}
                  </div>
                </div>
                {m.initiatives.some((i) => i.aiEnabled && i.appIds.includes(a.id)) && (
                  <Pill color="var(--st-teal)">
                    <Sparkles size={11} /> AI
                  </Pill>
                )}
              </div>
              <div className="stack-bar" style={{ margin: '12px 0 8px' }}>
                {Object.keys(STATUS).map((s) => {
                  const n = g.filter((x) => x.status === s).length;
                  return n ? <span key={s} style={{ flexGrow: n, background: STATUS[s].color }} title={`${STATUS[s].label}: ${n}`} /> : null;
                })}
              </div>
              <div className="faint" style={{ fontSize: 12 }}>
                {g.length} obligations · {open.length} open · {g.filter((x) => x.status === 'blocked').length} blocked
              </div>
            </Link>
          );
        })}
      </div>

      {dueSoon.length > 0 && (
        <div className="callout section-gap reveal" style={tone('var(--st-orange)')}>
          <ShieldCheck size={16} />
          <div>
            <b>Due in the next 30 days or overdue:</b>{' '}
            <span className="muted">{dueSoon.map((g) => `${g.appId} ${g.item} (${fmtDate(g.due!)})`).join(' · ')}</span>
          </div>
        </div>
      )}

      <div className="row-wrap section-gap reveal" style={{ marginTop: 22 }}>
        <h3 className="card-title" style={{ marginRight: 8 }}>
          Obligations register
        </h3>
        <button className={`filter-chip ${!type ? 'on' : ''}`} onClick={() => setType(null)}>
          All types
        </button>
        {TYPES.filter((t) => m.governance.some((g) => g.type === t)).map((t) => (
          <button key={t} className={`filter-chip ${type === t ? 'on' : ''}`} onClick={() => setType(type === t ? null : t)}>
            {t}
          </button>
        ))}
        <label className="check" style={{ marginLeft: 'auto' }}>
          <input type="checkbox" checked={hideDone} onChange={(e) => setHideDone(e.target.checked)} /> Hide done
        </label>
      </div>
      <div className="card section-gap reveal">
        <div className="card-body table-wrap">
          {items.length === 0 ? (
            <Empty title="Nothing matches these filters" />
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>App</th>
                  <th>Obligation</th>
                  <th>Type</th>
                  <th>Cadence</th>
                  <th>Due</th>
                  <th>Owner</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {items.map((g) => (
                  <tr key={g.id} style={{ cursor: 'pointer' }} onClick={() => setEdit({ isNew: false, rec: g })}>
                    <td className="mono nowrap">{g.id}</td>
                    <td>
                      <AppChip id={g.appId} />
                    </td>
                    <td style={{ minWidth: 240 }}>
                      {g.item}
                      {g.notes && <div className="faint" style={{ fontSize: 12 }}>{g.notes}</div>}
                    </td>
                    <td>{g.type}</td>
                    <td>{g.cadence ?? ''}</td>
                    <td className="date">{g.due ? fmtDate(g.due) : ''}</td>
                    <td>{g.owner ?? ''}</td>
                    <td>
                      <Pill color={STATUS[g.status].color}>{STATUS[g.status].label}</Pill>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
