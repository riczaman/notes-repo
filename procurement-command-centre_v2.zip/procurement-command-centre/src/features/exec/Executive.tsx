import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Presentation, Printer, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { allDecisions, allRisks, isPending, isMine, fmtDate, todayIso } from '../../domain/model';
import { stageCoverage, COVERAGE, NO_STAGE } from '../../domain/analysis';
import { INTEGRATION_STATUS, STATUS, impactRank } from '../../domain/meta';
import { PageHead, AppTile, Pill, AppChip, tone, CATEGORY } from '../../components/ui';
import { FlowGraph } from '../../components/FlowGraph';
import { currentGraph, futureGraph } from '../strategy/futureModel';
import { CHANGE_KIND } from '../strategy/FutureState';
import { OPP_CATEGORY } from '../strategy/Opportunities';

const plural = (n: number, w: string) => `${n} ${w}${n === 1 ? '' : 's'}`;

interface SlideDef {
  key: string;
  tag: string;
  title: string;
  body: ReactNode;
  sources: string;
}

function Slide({ s, n, total }: { s: SlideDef; n: number; total: number }) {
  return (
    <section className="slide">
      <header className="slide-head">
        <span className="slide-tag">{s.tag}</span>
        <h2 className="slide-title">{s.title}</h2>
      </header>
      <div className="slide-body">{s.body}</div>
      <footer className="slide-foot">
        <span>Sources: {s.sources}</span>
        <span>
          Procurement TPMM landscape · {fmtDate(todayIso())} · {n}/{total}
        </span>
      </footer>
    </section>
  );
}

const List = ({ items }: { items: ReactNode[] }) => (
  <ul className="slide-list">
    {items.map((x, k) => (
      <li key={k}>{x}</li>
    ))}
  </ul>
);

export function Executive() {
  const m = useModel();
  const [present, setPresent] = useState<number | null>(null);

  const slides = useMemo<SlideDef[]>(() => {
    const mine = m.appList.filter(isMine);
    const active = m.initiatives.filter((i) => i.status !== 'done');
    const cov = stageCoverage(m).filter((r) => r.id !== NO_STAGE);
    const live = m.integrations.filter((i) => i.status === 'live');
    const fragile = m.integrations.filter((i) => i.status === 'degraded' || i.status === 'manual');
    const blocked = m.initiatives.filter((i) => i.status === 'blocked' || i.status === 'at-risk');
    const openGaps = m.gaps.filter((g) => g.status !== 'closed');
    const highOpp = m.opportunities.filter((o) => o.priority === 'high' && o.status !== 'done' && o.status !== 'parked');
    const decisions = allDecisions(m).filter((d) => isPending(d.status));
    const risks = allRisks(m).filter((r) => impactRank(r.impact) >= 4);
    const deps = [...new Set(active.flatMap((i) => i.dependencies))];
    const cur = currentGraph(m);
    const fut = futureGraph(m);
    const name = (id: string) => m.apps[id]?.profile.name ?? id;

    return [
      {
        key: 'A',
        tag: 'A · Ecosystem',
        title: `${mine.length} applications across ${m.workstreams.length} workstreams support procurement, with ${active.length} initiatives in flight`,
        sources: 'data/apps/*/profile.json, data/portfolio/initiatives.json',
        body: (
          <div className="slide-grid-apps">
            {mine.map((a) => (
              <div key={a.id} className="slide-app">
                <AppTile app={a.profile} size={30} />
                <div style={{ minWidth: 0 }}>
                  <b>{a.profile.name}</b> <span className="mono faint">{a.id}</span>
                  <div className="muted">{a.profile.summary}</div>
                  <div className="faint" style={{ fontSize: 11 }}>
                    {CATEGORY[a.profile.category]?.label} · {m.initiatives.filter((i) => i.appIds[0] === a.id && i.status !== 'done').length} active initiatives
                  </div>
                </div>
              </div>
            ))}
          </div>
        ),
      },
      {
        key: 'B',
        tag: 'B · Capability coverage',
        title: cov.length
          ? `${cov.filter((r) => r.coverage === 'strong').length} of ${cov.length} lifecycle stages have strong coverage; ${cov.filter((r) => r.coverage === 'gap').length} carry confirmed gaps`
          : `${m.capabilities.length} business capabilities documented; lifecycle stages are not yet defined`,
        sources: 'data/landscape/lifecycle.json, capabilities.json, gaps.json',
        body: cov.length ? (
          <div className="slide-stages">
            {cov.map((r) => (
              <div key={r.id} className="slide-stage" style={tone(COVERAGE[r.coverage].color)}>
                <b>{r.name}</b>
                <Pill color={COVERAGE[r.coverage].color}>{COVERAGE[r.coverage].label}</Pill>
                <span className="faint">
                  {r.caps.length} capabilities · {r.confirmedGaps} confirmed gaps
                </span>
              </div>
            ))}
          </div>
        ) : (
          <List items={m.capabilities.map((c) => <>{c.name}: {c.appIds.map(name).join(', ') || 'no app'} {c.maturity ? `(${c.maturity})` : ''}</>)} />
        ),
      },
      {
        key: 'C',
        tag: 'C · Relationships',
        title: `${live.length} integrations run live today; ${fragile.length} are degraded or manual and need attention`,
        sources: `data/landscape/integrations.json (${cur.edges.map((e) => e.id).join(', ')})`,
        body: <FlowGraph fit nodes={cur.nodes} edges={cur.edges} height={360} />,
      },
      {
        key: 'D',
        tag: 'D · Functional overlap',
        title: `${m.overlaps.length} overlaps recorded: ${m.overlaps.filter((o) => o.kind === 'confirmed').length} confirmed, ${m.overlaps.filter((o) => o.kind !== 'confirmed').length} to validate`,
        sources: `data/landscape/overlaps.json (${m.overlaps.map((o) => o.id).join(', ')})`,
        body: (
          <List
            items={m.overlaps.map((o) => (
              <>
                <b>{o.title}</b> <span className="faint">({o.kind}, {o.confidence} confidence)</span>
                {o.recommendation && <div className="muted">{o.recommendation}</div>}
              </>
            ))}
          />
        ),
      },
      {
        key: 'E',
        tag: 'E · Capability gaps',
        title: `${openGaps.length} open gaps, ${openGaps.filter((g) => g.priority === 'high').length} high priority`,
        sources: `data/landscape/gaps.json (${openGaps.map((g) => g.id).join(', ')})`,
        body: (
          <List
            items={openGaps.map((g) => (
              <>
                <b>{g.title}</b> <span className="faint">({g.kind}, {g.priority})</span>
                {g.solution && <div className="muted">Direction: {g.solution}</div>}
              </>
            ))}
          />
        ),
      },
      {
        key: 'F',
        tag: 'F · Operational complexity',
        title: `${fragile.length} fragile integrations, ${blocked.length} initiatives at risk or blocked, ${deps.length} external dependencies`,
        sources: 'integrations.json, initiatives.json, notes.md risk tables',
        body: (
          <div className="slide-3col">
            <div>
              <h4>Fragile integrations</h4>
              <List items={fragile.map((i) => <>{i.source} → {i.target}: {i.purpose} <Pill color={INTEGRATION_STATUS[i.status].color}>{i.status}</Pill></>)} />
            </div>
            <div>
              <h4>At risk or blocked</h4>
              <List items={blocked.map((i) => <>{i.title} <Pill color={STATUS[i.status].color}>{STATUS[i.status].label}</Pill></>)} />
            </div>
            <div>
              <h4>Critical risks</h4>
              <List items={risks.slice(0, 5).map((r) => <>{r.appId}: {r.description}</>)} />
            </div>
          </div>
        ),
      },
      {
        key: 'G',
        tag: 'G · Opportunities',
        title: `${highOpp.length} high-priority opportunities to simplify, automate and modernise`,
        sources: `data/strategy/opportunities.json (${highOpp.map((o) => o.id).join(', ')})`,
        body: (
          <List
            items={highOpp.map((o) => (
              <>
                <b>{o.title}</b> <span className="faint">({OPP_CATEGORY[o.category]}{o.quarter ? `, ${o.quarter}` : ''})</span>
                {o.benefit && <div className="muted">{o.benefit}</div>}
              </>
            ))}
          />
        ),
      },
      {
        key: 'H',
        tag: 'H · Future-state direction',
        title: `${plural(m.futureState.length, 'proposed change')}: ${plural(m.futureState.filter((c) => c.kind.startsWith('retire')).length, 'retirement')} and ${plural(m.futureState.filter((c) => c.kind.startsWith('add')).length, 'addition')}. Proposals, not approved decisions`,
        sources: `data/strategy/future-state.json (${m.futureState.map((c) => c.id).join(', ')})`,
        body: (
          <div className="slide-2col">
            <FlowGraph fit nodes={fut.nodes} edges={fut.edges} height={330} />
            <List items={m.futureState.map((c) => <>{c.title} <span className="faint">({CHANGE_KIND[c.kind].label}, {c.status})</span></>)} />
          </div>
        ),
      },
      {
        key: 'I',
        tag: 'Decisions',
        title: `${decisions.length} decisions are needed to keep the portfolio moving`,
        sources: 'Section 05 of each data/apps/*/notes.md',
        body: (
          <List
            items={decisions.map((d) => (
              <>
                <AppChip id={d.appId} /> {d.decision} <span className="faint">(owner {d.by || 'TBC'})</span>
              </>
            ))}
          />
        ),
      },
    ];
  }, [m]);

  useEffect(() => {
    if (present === null) return;
    const k = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setPresent(null);
      if (e.key === 'ArrowRight' || e.key === ' ') setPresent((p) => Math.min(slides.length - 1, (p ?? 0) + 1));
      if (e.key === 'ArrowLeft') setPresent((p) => Math.max(0, (p ?? 0) - 1));
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [present, slides.length]);

  return (
    <div className="exec">
      <div className="no-print">
        <PageHead
          eyebrow="Executive"
          title="Landscape presentation"
          sub="Generated from the live data, so it is always current. Each slide lists the files and IDs behind it. Use Export PDF and choose Save as PDF, landscape."
          actions={
            <>
              <button className="btn" onClick={() => window.print()}>
                <Printer size={15} /> Export PDF
              </button>
              <button className="btn btn-primary" onClick={() => setPresent(0)}>
                <Presentation size={15} /> Present
              </button>
            </>
          }
        />
      </div>
      <div className="slides">
        {slides.map((s, k) => (
          <Slide key={s.key} s={s} n={k + 1} total={slides.length} />
        ))}
      </div>

      {present !== null && (
        <div className="present no-print" role="dialog" aria-modal="true">
          <div className="present-stage">
            <Slide s={slides[present]} n={present + 1} total={slides.length} />
          </div>
          <div className="present-bar">
            <button className="btn btn-ghost" onClick={() => setPresent(Math.max(0, present - 1))} aria-label="Previous slide">
              <ChevronLeft size={18} />
            </button>
            <span className="mono faint">
              {present + 1} / {slides.length}
            </span>
            <button className="btn btn-ghost" onClick={() => setPresent(Math.min(slides.length - 1, present + 1))} aria-label="Next slide">
              <ChevronRight size={18} />
            </button>
            <button className="btn btn-ghost" onClick={() => setPresent(null)} aria-label="Exit presentation">
              <X size={18} /> Esc
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
