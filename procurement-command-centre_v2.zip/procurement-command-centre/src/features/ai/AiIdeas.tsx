import { useState } from 'react';
import { Sparkles, Plus, PencilLine, Save, X, Trash2 } from 'lucide-react';
import { useData, useModel } from '../../store/DataProvider';
import { FILES } from '../../domain/schemas';
import { todayIso } from '../../domain/model';
import { parseAiIdeas, ideaToMarkdown, updateIdea, type AiIdea } from '../../domain/markdown';
import { Empty, Md, Pill, ClassBadge, tone } from '../../components/ui';
import { noteTone } from '../../domain/meta';

const LEVEL: Record<string, number> = { high: 3, medium: 2, low: 1, l: 3, m: 2, s: 1 };
const lvl = (v?: string) => LEVEL[(v ?? '').trim().toLowerCase()] ?? 2;

export function AiIdeas({ id }: { id: string }) {
  const m = useModel();
  const { save, toast } = useData();
  const a = m.apps[id];
  const raw = a.aiRaw ?? `---\napp: ${id}\nupdated: ${todayIso()}\n---\n\n# AI opportunities: ${a.profile.name}\n`;
  const parsed = a.ai ?? parseAiIdeas(raw);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');
  const [adding, setAdding] = useState(false);
  const [hover, setHover] = useState<number | null>(null);
  const [editIdx, setEditIdx] = useState<number | null>(null);

  const write = async (content: string, msg: string) => {
    try {
      await save([{ path: FILES.ai(id), content: content.replace(/^updated: .*$/m, `updated: ${todayIso()}`) }]);
      toast(msg);
      return true;
    } catch (e) {
      toast((e as Error).message, 'error');
      return false;
    }
  };

  if (editing)
    return (
      <div className="stack">
        <div className="row">
          <div className="muted grow" style={{ fontSize: 13 }}>
            Each idea is a <span className="mono">## heading</span> followed by <span className="mono">- **Key:** value</span> lines, then a description.
          </div>
          <button className="btn" onClick={() => setEditing(false)}>
            <X size={14} /> Cancel
          </button>
          <button className="btn btn-primary" onClick={async () => (await write(draft, 'AI ideas saved')) && setEditing(false)}>
            <Save size={14} /> Save
          </button>
        </div>
        <div className="editor-split">
          <textarea className="textarea" value={draft} onChange={(e) => setDraft(e.target.value)} spellCheck={false} />
          <div className="card card-pad preview-pane">
            <Md>{draft.replace(/^---[\s\S]*?---\n/, '')}</Md>
          </div>
        </div>
      </div>
    );

  const ideas = parsed.ideas;
  // Spread dots that share a cell so they never sit on top of each other.
  const cellCount: Record<string, number> = {};
  const pos = ideas.map((i) => {
    const x = lvl(i.meta.effort);
    const y = lvl(i.meta.impact);
    const k = `${x}-${y}`;
    const n = (cellCount[k] = (cellCount[k] ?? 0) + 1) - 1;
    return { left: ((x - 0.5) / 3) * 100 + ((n % 3) - 1) * 9, top: 100 - ((y - 0.5) / 3) * 100 + (Math.floor(n / 3) - 0.5 * Math.min(1, Math.floor((cellCount[k] - 1) / 3))) * 11 };
  });

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="grid g-wide">
        <div className="card card-pad reveal">
          <div className="row" style={{ marginBottom: 6 }}>
            <Sparkles size={17} color="var(--accent)" />
            <h3 className="card-title grow">AI opportunity backlog</h3>
            <button className="btn btn-sm" onClick={() => setAdding((v) => !v)}>
              <Plus size={13} /> Add idea
            </button>
            <button
              className="btn btn-sm btn-ghost"
              onClick={() => {
                setDraft(raw);
                setEditing(true);
              }}
            >
              <PencilLine size={13} /> Edit markdown
            </button>
          </div>
          <div className="muted" style={{ fontSize: 13.5, lineHeight: 1.6 }}>
            {parsed.intro ? <Md>{parsed.intro}</Md> : 'Ideas to automate and add AI to this application.'}
          </div>
          <div className="row-wrap" style={{ marginTop: 10 }}>
            <ClassBadge k="proposed" />
            <span className="faint" style={{ fontSize: 12 }}>
              Ideas stay proposed until you validate value and MRM impact. Source file: <span className="mono">data/apps/{id}/ai-ideas.md</span>
            </span>
          </div>
          {adding && <AddIdea onCancel={() => setAdding(false)} onSubmit={async (idea) => (await write(`${raw.trimEnd()}\n\n${ideaToMarkdown(idea)}\n`, 'Idea added')) && setAdding(false)} />}
        </div>

        <div className="card card-pad reveal">
          <div className="row" style={{ marginBottom: 10 }}>
            <h3 className="card-title grow">Impact vs effort</h3>
            <span className="card-sub">Top-left = quick wins</span>
          </div>
          <div style={{ position: 'relative', paddingLeft: 18, paddingBottom: 18 }}>
            <div className="matrix">
              <div className="matrix-q qw" style={{ left: 0, top: 0, width: '33.33%', height: '33.33%' }}>Quick wins</div>
              <div className="matrix-q" style={{ right: 0, top: 0, width: '33.33%', height: '33.33%', textAlign: 'right' }}>Big bets</div>
              <div className="matrix-q" style={{ right: 0, bottom: 0, width: '33.33%', height: '33.33%', display: 'flex', alignItems: 'flex-end', justifyContent: 'flex-end' }}>Deprioritise</div>
              {[33.33, 66.66].map((v) => (
                <div key={`v${v}`} style={{ position: 'absolute', left: `${v}%`, top: 0, bottom: 0, borderLeft: '1px dashed var(--border-strong)' }} />
              ))}
              {[33.33, 66.66].map((v) => (
                <div key={`h${v}`} style={{ position: 'absolute', top: `${v}%`, left: 0, right: 0, borderTop: '1px dashed var(--border-strong)' }} />
              ))}
              {ideas.map((i, k) => (
                <span
                  key={k}
                  className="matrix-dot"
                  style={{ left: `${Math.min(94, Math.max(6, pos[k].left))}%`, top: `${Math.min(92, Math.max(8, pos[k].top))}%`, opacity: hover === null || hover === k ? 1 : 0.35 }}
                  onMouseEnter={() => setHover(k)}
                  onMouseLeave={() => setHover(null)}
                  title={`${i.title} · Impact ${i.meta.impact ?? '?'} · Effort ${i.meta.effort ?? '?'}`}
                >
                  {k + 1}
                </span>
              ))}
            </div>
            <span className="matrix-axis" style={{ left: -4, top: '50%', transform: 'rotate(-90deg) translateX(50%)', transformOrigin: 'left' }}>Impact: low · med · high</span>
            <span className="matrix-axis" style={{ bottom: 0, left: '50%', transform: 'translateX(-50%)' }}>Effort: S · M · L</span>
          </div>
        </div>
      </div>

      {ideas.length === 0 ? (
        <Empty icon={Sparkles} title="No AI ideas yet">Add one above, or edit the Markdown directly.</Empty>
      ) : (
        <div className="grid g-3">
          {ideas.map((i, k) =>
            editIdx === k ? (
              <div key={k} className="card card-pad" style={{ gridColumn: '1 / -1' }}>
                <AddIdea initial={i} onCancel={() => setEditIdx(null)} onSubmit={async (idea) => (await write(updateIdea(raw, k, idea), 'Idea updated')) && setEditIdx(null)} />
              </div>
            ) : (
              <IdeaCard
                key={k}
                n={k + 1}
                idea={i}
                active={hover === k}
                onHover={(v) => setHover(v ? k : null)}
                onEdit={() => setEditIdx(k)}
                onDelete={async () => {
                  if (window.confirm(`Delete idea "${i.title}"?`)) await write(updateIdea(raw, k, null), 'Idea deleted');
                }}
              />
            ),
          )}
        </div>
      )}
    </div>
  );
}

function IdeaCard({ idea, n, active, onHover, onEdit, onDelete }: { idea: AiIdea; n: number; active: boolean; onHover: (v: boolean) => void; onEdit: () => void; onDelete: () => void }) {
  const { status, type, impact, effort, value, mrm } = idea.meta;
  const depends = idea.meta['depends on'];
  return (
    <article
      className="card idea reveal row-hover"
      style={active ? { borderColor: 'var(--accent)' } : undefined}
      onMouseEnter={() => onHover(true)}
      onMouseLeave={() => onHover(false)}
    >
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <span className="matrix-dot" style={{ position: 'static', margin: 0, width: 26, height: 26, flex: 'none', fontSize: 11 }}>
          {n}
        </span>
        <div className="idea-title grow">{idea.title}</div>
        <span className="row-actions" style={{ opacity: active ? 1 : undefined }}>
          <button className="btn btn-ghost icon-btn btn-sm" title="Edit idea" aria-label="Edit idea" onClick={onEdit}>
            <PencilLine size={13} />
          </button>
          <button className="btn btn-ghost icon-btn btn-sm" title="Delete idea" aria-label="Delete idea" onClick={onDelete}>
            <Trash2 size={13} />
          </button>
        </span>
      </div>
      <div className="row-wrap">
        {status && <Pill color={noteTone(status)?.color ?? 'var(--st-grey)'}>{status}</Pill>}
        {impact && <Pill color={noteTone(impact)?.color ?? 'var(--st-grey)'}>Impact {impact}</Pill>}
        {effort && (
          <span className="chip" style={tone('var(--st-grey)')}>
            Effort {effort}
          </span>
        )}
      </div>
      {value && <div style={{ fontSize: 13.5, lineHeight: 1.55 }}>{value}</div>}
      <dl className="idea-kv">
        {type && (
          <>
            <dt>Type</dt>
            <dd>{type}</dd>
          </>
        )}
        {mrm && (
          <>
            <dt>MRM</dt>
            <dd>{mrm}</dd>
          </>
        )}
        {depends && (
          <>
            <dt>Depends on</dt>
            <dd>{depends}</dd>
          </>
        )}
      </dl>
      {idea.description && <Md>{idea.description}</Md>}
    </article>
  );
}

function AddIdea({ onSubmit, onCancel, initial }: { onSubmit: (idea: AiIdea) => void; onCancel: () => void; initial?: AiIdea }) {
  const im = initial?.meta ?? {};
  const [f, setF] = useState({
    title: initial?.title ?? '',
    status: im.status ?? 'Idea',
    type: im.type ?? '',
    impact: im.impact ?? 'Medium',
    effort: im.effort ?? 'M',
    value: im.value ?? '',
    mrm: im.mrm ?? '',
    depends: im['depends on'] ?? '',
    description: initial?.description ?? '',
  });
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  return (
    <form
      className="add-row"
      style={{ marginTop: initial ? 0 : 14 }}
      onSubmit={(e) => {
        e.preventDefault();
        if (!f.title.trim()) return;
        const extra = Object.fromEntries(Object.entries(im).filter(([k]) => !['status', 'type', 'impact', 'effort', 'value', 'mrm', 'depends on'].includes(k)));
        onSubmit({
          title: f.title.trim(),
          meta: { status: f.status, type: f.type, impact: f.impact, effort: f.effort, value: f.value, mrm: f.mrm, 'depends on': f.depends, ...extra },
          description: f.description,
        });
      }}
    >
      <div className="add-grid">
        <label style={{ gridColumn: 'span 2' }}>
          <span className="field-label">Idea</span>
          <input className="input" style={{ width: '100%' }} value={f.title} onChange={set('title')} autoFocus />
        </label>
        <label>
          <span className="field-label">Status</span>
          <select className="select" style={{ width: '100%' }} value={f.status} onChange={set('status')}>
            {['Idea', 'POC built', 'Planned', 'In progress', 'Done', 'Parked', ...(['Idea', 'POC built', 'Planned', 'In progress', 'Done', 'Parked'].includes(f.status) ? [] : [f.status])].map((o) => (
              <option key={o}>{o}</option>
            ))}
          </select>
        </label>
        <label>
          <span className="field-label">Type</span>
          <input className="input" style={{ width: '100%' }} placeholder="RAG assistant, agent…" value={f.type} onChange={set('type')} />
        </label>
        <label>
          <span className="field-label">Impact</span>
          <select className="select" style={{ width: '100%' }} value={f.impact} onChange={set('impact')}>
            <option>High</option>
            <option>Medium</option>
            <option>Low</option>
          </select>
        </label>
        <label>
          <span className="field-label">Effort</span>
          <select className="select" style={{ width: '100%' }} value={f.effort} onChange={set('effort')}>
            <option>S</option>
            <option>M</option>
            <option>L</option>
          </select>
        </label>
        <label style={{ gridColumn: 'span 2' }}>
          <span className="field-label">Value</span>
          <input className="input" style={{ width: '100%' }} value={f.value} onChange={set('value')} />
        </label>
        <label>
          <span className="field-label">MRM impact</span>
          <input className="input" style={{ width: '100%' }} value={f.mrm} onChange={set('mrm')} />
        </label>
        <label>
          <span className="field-label">Depends on</span>
          <input className="input" style={{ width: '100%' }} value={f.depends} onChange={set('depends')} />
        </label>
      </div>
      <label>
        <span className="field-label">Description (optional)</span>
        <textarea className="textarea" rows={3} style={{ width: '100%' }} value={f.description} onChange={set('description')} />
      </label>
      <div className="row" style={{ justifyContent: 'flex-end' }}>
        <button type="button" className="btn btn-sm" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn btn-sm btn-primary">
          {initial ? <Save size={13} /> : <Plus size={13} />} {initial ? 'Save idea' : 'Add idea'}
        </button>
      </div>
    </form>
  );
}
