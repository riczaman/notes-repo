import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  ReactFlow, Background, Controls, MiniMap, Handle, Position, MarkerType, BackgroundVariant, useReactFlow, ReactFlowProvider,
  type Node, type Edge, type NodeProps,
} from '@xyflow/react';
import dagre from '@dagrejs/dagre';
import { Search, ArrowRight, Crosshair, ArrowUpFromLine, ArrowDownToLine, X, Plus, PencilLine } from 'lucide-react';
import { RecordEditor, useCollection, nextId, INTEGRATION_FIELDS } from '../../components/RecordEditor';
import { Integration as IntegrationSchema, FILES } from '../../domain/schemas';
import { useModel } from '../../store/DataProvider';
import type { Integration, Classification } from '../../domain/schemas';
import { INTEGRATION_STATUS, CLASSIFICATION, HEALTH } from '../../domain/meta';
import { PageHead, AppTile, ClassBadge, Pill, AppChip, tone, CATEGORY } from '../../components/ui';
import type { AppBundle } from '../../domain/model';

type AppNodeData = { app: AppBundle; dim: boolean; selected: boolean };
type Trace = 'all' | 'up' | 'down';
const NODE_W = 188;
const NODE_H = 54;
const MIN_READABLE_ZOOM = 0.78;

function AppNode({ data }: NodeProps<Node<AppNodeData>>) {
  const p = data.app.profile;
  return (
    <div className={`node ${p.portfolio === 'external' ? 'external' : ''} ${data.dim ? 'dim' : ''} ${data.selected ? 'selected' : ''}`} title={p.summary}>
      <Handle type="target" position={Position.Left} />
      <AppTile app={p} size={30} />
      <div style={{ minWidth: 0, flex: 1 }}>
        <div className="node-name">{p.name}</div>
        <div className="node-meta">
          <span className="mono">{p.id}</span>·<span>{CATEGORY[p.category]?.label}</span>
          {p.portfolio !== 'external' && <span className="health-dot" style={{ ...tone(HEALTH[p.health]?.color ?? 'var(--st-grey)'), width: 6, height: 6, marginLeft: 'auto' }} />}
        </div>
      </div>
      <Handle type="source" position={Position.Right} />
    </div>
  );
}
function GroupLabel({ data }: NodeProps<Node<{ text: string }>>) {
  return <div className="map-group-label">{data.text}</div>;
}
const nodeTypes = { app: AppNode, label: GroupLabel };

function layout(ids: string[], ints: Integration[]) {
  const linked = new Set(ints.flatMap((i) => [i.source, i.target]));
  const connected = ids.filter((id) => linked.has(id));
  const loose = ids.filter((id) => !linked.has(id));
  const g = new dagre.graphlib.Graph();
  g.setGraph({ rankdir: 'LR', nodesep: 18, ranksep: 58, marginx: 20, marginy: 20 });
  g.setDefaultEdgeLabel(() => ({}));
  connected.forEach((id) => g.setNode(id, { width: NODE_W, height: NODE_H }));
  // Navigation links (e.g. "UI link") are drawn but do not shape the data-flow layout.
  ints.filter((i) => !/ui link/i.test(i.method)).forEach((i) => g.setEdge(i.source, i.target));
  dagre.layout(g);
  const pos: Record<string, { x: number; y: number }> = {};
  let maxX = 0;
  let maxY = 0;
  connected.forEach((id) => {
    const n = g.node(id);
    pos[id] = { x: n.x - NODE_W / 2, y: n.y - NODE_H / 2 };
    maxX = Math.max(maxX, n.x + NODE_W / 2);
    maxY = Math.max(maxY, n.y + NODE_H / 2);
  });
  // Applications with no documented integrations sit in a labelled grid below the flow.
  const cols = Math.max(3, Math.floor(Math.max(maxX, NODE_W * 3) / (NODE_W + 24)));
  const top = connected.length ? maxY + 90 : 20;
  loose.forEach((id, k) => {
    pos[id] = { x: 20 + (k % cols) * (NODE_W + 24), y: top + 34 + Math.floor(k / cols) * (NODE_H + 22) };
  });
  return { pos, looseTop: loose.length ? top : null };
}

/** Walk the integration graph from one node in one direction. */
function reach(start: string, ints: Integration[], dir: 'up' | 'down') {
  const seen = new Set([start]);
  const queue = [start];
  while (queue.length) {
    const cur = queue.shift()!;
    for (const i of ints) {
      const next = dir === 'down' ? (i.source === cur ? i.target : null) : i.target === cur ? i.source : null;
      if (next && !seen.has(next)) {
        seen.add(next);
        queue.push(next);
      }
    }
  }
  return seen;
}

export function EcosystemMap() {
  return (
    <ReactFlowProvider>
      <MapInner />
    </ReactFlowProvider>
  );
}

function MapInner() {
  const m = useModel();
  const [params] = useSearchParams();
  const [q, setQ] = useState('');
  const [classes, setClasses] = useState<Set<Classification>>(new Set(['confirmed', 'inferred', 'proposed', 'unverified']));
  const [showUnlinked, setShowUnlinked] = useState(true);
  const [selected, setSelected] = useState<string | null>(params.get('focus'));
  const [edgeSel, setEdgeSel] = useState<string | null>(null);
  const [trace, setTrace] = useState<Trace>('all');
  const [isolate, setIsolate] = useState(false);
  const [editInt, setEditInt] = useState<{ rec: Partial<Integration>; isNew: boolean } | null>(null);
  const intCol = useCollection(FILES.integrations, m.integrations);
  const flow = useReactFlow();

  const ints = useMemo(() => m.integrations.filter((i) => classes.has(i.classification)), [m.integrations, classes]);

  const highlight = useMemo(() => {
    if (!selected) return null;
    const up = trace !== 'down' ? reach(selected, ints, 'up') : new Set<string>();
    const down = trace !== 'up' ? reach(selected, ints, 'down') : new Set<string>();
    return new Set([selected, ...up, ...down]);
  }, [selected, ints, trace]);

  const visibleIds = useMemo(() => {
    const linked = new Set(ints.flatMap((i) => [i.source, i.target]));
    let ids = m.appList.map((a) => a.id).filter((id) => showUnlinked || linked.has(id));
    if (isolate && highlight) ids = ids.filter((id) => highlight.has(id));
    return ids;
  }, [m.appList, ints, showUnlinked, isolate, highlight]);

  const visibleInts = ints.filter((i) => visibleIds.includes(i.source) && visibleIds.includes(i.target));
  const { pos, looseTop } = useMemo(() => layout(visibleIds, visibleInts), [visibleIds.join(), visibleInts.map((i) => i.id).join()]); // eslint-disable-line react-hooks/exhaustive-deps

  const needle = q.trim().toLowerCase();
  const match = (a: AppBundle) => !needle || `${a.id} ${a.profile.name} ${a.profile.aliases.join(' ')}`.toLowerCase().includes(needle);

  const nodes: Node[] = visibleIds.map((id) => {
    const app = m.apps[id];
    return {
      id,
      type: 'app',
      position: pos[id],
      data: { app, selected: selected === id, dim: (highlight ? !highlight.has(id) : false) || !match(app) },
    };
  });
  if (looseTop !== null)
    nodes.push({ id: '__loose', type: 'label', position: { x: 20, y: looseTop }, data: { text: 'No documented integrations yet' }, selectable: false, draggable: false });

  const edges: Edge[] = visibleInts.map((i) => {
    const s = INTEGRATION_STATUS[i.status];
    const on = !highlight || (highlight.has(i.source) && highlight.has(i.target));
    const dash = i.classification === 'proposed' ? '7 5' : i.classification === 'unverified' ? '2 4' : undefined;
    return {
      id: i.id,
      source: i.source,
      target: i.target,
      label: highlight && on ? (i.method.length > 26 ? i.method.slice(0, 24) + '…' : i.method) : undefined,
      animated: (i.status === 'live' || i.status === 'degraded') && on,
      style: { stroke: s.color, strokeWidth: edgeSel === i.id ? 3.2 : 2, strokeDasharray: dash, opacity: on ? 1 : 0.12 },
      labelStyle: { opacity: on ? 1 : 0 },
      labelBgStyle: { opacity: on ? 0.9 : 0 },
      markerEnd: { type: MarkerType.ArrowClosed, color: s.color, width: 16, height: 16 },
    };
  });

  const canvasRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  // Fit the whole map when it is readable; otherwise open at a readable zoom anchored on the start of the flow.
  useEffect(() => {
    const t = setTimeout(() => {
      const el = canvasRef.current;
      const pts = Object.values(pos);
      if (!el || !pts.length) return;
      const minX = Math.min(...pts.map((p) => p.x));
      const maxX = Math.max(...pts.map((p) => p.x)) + NODE_W;
      const minY = Math.min(...pts.map((p) => p.y));
      const maxY = Math.max(...pts.map((p) => p.y)) + NODE_H;
      const { width, height } = el.getBoundingClientRect();
      const fit = Math.min((width - 60) / (maxX - minX), (height - 80) / (maxY - minY));
      if (fit >= MIN_READABLE_ZOOM) flow.fitView({ padding: 0.08, duration: 500 });
      else {
        const zoom = MIN_READABLE_ZOOM;
        const gh = (maxY - minY) * zoom;
        const y = gh < height - 60 ? (height - gh) / 2 - minY * zoom : 56 - minY * zoom;
        flow.setViewport({ x: 30 - minX * zoom, y, zoom }, { duration: 500 });
      }
    }, 120);
    return () => clearTimeout(t);
  }, [ready, visibleIds.length, isolate, flow]); // eslint-disable-line react-hooks/exhaustive-deps

  const onSearch = useCallback(
    (v: string) => {
      setQ(v);
      const hit = m.appList.find((a) => v && `${a.id} ${a.profile.name}`.toLowerCase().includes(v.toLowerCase()));
      if (hit && pos[hit.id]) flow.setCenter(pos[hit.id].x + NODE_W / 2, pos[hit.id].y + NODE_H / 2, { zoom: 1.1, duration: 500 });
    },
    [m.appList, pos, flow],
  );

  const toggleClass = (c: Classification) => {
    const next = new Set(classes);
    if (next.has(c)) next.delete(c);
    else next.add(c);
    setClasses(next);
  };

  const selApp = selected ? m.apps[selected] : null;
  const selInt = edgeSel ? m.integrations.find((i) => i.id === edgeSel) : null;

  return (
    <div>
      <PageHead
        eyebrow="Landscape"
        title="Application ecosystem"
        sub="Only documented or explicitly proposed integrations are drawn. Click an application to trace its upstream and downstream network."
        actions={
          <button
            className="btn btn-primary"
            onClick={() =>
              setEditInt({
                isNew: true,
                rec: { id: nextId('INT', m.integrations), source: selected ?? undefined, status: 'planned', classification: 'unverified', direction: 'one-way', data: [], dependencies: [], limitations: [], evidence: [] },
              })
            }
          >
            <Plus size={15} /> Add integration
          </button>
        }
      />
      {editInt && (
        <RecordEditor
          title={editInt.isNew ? 'New integration' : `${editInt.rec.id}: ${editInt.rec.purpose}`}
          fields={INTEGRATION_FIELDS}
          initial={editInt.rec}
          isNew={editInt.isNew}
          schema={IntegrationSchema}
          onSave={async (rec) => {
            if (!m.apps[rec.source] || !m.apps[rec.target]) throw new Error('Choose both applications');
            await intCol.upsert(rec, editInt.isNew ? undefined : editInt.rec.id);
          }}
          onDelete={async () => {
            await intCol.remove(editInt.rec.id!);
            setEdgeSel(null);
          }}
          onClose={() => setEditInt(null)}
        />
      )}
      <div className="map-layout" style={{ position: 'relative' }}>
        <aside className="card map-panel">
          <div className="search">
            <Search size={15} />
            <input className="input" style={{ width: '100%' }} placeholder="Find an application" value={q} onChange={(e) => onSearch(e.target.value)} />
          </div>
          <div>
            <span className="field-label">Classification</span>
            {(Object.keys(CLASSIFICATION) as Classification[]).filter((c) => c !== 'undocumented').map((c) => (
              <label key={c} className="check">
                <input type="checkbox" checked={classes.has(c)} onChange={() => toggleClass(c)} />
                <ClassBadge k={c} />
                <span className="faint mono" style={{ marginLeft: 'auto' }}>
                  {m.integrations.filter((i) => i.classification === c).length}
                </span>
              </label>
            ))}
          </div>
          <label className="check">
            <input type="checkbox" checked={showUnlinked} onChange={(e) => setShowUnlinked(e.target.checked)} />
            Show apps with no documented integrations
          </label>
          <div>
            <span className="field-label">Integration status</span>
            <div className="legend">
              {Object.entries(INTEGRATION_STATUS).map(([k, s]) => (
                <div key={k} className="row" style={tone(s.color)}>
                  <span className="legend-line" />
                  {s.label}
                </div>
              ))}
              <div className="row" style={tone('var(--text-3)')}>
                <span className="legend-line dashed" /> Proposed
              </div>
              <div className="row" style={tone('var(--text-3)')}>
                <span className="legend-line dotted" /> Unverified
              </div>
              <div className="row">
                <span className="node external" style={{ width: 26, height: 14, padding: 0, borderRadius: 4 }} /> External system
              </div>
            </div>
          </div>
        </aside>

        <div className="card map-canvas" ref={canvasRef}>
          {!selApp && !selInt && (
            <div className="map-hint">
              <Crosshair size={14} /> Click an application to trace its network, or a line to see what flows across it
            </div>
          )}
          <ReactFlow
            nodes={nodes}
            edges={edges}
            nodeTypes={nodeTypes}
            onNodeClick={(_, n) => {
              if (n.type === 'label') return;
              setSelected(n.id === selected ? null : n.id);
              setEdgeSel(null);
            }}
            onEdgeClick={(_, e) => {
              setEdgeSel(e.id);
            }}
            onPaneClick={() => {
              setEdgeSel(null);
            }}
            nodesDraggable
            onInit={() => setReady(true)}
            minZoom={0.2}
            maxZoom={2}
            proOptions={{ hideAttribution: true }}
          >
            <Background variant={BackgroundVariant.Dots} gap={22} size={1.4} />
            <Controls showInteractive={false} />
            <MiniMap pannable zoomable nodeColor={(n) => (n.type === 'label' ? 'transparent' : '#5c667a')} nodeStrokeWidth={0} maskColor="rgba(8, 10, 14, 0.55)" />
          </ReactFlow>
        </div>

        {(selInt || selApp) && (
        <aside className="card map-panel map-detail">
          {selInt ? (
            <IntegrationDetail i={selInt} onClose={() => setEdgeSel(null)} onEdit={() => setEditInt({ isNew: false, rec: selInt })} />
          ) : selApp ? (
            <>
              <div className="row" style={{ alignItems: 'flex-start' }}>
                <AppTile app={selApp.profile} size={42} />
                <div className="grow">
                  <div className="app-name">{selApp.profile.name}</div>
                  <span className="chip chip-mono">{selApp.id}</span>
                </div>
                <button className="btn btn-ghost icon-btn btn-sm" onClick={() => setSelected(null)} aria-label="Clear selection">
                  <X size={15} />
                </button>
              </div>
              <div className="muted" style={{ fontSize: 13 }}>
                {selApp.profile.summary}
              </div>
              <div>
                <span className="field-label">Trace</span>
                <div className="row-wrap">
                  <button className={`filter-chip ${trace === 'all' ? 'on' : ''}`} onClick={() => setTrace('all')}>
                    <Crosshair size={13} /> Both
                  </button>
                  <button className={`filter-chip ${trace === 'up' ? 'on' : ''}`} onClick={() => setTrace('up')}>
                    <ArrowUpFromLine size={13} /> Upstream
                  </button>
                  <button className={`filter-chip ${trace === 'down' ? 'on' : ''}`} onClick={() => setTrace('down')}>
                    <ArrowDownToLine size={13} /> Downstream
                  </button>
                </div>
                <label className="check" style={{ marginTop: 8 }}>
                  <input type="checkbox" checked={isolate} onChange={(e) => setIsolate(e.target.checked)} /> Isolate this network
                </label>
              </div>
              <div>
                <span className="field-label">Connections ({m.integrations.filter((i) => i.source === selApp.id || i.target === selApp.id).length})</span>
                <div className="stack" style={{ gap: 6 }}>
                  {m.integrations
                    .filter((i) => i.source === selApp.id || i.target === selApp.id)
                    .map((i) => (
                      <button key={i.id} className="mini-row" style={{ gridTemplateColumns: 'auto minmax(0,1fr)', border: 'none', background: 'none', textAlign: 'left' }} onClick={() => setEdgeSel(i.id)}>
                        <span className="pill-dot" style={{ background: INTEGRATION_STATUS[i.status].color }} />
                        <span style={{ fontSize: 12.5 }}>
                          <span className="mono faint">{i.source === selApp.id ? '→' : '←'} {i.source === selApp.id ? i.target : i.source}</span> {i.purpose}
                        </span>
                      </button>
                    ))}
                </div>
              </div>
              <Link to={`/apps/${selApp.id}`} className="btn btn-primary">
                Open workspace <ArrowRight size={14} />
              </Link>
            </>
          ) : null}
        </aside>
        )}
      </div>
    </div>
  );
}

function IntegrationDetail({ i, onClose, onEdit }: { i: Integration; onClose: () => void; onEdit: () => void }) {
  const s = INTEGRATION_STATUS[i.status];
  return (
    <>
      <div className="row">
        <span className="chip chip-mono">{i.id}</span>
        <Pill color={s.color}>{s.label}</Pill>
        <span className="grow" />
        <button className="btn btn-sm" onClick={onEdit}>
          <PencilLine size={13} /> Edit
        </button>
        <button className="btn btn-ghost icon-btn btn-sm" onClick={onClose} aria-label="Close integration">
          <X size={15} />
        </button>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <AppChip id={i.source} />
        <ArrowRight size={15} className="faint" />
        <AppChip id={i.target} />
        <span className="faint" style={{ fontSize: 12 }}>
          {i.direction}
        </span>
      </div>
      <div style={{ fontSize: 14, fontWeight: 600, lineHeight: 1.4 }}>{i.purpose}</div>
      <ClassBadge k={i.classification} />
      <dl className="kv" style={{ gridTemplateColumns: '90px 1fr', fontSize: 12.5 }}>
        <dt>Method</dt>
        <dd>{i.method}</dd>
        <dt>Frequency</dt>
        <dd>{i.frequency ?? <span className="undoc">Undocumented</span>}</dd>
        <dt>Data</dt>
        <dd>{i.data.join(', ') || <span className="undoc">Undocumented</span>}</dd>
        {i.process && (
          <>
            <dt>Process</dt>
            <dd>{i.process}</dd>
          </>
        )}
        {i.dependencies.length > 0 && (
          <>
            <dt>Depends on</dt>
            <dd>{i.dependencies.join('; ')}</dd>
          </>
        )}
        {i.limitations.length > 0 && (
          <>
            <dt>Limitations</dt>
            <dd>{i.limitations.join('; ')}</dd>
          </>
        )}
        <dt>Evidence</dt>
        <dd className="muted">{i.evidence.map((e) => `${e.source}${e.ref ? ` (${e.ref})` : ''}`).join('; ')}</dd>
      </dl>
    </>
  );
}
