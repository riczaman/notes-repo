import { useState } from 'react';
import { Plus, Database, PencilLine, ShieldCheck } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { DataEntity, FILES } from '../../domain/schemas';
import { flowsFor, rolesFor, unregisteredEntities, type Role } from '../../domain/analysis';
import { INTEGRATION_STATUS } from '../../domain/meta';
import { PageHead, Empty, AppChip, Pill, ClassBadge, tone, useReveal } from '../../components/ui';
import { RecordEditor, useCollection, nextId, CLASS_OPTIONS, type FieldSpec } from '../../components/RecordEditor';
import { FlowGraph } from '../../components/FlowGraph';

const ROLE: Record<Role, { label: string; color: string }> = {
  creates: { label: 'Creates or sends', color: 'var(--st-teal)' },
  relays: { label: 'Transforms or relays', color: 'var(--st-sky)' },
  consumes: { label: 'Consumes', color: 'var(--st-sage)' },
};

const FIELDS: FieldSpec[] = [
  { key: 'id', label: 'Entity ID', readOnlyOnEdit: true },
  { key: 'name', label: 'Entity name', hint: 'Use the same words as in integration "Data exchanged" lists' },
  { key: 'systemOfRecord', label: 'System of record', type: 'app', hint: 'Only if documented. Leave blank otherwise' },
  { key: 'owner', label: 'Data owner' },
  { key: 'classification', label: 'Classification', type: 'select', options: CLASS_OPTIONS },
  { key: 'description', label: 'Description', type: 'textarea' },
  { key: 'attributes', label: 'Key attributes', type: 'lines' },
  { key: 'qualityIssues', label: 'Known data quality issues', type: 'lines' },
  { key: 'evidence', label: 'Documentation references', type: 'evidence' },
];

export function DataFlows() {
  const m = useModel();
  const col = useCollection(FILES.dataEntities, m.dataEntities);
  const unregistered = unregisteredEntities(m);
  const names = [...m.dataEntities.map((d) => d.name), ...unregistered];
  const [sel, setSel] = useState<string>(names[0] ?? '');
  const [edit, setEdit] = useState<{ rec: Partial<DataEntity>; isNew: boolean } | null>(null);
  const ref = useReveal<HTMLDivElement>([sel]);

  const entity = m.dataEntities.find((d) => d.name === sel);
  const flows = sel ? flowsFor(m, sel) : [];
  const roles = rolesFor(flows);
  const appIds = Object.keys(roles);

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Landscape"
        title="Data flows"
        sub="Pick a data entity to see which applications create, relay and consume it. Roles come only from documented integrations; a system of record is shown only when you record it."
        actions={
          <button className="btn btn-primary" onClick={() => setEdit({ isNew: true, rec: { id: nextId('ENT', m.dataEntities), attributes: [], qualityIssues: [], evidence: [], classification: 'confirmed' } })}>
            <Plus size={15} /> Register entity
          </button>
        }
      />
      {edit && (
        <RecordEditor
          title={edit.isNew ? 'New data entity' : `${edit.rec.id}: ${edit.rec.name}`}
          fields={FIELDS}
          initial={edit.rec}
          isNew={edit.isNew}
          schema={DataEntity}
          onSave={async (rec) => {
            await col.upsert(rec, edit.isNew ? undefined : edit.rec.id);
            setSel(rec.name);
          }}
          onDelete={() => col.remove(edit.rec.id!)}
          onClose={() => setEdit(null)}
        />
      )}

      <div className="row-wrap reveal" style={{ marginBottom: 16 }}>
        {m.dataEntities.map((d) => (
          <button key={d.id} className={`filter-chip ${sel === d.name ? 'on' : ''}`} onClick={() => setSel(d.name)}>
            <Database size={13} /> {d.name}
          </button>
        ))}
        {unregistered.map((n) => (
          <button key={n} className={`filter-chip ${sel === n ? 'on' : ''}`} style={{ borderStyle: 'dashed' }} onClick={() => setSel(n)} title="Used in integrations but not registered">
            {n}
          </button>
        ))}
      </div>

      {!sel ? (
        <Empty icon={Database} title="No data entities yet">Add "Data exchanged" to integrations on the Ecosystem map, or register an entity.</Empty>
      ) : (
        <div className="grid g-wide">
          <div className="card reveal">
            <div className="card-head">
              <h3 className="card-title">{sel}</h3>
              <span className="card-sub">{flows.length} documented flows</span>
            </div>
            <div className="card-body">
              {flows.length ? (
                <FlowGraph
                  height={340}
                  nodes={appIds.map((id) => ({
                    id,
                    label: m.apps[id]?.profile.name ?? id,
                    sub: id,
                    category: m.apps[id]?.profile.category,
                    variant: entity?.systemOfRecord === id ? 'sor' : 'normal',
                    badge: entity?.systemOfRecord === id ? 'System of record' : ROLE[roles[id]].label,
                  }))}
                  edges={flows.map((f) => ({ id: f.id, source: f.source, target: f.target, label: f.method, color: INTEGRATION_STATUS[f.status].color, dashed: f.classification === 'proposed', animated: f.status === 'live' }))}
                />
              ) : (
                <Empty title="No integration lists this entity yet" />
              )}
              <div className="table-wrap" style={{ marginTop: 14 }}>
                <table className="table">
                  <thead>
                    <tr>
                      <th>Flow</th>
                      <th>From → To</th>
                      <th>Mechanism</th>
                      <th>Trigger / frequency</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {flows.map((f) => (
                      <tr key={f.id}>
                        <td className="mono">{f.id}</td>
                        <td className="nowrap">
                          <AppChip id={f.source} /> → <AppChip id={f.target} />
                        </td>
                        <td>{f.method}</td>
                        <td>{f.frequency ?? <span className="undoc">Undocumented</span>}</td>
                        <td>
                          <Pill color={INTEGRATION_STATUS[f.status].color}>{INTEGRATION_STATUS[f.status].label}</Pill>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="stack">
            <div className="card card-pad reveal">
              <div className="row" style={{ marginBottom: 10 }}>
                <h3 className="card-title grow">Entity record</h3>
                {entity ? (
                  <button className="btn btn-sm" onClick={() => setEdit({ isNew: false, rec: entity })}>
                    <PencilLine size={13} /> Edit
                  </button>
                ) : (
                  <button className="btn btn-sm btn-primary" onClick={() => setEdit({ isNew: true, rec: { id: nextId('ENT', m.dataEntities), name: sel, attributes: [], qualityIssues: [], evidence: [], classification: 'confirmed' } })}>
                    <Plus size={13} /> Register
                  </button>
                )}
              </div>
              {entity ? (
                <dl className="kv" style={{ gridTemplateColumns: '120px 1fr' }}>
                  <dt>System of record</dt>
                  <dd>
                    {entity.systemOfRecord ? (
                      <span className="row">
                        <ShieldCheck size={14} color="var(--accent)" /> <AppChip id={entity.systemOfRecord} />
                      </span>
                    ) : (
                      <span className="undoc">Not established</span>
                    )}
                  </dd>
                  <dt>Owner</dt>
                  <dd>{entity.owner ?? <span className="undoc">Undocumented</span>}</dd>
                  <dt>Classification</dt>
                  <dd>
                    <ClassBadge k={entity.classification} />
                  </dd>
                  <dt>Attributes</dt>
                  <dd>{entity.attributes.join(', ') || <span className="undoc">Undocumented</span>}</dd>
                  <dt>Quality issues</dt>
                  <dd>{entity.qualityIssues.join('; ') || <span className="faint">None recorded</span>}</dd>
                  {entity.description && (
                    <>
                      <dt>Description</dt>
                      <dd>{entity.description}</dd>
                    </>
                  )}
                </dl>
              ) : (
                <div className="muted" style={{ fontSize: 13 }}>
                  This name appears in integrations but has no entity record yet. Register it to add a system of record, owner and quality issues.
                </div>
              )}
            </div>
            <div className="card card-pad reveal">
              <h3 className="card-title" style={{ marginBottom: 10 }}>Roles</h3>
              <div className="stack" style={{ gap: 8 }}>
                {appIds.map((id) => (
                  <div key={id} className="row" style={tone(ROLE[roles[id]].color)}>
                    <AppChip id={id} />
                    <span className="grow muted" style={{ fontSize: 13 }}>
                      {m.apps[id]?.profile.name}
                    </span>
                    <Pill color={ROLE[roles[id]].color}>{ROLE[roles[id]].label}</Pill>
                  </div>
                ))}
                {!appIds.length && <span className="faint">No roles yet</span>}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
