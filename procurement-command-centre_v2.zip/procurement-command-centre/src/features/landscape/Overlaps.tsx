import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, GitCompare, Info } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { Overlap, FILES } from '../../domain/schemas';
import { compareFacets, norm } from '../../domain/analysis';
import { PageHead, AppChip, Pill, tone, useReveal, Empty, AppTile } from '../../components/ui';
import { RecordEditor, useCollection, nextId, type FieldSpec } from '../../components/RecordEditor';

const KIND: Record<string, { label: string; color: string }> = {
  confirmed: { label: 'Confirmed overlap', color: 'var(--st-red)' },
  potential: { label: 'Potential overlap', color: 'var(--st-amber)' },
  complementary: { label: 'Complementary', color: 'var(--st-teal)' },
  investigate: { label: 'Needs investigation', color: 'var(--st-sky)' },
};

const FIELDS: FieldSpec[] = [
  { key: 'id', label: 'Overlap ID', readOnlyOnEdit: true },
  { key: 'kind', label: 'Finding', type: 'select', options: Object.keys(KIND) },
  { key: 'title', label: 'Title', wide: true },
  { key: 'confidence', label: 'Confidence', type: 'select', options: ['high', 'medium', 'low'] },
  { key: 'validation', label: 'Validation status', type: 'select', options: ['validated', 'pending', 'rejected'] },
  { key: 'appIds', label: 'Applications involved', type: 'apps' },
  { key: 'description', label: 'Description', type: 'textarea' },
  { key: 'impact', label: 'Business impact', type: 'textarea' },
  { key: 'recommendation', label: 'Potential recommendation', type: 'textarea' },
  { key: 'capabilities', label: 'Capability IDs involved', type: 'lines' },
  { key: 'evidence', label: 'Evidence', type: 'evidence', hint: 'Required: similar names are not proof of duplication' },
];

export function Overlaps() {
  const m = useModel();
  const [params] = useSearchParams();
  const col = useCollection(FILES.overlaps, m.overlaps);
  const [sel, setSel] = useState<string[]>(() => (params.get('apps')?.split(',').filter((x) => m.apps[x]) ?? []));
  const [edit, setEdit] = useState<{ rec: Partial<Overlap>; isNew: boolean } | null>(null);
  const ref = useReveal<HTMLDivElement>();
  const candidates = m.appList.filter((a) => a.profile.portfolio !== 'external' || a.profile.features.length);
  const facets = sel.length >= 2 ? compareFacets(m, sel) : [];

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Landscape"
        title="Overlap and duplication"
        sub="Compare applications side by side, then record evidence-backed findings. Shared wording is a lead to investigate, never proof."
        actions={
          <button
            className="btn btn-primary"
            onClick={() => setEdit({ isNew: true, rec: { id: nextId('OVL', m.overlaps), kind: 'potential', confidence: 'medium', validation: 'pending', appIds: sel, capabilities: [], evidence: [] } })}
          >
            <Plus size={15} /> Record overlap
          </button>
        }
      />
      {edit && (
        <RecordEditor
          title={edit.isNew ? 'New overlap finding' : `${edit.rec.id}: ${edit.rec.title}`}
          fields={FIELDS}
          initial={edit.rec}
          isNew={edit.isNew}
          schema={Overlap}
          onSave={(rec) => col.upsert(rec, edit.isNew ? undefined : edit.rec.id)}
          onDelete={() => col.remove(edit.rec.id!)}
          onClose={() => setEdit(null)}
        />
      )}

      <div className="card reveal">
        <div className="card-head">
          <GitCompare size={16} color="var(--accent)" />
          <h3 className="card-title">Compare applications</h3>
          <span className="card-sub">Pick two to four</span>
        </div>
        <div className="card-body">
          <div className="row-wrap" style={{ marginBottom: 14 }}>
            {candidates.map((a) => (
              <button
                key={a.id}
                className={`filter-chip ${sel.includes(a.id) ? 'on' : ''}`}
                onClick={() => setSel(sel.includes(a.id) ? sel.filter((x) => x !== a.id) : sel.length < 4 ? [...sel, a.id] : sel)}
              >
                <AppTile app={a.profile} size={18} /> {a.id}
              </button>
            ))}
          </div>
          {sel.length < 2 ? (
            <Empty icon={GitCompare} title="Select at least two applications" />
          ) : (
            <div className="table-wrap">
              <table className="table compare">
                <thead>
                  <tr>
                    <th style={{ width: 170 }}>Facet</th>
                    {sel.map((id) => (
                      <th key={id}>
                        {id} · {m.apps[id].profile.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {facets.map((f) => (
                    <tr key={f.label}>
                      <td className="faint" style={{ fontWeight: 600, fontSize: 12 }}>
                        {f.label}
                        {f.shared.size > 0 && (
                          <div>
                            <Pill color="var(--st-amber)">{f.shared.size} shared</Pill>
                          </div>
                        )}
                      </td>
                      {sel.map((id) => (
                        <td key={id} style={{ minWidth: 200 }}>
                          {f.values[id].length === 0 ? (
                            <span className="undoc">Undocumented</span>
                          ) : (
                            <ul className="bullets" style={{ fontSize: 12.5, paddingLeft: 14 }}>
                              {f.values[id].map((v, k) => (
                                <li key={k} className={f.shared.has(norm(v)) ? 'shared' : ''}>
                                  {v}
                                </li>
                              ))}
                            </ul>
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="callout" style={{ ...tone('var(--st-sky)'), marginTop: 12 }}>
                <Info size={15} />
                <div className="muted">Highlighted items match exactly across applications. Confirm with documentation before recording an overlap.</div>
              </div>
            </div>
          )}
        </div>
      </div>

      <h3 className="card-title section-gap reveal" style={{ marginTop: 22 }}>
        Overlap register ({m.overlaps.length})
      </h3>
      <div className="grid g-3 section-gap">
        {m.overlaps.map((o) => (
          <article key={o.id} className="card card-pad card-link reveal" onClick={() => setEdit({ isNew: false, rec: o })}>
            <div className="row-wrap" style={{ marginBottom: 8 }}>
              <span className="chip chip-mono">{o.id}</span>
              <Pill color={KIND[o.kind].color}>{KIND[o.kind].label}</Pill>
            </div>
            <div className="app-name" style={{ fontSize: 15 }}>
              {o.title}
            </div>
            <div className="muted" style={{ fontSize: 13, margin: '6px 0 10px' }}>
              {o.description}
            </div>
            <div className="row-wrap">
              {o.appIds.map((a) => (
                <AppChip key={a} id={a} />
              ))}
              <span className="chip">{o.confidence} confidence</span>
              <span className="chip">{o.validation}</span>
            </div>
            {o.recommendation && <div style={{ fontSize: 12.5, marginTop: 10 }}>↳ {o.recommendation}</div>}
            <div className="faint" style={{ fontSize: 11.5, marginTop: 8 }}>
              Evidence: {o.evidence.map((e) => e.source).join('; ') || 'none recorded'}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
