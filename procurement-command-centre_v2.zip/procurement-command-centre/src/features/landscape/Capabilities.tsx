import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Blocks, Layers } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { Capability, FILES } from '../../domain/schemas';
import { PageHead, Empty, AppChip, Pill, ClassBadge, tone, useReveal, AppTile } from '../../components/ui';
import { RecordEditor, useCollection, nextId, CLASS_OPTIONS, type FieldSpec } from '../../components/RecordEditor';

const MATURITY = ['none', 'initial', 'developing', 'defined', 'optimised'] as const;
const IMPORTANCE_COLOR: Record<string, string> = { critical: 'var(--st-red)', high: 'var(--st-orange)', medium: 'var(--st-amber)', low: 'var(--st-sage)' };

export function Capabilities() {
  const m = useModel();
  const col = useCollection(FILES.capabilities, m.capabilities);
  const [edit, setEdit] = useState<{ rec: Partial<Capability>; isNew: boolean } | null>(null);
  const ref = useReveal<HTMLDivElement>();
  const fields: FieldSpec[] = [
    { key: 'id', label: 'Capability ID', readOnlyOnEdit: true },
    { key: 'name', label: 'Business capability', hint: 'A business function, not an app feature' },
    { key: 'stage', label: 'Lifecycle stage', type: 'select', options: m.lifecycle.map((s) => s.id), hint: m.lifecycle.length ? undefined : 'Define stages on the Lifecycle page first' },
    { key: 'owner', label: 'Business owner' },
    { key: 'importance', label: 'Importance', type: 'select', options: ['critical', 'high', 'medium', 'low'] },
    { key: 'maturity', label: 'Current maturity', type: 'select', options: [...MATURITY] },
    { key: 'classification', label: 'Classification', type: 'select', options: CLASS_OPTIONS },
    { key: 'description', label: 'Description', type: 'textarea' },
    { key: 'appIds', label: 'Supporting applications', type: 'apps' },
    { key: 'limitations', label: 'Current limitations', type: 'lines' },
    { key: 'evidence', label: 'Source references', type: 'evidence' },
  ];

  const groups = [...m.lifecycle.map((s) => ({ id: s.id, name: s.name })), { id: '', name: 'No stage assigned' }]
    .map((g) => ({ ...g, caps: m.capabilities.filter((c) => (g.id ? c.stage === g.id : !c.stage || !m.lifecycle.some((s) => s.id === c.stage))) }))
    .filter((g) => g.caps.length);
  const appsInMatrix = m.appList.filter((a) => m.capabilities.some((c) => c.appIds.includes(a.id)));

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Landscape"
        title="Business capabilities"
        sub="What the business can do, and which applications make it possible. A capability shared by several applications is a prompt to check for overlap, not proof of it."
        actions={
          <button className="btn btn-primary" onClick={() => setEdit({ isNew: true, rec: { id: nextId('CAP', m.capabilities), appIds: [], limitations: [], evidence: [], classification: 'confirmed' } })}>
            <Plus size={15} /> Add capability
          </button>
        }
      />
      {edit && (
        <RecordEditor
          title={edit.isNew ? 'New capability' : `${edit.rec.id}: ${edit.rec.name}`}
          fields={fields}
          initial={edit.rec}
          isNew={edit.isNew}
          schema={Capability}
          onSave={(rec) => col.upsert(rec, edit.isNew ? undefined : edit.rec.id)}
          onDelete={() => col.remove(edit.rec.id!)}
          onClose={() => setEdit(null)}
        />
      )}

      {m.capabilities.length === 0 ? (
        <div className="card card-pad">
          <Empty icon={Blocks} title="No capabilities recorded yet" />
        </div>
      ) : (
        <>
          {groups.map((g) => (
            <section key={g.id || 'none'} className="section-gap reveal">
              <div className="row" style={{ marginBottom: 10 }}>
                <Layers size={15} className="faint" />
                <h3 className="card-title">{g.name}</h3>
                <span className="faint" style={{ fontSize: 12 }}>
                  {g.caps.length}
                </span>
              </div>
              <div className="grid g-3">
                {g.caps.map((c) => {
                  const lvl = c.maturity ? MATURITY.indexOf(c.maturity) : -1;
                  return (
                    <article key={c.id} className="card card-link card-pad" onClick={() => setEdit({ isNew: false, rec: c })}>
                      <div className="row-wrap" style={{ marginBottom: 6 }}>
                        <span className="chip chip-mono">{c.id}</span>
                        {c.importance && <Pill color={IMPORTANCE_COLOR[c.importance]}>{c.importance}</Pill>}
                        <ClassBadge k={c.classification} />
                      </div>
                      <div className="app-name" style={{ fontSize: 15 }}>
                        {c.name}
                      </div>
                      {c.description && <div className="muted" style={{ fontSize: 13, marginTop: 4 }}>{c.description}</div>}
                      <div style={{ marginTop: 10 }}>
                        <div className="row faint" style={{ fontSize: 11.5, justifyContent: 'space-between' }}>
                          <span>Maturity</span>
                          <span>{c.maturity ?? 'not assessed'}</span>
                        </div>
                        <div className="maturity">
                          {MATURITY.slice(1).map((x, k) => (
                            <span key={x} className={k < lvl ? 'on' : ''} />
                          ))}
                        </div>
                      </div>
                      <div className="row-wrap" style={{ marginTop: 10 }}>
                        {c.appIds.map((a) => (
                          <AppChip key={a} id={a} />
                        ))}
                        {c.appIds.length > 1 && (
                          <Link to={`/landscape/overlaps?apps=${c.appIds.join(',')}`} className="chip" style={tone('var(--st-amber)')} onClick={(e) => e.stopPropagation()}>
                            Compare apps
                          </Link>
                        )}
                      </div>
                      {c.limitations.length > 0 && <div className="faint" style={{ fontSize: 12, marginTop: 8 }}>Limitations: {c.limitations.join('; ')}</div>}
                    </article>
                  );
                })}
              </div>
            </section>
          ))}

          <div className="card section-gap reveal">
            <div className="card-head">
              <h3 className="card-title">Capability coverage by application</h3>
              <span className="card-sub" style={{ marginLeft: 'auto' }}>
                Rows with two or more dots are candidates for the overlap analysis
              </span>
            </div>
            <div className="card-body table-wrap">
              <table className="table matrix-table">
                <thead>
                  <tr>
                    <th>Capability</th>
                    {appsInMatrix.map((a) => (
                      <th key={a.id} style={{ textAlign: 'center' }} title={a.profile.name}>
                        {a.id}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {m.capabilities.map((c) => (
                    <tr key={c.id}>
                      <td style={{ minWidth: 220 }}>
                        {c.name} {c.appIds.length > 1 && <span className="chip" style={{ ...tone('var(--st-amber)'), marginLeft: 6 }}>{c.appIds.length} apps</span>}
                      </td>
                      {appsInMatrix.map((a) => (
                        <td key={a.id} style={{ textAlign: 'center' }}>
                          {c.appIds.includes(a.id) ? <span className="cov-dot" /> : <span className="faint">·</span>}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="row-wrap section-gap faint" style={{ fontSize: 12 }}>
            {appsInMatrix.map((a) => (
              <span key={a.id} className="row" style={{ gap: 6 }}>
                <AppTile app={a.profile} size={18} /> {a.id} = {a.profile.name}
              </span>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
