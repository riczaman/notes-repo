import { useState } from 'react';
import { Plus } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { Gap, FILES } from '../../domain/schemas';
import { stageCoverage, COVERAGE } from '../../domain/analysis';
import { PageHead, AppChip, Pill, tone, useReveal } from '../../components/ui';
import { RecordEditor, useCollection, nextId, type FieldSpec } from '../../components/RecordEditor';
import type { CSSProperties } from 'react';

const KIND: Record<string, { label: string; color: string }> = {
  confirmed: { label: 'Confirmed gap', color: 'var(--st-red)' },
  potential: { label: 'Potential gap', color: 'var(--st-amber)' },
  'needs-validation': { label: 'Needs business validation', color: 'var(--st-sky)' },
  undocumented: { label: 'Undocumented area', color: 'var(--st-grey)' },
};
const PRIORITY: Record<string, string> = { high: 'var(--st-orange)', medium: 'var(--st-amber)', low: 'var(--st-sage)' };

export function Gaps() {
  const m = useModel();
  const col = useCollection(FILES.gaps, m.gaps);
  const [edit, setEdit] = useState<{ rec: Partial<Gap>; isNew: boolean } | null>(null);
  const [showClosed, setShowClosed] = useState(false);
  const ref = useReveal<HTMLDivElement>();
  const rows = stageCoverage(m);
  const fields: FieldSpec[] = [
    { key: 'id', label: 'Gap ID', readOnlyOnEdit: true },
    { key: 'kind', label: 'Classification', type: 'select', options: Object.keys(KIND), hint: 'Use "Undocumented" when the documents are silent' },
    { key: 'title', label: 'Title', wide: true },
    { key: 'priority', label: 'Priority', type: 'select', options: ['high', 'medium', 'low'] },
    { key: 'status', label: 'Status', type: 'select', options: ['open', 'in-progress', 'closed'] },
    { key: 'capability', label: 'Capability affected', hint: 'Capability ID or name' },
    { key: 'stage', label: 'Lifecycle stage', type: 'select', options: m.lifecycle.map((s) => s.id) },
    { key: 'owner', label: 'Owner' },
    { key: 'appIds', label: 'Current applications involved', type: 'apps' },
    { key: 'description', label: 'Description', type: 'textarea' },
    { key: 'impact', label: 'Business impact', type: 'textarea' },
    { key: 'missing', label: 'Missing functionality', type: 'textarea' },
    { key: 'solution', label: 'Potential solution', type: 'textarea' },
    { key: 'evidence', label: 'Supporting evidence', type: 'evidence' },
  ];
  const cols: { key: keyof (typeof rows)[number]; label: string; color: string }[] = [
    { key: 'mature', label: 'Mature capabilities', color: 'var(--st-green)' },
    { key: 'developing', label: 'Developing', color: 'var(--st-amber)' },
    { key: 'confirmedGaps', label: 'Confirmed gaps', color: 'var(--st-red)' },
    { key: 'potentialGaps', label: 'Potential or to validate', color: 'var(--st-orange)' },
    { key: 'unknownGaps', label: 'Undocumented areas', color: 'var(--st-grey)' },
  ];
  const max = Math.max(1, ...rows.flatMap((r) => cols.map((c) => Number(r[c.key]))));
  const list = m.gaps.filter((g) => showClosed || g.status !== 'closed').sort((a, b) => ['high', 'medium', 'low'].indexOf(a.priority) - ['high', 'medium', 'low'].indexOf(b.priority));

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Landscape"
        title="Capability gaps"
        sub="Where the ecosystem does not support the business, by lifecycle stage. A silent document is recorded as undocumented, never as missing."
        actions={
          <button className="btn btn-primary" onClick={() => setEdit({ isNew: true, rec: { id: nextId('GAP', m.gaps), kind: 'potential', priority: 'medium', status: 'open', appIds: [], evidence: [] } })}>
            <Plus size={15} /> Add gap
          </button>
        }
      />
      {edit && (
        <RecordEditor
          title={edit.isNew ? 'New gap' : `${edit.rec.id}: ${edit.rec.title}`}
          fields={fields}
          initial={edit.rec}
          isNew={edit.isNew}
          schema={Gap}
          onSave={(rec) => col.upsert(rec, edit.isNew ? undefined : edit.rec.id)}
          onDelete={() => col.remove(edit.rec.id!)}
          onClose={() => setEdit(null)}
        />
      )}

      <div className="card reveal">
        <div className="card-head">
          <h3 className="card-title">Coverage heatmap</h3>
          <span className="card-sub" style={{ marginLeft: 'auto' }}>
            {m.lifecycle.length ? 'Stages from the Lifecycle page' : 'Define lifecycle stages to split this by stage'}
          </span>
        </div>
        <div className="card-body table-wrap">
          <div className="heat" style={{ gridTemplateColumns: `minmax(180px, 1.3fr) repeat(${cols.length}, minmax(86px, 1fr)) 120px`, minWidth: 760 }}>
            <span />
            {cols.map((c) => (
              <span key={c.key} className="heat-head">
                {c.label}
              </span>
            ))}
            <span className="heat-head">Coverage</span>
            {rows.map((r) => (
              <div key={r.id} style={{ display: 'contents' }}>
                <span className="heat-app">{r.name}</span>
                {cols.map((c) => {
                  const v = Number(r[c.key]);
                  return (
                    <span key={c.key} className={`heat-cell ${v ? '' : 'zero'}`} style={{ ...tone(c.color), '--i': v ? 0.25 + (v / max) * 0.75 : 0 } as CSSProperties}>
                      {v}
                    </span>
                  );
                })}
                <span className="heat-cell" style={{ ...tone(COVERAGE[r.coverage].color), '--i': 0.55 } as CSSProperties} title={COVERAGE[r.coverage].hint}>
                  {COVERAGE[r.coverage].label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="row section-gap reveal" style={{ marginTop: 22 }}>
        <h3 className="card-title grow">Gap register ({list.length})</h3>
        <label className="check">
          <input type="checkbox" checked={showClosed} onChange={(e) => setShowClosed(e.target.checked)} /> Show closed
        </label>
      </div>
      <div className="grid g-3 section-gap">
        {list.map((g) => (
          <article key={g.id} className="card card-pad card-link reveal" onClick={() => setEdit({ isNew: false, rec: g })}>
            <div className="row-wrap" style={{ marginBottom: 8 }}>
              <span className="chip chip-mono">{g.id}</span>
              <Pill color={KIND[g.kind].color}>{KIND[g.kind].label}</Pill>
              <Pill color={PRIORITY[g.priority]}>{g.priority}</Pill>
              {g.status !== 'open' && <span className="chip">{g.status}</span>}
            </div>
            <div className="app-name" style={{ fontSize: 15 }}>
              {g.title}
            </div>
            <div className="muted" style={{ fontSize: 13, margin: '6px 0 10px' }}>
              {g.description}
            </div>
            {g.solution && <div style={{ fontSize: 12.5, marginBottom: 8 }}>↳ {g.solution}</div>}
            <div className="row-wrap">
              {g.appIds.map((a) => (
                <AppChip key={a} id={a} />
              ))}
              {g.capability && <span className="chip">{g.capability}</span>}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
