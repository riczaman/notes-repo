import { useState } from 'react';
import { Link } from 'react-router-dom';
import { z } from 'zod';
import { Plus, PencilLine, Route, ArrowRight } from 'lucide-react';
import { useData, useModel } from '../../store/DataProvider';
import { LifecycleStage, FILES } from '../../domain/schemas';
import { stageCoverage, COVERAGE, NO_STAGE } from '../../domain/analysis';
import { INTEGRATION_STATUS } from '../../domain/meta';
import { PageHead, Empty, AppChip, Pill, tone, useReveal } from '../../components/ui';
import { RecordEditor, type FieldSpec } from '../../components/RecordEditor';

type View = 'business' | 'apps' | 'capabilities' | 'integrations';
const VIEWS: { key: View; label: string }[] = [
  { key: 'business', label: 'Business lifecycle' },
  { key: 'apps', label: 'Applications' },
  { key: 'capabilities', label: 'Capabilities' },
  { key: 'integrations', label: 'Integrations and data flow' },
];

const StageForm = LifecycleStage.extend({ appIds: z.array(z.string()).default([]) });
type StageForm = z.infer<typeof StageForm>;

const FIELDS: FieldSpec[] = [
  { key: 'id', label: 'Stage ID', hint: 'Short code, e.g. INTAKE', readOnlyOnEdit: true },
  { key: 'name', label: 'Stage name' },
  { key: 'order', label: 'Order', type: 'number', hint: '1 = first stage, left-most' },
  { key: 'description', label: 'Description', type: 'textarea' },
  { key: 'appIds', label: 'Applications supporting this stage', type: 'apps', hint: 'Saved on each application profile' },
];

export function Lifecycle() {
  const m = useModel();
  const { save, toast } = useData();
  const [view, setView] = useState<View>('business');
  const [edit, setEdit] = useState<{ rec: Partial<StageForm>; isNew: boolean } | null>(null);
  const [focus, setFocus] = useState<string | null>(null);
  const ref = useReveal<HTMLDivElement>([view]);
  const rows = stageCoverage(m).filter((r) => r.id !== NO_STAGE);
  const multi = m.appList.filter((a) => a.profile.lifecycleStages.filter((s) => m.lifecycle.some((l) => l.id === s)).length > 1).map((a) => a.id);

  const saveStage = async (rec: StageForm, originalId?: string) => {
    const { appIds, ...stage } = rec;
    if (!originalId && m.lifecycle.some((s) => s.id === stage.id)) throw new Error(`Stage ${stage.id} already exists`);
    const list = originalId ? m.lifecycle.map((s) => (s.id === originalId ? stage : s)) : [...m.lifecycle, stage];
    const writes: { path: string; content: string }[] = [{ path: FILES.lifecycle, content: JSON.stringify(list.sort((a, b) => a.order - b.order), null, 2) + '\n' }];
    // Stage membership lives on each application profile (one fact, one place).
    for (const a of m.appList) {
      const has = a.profile.lifecycleStages.includes(stage.id);
      const want = appIds.includes(a.id);
      if (has === want) continue;
      const lifecycleStages = want ? [...a.profile.lifecycleStages, stage.id] : a.profile.lifecycleStages.filter((x) => x !== stage.id);
      writes.push({ path: FILES.profile(a.id), content: JSON.stringify({ ...a.profile, lifecycleStages }, null, 2) + '\n' });
    }
    await save(writes);
    toast(`Stage ${stage.name} saved`);
  };

  const deleteStage = async (id: string) => {
    const writes: { path: string; content: string }[] = [{ path: FILES.lifecycle, content: JSON.stringify(m.lifecycle.filter((s) => s.id !== id), null, 2) + '\n' }];
    for (const a of m.appList.filter((x) => x.profile.lifecycleStages.includes(id)))
      writes.push({ path: FILES.profile(a.id), content: JSON.stringify({ ...a.profile, lifecycleStages: a.profile.lifecycleStages.filter((x) => x !== id) }, null, 2) + '\n' });
    await save(writes);
    toast('Stage deleted');
  };

  const openEditor = (id?: string) => {
    const s = m.lifecycle.find((x) => x.id === id);
    setEdit(
      s
        ? { isNew: false, rec: { ...s, appIds: m.appList.filter((a) => a.profile.lifecycleStages.includes(s.id)).map((a) => a.id) } }
        : { isNew: true, rec: { order: (m.lifecycle.at(-1)?.order ?? 0) + 1, appIds: [] } },
    );
  };

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Landscape"
        title="Procurement lifecycle"
        sub="The end-to-end lifecycle, stage by stage. Stages come from your source documentation, so nothing is assumed until you add it."
        actions={
          <button className="btn btn-primary" onClick={() => openEditor()}>
            <Plus size={15} /> Add stage
          </button>
        }
      />
      {edit && (
        <RecordEditor
          title={edit.isNew ? 'New lifecycle stage' : `Stage: ${edit.rec.name}`}
          fields={FIELDS}
          initial={edit.rec}
          isNew={edit.isNew}
          schema={StageForm}
          onSave={(rec) => saveStage(rec, edit.isNew ? undefined : edit.rec.id)}
          onDelete={() => deleteStage(edit.rec.id!)}
          deleteWarning="Delete this stage? It is also removed from every application profile."
          onClose={() => setEdit(null)}
        />
      )}

      {m.lifecycle.length === 0 ? (
        <div className="card card-pad reveal">
          <Empty icon={Route} title="No lifecycle stages defined yet">
            Add the stages from your source documentation in order (for example from intake to payment). Then assign applications to each stage, and link capabilities and gaps to stages on their pages.
            <div style={{ marginTop: 12 }}>
              <button className="btn btn-primary" onClick={() => openEditor()}>
                <Plus size={14} /> Add the first stage
              </button>
            </div>
          </Empty>
        </div>
      ) : (
        <>
          <div className="row-wrap reveal" style={{ marginBottom: 16 }}>
            {VIEWS.map((v) => (
              <button key={v.key} className={`filter-chip ${view === v.key ? 'on' : ''}`} onClick={() => setView(v.key)}>
                {v.label}
              </button>
            ))}
            <span className="grow" />
            {Object.entries(COVERAGE).map(([k, c]) => (
              <span key={k} className="row faint" style={{ fontSize: 12, ...tone(c.color) }} title={c.hint}>
                <span className="pill-dot" /> {c.label}
              </span>
            ))}
          </div>

          <div className="lifecycle reveal" style={{ gridTemplateColumns: `repeat(${rows.length}, minmax(200px, 1fr))` }}>
            {rows.map((r, k) => {
              const c = COVERAGE[r.coverage];
              const stageApps = m.appList.filter((a) => a.profile.lifecycleStages.includes(r.id));
              const intsInto = m.integrations.filter((i) => stageApps.some((a) => a.id === i.target));
              return (
                <section key={r.id} className={`stage ${focus && focus !== r.id ? 'dim' : ''}`} style={tone(c.color)} onClick={() => setFocus(focus === r.id ? null : r.id)}>
                  <header className="stage-head">
                    <span className="stage-num">{k + 1}</span>
                    <div className="grow" style={{ minWidth: 0 }}>
                      <div className="stage-name">{r.name}</div>
                      <span className="mono faint" style={{ fontSize: 10.5 }}>
                        {r.id}
                      </span>
                    </div>
                    <button
                      className="btn btn-ghost icon-btn btn-sm"
                      aria-label="Edit stage"
                      onClick={(e) => {
                        e.stopPropagation();
                        openEditor(r.id);
                      }}
                    >
                      <PencilLine size={13} />
                    </button>
                  </header>
                  <div className="stage-cov">
                    <Pill color={c.color}>{c.label}</Pill>
                  </div>
                  <div className="stage-body">
                    {view === 'business' && (
                      <>
                        <div className="muted" style={{ fontSize: 12.5 }}>{m.lifecycle.find((s) => s.id === r.id)?.description ?? <span className="undoc">No description</span>}</div>
                        <div className="faint" style={{ fontSize: 12 }}>
                          {r.caps.length} capabilities · {stageApps.length} applications · {r.confirmedGaps + r.potentialGaps} open gaps
                        </div>
                      </>
                    )}
                    {view === 'apps' &&
                      (stageApps.length ? (
                        stageApps.map((a) => (
                          <Link key={a.id} to={`/apps/${a.id}`} className="stage-item" onClick={(e) => e.stopPropagation()}>
                            <AppChip id={a.id} /> <span className="grow">{a.profile.name}</span>
                            {multi.includes(a.id) && <span className="chip" title="Supports more than one stage">multi</span>}
                          </Link>
                        ))
                      ) : (
                        <span className="undoc">Undocumented</span>
                      ))}
                    {view === 'capabilities' &&
                      (r.caps.length ? (
                        r.caps.map((cap) => (
                          <Link key={cap.id} to="/landscape/capabilities" className="stage-item" onClick={(e) => e.stopPropagation()}>
                            <span className="grow">{cap.name}</span>
                            <span className="faint" style={{ fontSize: 11 }}>{cap.maturity ?? 'maturity ?'}</span>
                          </Link>
                        ))
                      ) : (
                        <span className="undoc">No capabilities linked</span>
                      ))}
                    {view === 'integrations' &&
                      (intsInto.length ? (
                        intsInto.map((i) => (
                          <div key={i.id} className="stage-item" style={tone(INTEGRATION_STATUS[i.status].color)}>
                            <span className="pill-dot" />
                            <span className="mono" style={{ fontSize: 11 }}>
                              {i.source} <ArrowRight size={10} /> {i.target}
                            </span>
                            <span className="faint grow" style={{ fontSize: 11.5 }}>{i.data.slice(0, 2).join(', ')}</span>
                          </div>
                        ))
                      ) : (
                        <span className="undoc">No documented inbound flows</span>
                      ))}
                  </div>
                </section>
              );
            })}
          </div>
          {rows.some((r) => r.coverage === 'undocumented') && (
            <div className="faint reveal" style={{ fontSize: 12.5, marginTop: 12 }}>
              Undocumented means the information has not been established yet. It is not treated as a gap.
            </div>
          )}
        </>
      )}
    </div>
  );
}
