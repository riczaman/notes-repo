import { useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { UploadCloud, ClipboardPaste, CheckCircle2, AlertTriangle, FileJson, FileText, History, RotateCcw, Copy } from 'lucide-react';
import { useData, useModel } from '../../store/DataProvider';
import { FILES, type ApplicationSummary, type ImportRecord, Application } from '../../domain/schemas';
import { parseInput, diffProfile, applyChanges, similarApps, type ParsedInput, type Change } from '../../domain/merge';
import { todayIso } from '../../domain/model';
import { PageHead, Pill, Empty, useReveal, tone, AppChip } from '../../components/ui';

type Stage = 'input' | 'review' | 'done';

const KIND_TONE: Record<string, { label: string; color: string }> = {
  added: { label: 'New', color: 'var(--st-green)' },
  'array-add': { label: 'Adds items', color: 'var(--st-teal)' },
  changed: { label: 'Changes value', color: 'var(--st-amber)' },
  conflict: { label: 'Conflict', color: 'var(--st-red)' },
};

const one = (x: unknown): string => {
  if (typeof x === 'string') return x;
  if (x && typeof x === 'object') {
    const o = x as Record<string, unknown>;
    if (o.source || o.title) return [o.source ?? o.title, o.file, o.ref, o.section, o.reviewed && `reviewed ${o.reviewed}`, o.confidence && `${o.confidence} confidence`].filter(Boolean).join(' · ');
    return JSON.stringify(x);
  }
  return String(x);
};
const show = (v: unknown) => {
  if (v == null || v === '') return '';
  if (Array.isArray(v)) return v.map(one).join(' | ');
  return one(v);
};

export function Ingestion() {
  const m = useModel();
  const { save, toast } = useData();
  const ref = useReveal<HTMLDivElement>();
  const [stage, setStage] = useState<Stage>('input');
  const [text, setText] = useState('');
  const [filename, setFilename] = useState('');
  const [over, setOver] = useState(false);
  const [parsed, setParsed] = useState<ParsedInput | null>(null);
  const [idx, setIdx] = useState(0);
  const [accepted, setAccepted] = useState<Record<string, Set<string>>>({});
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ImportRecord[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  const readFile = async (f: File) => {
    setFilename(f.name);
    setText(await f.text());
  };

  const analyse = () => {
    const p = parseInput(text, filename);
    setParsed(p);
    const acc: Record<string, Set<string>> = {};
    for (const s of p.summaries) acc[s.id] = new Set(diffProfile(m.apps[s.id]?.profile, s).filter((c) => c.defaultOn).map((c) => c.path));
    setAccepted(acc);
    setIdx(0);
    if (!p.errors.length && (p.summaries.length || p.markdown)) setStage('review');
  };

  const reviews = useMemo(
    () =>
      (parsed?.summaries ?? []).map((s) => {
        const existing = m.apps[s.id]?.profile;
        const changes = diffProfile(existing, s);
        const similar = similarApps(s, m.appList.map((a) => a.profile));
        let createErrors: string[] = [];
        if (!existing) {
          const r = Application.safeParse({ ...s });
          if (!r.success) createErrors = r.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`);
        }
        return { s, existing, changes, similar, createErrors };
      }),
    [parsed, m],
  );

  const commit = async () => {
    if (!parsed) return;
    setBusy(true);
    const writes: { path: string; content: string }[] = [];
    const records: ImportRecord[] = [];
    const stamp = new Date();
    const at = stamp.toISOString();
    const errors: string[] = [];
    reviews.forEach((r, k) => {
      const acc = accepted[r.s.id] ?? new Set();
      const picked = r.changes.filter((c) => acc.has(c.path));
      if (!picked.length) return;
      const importId = `IMP-${at.replace(/\D/g, '').slice(0, 14)}-${k + 1}`;
      const { profile, errors: e } = applyChanges(r.existing, r.s, r.changes, acc, importId, todayIso());
      if (e.length) return errors.push(`${r.s.id}: ${e.join('; ')}`);
      writes.push({ path: FILES.profile(r.s.id), content: JSON.stringify(profile, null, 2) + '\n' });
      writes.push({
        path: FILES.snapshot(importId),
        content: JSON.stringify({ importId, at, appId: r.s.id, before: r.existing ?? null, incoming: r.s, accepted: [...acc], after: profile }, null, 2) + '\n',
      });
      records.push({
        id: importId,
        at,
        appId: r.s.id,
        kind: parsed.kind,
        action: r.existing ? 'updated' : 'created',
        sourceVersion: r.s.summaryVersion,
        sourceDocuments: r.s.sourceDocuments ?? [],
        fieldsChanged: picked.map((c) => c.path),
        previousImport: r.existing?.meta.lastImport,
        snapshot: FILES.snapshot(importId),
      });
    });
    if (parsed.markdown) {
      const md = parsed.markdown;
      if (!m.apps[md.appId] && !reviews.some((r) => r.s.id === md.appId)) errors.push(`No application ${md.appId}. Import its JSON profile first.`);
      else {
        const slug = md.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48) || 'summary';
        const path = `data/apps/${md.appId}/docs/${todayIso()}-${slug}.md`;
        writes.push({ path, content: md.raw + '\n' });
        records.push({
          id: `IMP-${at.replace(/\D/g, '').slice(0, 14)}-md`,
          at,
          appId: md.appId,
          kind: 'markdown',
          action: 'document-added',
          sourceDocuments: [],
          fieldsChanged: [path.split('/').pop()!],
        });
      }
    }
    if (errors.length) {
      toast(errors.join(' | '), 'error');
      setBusy(false);
      return;
    }
    if (!writes.length) {
      toast('Nothing selected to import', 'error');
      setBusy(false);
      return;
    }
    writes.push({ path: FILES.imports, content: JSON.stringify([...records, ...m.imports], null, 2) + '\n' });
    try {
      await save(writes);
      setResult(records);
      setStage('done');
      toast(`Imported ${records.length} change set${records.length > 1 ? 's' : ''}`);
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };

  const reset = () => {
    setStage('input');
    setText('');
    setFilename('');
    setParsed(null);
    setResult([]);
  };

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Landscape"
        title="Data ingestion"
        sub="Paste or drop the summary your research agent produced. Nothing is written until you approve each change, and every import keeps a before and after snapshot."
        actions={
          <button className="btn" onClick={() => navigator.clipboard?.writeText(TEMPLATE).then(() => toast('JSON template copied'))}>
            <Copy size={14} /> Copy JSON template
          </button>
        }
      />
      <div className="steps reveal">
        {['Provide summary', 'Review changes', 'Done'].map((l, k) => (
          <span key={l} className="row">
            {k > 0 && <span className="step-sep" />}
            <span className={`step ${['input', 'review', 'done'].indexOf(stage) >= k ? 'on' : ''}`}>
              <span className="n">{k + 1}</span>
              {l}
            </span>
          </span>
        ))}
      </div>

      {stage === 'input' && (
        <div className="grid g-wide">
          <div className="card card-pad reveal stack">
            <div
              className={`drop ${over ? 'over' : ''}`}
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => {
                e.preventDefault();
                setOver(true);
              }}
              onDragLeave={() => setOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setOver(false);
                const f = e.dataTransfer.files[0];
                if (f) readFile(f);
              }}
            >
              <UploadCloud size={30} color="var(--accent)" />
              <div style={{ fontWeight: 600, marginTop: 8 }}>Drop a .json or .md file, or click to choose</div>
              <div className="faint" style={{ fontSize: 12.5, marginTop: 4 }}>
                {filename ? `Loaded ${filename}` : 'JSON for structured profiles, Markdown for narrative summaries'}
              </div>
              <input ref={fileRef} type="file" accept=".json,.md,.markdown,.txt" hidden onChange={(e) => e.target.files?.[0] && readFile(e.target.files[0])} />
            </div>
            <label>
              <span className="field-label">
                <ClipboardPaste size={12} style={{ verticalAlign: -1 }} /> Or paste here
              </span>
              <textarea className="textarea" rows={14} style={{ width: '100%' }} placeholder='{ "id": "USFF", "summaryVersion": "2026-11-08.1", ... }' value={text} onChange={(e) => setText(e.target.value)} spellCheck={false} />
            </label>
            {parsed && parsed.errors.length > 0 && (
              <div className="callout" style={tone('var(--st-red)')}>
                <AlertTriangle size={16} />
                <div>
                  <b>Validation failed. Fix these and try again:</b>
                  {parsed.errors.map((e) => (
                    <div key={e} className="mono" style={{ fontSize: 12 }}>
                      {e}
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="row" style={{ justifyContent: 'flex-end' }}>
              <button className="btn btn-primary" disabled={!text.trim()} onClick={analyse}>
                Validate and preview
              </button>
            </div>
          </div>
          <div className="stack">
            <div className="card card-pad reveal">
              <h3 className="card-title" style={{ marginBottom: 10 }}>How matching works</h3>
              <ul className="bullets">
                <li>Records match on <b>id</b> only. A similar name raises a warning, never a merge.</li>
                <li>Empty values never overwrite existing data.</li>
                <li>Lists merge: new items are added, nothing is removed.</li>
                <li>A classification downgrade (confirmed to unverified) is flagged as a conflict and left unticked.</li>
                <li>Markdown needs front matter with <span className="mono">app: ID</span>. It is saved as a document; any profile fields in the front matter are diffed like JSON.</li>
              </ul>
            </div>
            <div className="card card-pad reveal">
              <h3 className="card-title" style={{ marginBottom: 10 }}>For your research agent</h3>
              <div className="muted" style={{ fontSize: 13, lineHeight: 1.6 }}>
                Give the agent <span className="mono">docs/RESEARCH_AGENT_PROMPT.md</span> and <span className="mono">schemas/application-summary.schema.json</span>. It returns one JSON file per application, ready to drop here.
              </div>
            </div>
            <ImportHistory />
          </div>
        </div>
      )}

      {stage === 'review' && parsed && (
        <div className="stack">
          {parsed.warnings.map((w) => (
            <div key={w} className="callout reveal" style={tone('var(--st-amber)')}>
              <AlertTriangle size={16} />
              <div>{w}</div>
            </div>
          ))}
          {reviews.length > 1 && (
            <div className="row-wrap reveal">
              {reviews.map((r, k) => (
                <button key={r.s.id} className={`filter-chip ${idx === k ? 'on' : ''}`} onClick={() => setIdx(k)}>
                  {r.s.id} <span className="faint">{r.existing ? 'update' : 'new'}</span>
                </button>
              ))}
            </div>
          )}
          {reviews[idx] && (
            <ReviewCard
              r={reviews[idx]}
              acc={accepted[reviews[idx].s.id] ?? new Set()}
              onToggle={(path) => {
                const id = reviews[idx].s.id;
                const next = new Set(accepted[id] ?? []);
                if (next.has(path)) next.delete(path);
                else next.add(path);
                setAccepted({ ...accepted, [id]: next });
              }}
            />
          )}
          {parsed.markdown && (
            <div className="card card-pad reveal">
              <div className="row">
                <FileText size={18} color="var(--accent)" />
                <div className="grow">
                  <b>{parsed.markdown.title}</b>
                  <div className="faint" style={{ fontSize: 12.5 }}>
                    Saved to <span className="mono">data/apps/{parsed.markdown.appId}/docs/</span> and shown under Documents and history
                  </div>
                </div>
                <AppChip id={parsed.markdown.appId} />
              </div>
            </div>
          )}
          <div className="row reveal" style={{ justifyContent: 'flex-end' }}>
            <button className="btn" onClick={() => setStage('input')}>
              Back
            </button>
            <button className="btn btn-primary" disabled={busy || reviews.some((r) => !r.existing && r.createErrors.length > 0)} onClick={commit}>
              <CheckCircle2 size={15} /> Approve and apply
            </button>
          </div>
        </div>
      )}

      {stage === 'done' && (
        <div className="card card-pad reveal" style={{ textAlign: 'center' }}>
          <CheckCircle2 size={38} color="var(--st-green)" />
          <h2 style={{ fontFamily: 'var(--font-display)', margin: '10px 0 4px' }}>Import applied</h2>
          <div className="muted">The landscape, directory and map now read the updated records.</div>
          <div className="row-wrap" style={{ justifyContent: 'center', margin: '16px 0' }}>
            {result.map((r) => (
              <Link key={r.id} to={`/apps/${r.appId}/profile`} className="chip chip-mono">
                {r.appId} · {r.action}
              </Link>
            ))}
          </div>
          <button className="btn" onClick={reset}>
            <RotateCcw size={14} /> Import another
          </button>
        </div>
      )}
    </div>
  );
}

function ReviewCard({
  r,
  acc,
  onToggle,
}: {
  r: { s: ApplicationSummary; existing?: Application; changes: Change[]; similar: Application[]; createErrors: string[] };
  acc: Set<string>;
  onToggle: (p: string) => void;
}) {
  const counts = r.changes.reduce<Record<string, number>>((o, c) => ({ ...o, [c.kind]: (o[c.kind] ?? 0) + 1 }), {});
  return (
    <div className="card reveal">
      <div className="card-head" style={{ flexWrap: 'wrap' }}>
        <FileJson size={18} color="var(--accent)" />
        <h3 className="card-title">
          {r.s.name ?? r.existing?.name ?? r.s.id} <span className="mono faint">{r.s.id}</span>
        </h3>
        <Pill color={r.existing ? 'var(--st-sky)' : 'var(--st-green)'}>{r.existing ? 'Existing application: update' : 'New application'}</Pill>
        {r.s.summaryVersion && <span className="chip">v{r.s.summaryVersion}</span>}
        <span className="grow" />
        {Object.entries(counts).map(([k, n]) => (
          <Pill key={k} color={KIND_TONE[k].color}>
            {n} {KIND_TONE[k].label.toLowerCase()}
          </Pill>
        ))}
      </div>
      <div className="card-body stack">
        {r.similar.length > 0 && (
          <div className="callout" style={tone('var(--st-amber)')}>
            <AlertTriangle size={16} />
            <div>
              <b>Possible duplicate.</b> Name or alias resembles {r.similar.map((a) => `${a.name} (${a.id})`).join(', ')}. IDs differ, so this will not merge. If it is the same application, change the incoming id to match.
            </div>
          </div>
        )}
        {r.createErrors.length > 0 && (
          <div className="callout" style={tone('var(--st-red)')}>
            <AlertTriangle size={16} />
            <div>
              <b>A new application needs these fields:</b>
              {r.createErrors.map((e) => (
                <div key={e} className="mono" style={{ fontSize: 12 }}>
                  {e}
                </div>
              ))}
            </div>
          </div>
        )}
        {r.changes.length === 0 ? (
          <Empty icon={CheckCircle2} title="No new information">Everything in this summary already matches the record.</Empty>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th style={{ width: 36 }}>Apply</th>
                  <th>Field</th>
                  <th>Change</th>
                  <th>Existing</th>
                  <th>Incoming</th>
                </tr>
              </thead>
              <tbody>
                {r.changes.map((c) => (
                  <tr key={c.path} className="diff-row">
                    <td>
                      <input type="checkbox" checked={acc.has(c.path)} onChange={() => onToggle(c.path)} style={{ accentColor: 'var(--accent)' }} aria-label={`Apply ${c.path}`} />
                    </td>
                    <td className="mono">{c.path}</td>
                    <td>
                      <Pill color={KIND_TONE[c.kind].color}>{KIND_TONE[c.kind].label}</Pill>
                    </td>
                    <td>
                      <div className={`diff-val ${c.kind === 'changed' || c.kind === 'conflict' ? 'before' : 'faint'}`}>{c.kind === 'array-add' ? `${(c.before as unknown[]).length} existing items` : show(c.before) || <span className="undoc">Empty</span>}</div>
                    </td>
                    <td>
                      <div className="diff-val after">
                        {c.kind === 'array-add' ? (
                          <>
                            {(c.additions ?? []).map((x, k) => (
                              <div key={k}>
                                <span className="add-mark">+ </span>
                                {show(x)}
                              </div>
                            ))}
                          </>
                        ) : (
                          show(c.after)
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function ImportHistory() {
  const m = useModel();
  return (
    <div className="card reveal">
      <div className="card-head">
        <History size={16} color="var(--text-3)" />
        <h3 className="card-title">Import history</h3>
        <span className="card-sub">{m.imports.length}</span>
      </div>
      <div className="card-body">
        {m.imports.length === 0 ? (
          <div className="faint" style={{ fontSize: 13 }}>No imports yet. Seed data came from your notes and the Oct 20 deck.</div>
        ) : (
          m.imports.slice(0, 8).map((x) => (
            <div key={x.id} className="entry" style={{ paddingBottom: 8 }}>
              <span className="entry-dot" />
              <div>
                <div className="row">
                  <AppChip id={x.appId} /> <b style={{ fontSize: 13 }}>{x.action}</b>
                </div>
                <div className="faint" style={{ fontSize: 12 }}>
                  {new Date(x.at).toLocaleString()} · {x.fieldsChanged.length} field{x.fieldsChanged.length === 1 ? '' : 's'}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

const TEMPLATE = JSON.stringify(
  {
    id: 'APPID',
    summaryVersion: 'YYYY-MM-DD.1',
    name: 'Application name',
    aliases: [],
    category: 'web-app | automation | data-pipeline | saas | ai-model | platform | reporting | legacy-app',
    portfolio: 'owned | supported | external',
    status: 'live | in-delivery | onboarding | planned | retiring | retired',
    summary: 'One line: what it does and for whom',
    purpose: '',
    owners: { business: '', technical: '', support: '' },
    features: [],
    processes: [],
    userGroups: [],
    tech: { stack: [], hosting: '', apis: [], dataSources: [], dataDestinations: [], dependencies: [], auth: '' },
    ops: { supportModel: '', knownIssues: [], limitations: [], techDebt: [], improvements: [], compliance: [] },
    classification: 'confirmed | inferred | proposed | unverified | undocumented',
    sourceDocuments: [{ source: 'Document title', file: 'file.xlsx', ref: 'Sheet or page', section: '', url: '', reviewed: 'YYYY-MM-DD', confidence: 'high' }],
  },
  null,
  2,
);
