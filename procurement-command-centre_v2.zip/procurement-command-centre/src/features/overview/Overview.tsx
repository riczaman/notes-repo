import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import {
  Boxes, Rocket, HelpCircle, AlertTriangle, ShieldAlert, Star, Target, CheckCircle2, ArrowRight, KanbanSquare, CalendarClock, AlertOctagon,
} from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { allActions, allDates, allDecisions, allRisks, isPending, today, fmtDate, isMine } from '../../domain/model';
import { STATUS, STATUS_ORDER, noteTone, impactRank } from '../../domain/meta';
import type { Initiative } from '../../domain/schemas';
import { Kpi, PageHead, StatusPill, AppChip, Pill, tone, useReveal, Empty, AppTile } from '../../components/ui';
import { InitiativeDrawer } from '../workboard/InitiativeDrawer';

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
};

export function Overview() {
  const m = useModel();
  const nav = useNavigate();
  const [open, setOpen] = useState<Initiative | null>(null);
  const ref = useReveal<HTMLDivElement>();

  const d = useMemo(() => {
    const active = m.initiatives.filter((i) => i.status !== 'done');
    const risks = allRisks(m);
    const decisions = allDecisions(m).filter((x) => isPending(x.status));
    const actions = allActions(m);
    const owned = m.appList.filter(isMine);
    const hot = active.filter((i) => i.status === 'at-risk' || i.status === 'blocked');
    const high = risks.filter((r) => impactRank(r.impact) >= 3);
    const byStatus = STATUS_ORDER.map((s) => ({ key: s, name: STATUS[s].label, value: m.initiatives.filter((i) => i.status === s).length, color: STATUS[s].color })).filter((x) => x.value);
    return { active, risks, decisions, actions, owned, hot, high, byStatus };
  }, [m]);

  const focus = m.initiatives.filter((i) => i.leadershipFocus);
  const headline = `${d.active.length} active initiatives across ${m.workstreams.length} workstreams. ${d.hot.length} at risk or blocked, ${d.decisions.length} decisions waiting.`;

  return (
    <div ref={ref}>
      <PageHead
        eyebrow={
          <>
            {greeting()}, Ricky · {new Date().toLocaleDateString('en-CA', { weekday: 'long', month: 'long', day: 'numeric' })}
          </>
        }
        title="Procurement Technology Portfolio"
        sub={headline}
        actions={
          <Link to="/workboard" className="btn">
            <KanbanSquare size={15} /> Open workboard
          </Link>
        }
      />

      <div className="grid g-kpi">
        <Kpi icon={Boxes} label="Applications" value={d.owned.length} color="var(--st-teal)" foot={`${m.appList.length - d.owned.length} connected external systems`} />
        <Kpi icon={Rocket} label="Active initiatives" value={d.active.length} color="var(--st-sky)" foot={`${m.initiatives.filter((i) => i.status === 'in-delivery').length} in delivery now`} />
        <Kpi icon={HelpCircle} label="Decisions pending" value={d.decisions.length} color="var(--st-amber)" foot="From app notes, section 05" />
        <Kpi icon={AlertTriangle} label="At risk or blocked" value={d.hot.length} color="var(--st-orange)" foot={d.hot.map((h) => h.appIds[0]).filter((v, i, a) => a.indexOf(v) === i).join(' · ')} />
        <Kpi icon={ShieldAlert} label="High-impact risks" value={d.high.length} color="var(--st-red)" foot={`${d.risks.length} open risks and issues`} />
      </div>

      <div className="grid g-hero section-gap">
        {focus.map((f) => (
          <Spotlight key={f.id} i={f} onOpen={() => setOpen(f)} />
        ))}
        <div className="card reveal">
          <div className="card-head">
            <h3 className="card-title">Status mix</h3>
            <span className="card-sub">{m.initiatives.length} initiatives</span>
          </div>
          <div className="card-body donut-grid">
            <div style={{ position: 'relative', height: 180 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={d.byStatus} dataKey="value" nameKey="name" innerRadius={58} outerRadius={84} paddingAngle={2.5} stroke="none" animationDuration={900}>
                    {d.byStatus.map((s) => (
                      <Cell key={s.key} fill={s.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ payload }) =>
                      payload?.[0] ? (
                        <div className="chart-tip">
                          {payload[0].name}: <b>{payload[0].value as number}</b>
                        </div>
                      ) : null
                    }
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="donut-center">
                <div>
                  <b>{d.active.length}</b>
                  <span>active</span>
                </div>
              </div>
            </div>
            <div className="legend-list">
              {d.byStatus.map((s) => (
                <Link to={`/workboard?status=${s.key}`} key={s.key} className="li" style={tone(s.color)}>
                  <span className="sw" />
                  {s.name}
                  <span className="v">{s.value}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      <Timeline />

      <div className="grid g-2 section-gap">
        {m.workstreams.map((w) => {
          const items = m.initiatives.filter((i) => i.workstream === w.id).sort((a, b) => STATUS[a.status].order - STATUS[b.status].order);
          return (
            <div key={w.id} className="card lane reveal">
              <div className="lane-head">
                <span className="lane-name">{w.name}</span>
                <span className="faint" style={{ fontSize: 12 }}>
                  {items.length} initiatives
                </span>
                <Link to={`/workboard?ws=${w.id}`} className="btn btn-ghost btn-sm" style={{ marginLeft: 'auto' }}>
                  Board <ArrowRight size={13} />
                </Link>
              </div>
              <div className="stack-bar" style={{ marginBottom: 10 }}>
                {STATUS_ORDER.map((s) => {
                  const n = items.filter((i) => i.status === s).length;
                  return n ? <span key={s} style={{ flexGrow: n, background: STATUS[s].color }} title={`${STATUS[s].label}: ${n}`} /> : null;
                })}
              </div>
              <div>
                {items.slice(0, 6).map((i) => (
                  <div key={i.id} className="mini-row" onClick={() => setOpen(i)}>
                    <span className="pill-dot" style={{ background: STATUS[i.status].color }} />
                    <span className="t">
                      {i.leadershipFocus && <Star size={12} className="star" style={{ marginRight: 5, verticalAlign: -1 }} />}
                      {i.title}
                    </span>
                    <span className="row" style={{ gap: 5 }}>
                      {i.appIds.slice(0, 2).map((a) => (
                        <AppChip key={a} id={a} />
                      ))}
                    </span>
                  </div>
                ))}
                {items.length > 6 && (
                  <Link to={`/workboard?ws=${w.id}`} className="faint" style={{ fontSize: 12.5, padding: '6px 6px 0', display: 'block' }}>
                    +{items.length - 6} more on the board
                  </Link>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid g-wide section-gap">
        <div className="card reveal">
          <div className="card-head">
            <AlertOctagon size={16} color="var(--st-orange)" />
            <h3 className="card-title">Top risks and issues</h3>
            <span className="card-sub" style={{ marginLeft: 'auto' }}>
              From section 04 of every app's notes
            </span>
          </div>
          <div className="card-body table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>App</th>
                  <th>Description</th>
                  <th>Impact</th>
                  <th>Mitigation</th>
                </tr>
              </thead>
              <tbody>
                {d.high.slice(0, 8).map((r) => (
                  <tr key={r.appId + r.id} style={{ cursor: 'pointer' }} onClick={() => nav(`/apps/${r.appId}/notes#risks`)}>
                    <td>
                      <div className="stack" style={{ gap: 5, alignItems: 'flex-start' }}>
                        <AppChip id={r.appId} />
                        <span className="faint" style={{ fontSize: 11.5 }}>{r.type}</span>
                      </div>
                    </td>
                    <td style={{ minWidth: 220 }}>{r.description}</td>
                    <td>
                      <Pill color={noteTone(r.impact)?.color ?? 'var(--st-grey)'}>{r.impact}</Pill>
                    </td>
                    <td className="muted" style={{ fontSize: 12.5, minWidth: 150 }}>
                      {r.mitigation}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card reveal">
          <div className="card-head">
            <HelpCircle size={16} color="var(--st-amber)" />
            <h3 className="card-title">Decisions needed</h3>
            <span className="card-sub" style={{ marginLeft: 'auto' }}>
              {d.decisions.length} pending
            </span>
          </div>
          <div className="card-body stack" style={{ gap: 4 }}>
            {d.decisions.length === 0 && <Empty title="No pending decisions" />}
            {d.decisions.map((x, k) => (
              <div key={k} role="link" tabIndex={0} onClick={() => nav(`/apps/${x.appId}/notes#decisions`)} className="mini-row" style={{ gridTemplateColumns: 'auto minmax(0,1fr)', alignItems: 'start' }}>
                <AppChip id={x.appId} />
                <div>
                  <div style={{ fontSize: 13, lineHeight: 1.45 }}>{x.decision}</div>
                  <div className="faint" style={{ fontSize: 11.5, marginTop: 2 }}>
                    {x.by && <>Owner: {x.by} · </>}raised {fmtDate(x.date)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Heatmap />

      {open && <InitiativeDrawer initiative={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

function Spotlight({ i, onOpen }: { i: Initiative; onOpen: () => void }) {
  const m = useModel();
  const risks = allRisks(m).filter((r) => r.initiative === i.id);
  const app = m.apps[i.appIds[0]];
  return (
    <div className="card spot card-link reveal" style={tone(STATUS[i.status].color)} onClick={onOpen}>
      <div className="card-body" style={{ paddingTop: 18 }}>
        <div className="row-wrap">
          <Pill color="var(--st-amber)" dot={false}>
            <Star size={11} /> Leadership focus
          </Pill>
          <StatusPill status={i.status} />
          <span className="chip chip-mono">{i.id}</span>
        </div>
        <div className="row" style={{ gap: 14, marginTop: 10, alignItems: 'flex-start' }}>
          {app && <AppTile app={app.profile} size={46} />}
          <div className="grow">
            <div className="spot-title">{i.title}</div>
            <div className="muted" style={{ fontSize: 13.5, lineHeight: 1.55 }}>
              {i.summary}
            </div>
          </div>
        </div>
        <div className="grid spot-grid">
          <ul className="check-list">
            {i.progress.slice(0, 4).map((p, k) => (
              <li key={k}>
                <CheckCircle2 size={15} color="var(--st-teal)" />
                {p}
              </li>
            ))}
          </ul>
          <div className="stack" style={{ gap: 9 }}>
            <div className="callout" style={tone('var(--accent)')}>
              <Target size={15} />
              <div>
                <b>Target</b>
                <div className="muted">{i.target.label}</div>
              </div>
            </div>
            <div className="callout" style={tone('var(--st-orange)')}>
              <AlertTriangle size={15} />
              <div>
                <b>{risks.length} open risks and issues</b>
                <div className="muted">{risks.filter((r) => impactRank(r.impact) >= 3).length} rated high or critical</div>
              </div>
            </div>
          </div>
        </div>
        {i.decision && (
          <div className="callout" style={{ ...tone('var(--st-amber)'), marginTop: 12 }}>
            <HelpCircle size={15} />
            <div>
              <b>Decision:</b> <span className="muted">{i.decision}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/** Horizontal timeline: hard dates from notes section 01 plus dated initiative targets. */
function Timeline() {
  const m = useModel();
  const start = today();
  start.setDate(start.getDate() - 10);
  const end = new Date(start);
  end.setMonth(end.getMonth() + 5);
  const span = end.getTime() - start.getTime();
  const pct = (d: Date) => ((d.getTime() - start.getTime()) / span) * 100;

  const items = allDates(m).filter((x) => x.when >= start && x.when <= end);
  // Greedy lane packing on each label's real span (labels right of 62% extend leftwards).
  const LABEL = 24;
  const lanes: [number, number][][] = [];
  const placed = items.map((x) => {
    const p = pct(x.when);
    const span: [number, number] = p > 62 ? [p - LABEL, p + 1] : [p - 1, p + LABEL];
    let lane = lanes.findIndex((l) => l.every(([a, b]) => span[1] <= a || span[0] >= b));
    if (lane === -1) {
      lane = lanes.length;
      lanes.push([]);
    }
    lanes[lane].push(span);
    return { ...x, p, lane };
  });
  const months: Date[] = [];
  const cur = new Date(start.getFullYear(), start.getMonth() + 1, 1);
  while (cur <= end) {
    months.push(new Date(cur));
    cur.setMonth(cur.getMonth() + 1);
  }
  const color = (s: string) => (STATUS as Record<string, { color: string }>)[s]?.color ?? noteTone(s)?.color ?? 'var(--st-grey)';

  return (
    <div className="card section-gap reveal">
      <div className="card-head">
        <CalendarClock size={16} color="var(--accent)" />
        <h3 className="card-title">Upcoming dates</h3>
        <span className="card-sub" style={{ marginLeft: 'auto' }}>
          Next 5 months · square markers are month-precision dates
        </span>
      </div>
      <div className="card-body">
        {placed.length === 0 ? (
          <Empty title="No dated milestones in the next 5 months">Add hard dates to section 01 of an app's notes.</Empty>
        ) : (
          <div className="timeline">
            <div className="tl-axis">
              {months.map((mo) => (
                <span key={mo.toISOString()} className="tl-month" style={{ left: `${pct(mo)}%` }}>
                  {mo.toLocaleDateString('en-CA', { month: 'short' })}
                  {mo.getMonth() === 0 ? ` ${mo.getFullYear()}` : ''}
                </span>
              ))}
            </div>
            <div className="tl-track" style={{ height: lanes.length * 34 + 14 }}>
              <div className="tl-today" style={{ left: `${pct(today())}%` }}>
                <span>TODAY</span>
              </div>
              {placed.map((x, k) => (
                <Link
                  key={k}
                  to={`/apps/${x.appId}/notes#dates`}
                  className={`tl-item ${x.p > 62 ? 'flip' : ''}`}
                  style={{ left: `${x.p}%`, top: 14 + x.lane * 34, ...tone(color(x.status)) }}
                  title={`${x.date} · ${x.appId} · ${x.label}${x.notes ? ` · ${x.notes}` : ''}`}
                >
                  <span className={`tl-dot ${x.precision === 'month' ? 'month' : ''}`} />
                  <span className="tl-label">
                    <b>{x.appId}</b> {x.label} <span className="mono faint">{fmtDate(x.date)}</span>
                  </span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/** Workload heatmap: where the work sits, per application. */
function Heatmap() {
  const m = useModel();
  const risks = allRisks(m);
  const actions = allActions(m);
  const decisions = allDecisions(m).filter((x) => isPending(x.status));
  const owned = m.appList.filter(isMine);
  const cols = [
    { key: 'init', label: 'Active initiatives', color: 'var(--st-sky)', get: (id: string) => m.initiatives.filter((i) => i.status !== 'done' && i.appIds[0] === id).length },
    { key: 'act', label: 'Open actions', color: 'var(--st-teal)', get: (id: string) => actions.filter((a) => a.appId === id).length },
    { key: 'risk', label: 'High risks', color: 'var(--st-orange)', get: (id: string) => risks.filter((r) => r.appId === id && impactRank(r.impact) >= 3).length },
    { key: 'dec', label: 'Pending decisions', color: 'var(--st-amber)', get: (id: string) => decisions.filter((x) => x.appId === id).length },
  ];
  const values = owned.map((a) => cols.map((c) => c.get(a.id)));
  const max = cols.map((_, j) => Math.max(1, ...values.map((v) => v[j])));

  return (
    <div className="card section-gap reveal">
      <div className="card-head">
        <h3 className="card-title">Workload heatmap</h3>
        <span className="card-sub" style={{ marginLeft: 'auto' }}>
          Where the open work sits. Click a row to open the app
        </span>
      </div>
      <div className="card-body table-wrap">
        <div className="heat" style={{ gridTemplateColumns: `minmax(200px, 1.3fr) repeat(${cols.length}, minmax(90px, 1fr))`, minWidth: 640 }}>
          <span />
          {cols.map((c) => (
            <span key={c.key} className="heat-head">
              {c.label}
            </span>
          ))}
          {owned.map((a, r) => (
            <Row key={a.id} id={a.id}>
              <Link to={`/apps/${a.id}`} className="heat-app">
                <AppTile app={a.profile} size={26} />
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.profile.name}</span>
              </Link>
              {cols.map((c, j) => {
                const v = values[r][j];
                return (
                  <Link
                    key={c.key}
                    to={`/apps/${a.id}${c.key === 'init' ? '' : '/notes'}`}
                    className={`heat-cell ${v ? '' : 'zero'}`}
                    style={{ ...tone(c.color), '--i': v ? 0.25 + (v / max[j]) * 0.75 : 0 } as React.CSSProperties}
                  >
                    {v}
                  </Link>
                );
              })}
            </Row>
          ))}
        </div>
      </div>
    </div>
  );
}

const Row = ({ children }: { id: string; children: React.ReactNode }) => <>{children}</>;
