import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, FileText, ArrowRight, ArrowLeftRight, Sparkles, NotebookPen, LayoutGrid, Fingerprint, History, Network } from 'lucide-react';
import { useModel } from '../../store/DataProvider';
import { allRisks, allActions, allDecisions, isPending, fmtDate } from '../../domain/model';
import { APP_STATUS, INTEGRATION_STATUS, STATUS, impactRank, noteTone } from '../../domain/meta';
import type { Initiative } from '../../domain/schemas';
import { AppTile, Pill, HealthDot, StatusPill, AppChip, ClassBadge, Empty, tone, useReveal, CATEGORY, Md, AiTag } from '../../components/ui';
import { InitiativeDrawer } from '../workboard/InitiativeDrawer';
import { NotesView } from '../notes/NotesView';
import { AiIdeas } from '../ai/AiIdeas';
import { ProfileView } from './ProfileView';
import { useExportContext } from '../../components/Shell';

const TABS = [
  { key: 'overview', label: 'Overview', icon: LayoutGrid },
  { key: 'notes', label: 'Notes', icon: NotebookPen },
  { key: 'ai', label: 'AI ideas', icon: Sparkles },
  { key: 'profile', label: 'Architecture profile', icon: Fingerprint },
  { key: 'integrations', label: 'Integrations', icon: Network },
  { key: 'history', label: 'Documents & history', icon: History },
] as const;

export function AppWorkspace() {
  const { id = '', tab = 'overview' } = useParams();
  const m = useModel();
  const nav = useNavigate();
  const ref = useReveal<HTMLDivElement>([id, tab]);
  const exportContext = useExportContext();
  const a = m.apps[id];
  if (!a) return <Empty title={`No application with ID ${id}`}>Check the URL or import it from Data ingestion.</Empty>;
  const p = a.profile;
  const meta = a.notes?.meta ?? {};
  const st = APP_STATUS[p.status];
  const ints = m.integrations.filter((i) => i.source === id || i.target === id);
  const counts: Record<string, number | undefined> = {
    ai: a.ai?.ideas.length,
    integrations: ints.length,
    notes: a.notes?.sections.reduce((n, s) => n + (s.table?.rows.length ?? 0) + s.entries.length, 0),
    history: m.imports.filter((x) => x.appId === id).length + a.docs.length,
  };

  return (
    <div ref={ref} key={id}>
      <Link to="/apps" className="btn btn-ghost btn-sm reveal" style={{ marginBottom: 14, marginLeft: -8 }}>
        <ArrowLeft size={14} /> Applications
      </Link>
      <header className="ws-head reveal">
        <AppTile app={p} size={58} />
        <div className="grow">
          <div className="row-wrap" style={{ marginBottom: 6 }}>
            <span className="chip chip-mono">{p.id}</span>
            <span className="faint" style={{ fontSize: 12.5 }}>
              {CATEGORY[p.category]?.label} · {p.portfolio}
            </span>
            <HealthDot health={p.health} />
            <Pill color={st?.color ?? 'var(--st-grey)'}>{st?.label}</Pill>
            {meta.status && <Pill color={noteTone(meta.status)?.color ?? 'var(--st-grey)'}>Overall: {meta.status}</Pill>}
          </div>
          <h1 className="page-title">{meta.title ?? p.name}</h1>
          <div className="page-sub">{meta.tagline ?? p.summary}</div>
        </div>
        {p.portfolio !== 'external' && (
          <button className="btn" onClick={() => exportContext([id])} title={`Write context/${id}.md`}>
            <FileText size={15} /> Copilot context
          </button>
        )}
      </header>

      {a.notes && (
        <div className="meta-strip reveal">
          {[
            ['Phase', meta.phase],
            ['Sponsor', meta.sponsor],
            ['My role', meta.role ?? p.myRole],
            ['Next milestone', meta.nextMilestone],
            ['Go-live', meta.goLive],
            ['Last updated', meta.updated ? fmtDate(String(meta.updated)) : undefined],
          ].map(([k, v]) => (
            <div key={k} className="meta-cell">
              <div className="k">{k}</div>
              <div className="v" title={String(v ?? '')}>
                {v ?? <span className="faint">Not set</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      <nav className="tabs reveal">
        {TABS.filter((t) => p.portfolio !== 'external' || ['overview', 'profile', 'integrations'].includes(t.key)).map((t) => (
          <button key={t.key} className={`tab ${tab === t.key ? 'on' : ''}`} onClick={() => nav(`/apps/${id}${t.key === 'overview' ? '' : `/${t.key}`}`)}>
            <t.icon size={15} /> {t.label}
            {counts[t.key] ? <span className="count">{counts[t.key]}</span> : null}
          </button>
        ))}
      </nav>

      {tab === 'overview' && <OverviewTab id={id} />}
      {tab === 'notes' && <NotesView id={id} />}
      {tab === 'ai' && <AiIdeas id={id} />}
      {tab === 'profile' && <ProfileView id={id} />}
      {tab === 'integrations' && <IntegrationsTab id={id} />}
      {tab === 'history' && <HistoryTab id={id} />}
    </div>
  );
}

function OverviewTab({ id }: { id: string }) {
  const m = useModel();
  const a = m.apps[id];
  const [open, setOpen] = useState<Initiative | null>(null);
  const inits = m.initiatives.filter((i) => i.appIds.includes(id)).sort((x, y) => STATUS[x.status].order - STATUS[y.status].order);
  const risks = allRisks(m).filter((r) => r.appId === id);
  const actions = allActions(m).filter((r) => r.appId === id);
  const decisions = allDecisions(m).filter((r) => r.appId === id && isPending(r.status));
  const ints = m.integrations.filter((i) => i.source === id || i.target === id);
  const thisWeek = a.notes?.meta.thisWeek ?? [];

  return (
    <div className="stack" style={{ gap: 16 }}>
      {thisWeek.length > 0 && (
        <div className="card reveal">
          <div className="card-head">
            <h3 className="card-title">This week</h3>
          </div>
          <div className="card-body this-week">
            {thisWeek.slice(0, 3).map((t, k) => (
              <div key={k} className="tw-item">
                <span className="tw-num">{k + 1}</span>
                {t}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid g-wide">
        <div className="card reveal">
          <div className="card-head">
            <h3 className="card-title">Initiatives</h3>
            <span className="card-sub">{inits.length}</span>
          </div>
          <div className="card-body stack" style={{ gap: 4 }}>
            {inits.length === 0 && <Empty title="No initiatives linked to this application" />}
            {inits.map((i) => (
              <div key={i.id} className="mini-row" style={{ gridTemplateColumns: 'minmax(0,1fr) auto', padding: '10px 8px' }} onClick={() => setOpen(i)}>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 13.5 }}>{i.title}</div>
                  <div className="faint" style={{ fontSize: 12, marginTop: 2 }}>
                    {i.target.label}
                  </div>
                </div>
                <div className="row">
                  {i.aiEnabled && <AiTag />}
                  <StatusPill status={i.status} />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="stack" style={{ gap: 16 }}>
          <div className="card reveal card-pad">
            <div className="grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
              {[
                ['Open actions', actions.length, 'var(--st-teal)'],
                ['Open risks', risks.length, 'var(--st-orange)'],
                ['Decisions', decisions.length, 'var(--st-amber)'],
              ].map(([k, v, c]) => (
                <Link key={k as string} to={`/apps/${id}/notes`} className="callout" style={{ ...tone(c as string), flexDirection: 'column', gap: 2 }}>
                  <b style={{ fontFamily: 'var(--font-display)', fontSize: 26, lineHeight: 1 }}>{v as number}</b>
                  <span className="muted" style={{ fontSize: 12 }}>
                    {k}
                  </span>
                </Link>
              ))}
            </div>
          </div>
          <div className="card reveal">
            <div className="card-head">
              <h3 className="card-title">Purpose</h3>
            </div>
            <div className="card-body">
              <Md>{a.profile.purpose ?? a.profile.summary}</Md>
            </div>
          </div>
        </div>
      </div>

      <div className="grid g-2">
        <div className="card reveal">
          <div className="card-head">
            <h3 className="card-title">Top risks</h3>
          </div>
          <div className="card-body stack" style={{ gap: 8 }}>
            {risks.length === 0 && <Empty title="No open risks recorded" />}
            {risks.slice(0, 4).map((r) => (
              <div key={r.id} className="row" style={{ alignItems: 'flex-start', gap: 10 }}>
                <Pill color={noteTone(r.impact)?.color ?? 'var(--st-grey)'}>{r.impact || '?'}</Pill>
                <div style={{ fontSize: 13 }}>{r.description}</div>
              </div>
            ))}
            {risks.filter((r) => impactRank(r.impact) >= 3).length > 4 && (
              <Link to={`/apps/${id}/notes#risks`} className="faint" style={{ fontSize: 12.5 }}>
                See all in notes →
              </Link>
            )}
          </div>
        </div>
        <div className="card reveal">
          <div className="card-head">
            <h3 className="card-title">Connections</h3>
            <Link to={`/landscape/map?focus=${id}`} className="btn btn-ghost btn-sm" style={{ marginLeft: 'auto' }}>
              Open in map <ArrowRight size={13} />
            </Link>
          </div>
          <div className="card-body stack" style={{ gap: 6 }}>
            {ints.length === 0 && <Empty title="No documented integrations yet" />}
            {ints.map((i) => {
              const other = i.source === id ? i.target : i.source;
              const s = INTEGRATION_STATUS[i.status];
              return (
                <div key={i.id} className="row" style={{ fontSize: 13 }}>
                  {i.source === id ? <ArrowRight size={14} className="faint" /> : <ArrowLeftRight size={14} className="faint" />}
                  <AppChip id={other} />
                  <span className="grow muted" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {i.purpose}
                  </span>
                  <Pill color={s.color}>{s.label}</Pill>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      {open && <InitiativeDrawer initiative={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

function IntegrationsTab({ id }: { id: string }) {
  const m = useModel();
  const ints = m.integrations.filter((i) => i.source === id || i.target === id);
  if (!ints.length) return <Empty icon={Network} title="No documented integrations">Only confirmed or explicitly proposed connections are recorded.</Empty>;
  return (
    <div className="grid g-2">
      {ints.map((i) => {
        const s = INTEGRATION_STATUS[i.status];
        return (
          <div key={i.id} className="card card-pad reveal">
            <div className="row-wrap" style={{ marginBottom: 8 }}>
              <span className="chip chip-mono">{i.id}</span>
              <Pill color={s.color}>{s.label}</Pill>
              <ClassBadge k={i.classification} />
            </div>
            <div className="row" style={{ gap: 8, fontWeight: 600, marginBottom: 6 }}>
              <AppChip id={i.source} /> <ArrowRight size={15} className="faint" /> <AppChip id={i.target} />
            </div>
            <div style={{ fontSize: 13.5, marginBottom: 10 }}>{i.purpose}</div>
            <dl className="kv" style={{ gridTemplateColumns: '110px 1fr' }}>
              <dt>Method</dt>
              <dd>{i.method}</dd>
              <dt>Frequency</dt>
              <dd>{i.frequency ?? <span className="undoc">Undocumented</span>}</dd>
              <dt>Data</dt>
              <dd>{i.data.join(', ') || <span className="undoc">Undocumented</span>}</dd>
              {i.dependencies.length > 0 && (
                <>
                  <dt>Depends on</dt>
                  <dd>{i.dependencies.join('; ')}</dd>
                </>
              )}
              {i.limitations.length > 0 && (
                <>
                  <dt>Limitations</dt>
                  <dd>{i.limitations.join('; ')}</dd>
                </>
              )}
              <dt>Evidence</dt>
              <dd className="muted">{i.evidence.map((e) => `${e.source}${e.ref ? `, ${e.ref}` : ''}`).join(' · ') || 'None'}</dd>
            </dl>
          </div>
        );
      })}
    </div>
  );
}

function HistoryTab({ id }: { id: string }) {
  const m = useModel();
  const a = m.apps[id];
  const imports = m.imports.filter((x) => x.appId === id).sort((x, y) => y.at.localeCompare(x.at));
  const [doc, setDoc] = useState<string | null>(a.docs[0]?.path ?? null);
  const current = a.docs.find((d) => d.path === doc);
  return (
    <div className="grid g-wide">
      <div className="card reveal">
        <div className="card-head">
          <h3 className="card-title">Imported documents</h3>
          <span className="card-sub">{a.docs.length}</span>
        </div>
        <div className="card-body">
          {a.docs.length === 0 ? (
            <Empty icon={FileText} title="No narrative summaries imported yet">
              Import a Markdown summary from <Link to="/ingest" style={{ color: 'var(--accent)' }}>Data ingestion</Link>.
            </Empty>
          ) : (
            <>
              <div className="row-wrap" style={{ marginBottom: 12 }}>
                {a.docs.map((d) => (
                  <button key={d.path} className={`filter-chip ${doc === d.path ? 'on' : ''}`} onClick={() => setDoc(d.path)}>
                    {d.path.split('/').pop()}
                  </button>
                ))}
              </div>
              {current && <Md>{current.raw.replace(/^---[\s\S]*?---\n/, '')}</Md>}
            </>
          )}
        </div>
      </div>
      <div className="card reveal">
        <div className="card-head">
          <h3 className="card-title">Import history</h3>
        </div>
        <div className="card-body stack" style={{ gap: 10 }}>
          {imports.length === 0 && <Empty icon={History} title="No imports yet" />}
          {imports.map((x) => (
            <div key={x.id} className="entry" style={{ paddingBottom: 6 }}>
              <span className="entry-dot" />
              <div>
                <div className="entry-head">
                  {x.action} <span className="mono faint">{x.id}</span>
                </div>
                <div className="faint" style={{ fontSize: 12 }}>
                  {new Date(x.at).toLocaleString()} · {x.kind}
                  {x.sourceVersion ? ` · v${x.sourceVersion}` : ''}
                </div>
                {x.fieldsChanged.length > 0 && <div className="muted" style={{ fontSize: 12.5, marginTop: 4 }}>{x.fieldsChanged.join(', ')}</div>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
