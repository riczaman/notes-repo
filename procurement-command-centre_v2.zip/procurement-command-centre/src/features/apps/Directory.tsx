import { useState } from 'react';
import { AppEditor } from './AppEditor';
import { useNavigate } from 'react-router-dom';
import { Search, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useModel } from '../../store/DataProvider';
import { allActions, allRisks, allDecisions, isPending, isMine } from '../../domain/model';
import { APP_STATUS, impactRank } from '../../domain/meta';
import { PageHead, AppTile, Pill, HealthDot, CATEGORY, useReveal } from '../../components/ui';

const GROUPS = [
  { key: 'owned', label: 'Owned' },
  { key: 'supported', label: 'Supported' },
  { key: 'external', label: 'Connected systems' },
] as const;

export function Directory() {
  const m = useModel();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [group, setGroup] = useState<string>('mine');
  const [creating, setCreating] = useState(false);
  const ref = useReveal<HTMLDivElement>([group]);
  const risks = allRisks(m);
  const actions = allActions(m);
  const decisions = allDecisions(m).filter((d) => isPending(d.status));
  const needle = q.trim().toLowerCase();

  const list = m.appList.filter(
    (a) =>
      (group === 'all' || (group === 'mine' ? isMine(a) : a.profile.portfolio === group)) &&
      (!needle || `${a.id} ${a.profile.name} ${a.profile.aliases.join(' ')} ${a.profile.summary}`.toLowerCase().includes(needle)),
  );

  return (
    <div ref={ref}>
      <PageHead
        eyebrow="Portfolio"
        title="Applications"
        sub="Every application has one record, keyed by a unique ID. The workboard, notes and landscape map all read the same record."
        actions={
          <>
            <Link to="/ingest" className="btn">
              Import summary
            </Link>
            <button className="btn btn-primary" onClick={() => setCreating(true)}>
              <Plus size={15} /> New application
            </button>
          </>
        }
      />
      <div className="row-wrap reveal" style={{ marginBottom: 18 }}>
        <div className="search">
          <Search size={15} />
          <input className="input" placeholder="Search name, ID or alias" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        {[{ key: 'mine', label: 'Mine' }, ...GROUPS, { key: 'all', label: 'All' }].map((g) => (
          <button key={g.key} className={`filter-chip ${group === g.key ? 'on' : ''}`} onClick={() => setGroup(g.key)}>
            {g.label}
          </button>
        ))}
      </div>

      {creating && <AppEditor onClose={() => setCreating(false)} />}
      <div className="grid g-3">
        {list.map((a) => {
          const p = a.profile;
          const st = APP_STATUS[p.status];
          const appRisks = risks.filter((r) => r.appId === a.id);
          const high = appRisks.filter((r) => impactRank(r.impact) >= 3).length;
          return (
            <article key={a.id} className="card card-link app-card reveal" onClick={() => nav(`/apps/${a.id}`)}>
              <div className="app-card-head">
                <AppTile app={p} size={44} />
                <div className="grow">
                  <div className="app-name">{p.name}</div>
                  <div className="row" style={{ gap: 6, marginTop: 4 }}>
                    <span className="chip chip-mono">{p.id}</span>
                    <span className="faint" style={{ fontSize: 12 }}>
                      {CATEGORY[p.category]?.label}
                    </span>
                  </div>
                </div>
                <div className="row" style={{ gap: 8 }}>
                  <HealthDot health={p.health} />
                  <Pill color={st?.color ?? 'var(--st-grey)'}>{st?.label ?? p.status}</Pill>
                </div>
              </div>
              <div className="app-sum">{p.summary}</div>
              {p.myRole && (
                <div className="faint" style={{ fontSize: 12 }}>
                  My role: <span className="muted">{p.myRole}</span>
                </div>
              )}
              {p.portfolio !== 'external' && (
                <div className="app-stats">
                  <div className="app-stat">
                    <b>{m.initiatives.filter((i) => i.appIds.includes(a.id) && i.status !== 'done').length}</b>
                    <span>Initiatives</span>
                  </div>
                  <div className="app-stat">
                    <b>{actions.filter((x) => x.appId === a.id).length}</b>
                    <span>Open actions</span>
                  </div>
                  <div className={`app-stat ${high ? 'warn' : ''}`}>
                    <b>{appRisks.length}</b>
                    <span>{high ? `${high} high` : 'Risks'}</span>
                  </div>
                  <div className="app-stat">
                    <b>{decisions.filter((x) => x.appId === a.id).length}</b>
                    <span>Decisions</span>
                  </div>
                </div>
              )}
            </article>
          );
        })}
      </div>
    </div>
  );
}
