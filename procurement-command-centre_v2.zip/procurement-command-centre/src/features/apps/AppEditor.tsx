import { RecordEditor, type FieldSpec, CLASS_OPTIONS } from '../../components/RecordEditor';
import { useData, useModel } from '../../store/DataProvider';
import { Application, FILES } from '../../domain/schemas';
import { todayIso } from '../../domain/model';
import { starterNotes } from '../notes/NotesView';

const FIELDS = (workstreams: string[]): FieldSpec[] => [
  { key: 'id', label: 'Application ID', hint: 'Short uppercase code, e.g. USFF. Permanent', readOnlyOnEdit: true },
  { key: 'name', label: 'Name' },
  { key: 'category', label: 'Category', type: 'select', options: ['web-app', 'automation', 'data-pipeline', 'saas', 'ai-model', 'platform', 'reporting', 'legacy-app'] },
  { key: 'portfolio', label: 'Portfolio', type: 'select', options: ['owned', 'supported', 'external'] },
  { key: 'status', label: 'Status', type: 'select', options: ['live', 'in-delivery', 'onboarding', 'planned', 'retiring', 'retired'] },
  { key: 'health', label: 'Health', type: 'select', options: ['green', 'amber', 'red', 'unknown'] },
  { key: 'workstream', label: 'Workstream', type: 'select', options: workstreams },
  { key: 'myRole', label: 'My role' },
  { key: 'classification', label: 'Classification', type: 'select', options: CLASS_OPTIONS },
  { key: 'summary', label: 'One-line summary', wide: true },
  { key: 'purpose', label: 'Business purpose', type: 'textarea' },
  { key: 'aliases', label: 'Alternative names', type: 'lines' },
  { key: 'owners.business', label: 'Business owner' },
  { key: 'owners.technical', label: 'Technical owner' },
  { key: 'owners.support', label: 'Support team' },
  { key: 'tech.hosting', label: 'Hosting' },
  { key: 'tech.stack', label: 'Technology stack', type: 'lines' },
  { key: 'features', label: 'Key features', type: 'lines' },
  { key: 'lifecycleStages', label: 'Lifecycle stage IDs', type: 'lines', hint: 'IDs from the Lifecycle page' },
  { key: 'capabilities', label: 'Capability IDs', type: 'lines', hint: 'IDs from the Capabilities page' },
  { key: 'ops.knownIssues', label: 'Known issues', type: 'lines' },
  { key: 'ops.compliance', label: 'Compliance items', type: 'lines' },
  { key: 'evidence', label: 'Evidence', type: 'evidence', hint: 'Source | page or sheet | YYYY-MM-DD | high/medium/low' },
];

/** Which other records point at this application. Deleting is blocked while any exist. */
export function referencesTo(m: ReturnType<typeof useModel>, id: string): string[] {
  return [
    ...m.initiatives.filter((x) => x.appIds.includes(id)).map((x) => x.id),
    ...m.integrations.filter((x) => x.source === id || x.target === id).map((x) => x.id),
    ...m.overlaps.filter((x) => x.appIds.includes(id)).map((x) => x.id),
    ...m.gaps.filter((x) => x.appIds.includes(id)).map((x) => x.id),
    ...m.capabilities.filter((x) => x.appIds.includes(id)).map((x) => x.id),
    ...m.opportunities.filter((x) => x.appIds.includes(id)).map((x) => x.id),
    ...m.governance.filter((x) => x.appId === id).map((x) => x.id),
    ...m.futureState.filter((x) => [x.appId, x.source, x.target].includes(id)).map((x) => x.id),
    ...m.dataEntities.filter((x) => x.systemOfRecord === id).map((x) => x.id),
  ];
}

export function AppEditor({ id, onClose, onDeleted }: { id?: string; onClose: () => void; onDeleted?: () => void }) {
  const m = useModel();
  const { save, toast } = useData();
  const existing = id ? m.apps[id] : undefined;
  const isNew = !existing;
  const initial = existing?.profile ?? { portfolio: 'owned', status: 'live', health: 'unknown', category: 'web-app', classification: 'confirmed', aliases: [] };

  return (
    <RecordEditor
      title={isNew ? 'New application' : `${existing.profile.name} (${existing.id})`}
      fields={FIELDS(m.workstreams.map((w) => w.id))}
      initial={initial}
      isNew={isNew}
      schema={Application}
      onSave={async (rec) => {
        if (isNew && m.apps[rec.id]) throw new Error(`An application with ID ${rec.id} already exists`);
        const profile = { ...rec, meta: { ...rec.meta, created: rec.meta.created ?? todayIso(), updated: todayIso() } };
        const writes = [{ path: FILES.profile(rec.id), content: JSON.stringify(profile, null, 2) + '\n' }];
        if (isNew && rec.portfolio !== 'external') {
          writes.push({ path: FILES.notes(rec.id), content: starterNotes(rec.id, rec.name) });
          writes.push({ path: FILES.ai(rec.id), content: `---\napp: ${rec.id}\nupdated: ${todayIso()}\n---\n\n# AI opportunities: ${rec.name}\n` });
        }
        await save(writes);
        toast(isNew ? `${rec.id} created` : `${rec.id} saved`);
      }}
      onDelete={async () => {
        const refs = referencesTo(m, id!);
        if (refs.length) throw new Error(`Still referenced by ${refs.join(', ')}. Remove those links first.`);
        const files = Object.keys(m.files).filter((p) => p.startsWith(`data/apps/${id}/`));
        await save([], files);
        toast(`${id} deleted`);
        onDeleted?.();
      }}
      deleteWarning={`Delete ${id} and its notes, AI ideas and documents? This removes the files.`}
      onClose={onClose}
    />
  );
}
