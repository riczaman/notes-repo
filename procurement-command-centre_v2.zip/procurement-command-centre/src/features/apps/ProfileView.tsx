import { useState, type ReactNode } from 'react';
import { PencilLine, Save, X, CircleDashed, SlidersHorizontal } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AppEditor } from './AppEditor';
import { useData, useModel } from '../../store/DataProvider';
import { Application, FILES } from '../../domain/schemas';
import { todayIso, fmtDate } from '../../domain/model';
import { ClassBadge } from '../../components/ui';

const Undoc = () => (
  <span className="undoc">
    <CircleDashed size={12} /> Undocumented
  </span>
);

const val = (v: unknown): ReactNode => {
  if (v == null || v === '' || (Array.isArray(v) && v.length === 0)) return <Undoc />;
  if (Array.isArray(v))
    return (
      <ul className="bullets" style={{ fontSize: 13, color: 'var(--text)' }}>
        {v.map((x, k) => (
          <li key={k}>{String(x)}</li>
        ))}
      </ul>
    );
  return String(v);
};

function Block({ title, rows }: { title: string; rows: [string, unknown][] }) {
  return (
    <div className="card reveal">
      <div className="card-head">
        <h3 className="card-title">{title}</h3>
      </div>
      <div className="card-body">
        <dl className="kv">
          {rows.map(([k, v]) => (
            <div key={k} style={{ display: 'contents' }}>
              <dt>{k}</dt>
              <dd>{val(v)}</dd>
            </div>
          ))}
        </dl>
      </div>
    </div>
  );
}

export function ProfileView({ id }: { id: string }) {
  const m = useModel();
  const { save, toast } = useData();
  const p = m.apps[id].profile;
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');
  const [errors, setErrors] = useState<string[]>([]);
  const [form, setForm] = useState(false);
  const nav = useNavigate();

  if (editing)
    return (
      <div className="stack">
        <div className="row">
          <div className="muted grow" style={{ fontSize: 13 }}>
            Editing <span className="mono">{FILES.profile(id)}</span>. The ID cannot change here. Validated before saving.
          </div>
          <button className="btn" onClick={() => setEditing(false)}>
            <X size={14} /> Cancel
          </button>
          <button
            className="btn btn-primary"
            onClick={async () => {
              let data: Record<string, unknown>;
              try {
                data = JSON.parse(draft);
              } catch (e) {
                return setErrors([`Invalid JSON: ${(e as Error).message}`]);
              }
              if (data.id !== id) return setErrors([`The id must stay "${id}". Rename via aliases instead.`]);
              data.meta = { ...(data.meta as object), updated: todayIso() };
              const res = Application.safeParse(data);
              if (!res.success) return setErrors(res.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`));
              try {
                await save([{ path: FILES.profile(id), content: JSON.stringify(res.data, null, 2) + '\n' }]);
                toast('Profile saved');
                setEditing(false);
              } catch (e) {
                setErrors([(e as Error).message]);
              }
            }}
          >
            <Save size={14} /> Validate and save
          </button>
        </div>
        {errors.length > 0 && (
          <div className="callout" style={{ '--tone': 'var(--st-red)' } as React.CSSProperties}>
            <div>{errors.map((e) => <div key={e}>{e}</div>)}</div>
          </div>
        )}
        <textarea className="textarea" style={{ minHeight: '70vh' }} value={draft} onChange={(e) => setDraft(e.target.value)} spellCheck={false} />
      </div>
    );

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="row reveal">
        <span className="muted" style={{ fontSize: 13 }}>
          Classification
        </span>
        <ClassBadge k={p.classification} />
        <span className="faint grow" style={{ fontSize: 12.5 }}>
          Last reviewed {p.meta.lastReviewed ? fmtDate(p.meta.lastReviewed) : 'never'}
          {p.meta.sourceVersion ? ` · source summary v${p.meta.sourceVersion}` : ''}
          {p.meta.lastImport ? ` · last import ${p.meta.lastImport}` : ''}
        </span>
        <button className="btn btn-sm btn-primary" onClick={() => setForm(true)}>
          <SlidersHorizontal size={13} /> Edit fields
        </button>
        <button
          className="btn btn-sm"
          onClick={() => {
            setDraft(JSON.stringify(p, null, 2));
            setErrors([]);
            setEditing(true);
          }}
        >
          <PencilLine size={13} /> Edit JSON
        </button>
      </div>
      {form && <AppEditor id={id} onClose={() => setForm(false)} onDeleted={() => nav('/apps')} />}
      <div className="grid g-2">
        <Block
          title="Identity"
          rows={[
            ['Application ID', p.id],
            ['Name', p.name],
            ['Alternative names', p.aliases],
            ['Description', p.summary],
            ['Business purpose', p.purpose],
            ['Business owner', p.owners.business],
            ['Technical owner', p.owners.technical],
            ['Support team', p.owners.support],
            ['Status', p.status],
          ]}
        />
        <Block
          title="Business functionality"
          rows={[
            ['Capabilities', p.capabilities],
            ['Key features', p.features],
            ['Lifecycle stages', p.lifecycleStages],
            ['Processes', p.processes],
            ['User groups', p.userGroups],
            ['Main use cases', p.useCases],
          ]}
        />
        <Block
          title="Technical architecture"
          rows={[
            ['Technology stack', p.tech.stack],
            ['Hosting', p.tech.hosting],
            ['Architecture pattern', p.tech.pattern],
            ['Data sources', p.tech.dataSources],
            ['Data destinations', p.tech.dataDestinations],
            ['APIs', p.tech.apis],
            ['Dependencies', p.tech.dependencies],
            ['Auth', p.tech.auth],
          ]}
        />
        <Block
          title="Operational"
          rows={[
            ['Support model', p.ops.supportModel],
            ['Known issues', p.ops.knownIssues],
            ['Limitations', p.ops.limitations],
            ['Technical debt', p.ops.techDebt],
            ['Future improvements', p.ops.improvements],
            ['Compliance', p.ops.compliance],
          ]}
        />
      </div>
      <div className="card reveal">
        <div className="card-head">
          <h3 className="card-title">Documentation and evidence</h3>
        </div>
        <div className="card-body table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Source</th>
                <th>Reference</th>
                <th>Reviewed</th>
                <th>Confidence</th>
              </tr>
            </thead>
            <tbody>
              {[...p.docs.map((d) => ({ source: d.title, ref: d.ref ?? d.type, reviewed: '', confidence: '' })), ...p.evidence.map((e) => ({ source: e.source, ref: [e.file, e.ref, e.section].filter(Boolean).join(' · '), reviewed: e.reviewed ?? '', confidence: e.confidence ?? '' }))].map((r, k) => (
                <tr key={k}>
                  <td>{r.source}</td>
                  <td className="muted">{r.ref || 'None'}</td>
                  <td className="date">{r.reviewed}</td>
                  <td>{r.confidence}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
