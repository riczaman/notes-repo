import type { Model } from './model';
import { allRisks, allDecisions, isPending, isMine } from './model';
import { STATUS } from './meta';
import { splitFrontMatter } from './markdown';

/**
 * Copilot context packs: one Markdown file per application, written to context/.
 * Each pack is self-contained so you can drop it into a Copilot or agent prompt.
 */

const list = (items: string[] | undefined) => (items?.length ? items.map((x) => `- ${x}`).join('\n') : '- None recorded');

export function appContext(m: Model, id: string, generated: string): string {
  const a = m.apps[id];
  const p = a.profile;
  const inits = m.initiatives.filter((i) => i.appIds.includes(id));
  const ints = m.integrations.filter((i) => i.source === id || i.target === id);
  const ovl = m.overlaps.filter((o) => o.appIds.includes(id));
  const gaps = m.gaps.filter((g) => g.appIds.includes(id));
  const name = (x: string) => m.apps[x]?.profile.name ?? x;

  const out: string[] = [];
  out.push(`# Context pack: ${p.name} (${p.id})`);
  out.push(`> Generated ${generated} from the Procurement Command Centre. Source of truth: data/apps/${id}/. Treat "proposed" and "unverified" items as unconfirmed.`);
  out.push(`## Application\n\n| Field | Value |\n|---|---|\n| ID | ${p.id} |\n| Name | ${p.name} |\n| Aliases | ${p.aliases.join(', ') || 'None'} |\n| Category | ${p.category} |\n| Portfolio | ${p.portfolio} |\n| Status | ${p.status} |\n| Health | ${p.health} |\n| My role | ${p.myRole ?? 'Not recorded'} |\n| Classification | ${p.classification} |`);
  out.push(`**Summary:** ${p.summary}`);
  if (p.purpose) out.push(`**Purpose:** ${p.purpose}`);
  out.push(`### Features\n${list(p.features)}\n\n### Processes\n${list(p.processes)}\n\n### User groups\n${list(p.userGroups)}`);
  out.push(`### Technical\n- Stack: ${p.tech.stack.join(', ') || 'Not recorded'}\n- Hosting: ${p.tech.hosting ?? 'Not recorded'}\n- Pattern: ${p.tech.pattern ?? 'Not recorded'}\n- Auth: ${p.tech.auth ?? 'Not recorded'}\n- APIs: ${p.tech.apis.join('; ') || 'None recorded'}\n- Data sources: ${p.tech.dataSources.join('; ') || 'None recorded'}\n- Data destinations: ${p.tech.dataDestinations.join('; ') || 'None recorded'}\n- Dependencies: ${p.tech.dependencies.join('; ') || 'None recorded'}`);
  out.push(`### Operations\n- Support model: ${p.ops.supportModel ?? 'Not recorded'}\n\n**Known issues**\n${list(p.ops.knownIssues)}\n\n**Limitations**\n${list(p.ops.limitations)}\n\n**Technical debt**\n${list(p.ops.techDebt)}\n\n**Compliance**\n${list(p.ops.compliance)}`);

  out.push(`## Initiatives (${inits.length})`);
  for (const i of inits) {
    out.push(
      `### ${i.id}: ${i.title}\n- Status: ${STATUS[i.status]?.label ?? i.status} · Priority ${i.priority}${i.leadershipFocus ? ' · Leadership focus' : ''}${i.aiEnabled ? ' · AI-enabled' : ''}\n- Target: ${i.target.label}\n- Summary: ${i.summary}${i.problem ? `\n- Problem: ${i.problem}` : ''}${i.decision ? `\n- Open decision: ${i.decision}` : ''}${i.progress.length ? `\n- Progress:\n${i.progress.map((x) => `  - ${x}`).join('\n')}` : ''}${i.nextSteps.length ? `\n- Next steps:\n${i.nextSteps.map((x) => `  - ${x}`).join('\n')}` : ''}${i.dependencies.length ? `\n- Dependencies: ${i.dependencies.join('; ')}` : ''}`,
    );
  }

  out.push(`## Integrations (${ints.length})\n\n| ID | From | To | Purpose | Method | Frequency | Status | Classification |\n|---|---|---|---|---|---|---|---|\n${ints
    .map((i) => `| ${i.id} | ${name(i.source)} | ${name(i.target)} | ${i.purpose} | ${i.method} | ${i.frequency ?? ''} | ${i.status} | ${i.classification} |`)
    .join('\n')}`);
  if (ovl.length) out.push(`## Overlaps\n${ovl.map((o) => `- ${o.id} (${o.kind}, ${o.confidence} confidence): ${o.title}. ${o.description}`).join('\n')}`);
  if (gaps.length) out.push(`## Gaps\n${gaps.map((g) => `- ${g.id} (${g.kind}, ${g.priority}): ${g.title}. ${g.description}`).join('\n')}`);
  const caps = m.capabilities.filter((c) => c.appIds.includes(id));
  if (caps.length) out.push(`## Business capabilities\n${caps.map((c) => `- ${c.id}: ${c.name}${c.maturity ? ` (maturity ${c.maturity})` : ''}${c.limitations.length ? `. Limitations: ${c.limitations.join('; ')}` : ''}`).join('\n')}`);
  const gov = m.governance.filter((g) => g.appId === id);
  if (gov.length) out.push(`## Model governance obligations\n${gov.map((g) => `- ${g.id} [${g.status}] ${g.item} (${g.type}${g.cadence ? `, ${g.cadence}` : ''}${g.due ? `, due ${g.due}` : ''})${g.notes ? `. ${g.notes}` : ''}`).join('\n')}`);
  const opps = m.opportunities.filter((o) => o.appIds.includes(id));
  if (opps.length) out.push(`## Opportunities (not commitments)\n${opps.map((o) => `- ${o.id} [${o.status}, ${o.priority}] ${o.title}${o.improvement ? `: ${o.improvement}` : ''}`).join('\n')}`);
  const fut = m.futureState.filter((c) => [c.appId, c.source, c.target].includes(id));
  if (fut.length) out.push(`## Future-state proposals (not approved unless stated)\n${fut.map((c) => `- ${c.id} [${c.status}] ${c.title}${c.description ? `. ${c.description}` : ''}`).join('\n')}`);

  if (a.notesRaw) out.push(`## Working notes\n\n${splitFrontMatter(a.notesRaw).body.replace(/^## /gm, '### ')}`);
  if (a.aiRaw) out.push(`## AI opportunity ideas (proposed)\n\n${splitFrontMatter(a.aiRaw).body.replace(/^# .*$/m, '').replace(/^## /gm, '### ')}`);
  return out.join('\n\n') + '\n';
}

export function portfolioContext(m: Model, generated: string): string {
  const risks = allRisks(m).filter((r) => /critical|high/i.test(r.impact));
  const decisions = allDecisions(m).filter((d) => isPending(d.status));
  const owned = m.appList.filter(isMine);
  return [
    `# Context pack: Procurement technology portfolio`,
    `> Generated ${generated}. ${owned.length} owned or supported applications, ${m.initiatives.length} initiatives.`,
    `## Applications\n\n| ID | Name | Status | My role | Summary |\n|---|---|---|---|---|\n${owned.map((a) => `| ${a.id} | ${a.profile.name} | ${a.profile.status} | ${a.profile.myRole ?? ''} | ${a.profile.summary} |`).join('\n')}`,
    `## Initiatives\n\n| ID | Title | Apps | Status | Target |\n|---|---|---|---|---|\n${m.initiatives.map((i) => `| ${i.id} | ${i.title} | ${i.appIds.join(', ')} | ${STATUS[i.status]?.label} | ${i.target.label} |`).join('\n')}`,
    `## Pending decisions\n${decisions.map((d) => `- [${d.appId}] ${d.decision} (raised ${d.date}, owner ${d.by})`).join('\n') || '- None'}`,
    `## High and critical risks\n${risks.map((r) => `- [${r.appId} ${r.id}] ${r.description} · Impact ${r.impact} · Mitigation: ${r.mitigation}`).join('\n') || '- None'}`,
  ].join('\n\n') + '\n';
}
