import { Application, ApplicationSummary, type Evidence } from './schemas';

/**
 * Import merge rules
 * 1. Match on id only.
 * 2. Never overwrite with an empty value.
 * 3. String arrays: union (case-insensitive). Object arrays: append items not already present.
 * 4. Different non-empty scalars are "changed" and need your approval.
 * 5. A classification downgrade (e.g. confirmed → unverified) is a "conflict" and is unticked by default.
 */

export type ChangeKind = 'added' | 'changed' | 'array-add' | 'conflict';

export interface Change {
  path: string;
  kind: ChangeKind;
  before: unknown;
  after: unknown;
  /** For array-add: the new items only. */
  additions?: unknown[];
  defaultOn: boolean;
}

const CLASS_RANK: Record<string, number> = { confirmed: 4, inferred: 3, proposed: 2, unverified: 1, undocumented: 0 };
const SKIP = new Set(['id', 'summaryVersion', 'sourceDocuments', 'meta']);

export const isEmpty = (v: unknown) =>
  v == null || (typeof v === 'string' && v.trim() === '') || (Array.isArray(v) && v.length === 0) ||
  (typeof v === 'object' && !Array.isArray(v) && Object.values(v as object).every(isEmpty));

const isPlainObject = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);
const key = (v: unknown) => (typeof v === 'string' ? v.trim().toLowerCase() : JSON.stringify(v));

function walk(before: unknown, after: unknown, path: string, out: Change[]) {
  if (isEmpty(after)) return; // rule 2
  if (Array.isArray(after)) {
    const existing = Array.isArray(before) ? before : [];
    const seen = new Set(existing.map(key));
    const additions = after.filter((x) => !isEmpty(x) && !seen.has(key(x)));
    if (additions.length) out.push({ path, kind: existing.length ? 'array-add' : 'added', before: existing, after: [...existing, ...additions], additions, defaultOn: true });
    return;
  }
  if (isPlainObject(after)) {
    const b = isPlainObject(before) ? before : {};
    for (const k of Object.keys(after)) walk(b[k], after[k], path ? `${path}.${k}` : k, out);
    return;
  }
  if (isEmpty(before)) {
    out.push({ path, kind: 'added', before, after, defaultOn: true });
    return;
  }
  if (before === after) return;
  if (path === 'classification' && (CLASS_RANK[String(after)] ?? 0) < (CLASS_RANK[String(before)] ?? 0)) {
    out.push({ path, kind: 'conflict', before, after, defaultOn: false });
    return;
  }
  out.push({ path, kind: 'changed', before, after, defaultOn: true });
}

export function diffProfile(existing: Application | undefined, incoming: ApplicationSummary): Change[] {
  const out: Change[] = [];
  const base = (existing ?? {}) as Record<string, unknown>;
  for (const k of Object.keys(incoming)) {
    if (SKIP.has(k)) continue;
    walk(base[k], (incoming as Record<string, unknown>)[k], k, out);
  }
  if (incoming.sourceDocuments?.length) {
    walk(existing?.evidence ?? [], incoming.sourceDocuments, 'evidence', out);
    // collapse duplicate evidence change if incoming also had evidence
    const ev = out.filter((c) => c.path === 'evidence');
    if (ev.length > 1) {
      const merged = ev.reduce((acc, c) => ({ ...acc, additions: [...(acc.additions ?? []), ...(c.additions ?? [])] }));
      merged.after = [...((existing?.evidence ?? []) as Evidence[]), ...(merged.additions ?? [])];
      return [...out.filter((c) => c.path !== 'evidence'), merged];
    }
  }
  return out;
}

function setPath(obj: Record<string, unknown>, path: string, value: unknown) {
  const parts = path.split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    if (!isPlainObject(cur[parts[i]])) cur[parts[i]] = {};
    cur = cur[parts[i]] as Record<string, unknown>;
  }
  cur[parts[parts.length - 1]] = value;
}

export interface ApplyResult {
  profile: Application;
  errors: string[];
}

export function applyChanges(
  existing: Application | undefined,
  incoming: ApplicationSummary,
  changes: Change[],
  accepted: Set<string>,
  importId: string,
  todayIso: string,
): ApplyResult {
  const next = structuredClone((existing ?? { id: incoming.id }) as Record<string, unknown>);
  for (const c of changes) if (accepted.has(c.path)) setPath(next, c.path, structuredClone(c.after));

  // A renamed application keeps its old name as an alias, so later searches still find it.
  if (existing && accepted.has('name') && incoming.name && incoming.name !== existing.name) {
    const aliases = new Set([...(existing.aliases ?? []), existing.name]);
    next.aliases = [...aliases];
  }
  const meta = { ...((existing?.meta ?? {}) as Record<string, unknown>) };
  meta.updated = todayIso;
  if (!existing) meta.created = todayIso;
  meta.lastReviewed = todayIso;
  if (incoming.summaryVersion) meta.sourceVersion = incoming.summaryVersion;
  if (existing?.meta.lastImport) meta.previousImport = existing.meta.lastImport;
  meta.lastImport = importId;
  next.meta = meta;

  const res = Application.safeParse(next);
  if (!res.success) return { profile: next as Application, errors: res.error.issues.map((i) => `${i.path.join('.') || '(root)'}: ${i.message}`) };
  return { profile: res.data, errors: [] };
}

/* ───────────────────────── Parsing input ───────────────────────── */

export interface ParsedInput {
  kind: 'json' | 'markdown';
  summaries: ApplicationSummary[];
  markdown?: { appId: string; raw: string; title: string };
  errors: string[];
  warnings: string[];
}

import { splitFrontMatter } from './markdown';

export function parseInput(text: string, filename = ''): ParsedInput {
  const trimmed = text.trim();
  const isJson = filename.endsWith('.json') || trimmed.startsWith('{') || trimmed.startsWith('[');
  if (isJson) {
    let data: unknown;
    try {
      data = JSON.parse(trimmed);
    } catch (e) {
      return { kind: 'json', summaries: [], errors: [`Not valid JSON: ${(e as Error).message}`], warnings: [] };
    }
    const list = Array.isArray(data) ? data : [data];
    const summaries: ApplicationSummary[] = [];
    const errors: string[] = [];
    list.forEach((item, i) => {
      const res = ApplicationSummary.safeParse(item);
      if (res.success) summaries.push(stripDefaults(res.data, item as Record<string, unknown>));
      else errors.push(...res.error.issues.map((x) => `Record ${i + 1} · ${x.path.join('.') || '(root)'}: ${x.message}`));
    });
    return { kind: 'json', summaries, errors, warnings: [] };
  }
  const { meta, body } = splitFrontMatter<Record<string, unknown>>(trimmed);
  const appId = String(meta.app ?? meta.id ?? '').toUpperCase();
  if (!appId) return { kind: 'markdown', summaries: [], errors: ['Markdown needs front matter with "app: <APP_ID>"'], warnings: [] };
  const title = String(meta.title ?? body.match(/^#\s+(.*)$/m)?.[1] ?? 'Imported summary');
  const profileFields = { ...meta, id: appId } as Record<string, unknown>;
  delete profileFields.app;
  delete profileFields.title;
  delete profileFields.type;
  const res = ApplicationSummary.safeParse(profileFields);
  const summaries = res.success && Object.keys(profileFields).length > 1 ? [stripDefaults(res.data, profileFields)] : [];
  const warnings = res.success ? [] : res.error.issues.map((x) => `Front matter ${x.path.join('.')}: ${x.message} (ignored; document still imported)`);
  return { kind: 'markdown', summaries, markdown: { appId, raw: trimmed, title }, errors: [], warnings };
}

/** Zod fills defaults ([] and {}); remove keys the source never sent so they cannot look like data. */
function stripDefaults(parsed: ApplicationSummary, original: Record<string, unknown>): ApplicationSummary {
  const out: Record<string, unknown> = {};
  for (const k of Object.keys(parsed)) if (k in original) out[k] = (parsed as Record<string, unknown>)[k];
  return out as ApplicationSummary;
}

/** Name or alias collisions with a different id: warn, never merge. */
export function similarApps(incoming: ApplicationSummary, apps: Application[]): Application[] {
  const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  const names = [incoming.name, ...(incoming.aliases ?? [])].filter(Boolean).map((s) => norm(s!));
  if (!names.length) return [];
  return apps.filter(
    (a) => a.id !== incoming.id && [a.name, ...a.aliases, a.id].some((n) => names.some((x) => x && (norm(n) === x || norm(n).includes(x) || x.includes(norm(n))))),
  );
}
