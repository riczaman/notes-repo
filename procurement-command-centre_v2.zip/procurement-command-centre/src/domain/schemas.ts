import { z } from 'zod';

/* ───────────────────────── Shared ───────────────────────── */

export const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD');

export const Classification = z.enum(['confirmed', 'inferred', 'proposed', 'unverified', 'undocumented']);
export type Classification = z.infer<typeof Classification>;

export const Confidence = z.enum(['high', 'medium', 'low']);

export const Evidence = z.object({
  source: z.string().describe('Document title, or "Owner notes" for your own statements'),
  file: z.string().optional(),
  ref: z.string().optional().describe('Worksheet, page or slide reference'),
  section: z.string().optional(),
  url: z.string().optional(),
  reviewed: isoDate.optional(),
  validated: isoDate.optional(),
  confidence: Confidence.optional(),
});
export type Evidence = z.infer<typeof Evidence>;

/* ───────────────────────── Application ───────────────────────── */

export const AppCategory = z.enum([
  'web-app',
  'automation',
  'data-pipeline',
  'saas',
  'ai-model',
  'platform',
  'reporting',
  'legacy-app',
]);

export const Portfolio = z.enum(['owned', 'supported', 'external']);
export const AppStatus = z.enum(['live', 'in-delivery', 'onboarding', 'planned', 'retiring', 'retired']);
export const Health = z.enum(['green', 'amber', 'red', 'unknown']);

export const DocRef = z.object({
  title: z.string(),
  type: z.enum(['sharepoint', 'excel', 'deck', 'diagram', 'technical', 'summary', 'other']).default('other'),
  url: z.string().optional(),
  ref: z.string().optional(),
});

export const Application = z.object({
  id: z.string().regex(/^[A-Z0-9-]{2,24}$/, 'Uppercase letters, numbers and dashes'),
  name: z.string(),
  aliases: z.array(z.string()).default([]),
  category: AppCategory,
  portfolio: Portfolio,
  status: AppStatus,
  health: Health.default('unknown'),
  workstream: z.string().optional(),
  myRole: z.string().optional(),
  summary: z.string().describe('One line: what it does and for whom'),
  purpose: z.string().optional(),
  owners: z
    .object({ business: z.string().optional(), technical: z.string().optional(), support: z.string().optional() })
    .default({}),
  lifecycleStages: z.array(z.string()).default([]),
  capabilities: z.array(z.string()).default([]).describe('Capability IDs'),
  features: z.array(z.string()).default([]),
  processes: z.array(z.string()).default([]),
  userGroups: z.array(z.string()).default([]),
  useCases: z.array(z.string()).default([]),
  tech: z
    .object({
      stack: z.array(z.string()).default([]),
      hosting: z.string().optional(),
      pattern: z.string().optional(),
      auth: z.string().optional(),
      apis: z.array(z.string()).default([]),
      dataSources: z.array(z.string()).default([]),
      dataDestinations: z.array(z.string()).default([]),
      dependencies: z.array(z.string()).default([]),
    })
    .default({ stack: [], apis: [], dataSources: [], dataDestinations: [], dependencies: [] }),
  ops: z
    .object({
      supportModel: z.string().optional(),
      limitations: z.array(z.string()).default([]),
      techDebt: z.array(z.string()).default([]),
      knownIssues: z.array(z.string()).default([]),
      improvements: z.array(z.string()).default([]),
      compliance: z.array(z.string()).default([]),
    })
    .default({ limitations: [], techDebt: [], knownIssues: [], improvements: [], compliance: [] }),
  docs: z.array(DocRef).default([]),
  classification: Classification.default('confirmed'),
  evidence: z.array(Evidence).default([]),
  meta: z
    .object({
      created: isoDate.optional(),
      updated: isoDate.optional(),
      lastReviewed: isoDate.optional(),
      lastValidated: isoDate.optional(),
      sourceVersion: z.string().optional(),
      previousImport: z.string().optional(),
      lastImport: z.string().optional(),
    })
    .default({}),
});
export type Application = z.infer<typeof Application>;

/** What the research agent sends. Same shape, every field optional except id. */
export const ApplicationSummary = Application.partial().extend({
  id: Application.shape.id,
  summaryVersion: z.string().optional().describe('Version of this summary, e.g. 2026-11-08.1'),
  sourceDocuments: z.array(Evidence).optional(),
});
export type ApplicationSummary = z.infer<typeof ApplicationSummary>;

/* ───────────────────────── Portfolio ───────────────────────── */

export const InitiativeStatus = z.enum([
  'in-delivery',
  'decision-needed',
  'at-risk',
  'blocked',
  'planning',
  'bau',
  'not-started',
  'done',
]);
export type InitiativeStatus = z.infer<typeof InitiativeStatus>;

export const Initiative = z.object({
  id: z.string(),
  title: z.string(),
  appIds: z.array(z.string()).min(1),
  workstream: z.string(),
  status: InitiativeStatus,
  priority: z.enum(['P1', 'P2', 'P3']).default('P2'),
  leadershipFocus: z.boolean().default(false),
  aiEnabled: z.boolean().default(false),
  target: z.object({ label: z.string(), date: isoDate.optional() }),
  phase: z.string().optional(),
  summary: z.string(),
  problem: z.string().optional(),
  progress: z.array(z.string()).default([]),
  nextSteps: z.array(z.string()).default([]),
  decision: z.string().optional().describe('Open decision, phrased as a question'),
  dependencies: z.array(z.string()).default([]),
  tags: z.array(z.string()).default([]),
  updated: isoDate,
});
export type Initiative = z.infer<typeof Initiative>;

export const Workstream = z.object({ id: z.string(), name: z.string(), description: z.string().optional() });
export type Workstream = z.infer<typeof Workstream>;

/* ───────────────────────── Landscape ───────────────────────── */

export const Integration = z.object({
  id: z.string().regex(/^INT-\d{3,}$/),
  source: z.string(),
  target: z.string(),
  purpose: z.string(),
  data: z.array(z.string()).default([]),
  method: z.string(),
  frequency: z.string().optional(),
  direction: z.enum(['one-way', 'two-way']).default('one-way'),
  process: z.string().optional(),
  dependencies: z.array(z.string()).default([]),
  status: z.enum(['live', 'degraded', 'manual', 'in-delivery', 'planned', 'retiring']),
  limitations: z.array(z.string()).default([]),
  classification: Classification,
  evidence: z.array(Evidence).default([]),
});
export type Integration = z.infer<typeof Integration>;

export const LifecycleStage = z.object({ id: z.string(), name: z.string(), order: z.number(), description: z.string().optional() });
export type LifecycleStage = z.infer<typeof LifecycleStage>;

export const Capability = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string().optional(),
  stage: z.string().optional(),
  appIds: z.array(z.string()).default([]),
  owner: z.string().optional(),
  importance: z.enum(['critical', 'high', 'medium', 'low']).optional(),
  maturity: z.enum(['none', 'initial', 'developing', 'defined', 'optimised']).optional(),
  limitations: z.array(z.string()).default([]),
  classification: Classification.default('confirmed'),
  evidence: z.array(Evidence).default([]),
});
export type Capability = z.infer<typeof Capability>;

export const Overlap = z.object({
  id: z.string().regex(/^OVL-\d{3,}$/),
  title: z.string(),
  appIds: z.array(z.string()).min(2),
  capabilities: z.array(z.string()).default([]),
  description: z.string(),
  impact: z.string().optional(),
  confidence: Confidence,
  kind: z.enum(['confirmed', 'potential', 'complementary', 'investigate']),
  validation: z.enum(['validated', 'pending', 'rejected']).default('pending'),
  recommendation: z.string().optional(),
  evidence: z.array(Evidence).default([]),
});
export type Overlap = z.infer<typeof Overlap>;

export const Gap = z.object({
  id: z.string().regex(/^GAP-\d{3,}$/),
  title: z.string(),
  capability: z.string().optional(),
  stage: z.string().optional(),
  description: z.string(),
  impact: z.string().optional(),
  appIds: z.array(z.string()).default([]),
  missing: z.string().optional(),
  solution: z.string().optional(),
  priority: z.enum(['high', 'medium', 'low']).default('medium'),
  owner: z.string().optional(),
  status: z.enum(['open', 'in-progress', 'closed']).default('open'),
  kind: z.enum(['confirmed', 'potential', 'undocumented', 'needs-validation']),
  evidence: z.array(Evidence).default([]),
});
export type Gap = z.infer<typeof Gap>;

/* ───────────────────────── Data, strategy, governance ───────────────────────── */

export const DataEntity = z.object({
  id: z.string().regex(/^ENT-\d{3,}$/),
  name: z.string().describe('Must match the wording used in integration "data" lists'),
  description: z.string().optional(),
  systemOfRecord: z.string().optional().describe('App ID. Leave empty unless documented'),
  owner: z.string().optional(),
  attributes: z.array(z.string()).default([]),
  qualityIssues: z.array(z.string()).default([]),
  classification: Classification.default('confirmed'),
  evidence: z.array(Evidence).default([]),
});
export type DataEntity = z.infer<typeof DataEntity>;

export const FutureChange = z.object({
  id: z.string().regex(/^FUT-\d{3,}$/),
  kind: z.enum(['add-app', 'retire-app', 'modify-app', 'add-integration', 'retire-integration', 'add-capability', 'automation', 'ai-capability', 'data-improvement']),
  title: z.string(),
  appId: z.string().optional().describe('Existing app affected'),
  newAppName: z.string().optional().describe('For add-app: the proposed application'),
  integrationId: z.string().optional().describe('For retire-integration'),
  source: z.string().optional().describe('For add-integration: from app ID'),
  target: z.string().optional().describe('For add-integration: to app ID'),
  description: z.string().optional(),
  rationale: z.string().optional(),
  outcome: z.string().optional(),
  status: z.enum(['proposed', 'under-review', 'approved', 'rejected']).default('proposed'),
  evidence: z.array(Evidence).default([]),
});
export type FutureChange = z.infer<typeof FutureChange>;

export const Opportunity = z.object({
  id: z.string().regex(/^OPP-\d{3,}$/),
  title: z.string(),
  category: z.enum(['consolidation', 'rationalisation', 'automation', 'integration', 'data', 'reporting', 'ai', 'user-experience', 'complexity', 'governance']),
  description: z.string().optional(),
  appIds: z.array(z.string()).default([]),
  problem: z.string().optional(),
  improvement: z.string().optional(),
  benefit: z.string().optional().describe('Qualitative only. No invented savings'),
  dependencies: z.array(z.string()).default([]),
  complexity: z.enum(['low', 'medium', 'high']).default('medium'),
  priority: z.enum(['high', 'medium', 'low']).default('medium'),
  effort: z.string().optional(),
  status: z.enum(['idea', 'assessing', 'planned', 'in-progress', 'done', 'parked']).default('idea'),
  quarter: z.string().optional().describe('Target quarter, e.g. 2027-Q1'),
  links: z.array(z.string()).default([]).describe('Related OVL-, GAP- or initiative IDs'),
  evidence: z.array(Evidence).default([]),
});
export type Opportunity = z.infer<typeof Opportunity>;

export const GovernanceItem = z.object({
  id: z.string().regex(/^GOV-\d{3,}$/),
  appId: z.string(),
  item: z.string(),
  type: z.enum(['testing', 'artifact', 'approval', 'monitoring', 'finding', 'onboarding', 'security']),
  cadence: z.string().optional().describe('e.g. Quarterly, Annual, One-off'),
  due: z.string().optional(),
  status: z.enum(['not-started', 'in-progress', 'done', 'blocked', 'ongoing', 'needs-info']).default('not-started'),
  owner: z.string().optional(),
  notes: z.string().optional(),
});
export type GovernanceItem = z.infer<typeof GovernanceItem>;

/* ───────────────────────── Import history ───────────────────────── */

export const ImportRecord = z.object({
  id: z.string(),
  at: z.string(),
  appId: z.string(),
  kind: z.enum(['json', 'markdown', 'paste']),
  action: z.enum(['created', 'updated', 'document-added']),
  sourceVersion: z.string().optional(),
  sourceDocuments: z.array(Evidence).default([]),
  fieldsChanged: z.array(z.string()).default([]),
  previousImport: z.string().optional(),
  snapshot: z.string().optional(),
});
export type ImportRecord = z.infer<typeof ImportRecord>;

export const FILES = {
  initiatives: 'data/portfolio/initiatives.json',
  workstreams: 'data/portfolio/workstreams.json',
  integrations: 'data/landscape/integrations.json',
  lifecycle: 'data/landscape/lifecycle.json',
  capabilities: 'data/landscape/capabilities.json',
  overlaps: 'data/landscape/overlaps.json',
  gaps: 'data/landscape/gaps.json',
  imports: 'data/history/imports.json',
  dataEntities: 'data/landscape/data-entities.json',
  futureState: 'data/strategy/future-state.json',
  opportunities: 'data/strategy/opportunities.json',
  governance: 'data/governance/model-governance.json',
  profile: (id: string) => `data/apps/${id}/profile.json`,
  notes: (id: string) => `data/apps/${id}/notes.md`,
  ai: (id: string) => `data/apps/${id}/ai-ideas.md`,
  snapshot: (id: string) => `data/history/snapshots/${id}.json`,
} as const;
