import YAML from 'yaml';

/* ───────────────────────── Front matter ───────────────────────── */

export interface Parsed<T> {
  meta: T;
  body: string;
}

export function splitFrontMatter<T = Record<string, unknown>>(raw: string): Parsed<T> {
  const m = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (!m) return { meta: {} as T, body: raw };
  let meta = {} as T;
  try {
    meta = (YAML.parse(m[1]) ?? {}) as T;
  } catch {
    /* invalid YAML: keep body readable, surface as empty meta */
  }
  return { meta, body: raw.slice(m[0].length) };
}

export function joinFrontMatter(meta: Record<string, unknown>, body: string): string {
  return `---\n${YAML.stringify(meta, { lineWidth: 0 }).trimEnd()}\n---\n\n${body.replace(/^\n+/, '')}`;
}

/* ───────────────────────── Tables ───────────────────────── */

export interface MdTable {
  headers: string[];
  rows: Record<string, string>[];
}

function splitRow(line: string): string[] {
  const inner = line.trim().replace(/^\|/, '').replace(/\|$/, '');
  const cells: string[] = [];
  let cur = '';
  for (let i = 0; i < inner.length; i++) {
    if (inner[i] === '\\' && inner[i + 1] === '|') {
      cur += '|';
      i++;
    } else if (inner[i] === '|') {
      cells.push(cur.trim());
      cur = '';
    } else cur += inner[i];
  }
  cells.push(cur.trim());
  return cells;
}

const isTableLine = (l: string) => l.trim().startsWith('|');
const isSeparator = (l: string) => /^\s*\|?\s*:?-{2,}/.test(l) && /^[\s|:-]+$/.test(l);

export function parseFirstTable(md: string): MdTable | null {
  const lines = md.split(/\r?\n/);
  for (let i = 0; i < lines.length - 1; i++) {
    if (isTableLine(lines[i]) && isSeparator(lines[i + 1])) {
      const headers = splitRow(lines[i]);
      const rows: Record<string, string>[] = [];
      for (let j = i + 2; j < lines.length && isTableLine(lines[j]); j++) {
        const cells = splitRow(lines[j]);
        if (cells.every((c) => !c)) continue;
        const row: Record<string, string> = {};
        headers.forEach((h, k) => (row[h] = cells[k] ?? ''));
        rows.push(row);
      }
      return { headers, rows };
    }
  }
  return null;
}

export const escapeCell = (v: string) => v.replace(/\|/g, '\\|').replace(/\r?\n/g, ' ').trim();
export const tableRow = (cells: string[]) => `| ${cells.map(escapeCell).join(' | ')} |`;

/** Look up a cell by any of several header names, case-insensitive. */
export function cell(row: Record<string, string>, ...names: string[]): string {
  const keys = Object.keys(row);
  for (const n of names) {
    const k = keys.find((key) => key.toLowerCase().startsWith(n.toLowerCase()));
    if (k && row[k]) return row[k];
  }
  return '';
}

/* ───────────────────────── Notes document ───────────────────────── */

export type SectionKey =
  | 'dates'
  | 'actions'
  | 'requests'
  | 'risks'
  | 'decisions'
  | 'backlog'
  | 'contacts'
  | 'howto'
  | 'meetings'
  | 'other';

export const SECTION_DEFS: { key: SectionKey; num: string; title: string; hint: string; match: RegExp }[] = [
  { key: 'dates', num: '01', title: 'Key Dates & Deadlines', hint: 'Hard dates only. Use YYYY-MM-DD so Copilot can sort them.', match: /key dates|deadline/i },
  { key: 'actions', num: '02', title: 'Action Items', hint: 'Things I own or am chasing. Move done items to the bottom.', match: /action/i },
  { key: 'requests', num: '03', title: 'Requests Log', hint: 'Asks from leadership and stakeholders, so nothing gets lost.', match: /request/i },
  { key: 'risks', num: '04', title: 'Risks & Issues', hint: 'Risk = might happen. Issue = happening now.', match: /risk|issue/i },
  { key: 'decisions', num: '05', title: 'Decisions', hint: 'What was decided, by whom, and why. Pending decisions stay at the top.', match: /decision/i },
  { key: 'backlog', num: '06', title: 'Future State & Backlog', hint: 'Ideas and next-phase work. Not committed yet.', match: /future|backlog/i },
  { key: 'contacts', num: '07', title: 'Contacts', hint: 'Who owns what. Note how they prefer to be reached.', match: /contact/i },
  { key: 'howto', num: '08', title: 'How-To & Knowledge', hint: 'Steps you will forget in 3 months. Write it once here.', match: /how-to|howto|knowledge/i },
  { key: 'meetings', num: '09', title: 'Meeting Notes', hint: 'Newest on top. Copy actions into section 02.', match: /meeting/i },
];

export interface NotesMeta {
  app?: string;
  title?: string;
  tagline?: string;
  status?: string;
  phase?: string;
  sponsor?: string;
  role?: string;
  nextMilestone?: string;
  goLive?: string;
  updated?: string;
  links?: { label: string; url?: string }[];
  thisWeek?: string[];
}

export interface NotesSection {
  key: SectionKey;
  num: string;
  title: string;
  hint?: string;
  table: MdTable | null;
  /** Markdown that is not the hint or the first table. */
  prose: string;
  entries: { heading: string; body: string }[];
}

export interface NotesDoc {
  meta: NotesMeta;
  sections: NotesSection[];
}

export function parseNotes(raw: string): NotesDoc {
  const { meta, body } = splitFrontMatter<NotesMeta>(raw);
  const parts = body.split(/^## +/m).slice(1);
  const sections = parts.map((part) => {
    const nl = part.indexOf('\n');
    const headLine = (nl === -1 ? part : part.slice(0, nl)).trim();
    const content = nl === -1 ? '' : part.slice(nl + 1);
    const numMatch = headLine.match(/^(\d{1,2})\s+(.*)$/);
    const title = numMatch ? numMatch[2] : headLine;
    const def = SECTION_DEFS.find((d) => d.match.test(title));
    const lines = content.split(/\r?\n/);
    const hintLines = lines.filter((l) => l.startsWith('> ')).slice(0, 1);
    const table = parseFirstTable(content);
    // prose = content minus hint and table lines
    let inTable = false;
    const proseLines: string[] = [];
    let tableSeen = false;
    for (const l of lines) {
      if (hintLines.includes(l)) continue;
      if (!tableSeen && isTableLine(l)) {
        inTable = true;
        continue;
      }
      if (inTable && !isTableLine(l)) {
        inTable = false;
        tableSeen = true;
      }
      if (inTable) continue;
      proseLines.push(l);
    }
    const prose = proseLines.join('\n').trim();
    const entries = prose
      .split(/^### +/m)
      .slice(1)
      .map((e) => {
        const i = e.indexOf('\n');
        return { heading: (i === -1 ? e : e.slice(0, i)).trim(), body: i === -1 ? '' : e.slice(i + 1).trim() };
      });
    return {
      key: def?.key ?? 'other',
      num: numMatch?.[1] ?? def?.num ?? '',
      title,
      hint: hintLines[0]?.slice(2),
      table,
      prose,
      entries,
    } satisfies NotesSection;
  });
  return { meta, sections };
}

/** Section boundaries in the raw text, used for surgical inserts. */
function locateSection(raw: string, key: SectionKey): { start: number; end: number } | null {
  const re = /^## +(.*)$/gm;
  const heads: { idx: number; title: string }[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(raw))) heads.push({ idx: m.index, title: m[1] });
  for (let i = 0; i < heads.length; i++) {
    const title = heads[i].title.replace(/^\d{1,2}\s+/, '');
    const def = SECTION_DEFS.find((d) => d.match.test(title));
    if (def?.key === key) return { start: heads[i].idx, end: i + 1 < heads.length ? heads[i + 1].idx : raw.length };
  }
  return null;
}

/** Insert a row at the top of a section's first table. Creates the section if missing. */
export function insertTableRow(raw: string, key: SectionKey, headers: string[], values: Record<string, string>): string {
  const loc = locateSection(raw, key);
  const row = tableRow(headers.map((h) => values[h] ?? ''));
  if (!loc) {
    const def = SECTION_DEFS.find((d) => d.key === key)!;
    const block = `\n## ${def.num} ${def.title}\n\n> ${def.hint}\n\n${tableRow(headers)}\n|${headers.map(() => '---').join('|')}|\n${row}\n`;
    return raw.trimEnd() + '\n' + block;
  }
  const section = raw.slice(loc.start, loc.end);
  const lines = section.split('\n');
  const sepIdx = lines.findIndex((l, i) => i > 0 && isSeparator(l) && isTableLine(lines[i - 1]));
  if (sepIdx === -1) {
    const tableBlock = `${tableRow(headers)}\n|${headers.map(() => '---').join('|')}|\n${row}\n`;
    return raw.slice(0, loc.end).trimEnd() + '\n\n' + tableBlock + '\n' + raw.slice(loc.end);
  }
  const existingHeaders = splitRow(lines[sepIdx - 1]);
  const aligned = tableRow(existingHeaders.map((h) => values[h] ?? ''));
  lines.splice(sepIdx + 1, 0, aligned);
  return raw.slice(0, loc.start) + lines.join('\n') + raw.slice(loc.end);
}

/** Insert a "### heading" entry at the top of a section (meeting notes). */
export function insertEntry(raw: string, key: SectionKey, heading: string, body: string): string {
  const loc = locateSection(raw, key);
  const entry = `### ${heading}\n\n${body.trim()}\n\n`;
  if (!loc) {
    const def = SECTION_DEFS.find((d) => d.key === key)!;
    return `${raw.trimEnd()}\n\n## ${def.num} ${def.title}\n\n> ${def.hint}\n\n${entry}`;
  }
  const section = raw.slice(loc.start, loc.end);
  const firstEntry = section.search(/^### /m);
  const insertAt =
    firstEntry === -1 ? loc.end : loc.start + firstEntry;
  const prefix = raw.slice(0, insertAt);
  const glue = prefix.endsWith('\n\n') ? '' : prefix.endsWith('\n') ? '\n' : '\n\n';
  return prefix + glue + entry + raw.slice(insertAt);
}

export function updateMetaField(raw: string, patch: Partial<NotesMeta>): string {
  const { meta, body } = splitFrontMatter<Record<string, unknown>>(raw);
  return joinFrontMatter({ ...meta, ...patch }, body);
}

/* ───────────────────────── AI ideas ───────────────────────── */

export interface AiIdea {
  title: string;
  meta: Record<string, string>;
  description: string;
}

export function parseAiIdeas(raw: string): { meta: Record<string, unknown>; intro: string; ideas: AiIdea[] } {
  const { meta, body } = splitFrontMatter(raw);
  const [intro, ...blocks] = body.split(/^## +/m);
  const ideas = blocks.map((b) => {
    const nl = b.indexOf('\n');
    const title = (nl === -1 ? b : b.slice(0, nl)).trim();
    const rest = nl === -1 ? '' : b.slice(nl + 1);
    const m: Record<string, string> = {};
    const desc: string[] = [];
    for (const line of rest.split(/\r?\n/)) {
      const kv = line.match(/^\s*[-*]\s+\*\*([^*]+?):?\*\*:?\s*(.*)$/);
      if (kv) m[kv[1].trim().toLowerCase()] = kv[2].trim();
      else desc.push(line);
    }
    return { title, meta: m, description: desc.join('\n').trim() };
  });
  return { meta, intro: intro.replace(/^#\s.*$/m, '').trim(), ideas };
}

/* ───────────────────────── Edit and delete ───────────────────────── */

/** Line positions of the data rows in a section's first table, in the same order parseFirstTable returns them. */
function tableRowLines(raw: string, key: SectionKey) {
  const loc = locateSection(raw, key);
  if (!loc) return null;
  const before = raw.slice(0, loc.start);
  const lines = raw.slice(loc.start, loc.end).split('\n');
  const sepIdx = lines.findIndex((l, i) => i > 0 && isSeparator(l) && isTableLine(lines[i - 1]));
  if (sepIdx === -1) return null;
  const headers = splitRow(lines[sepIdx - 1]);
  const rows: number[] = [];
  for (let j = sepIdx + 1; j < lines.length && isTableLine(lines[j]); j++) {
    if (splitRow(lines[j]).every((c) => !c)) continue;
    rows.push(j);
  }
  return { loc, before, lines, headers, rows };
}

/** Replace (values) or delete (null) the n-th row of a section table. */
export function updateTableRow(raw: string, key: SectionKey, index: number, values: Record<string, string> | null): string {
  const t = tableRowLines(raw, key);
  if (!t || t.rows[index] === undefined) throw new Error('Row not found. The file may have changed; reload and try again.');
  if (values) t.lines[t.rows[index]] = tableRow(t.headers.map((h) => values[h] ?? ''));
  else t.lines.splice(t.rows[index], 1);
  return t.before + t.lines.join('\n') + raw.slice(t.loc.end);
}

/** Replace (heading + body) or delete (null) the n-th "### " entry of a section. */
export function updateEntry(raw: string, key: SectionKey, index: number, next: { heading: string; body: string } | null): string {
  const loc = locateSection(raw, key);
  if (!loc) throw new Error('Section not found');
  const section = raw.slice(loc.start, loc.end);
  const starts: number[] = [];
  const re = /^### /gm;
  let m: RegExpExecArray | null;
  while ((m = re.exec(section))) starts.push(m.index);
  if (starts[index] === undefined) throw new Error('Entry not found. Reload and try again.');
  const s = starts[index];
  const e = starts[index + 1] ?? section.length;
  const replacement = next ? `### ${next.heading}\n\n${next.body.trim()}\n\n` : '';
  const updated = section.slice(0, s) + replacement + section.slice(e);
  return raw.slice(0, loc.start) + updated.replace(/\n{3,}$/, '\n\n') + raw.slice(loc.end);
}

export function ideaToMarkdown(i: AiIdea): string {
  const order = ['status', 'type', 'impact', 'effort', 'value', 'mrm', 'depends on'];
  const label = (k: string) => k.replace(/\b\w/g, (c) => c.toUpperCase()).replace('Mrm', 'MRM');
  const keys = [...order.filter((k) => i.meta[k]), ...Object.keys(i.meta).filter((k) => !order.includes(k) && i.meta[k])];
  const lines = [`## ${i.title.trim()}`, ...keys.map((k) => `- **${label(k)}:** ${i.meta[k]}`)];
  if (i.description.trim()) lines.push('', i.description.trim());
  return lines.join('\n');
}

/** Replace or delete (null) the n-th "## " idea block. */
export function updateIdea(raw: string, index: number, next: AiIdea | null): string {
  const { body } = splitFrontMatter(raw);
  const fm = raw.slice(0, raw.length - body.length);
  const [intro, ...blocks] = body.split(/^(?=## )/m);
  if (blocks[index] === undefined) throw new Error('Idea not found. Reload and try again.');
  if (next) blocks[index] = ideaToMarkdown(next) + '\n\n';
  else blocks.splice(index, 1);
  return (fm + intro + blocks.join('')).replace(/\n{3,}/g, '\n\n').trimEnd() + '\n';
}
