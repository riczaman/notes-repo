import { z } from 'zod';
import {
  Application,
  Initiative,
  Workstream,
  Integration,
  Overlap,
  Gap,
  ImportRecord,
  LifecycleStage,
  Capability,
  DataEntity,
  FutureChange,
  Opportunity,
  GovernanceItem,
  FILES,
} from './schemas';
import { parseNotes, parseAiIdeas, cell, type NotesDoc, type AiIdea } from './markdown';
import { impactRank } from './meta';

export interface AppBundle {
  id: string;
  profile: Application;
  notesRaw?: string;
  notes?: NotesDoc;
  aiRaw?: string;
  ai?: { meta: Record<string, unknown>; intro: string; ideas: AiIdea[] };
  docs: { path: string; raw: string }[];
}

export interface Model {
  apps: Record<string, AppBundle>;
  appList: AppBundle[];
  initiatives: Initiative[];
  workstreams: Workstream[];
  integrations: Integration[];
  overlaps: Overlap[];
  gaps: Gap[];
  lifecycle: LifecycleStage[];
  capabilities: Capability[];
  dataEntities: DataEntity[];
  futureState: FutureChange[];
  opportunities: Opportunity[];
  governance: GovernanceItem[];
  imports: ImportRecord[];
  issues: { file: string; message: string }[];
  files: Record<string, string>;
}

function parseJson<T>(files: Record<string, string>, path: string, schema: z.ZodType<T>, issues: Model['issues'], fallback: T): T {
  const raw = files[path];
  if (raw == null) return fallback;
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch (e) {
    issues.push({ file: path, message: `Invalid JSON: ${(e as Error).message}` });
    return fallback;
  }
  const res = schema.safeParse(data);
  if (res.success) return res.data;
  issues.push({ file: path, message: res.error.issues.slice(0, 3).map((i) => `${i.path.join('.')}: ${i.message}`).join('; ') });
  return data as T; // show what we can; the warning tells you what to fix
}

export function buildModel(files: Record<string, string>): Model {
  const issues: Model['issues'] = [];
  const apps: Record<string, AppBundle> = {};

  for (const path of Object.keys(files)) {
    const m = path.match(/^data\/apps\/([^/]+)\/profile\.json$/);
    if (!m) continue;
    const profile = parseJson(files, path, Application, issues, null as unknown as Application);
    if (!profile) continue;
    const id = profile.id ?? m[1];
    if (id !== m[1]) issues.push({ file: path, message: `Folder ${m[1]} holds profile id ${id}` });
    const notesRaw = files[FILES.notes(m[1])];
    const aiRaw = files[FILES.ai(m[1])];
    const docs = Object.keys(files)
      .filter((p) => p.startsWith(`data/apps/${m[1]}/docs/`))
      .sort()
      .reverse()
      .map((p) => ({ path: p, raw: files[p] }));
    apps[id] = {
      id,
      profile,
      notesRaw,
      notes: notesRaw ? parseNotes(notesRaw) : undefined,
      aiRaw,
      ai: aiRaw ? parseAiIdeas(aiRaw) : undefined,
      docs,
    };
  }

  const initiatives = parseJson(files, FILES.initiatives, z.array(Initiative), issues, []);
  const integrations = parseJson(files, FILES.integrations, z.array(Integration), issues, []);

  // Referential integrity: every reference must point at a known application.
  for (const i of initiatives)
    for (const a of i.appIds ?? []) if (!apps[a]) issues.push({ file: FILES.initiatives, message: `${i.id} references unknown app ${a}` });
  for (const i of integrations)
    for (const a of [i.source, i.target]) if (!apps[a]) issues.push({ file: FILES.integrations, message: `${i.id} references unknown app ${a}` });
  const ids = new Set<string>();
  for (const i of initiatives) {
    if (ids.has(i.id)) issues.push({ file: FILES.initiatives, message: `Duplicate initiative id ${i.id}` });
    ids.add(i.id);
  }

  const order = { owned: 0, supported: 1, external: 2 } as Record<string, number>;
  const appList = Object.values(apps).sort(
    (a, b) => order[a.profile.portfolio] - order[b.profile.portfolio] || a.profile.name.localeCompare(b.profile.name),
  );

  return {
    apps,
    appList,
    initiatives,
    workstreams: parseJson(files, FILES.workstreams, z.array(Workstream), issues, []),
    integrations,
    overlaps: parseJson(files, FILES.overlaps, z.array(Overlap), issues, []),
    gaps: parseJson(files, FILES.gaps, z.array(Gap), issues, []),
    lifecycle: parseJson(files, FILES.lifecycle, z.array(LifecycleStage), issues, []).sort((a, b) => a.order - b.order),
    dataEntities: parseJson(files, FILES.dataEntities, z.array(DataEntity), issues, []),
    futureState: parseJson(files, FILES.futureState, z.array(FutureChange), issues, []),
    opportunities: parseJson(files, FILES.opportunities, z.array(Opportunity), issues, []),
    governance: parseJson(files, FILES.governance, z.array(GovernanceItem), issues, []),
    capabilities: parseJson(files, FILES.capabilities, z.array(Capability), issues, []),
    imports: parseJson(files, FILES.imports, z.array(ImportRecord), issues, []),
    issues,
    files,
  };
}

/* ───────────────────────── Rollups across notes ───────────────────────── */

export interface RiskRow {
  appId: string;
  id: string;
  type: string;
  initiative: string;
  description: string;
  impact: string;
  likelihood: string;
  owner: string;
  mitigation: string;
  status: string;
}

const isOpen = (s: string) => !/^(closed|done|resolved|complete)/i.test(s.trim());

export function allRisks(m: Model): RiskRow[] {
  return m.appList
    .flatMap((a) => {
      const t = a.notes?.sections.find((s) => s.key === 'risks')?.table;
      return (t?.rows ?? []).map((r) => ({
        appId: a.id,
        id: cell(r, 'ID'),
        type: cell(r, 'Type'),
        initiative: cell(r, 'Initiative'),
        description: cell(r, 'Description'),
        impact: cell(r, 'Impact'),
        likelihood: cell(r, 'Likelihood'),
        owner: cell(r, 'Owner'),
        mitigation: cell(r, 'Mitigation'),
        status: cell(r, 'Status') || 'Open',
      }));
    })
    .filter((r) => r.description && isOpen(r.status))
    .sort((a, b) => impactRank(b.impact) - impactRank(a.impact) || impactRank(b.likelihood) - impactRank(a.likelihood));
}

export interface ActionRow {
  appId: string;
  id: string;
  action: string;
  owner: string;
  due: string;
  status: string;
  source: string;
}

export function allActions(m: Model): ActionRow[] {
  return m.appList.flatMap((a) => {
    const t = a.notes?.sections.find((s) => s.key === 'actions')?.table;
    return (t?.rows ?? [])
      .map((r) => ({
        appId: a.id,
        id: cell(r, 'ID'),
        action: cell(r, 'Action'),
        owner: cell(r, 'Owner'),
        due: cell(r, 'Due'),
        status: cell(r, 'Status'),
        source: cell(r, 'Source'),
      }))
      .filter((r) => r.action && !/^(done|complete|not required|already complete)/i.test(r.status));
  });
}

export interface DecisionRow {
  appId: string;
  date: string;
  decision: string;
  status: string;
  by: string;
  why: string;
}

export function allDecisions(m: Model): DecisionRow[] {
  return m.appList.flatMap((a) => {
    const t = a.notes?.sections.find((s) => s.key === 'decisions')?.table;
    return (t?.rows ?? [])
      .map((r) => ({
        appId: a.id,
        date: cell(r, 'Date'),
        decision: cell(r, 'Decision'),
        status: cell(r, 'Status'),
        by: cell(r, 'Decided by', 'By'),
        why: cell(r, 'Why'),
      }))
      .filter((r) => r.decision);
  });
}

export interface DateRow {
  appId: string;
  date: string;
  /** Parsed start of the period (month precision dates start on the 1st). */
  when: Date;
  precision: 'day' | 'month';
  label: string;
  owner: string;
  status: string;
  notes: string;
  source: 'notes' | 'initiative';
}

export function parseLooseDate(v: string): { when: Date; precision: 'day' | 'month' } | null {
  const d = v.trim().match(/^(\d{4})-(\d{2})(?:-(\d{2}))?$/);
  if (!d) return null;
  const when = new Date(Number(d[1]), Number(d[2]) - 1, d[3] ? Number(d[3]) : 1);
  return { when, precision: d[3] ? 'day' : 'month' };
}

export function allDates(m: Model): DateRow[] {
  const rows: DateRow[] = [];
  for (const a of m.appList) {
    const t = a.notes?.sections.find((s) => s.key === 'dates')?.table;
    for (const r of t?.rows ?? []) {
      const p = parseLooseDate(cell(r, 'Date'));
      if (!p) continue;
      rows.push({
        appId: a.id,
        date: cell(r, 'Date'),
        ...p,
        label: cell(r, 'Milestone'),
        owner: cell(r, 'Owner'),
        status: cell(r, 'Status'),
        notes: cell(r, 'Notes'),
        source: 'notes',
      });
    }
  }
  for (const i of m.initiatives) {
    if (!i.target?.date) continue;
    if (rows.some((r) => r.date === i.target.date && i.appIds.includes(r.appId))) continue;
    const p = parseLooseDate(i.target.date);
    if (p)
      rows.push({ appId: i.appIds[0], date: i.target.date, ...p, label: i.title, owner: '', status: i.status, notes: '', source: 'initiative' });
  }
  return rows.sort((a, b) => a.when.getTime() - b.when.getTime());
}

/** Applications you manage: owned or supported, excluding shared platform components such as a Power Automate flow. */
export const isMine = (a: AppBundle) => a.profile.portfolio !== 'external' && a.profile.category !== 'platform';

export const isPending = (s: string) => /^(pending|open|needed)/i.test(s.trim());

export const today = () => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
};

export const fmtDate = (iso: string) => {
  const p = parseLooseDate(iso);
  if (!p) return iso;
  return p.when.toLocaleDateString('en-CA', p.precision === 'day' ? { month: 'short', day: 'numeric', year: 'numeric' } : { month: 'short', year: 'numeric' });
};

export const todayIso = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
