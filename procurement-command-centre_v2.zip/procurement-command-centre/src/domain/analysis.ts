import type { Model } from './model';
import type { Capability, Integration } from './schemas';

/* ───────────────────────── Lifecycle coverage ───────────────────────── */

export type Coverage = 'strong' | 'partial' | 'gap' | 'undocumented';

export const COVERAGE: Record<Coverage, { label: string; color: string; hint: string }> = {
  strong: { label: 'Strong', color: 'var(--st-green)', hint: 'Capabilities documented, no open gaps, maturity defined or better' },
  partial: { label: 'Partial', color: 'var(--st-amber)', hint: 'Potential gaps, items needing validation, or capabilities still developing' },
  gap: { label: 'Gap', color: 'var(--st-red)', hint: 'At least one confirmed open gap' },
  undocumented: { label: 'Undocumented', color: 'var(--st-grey)', hint: 'Not enough information yet. This is not the same as missing' },
};

export interface StageRow {
  id: string;
  name: string;
  caps: Capability[];
  mature: number;
  developing: number;
  confirmedGaps: number;
  potentialGaps: number;
  unknownGaps: number;
  apps: string[];
  coverage: Coverage;
}

export const NO_STAGE = '__none';

export function stageCoverage(m: Model): StageRow[] {
  const stages = [...m.lifecycle.map((s) => ({ id: s.id, name: s.name })), { id: NO_STAGE, name: 'No stage assigned' }];
  return stages
    .map((s) => {
      const inStage = (x?: string) => (s.id === NO_STAGE ? !x || !m.lifecycle.some((l) => l.id === x) : x === s.id);
      const caps = m.capabilities.filter((c) => inStage(c.stage));
      const gaps = m.gaps.filter((g) => g.status !== 'closed' && inStage(g.stage));
      const mature = caps.filter((c) => c.maturity === 'defined' || c.maturity === 'optimised').length;
      const developing = caps.filter((c) => c.maturity && ['none', 'initial', 'developing'].includes(c.maturity)).length;
      const confirmedGaps = gaps.filter((g) => g.kind === 'confirmed').length;
      const potentialGaps = gaps.filter((g) => g.kind === 'potential' || g.kind === 'needs-validation').length;
      const unknownGaps = gaps.filter((g) => g.kind === 'undocumented').length;
      const apps = [
        ...new Set([
          ...caps.flatMap((c) => c.appIds),
          ...(s.id === NO_STAGE ? [] : m.appList.filter((a) => a.profile.lifecycleStages.includes(s.id)).map((a) => a.id)),
        ]),
      ];
      const coverage: Coverage = confirmedGaps
        ? 'gap'
        : potentialGaps || developing
          ? 'partial'
          : caps.length
            ? 'strong'
            : 'undocumented';
      return { ...s, caps, mature, developing, confirmedGaps, potentialGaps, unknownGaps, apps, coverage };
    })
    .filter((r) => r.id !== NO_STAGE || r.caps.length || m.gaps.some((g) => !g.stage));
}

/* ───────────────────────── Data entities ───────────────────────── */

export const norm = (s: string) => s.trim().toLowerCase();

export function flowsFor(m: Model, entity: string): Integration[] {
  const e = norm(entity);
  return m.integrations.filter((i) => i.data.some((d) => norm(d) === e || norm(d).startsWith(e + ' ') || norm(d).startsWith(e + ':')));
}

export type Role = 'creates' | 'consumes' | 'relays';

/** Roles derived only from documented flows. A system of record is never inferred. */
export function rolesFor(flows: Integration[]): Record<string, Role> {
  const out: Record<string, Role> = {};
  const srcs = new Set(flows.map((f) => f.source));
  const tgts = new Set(flows.map((f) => f.target));
  for (const id of new Set([...srcs, ...tgts])) out[id] = srcs.has(id) && tgts.has(id) ? 'relays' : srcs.has(id) ? 'creates' : 'consumes';
  return out;
}

/** Entity names used in integrations that have no register entry yet. */
export function unregisteredEntities(m: Model): string[] {
  const known = new Set(m.dataEntities.map((d) => norm(d.name)));
  const all = new Map<string, string>();
  for (const i of m.integrations) for (const d of i.data) if (!all.has(norm(d))) all.set(norm(d), d);
  return [...all.entries()].filter(([k]) => !known.has(k)).map(([, v]) => v);
}

/* ───────────────────────── Compare ───────────────────────── */

export function compareFacets(m: Model, ids: string[]) {
  const facet = (label: string, get: (id: string) => string[]) => {
    const values = Object.fromEntries(ids.map((id) => [id, get(id)]));
    const counts = new Map<string, number>();
    for (const id of ids) for (const v of new Set(values[id].map(norm))) counts.set(v, (counts.get(v) ?? 0) + 1);
    const shared = new Set([...counts.entries()].filter(([, n]) => n > 1).map(([k]) => k));
    return { label, values, shared };
  };
  const p = (id: string) => m.apps[id].profile;
  const ints = (id: string) => m.integrations.filter((i) => i.source === id || i.target === id);
  return [
    facet('Business purpose', (id) => [p(id).purpose ?? p(id).summary]),
    facet('Capabilities', (id) => m.capabilities.filter((c) => c.appIds.includes(id)).map((c) => c.name)),
    facet('Features', (id) => p(id).features),
    facet('Processes and workflows', (id) => p(id).processes),
    facet('Data captured or exchanged', (id) => [...new Set(ints(id).flatMap((i) => i.data))]),
    facet('Integrations', (id) => ints(id).map((i) => `${i.source} → ${i.target}`)),
    facet('User groups', (id) => p(id).userGroups),
    facet('Lifecycle stages', (id) => p(id).lifecycleStages),
  ];
}
