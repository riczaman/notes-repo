import type { InitiativeStatus, Classification } from './schemas';

export interface Tone {
  label: string;
  /** CSS variable name holding the colour, e.g. var(--st-teal) */
  color: string;
}

export const STATUS: Record<InitiativeStatus, Tone & { order: number }> = {
  'decision-needed': { label: 'Decision needed', color: 'var(--st-amber)', order: 0 },
  'at-risk': { label: 'At risk', color: 'var(--st-orange)', order: 1 },
  blocked: { label: 'Blocked', color: 'var(--st-red)', order: 2 },
  'in-delivery': { label: 'In delivery', color: 'var(--st-teal)', order: 3 },
  planning: { label: 'Planning', color: 'var(--st-sky)', order: 4 },
  'not-started': { label: 'Not started', color: 'var(--st-grey)', order: 5 },
  bau: { label: 'BAU', color: 'var(--st-sage)', order: 6 },
  done: { label: 'Done', color: 'var(--st-green)', order: 7 },
};

export const STATUS_ORDER = (Object.keys(STATUS) as InitiativeStatus[]).sort((a, b) => STATUS[a].order - STATUS[b].order);

export const CLASSIFICATION: Record<Classification, Tone & { hint: string }> = {
  confirmed: { label: 'Confirmed', color: 'var(--st-green)', hint: 'Directly supported by source documentation' },
  inferred: { label: 'Inferred', color: 'var(--st-sky)', hint: 'Supported by several sources, not explicitly stated' },
  proposed: { label: 'Proposed', color: 'var(--st-amber)', hint: 'Suggested future-state change, not approved' },
  unverified: { label: 'Unverified', color: 'var(--st-orange)', hint: 'Needs confirmation' },
  undocumented: { label: 'Undocumented', color: 'var(--st-grey)', hint: 'Not yet established' },
};

export const INTEGRATION_STATUS: Record<string, Tone> = {
  live: { label: 'Live', color: 'var(--st-teal)' },
  degraded: { label: 'Degraded', color: 'var(--st-orange)' },
  manual: { label: 'Manual', color: 'var(--st-amber)' },
  'in-delivery': { label: 'In delivery', color: 'var(--st-sky)' },
  planned: { label: 'Planned', color: 'var(--st-grey)' },
  retiring: { label: 'Retiring', color: 'var(--st-red)' },
};

export const HEALTH: Record<string, Tone> = {
  green: { label: 'Healthy', color: 'var(--st-green)' },
  amber: { label: 'Watch', color: 'var(--st-amber)' },
  red: { label: 'Critical', color: 'var(--st-red)' },
  unknown: { label: 'Unknown', color: 'var(--st-grey)' },
};

export const APP_STATUS: Record<string, Tone> = {
  live: { label: 'Live', color: 'var(--st-teal)' },
  'in-delivery': { label: 'In delivery', color: 'var(--st-sky)' },
  onboarding: { label: 'Onboarding', color: 'var(--st-amber)' },
  planned: { label: 'Planned', color: 'var(--st-grey)' },
  retiring: { label: 'Retiring', color: 'var(--st-orange)' },
  retired: { label: 'Retired', color: 'var(--st-grey)' },
};

/** Free-text statuses used inside notes tables. Matched loosely. */
export function noteTone(value: string): Tone | null {
  const v = value.trim().toLowerCase();
  if (!v) return null;
  const rules: [RegExp, string][] = [
    [/^(done|complete|completed|decided|closed|already complete)/, 'var(--st-green)'],
    [/^(on track|commit to date|committed)/, 'var(--st-teal)'],
    [/^(in progress|open|in delivery|active)/, 'var(--st-sky)'],
    [/^(at risk|pending|need more info|watch)/, 'var(--st-amber)'],
    [/^(blocked|critical|overdue)/, 'var(--st-red)'],
    [/^(high)/, 'var(--st-orange)'],
    [/^(medium)/, 'var(--st-amber)'],
    [/^(low)/, 'var(--st-sage)'],
    [/^(not started|not yet discussed|not required|tbc|idea)/, 'var(--st-grey)'],
    [/^(risk)$/, 'var(--st-amber)'],
    [/^(issue)$/, 'var(--st-red)'],
    [/^(poc|planned)/, 'var(--st-sky)'],
  ];
  for (const [re, color] of rules) if (re.test(v)) return { label: value, color };
  return null;
}

export const IMPACT_RANK: Record<string, number> = { critical: 4, high: 3, medium: 2, low: 1 };
export const impactRank = (v: string) => IMPACT_RANK[v.trim().toLowerCase()] ?? 0;
