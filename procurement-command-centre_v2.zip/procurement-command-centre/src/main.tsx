import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import '@fontsource-variable/inter';
import '@fontsource-variable/space-grotesk';
import '@fontsource-variable/jetbrains-mono';
import '@xyflow/react/dist/style.css';
import './styles/tokens.css';
import './styles/app.css';
import { DataProvider, useData } from './store/DataProvider';
import { Shell } from './components/Shell';
import { Overview } from './features/overview/Overview';
import { Workboard } from './features/workboard/Workboard';
import { Directory } from './features/apps/Directory';
import { AppWorkspace } from './features/apps/AppWorkspace';
import { EcosystemMap } from './features/map/EcosystemMap';
import { Ingestion } from './features/ingest/Ingestion';
import { Lifecycle } from './features/landscape/Lifecycle';
import { Capabilities } from './features/landscape/Capabilities';
import { Overlaps } from './features/landscape/Overlaps';
import { Gaps } from './features/landscape/Gaps';
import { DataFlows } from './features/landscape/DataFlows';
import { FutureState } from './features/strategy/FutureState';
import { Opportunities } from './features/strategy/Opportunities';
import { Governance } from './features/governance/Governance';
import { Executive } from './features/exec/Executive';
import { Empty } from './components/ui';
import { ErrorBoundary } from './components/ErrorBoundary';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { useEffect } from 'react';

// Apply the saved theme before first paint to avoid a flash.
try {
  const t = localStorage.getItem('pcc-theme');
  if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t;
} catch {
  /* storage unavailable */
}

function ScrollTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function Gate() {
  const { model, loading, error } = useData();
  const { pathname } = useLocation();
  if (loading && !model)
    return (
      <div style={{ display: 'grid', placeItems: 'center', height: '100vh' }}>
        <Empty icon={Loader2} title="Loading portfolio data" />
      </div>
    );
  if (!model)
    return (
      <div style={{ display: 'grid', placeItems: 'center', height: '100vh' }}>
        <Empty icon={AlertTriangle} title="Could not reach the data API">
          {error}. Start the app with <code>npm run dev</code> so the local file API is running.
        </Empty>
      </div>
    );
  return (
    <Shell>
      <ScrollTop />
      <ErrorBoundary resetKey={pathname}>
      <Routes>
        <Route path="/" element={<Overview />} />
        <Route path="/workboard" element={<Workboard />} />
        <Route path="/apps" element={<Directory />} />
        <Route path="/apps/:id" element={<AppWorkspace />} />
        <Route path="/apps/:id/:tab" element={<AppWorkspace />} />
        <Route path="/landscape/map" element={<EcosystemMap />} />
        <Route path="/ingest" element={<Ingestion />} />
        <Route path="/landscape/lifecycle" element={<Lifecycle />} />
        <Route path="/landscape/capabilities" element={<Capabilities />} />
        <Route path="/landscape/overlaps" element={<Overlaps />} />
        <Route path="/landscape/gaps" element={<Gaps />} />
        <Route path="/landscape/data" element={<DataFlows />} />
        <Route path="/strategy/future" element={<FutureState />} />
        <Route path="/strategy/opportunities" element={<Opportunities />} />
        <Route path="/governance" element={<Governance />} />
        <Route path="/executive" element={<Executive />} />
        <Route path="*" element={<Empty title="Page not found" />} />
      </Routes>
      </ErrorBoundary>
    </Shell>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <DataProvider>
      <HashRouter>
        <Gate />
      </HashRouter>
    </DataProvider>
  </StrictMode>,
);
