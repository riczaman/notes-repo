import { Component, type ReactNode } from 'react';
import { AlertTriangle } from 'lucide-react';

/** Keeps one broken page from blanking the whole app. Your data files are not affected. */
export class ErrorBoundary extends Component<{ children: ReactNode; resetKey: string }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  componentDidUpdate(prev: { resetKey: string }) {
    if (prev.resetKey !== this.props.resetKey && this.state.error) this.setState({ error: null });
  }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="card card-pad" style={{ maxWidth: 720 }}>
        <div className="row" style={{ marginBottom: 10 }}>
          <AlertTriangle size={18} color="var(--st-red)" />
          <h3 className="card-title">This page hit an error</h3>
        </div>
        <p className="muted" style={{ fontSize: 13.5 }}>
          Your data is safe on disk. The most common cause is a hand-edited file with a typo (for example a missing comma in JSON). Fix the file or undo the last change, then reload.
        </p>
        <pre className="textarea" style={{ whiteSpace: 'pre-wrap', fontSize: 12 }}>{this.state.error.message}</pre>
        <button className="btn" onClick={() => location.reload()}>
          Reload
        </button>
      </div>
    );
  }
}
