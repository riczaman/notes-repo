import { useMemo, useRef } from 'react';
import { ReactFlow, ReactFlowProvider, Background, Controls, Handle, Position, MarkerType, BackgroundVariant, type Node, type Edge, type NodeProps } from '@xyflow/react';
import dagre from '@dagrejs/dagre';
import { AppTile, tone } from './ui';
import type { Application } from '../domain/schemas';

/** Small read-only flow diagram used by Data flows, Current vs future state and the Executive view. */

export type Variant = 'normal' | 'proposed' | 'modified' | 'retiring' | 'sor' | 'external';

export type GNode = {
  id: string;
  label: string;
  sub?: string;
  category?: Application['category'];
  variant?: Variant;
  badge?: string;
};
export interface GEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  color: string;
  dashed?: boolean;
  faded?: boolean;
  animated?: boolean;
}

const W = 176;
const H = 50;

const VARIANT_COLOR: Record<Variant, string> = {
  normal: 'var(--border-strong)',
  external: 'var(--border-strong)',
  proposed: 'var(--st-green)',
  modified: 'var(--st-amber)',
  retiring: 'var(--st-red)',
  sor: 'var(--accent)',
};

function GraphNode({ data }: NodeProps<Node<GNode>>) {
  const v = data.variant ?? 'normal';
  return (
    <div
      className={`node gnode v-${v}`}
      style={{ width: W, ...tone(VARIANT_COLOR[v]) }}
      title={data.sub ? `${data.label} · ${data.sub}` : data.label}
    >
      <Handle type="target" position={Position.Left} />
      <AppTile app={{ category: data.category ?? 'platform' }} size={26} />
      <div style={{ minWidth: 0, flex: 1 }}>
        <div className="node-name">{data.label}</div>
        {(data.sub || data.badge) && (
          <div className="node-meta">
            {data.sub && <span className="mono">{data.sub}</span>}
            {data.badge && <span className="gbadge">{data.badge}</span>}
          </div>
        )}
      </div>
      <Handle type="source" position={Position.Right} />
    </div>
  );
}
const nodeTypes = { g: GraphNode };

const READABLE = 0.72;

/** fit = true shows the whole graph (slides, print). Otherwise it opens at a readable zoom anchored on the start of the flow. */
export function FlowGraph({ nodes, edges, height = 420, fit = false }: { nodes: GNode[]; edges: GEdge[]; height?: number; fit?: boolean }) {
  const box = useRef<HTMLDivElement>(null);
  const { rfNodes, rfEdges } = useMemo(() => {
    const g = new dagre.graphlib.Graph();
    g.setGraph({ rankdir: 'LR', nodesep: 16, ranksep: 54, marginx: 10, marginy: 10 });
    g.setDefaultEdgeLabel(() => ({}));
    nodes.forEach((n) => g.setNode(n.id, { width: W, height: H }));
    edges.forEach((e) => g.setEdge(e.source, e.target));
    dagre.layout(g);
    const rfNodes: Node<GNode>[] = nodes.map((n) => {
      const p = g.node(n.id);
      return { id: n.id, type: 'g', position: { x: p.x - W / 2, y: p.y - H / 2 }, data: n, draggable: false };
    });
    const rfEdges: Edge[] = edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
      label: e.label,
      animated: e.animated,
      style: { stroke: e.color, strokeWidth: 2, strokeDasharray: e.dashed ? '7 5' : undefined, opacity: e.faded ? 0.3 : 1 },
      markerEnd: { type: MarkerType.ArrowClosed, color: e.color, width: 15, height: 15 },
    }));
    return { rfNodes, rfEdges };
  }, [nodes, edges]);

  return (
    <div className="map-canvas flow-mini" style={{ height }} ref={box}>
      <ReactFlowProvider>
        <ReactFlow
          nodes={rfNodes}
          edges={rfEdges}
          nodeTypes={nodeTypes}
          fitView={fit}
          fitViewOptions={{ padding: 0.12 }}
          onInit={(inst) => {
            if (fit || !box.current || !rfNodes.length) return;
            const xs = rfNodes.map((n) => n.position.x);
            const ys = rfNodes.map((n) => n.position.y);
            const minX = Math.min(...xs);
            const minY = Math.min(...ys);
            const gw = Math.max(...xs) + W - minX;
            const gh = Math.max(...ys) + H - minY;
            const { width, height: h } = box.current.getBoundingClientRect();
            if (Math.min((width - 40) / gw, (h - 40) / gh) >= READABLE) {
              setTimeout(() => inst.fitView({ padding: 0.12 }), 60);
              return;
            }
            const y = gh * READABLE < h - 40 ? (h - gh * READABLE) / 2 - minY * READABLE : 20 - minY * READABLE;
            setTimeout(() => inst.setViewport({ x: 20 - minX * READABLE, y, zoom: READABLE }), 30);
          }}
          minZoom={0.2}
          maxZoom={1.4}
          nodesConnectable={false}
          proOptions={{ hideAttribution: true }}
        >
          <Background variant={BackgroundVariant.Dots} gap={20} size={1.2} />
          <Controls showInteractive={false} />
        </ReactFlow>
      </ReactFlowProvider>
    </div>
  );
}
