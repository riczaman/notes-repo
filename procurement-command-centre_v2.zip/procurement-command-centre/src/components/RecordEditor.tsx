import { useState } from 'react';
import type { ZodType } from 'zod';
import { Save, Trash2, AlertTriangle } from 'lucide-react';
import { Drawer, tone } from './ui';
import { useData, useModel } from '../store/DataProvider';

/**
 * One form for every JSON collection (initiatives, integrations, gaps, opportunities…).
 * Each page passes field definitions; the editor validates with the Zod schema before writing.
 */

export type FieldType = 'text' | 'textarea' | 'select' | 'lines' | 'apps' | 'app' | 'bool' | 'number' | 'evidence';

export interface FieldSpec {
  key: string; // dot paths allowed: "target.label"
  label: string;
  type?: FieldType;
  options?: string[];
  hint?: string;
  wide?: boolean;
  readOnlyOnEdit?: boolean;
}

const get = (o: Record<string, unknown>, path: string): unknown => path.split('.').reduce<unknown>((v, k) => (v as Record<string, unknown> | undefined)?.[k], o);
function set(o: Record<string, unknown>, path: string, value: unknown) {
  const parts = path.split('.');
  let cur = o;
  for (let i = 0; i < parts.length - 1; i++) {
    cur[parts[i]] = { ...((cur[parts[i]] as object) ?? {}) };
    cur = cur[parts[i]] as Record<string, unknown>;
  }
  if (value === '' || value === undefined) delete cur[parts[parts.length - 1]];
  else cur[parts[parts.length - 1]] = value;
}

const toLines = (v: unknown) => (Array.isArray(v) ? v.join('\n') : '');
const fromLines = (s: string) => s.split('\n').map((x) => x.trim()).filter(Boolean);
const evToLines = (v: unknown) =>
  Array.isArray(v) ? v.map((e: Record<string, string>) => [e.source, e.ref ?? '', e.reviewed ?? '', e.confidence ?? ''].join(' | ').replace(/( \| )+$/, '')).join('\n') : '';
const evFromLines = (s: string) =>
  fromLines(s).map((l) => {
    const [source, ref, reviewed, confidence] = l.split('|').map((x) => x.trim());
    const e: Record<string, string> = { source };
    if (ref) e.ref = ref;
    if (reviewed) e.reviewed = reviewed;
    if (confidence && ['high', 'medium', 'low'].includes(confidence)) e.confidence = confidence;
    return e;
  });

/** Keeps the raw text while typing so blank lines and trailing newlines are not stripped mid-edit. */
function LinesField({ initial, onChange, placeholder, mono }: { initial: string; onChange: (text: string) => void; placeholder: string; mono: boolean }) {
  const [text, setText] = useState(initial);
  return (
    <textarea
      className="textarea"
      rows={4}
      style={{ width: '100%', fontFamily: mono ? undefined : 'var(--font-ui)' }}
      placeholder={placeholder}
      value={text}
      onChange={(e) => {
        setText(e.target.value);
        onChange(e.target.value);
      }}
    />
  );
}

export function nextId(prefix: string, list: { id: string }[]) {
  const n = list.map((x) => Number(x.id.replace(`${prefix}-`, ''))).filter((x) => !Number.isNaN(x));
  return `${prefix}-${String((n.length ? Math.max(...n) : 0) + 1).padStart(3, '0')}`;
}

/** Upsert and delete helpers for one JSON array file. */
export function useCollection<T extends { id: string }>(file: string, list: T[]) {
  const { save, toast } = useData();
  const write = async (next: T[], msg: string) => {
    await save([{ path: file, content: JSON.stringify(next, null, 2) + '\n' }]);
    toast(msg);
  };
  return {
    upsert: async (rec: T, originalId?: string) => {
      const key = originalId ?? rec.id;
      if (rec.id !== key && list.some((x) => x.id === rec.id)) throw new Error(`ID ${rec.id} already exists`);
      if (!originalId && list.some((x) => x.id === rec.id)) throw new Error(`ID ${rec.id} already exists`);
      const exists = list.some((x) => x.id === key);
      await write(exists ? list.map((x) => (x.id === key ? rec : x)) : [...list, rec], `${rec.id} saved`);
    },
    remove: async (id: string) => {
      await write(
        list.filter((x) => x.id !== id),
        `${id} deleted`,
      );
    },
  };
}

interface Props<T> {
  title: string;
  fields: FieldSpec[];
  initial: Partial<T>;
  isNew: boolean;
  schema: ZodType<T>;
  onSave: (rec: T) => Promise<void>;
  onDelete?: () => Promise<void>;
  onClose: () => void;
  deleteWarning?: string;
}

export function RecordEditor<T>({ title, fields, initial, isNew, schema, onSave, onDelete, onClose, deleteWarning }: Props<T>) {
  const m = useModel();
  const [draft, setDraft] = useState<Record<string, unknown>>(() => structuredClone(initial as Record<string, unknown>));
  const [errors, setErrors] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const apps = m.appList;

  const field = (f: FieldSpec) => {
    const v = get(draft, f.key);
    const update = (val: unknown) => {
      const next = structuredClone(draft);
      set(next, f.key, val);
      setDraft(next);
    };
    const disabled = !isNew && f.readOnlyOnEdit;
    switch (f.type ?? 'text') {
      case 'textarea':
        return <textarea className="textarea" rows={3} style={{ width: '100%', fontFamily: 'var(--font-ui)' }} value={String(v ?? '')} onChange={(e) => update(e.target.value)} />;
      case 'select':
        return (
          <select className="select" style={{ width: '100%' }} value={String(v ?? '')} onChange={(e) => update(e.target.value)}>
            <option value="" />
            {f.options?.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        );
      case 'lines':
        return <LinesField initial={toLines(v)} placeholder="One item per line" mono={false} onChange={(t) => update(fromLines(t))} />;
      case 'evidence':
        return <LinesField initial={evToLines(v)} placeholder="Source | page or sheet | YYYY-MM-DD | high" mono onChange={(t) => update(evFromLines(t))} />;
      case 'bool':
        return (
          <span className="check">
            <input type="checkbox" checked={Boolean(v)} onChange={(e) => update(e.target.checked)} /> Yes
          </span>
        );
      case 'number':
        return <input className="input" type="number" style={{ width: '100%' }} value={v === undefined ? '' : String(v)} onChange={(e) => update(e.target.value === '' ? undefined : Number(e.target.value))} />;
      case 'app':
        return (
          <select className="select" style={{ width: '100%' }} value={String(v ?? '')} onChange={(e) => update(e.target.value)}>
            <option value="" />
            {apps.map((a) => (
              <option key={a.id} value={a.id}>
                {a.id} · {a.profile.name}
              </option>
            ))}
          </select>
        );
      case 'apps': {
        const sel = new Set((v as string[]) ?? []);
        return (
          <div className="row-wrap">
            {apps.map((a) => (
              <button
                type="button"
                key={a.id}
                className={`filter-chip ${sel.has(a.id) ? 'on' : ''}`}
                style={{ height: 26, fontSize: 12 }}
                onClick={() => {
                  const n = new Set(sel);
                  if (n.has(a.id)) n.delete(a.id);
                  else n.add(a.id);
                  update([...n]);
                }}
              >
                {a.id}
              </button>
            ))}
          </div>
        );
      }
      default:
        return <input className="input" style={{ width: '100%' }} disabled={disabled} value={String(v ?? '')} onChange={(e) => update(e.target.value)} />;
    }
  };

  const submit = async () => {
    const res = schema.safeParse(draft);
    if (!res.success) return setErrors(res.error.issues.map((i) => `${i.path.join('.') || 'record'}: ${i.message}`));
    setBusy(true);
    try {
      await onSave(res.data);
      onClose();
    } catch (e) {
      setErrors([(e as Error).message]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Drawer
      onClose={onClose}
      head={
        <>
          <div className="eyebrow">{isNew ? 'New record' : 'Edit record'}</div>
          <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 20 }}>{title}</h2>
        </>
      }
    >
      <form
        className="stack"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <div className="add-grid" style={{ gridTemplateColumns: 'repeat(2, minmax(0, 1fr))' }}>
          {fields.map((f) => (
            <label key={f.key} style={f.wide || ['textarea', 'lines', 'apps', 'evidence'].includes(f.type ?? '') ? { gridColumn: '1 / -1' } : undefined}>
              <span className="field-label">{f.label}</span>
              {field(f)}
              {f.hint && <span className="faint" style={{ fontSize: 11.5, display: 'block', marginTop: 3 }}>{f.hint}</span>}
            </label>
          ))}
        </div>
        {errors.length > 0 && (
          <div className="callout" style={tone('var(--st-red)')}>
            <AlertTriangle size={16} />
            <div>
              {errors.map((e) => (
                <div key={e} className="mono" style={{ fontSize: 12 }}>
                  {e}
                </div>
              ))}
            </div>
          </div>
        )}
        <div className="row" style={{ justifyContent: 'space-between' }}>
          {onDelete && !isNew ? (
            <button
              type="button"
              className="btn"
              style={{ color: 'var(--st-red)' }}
              onClick={async () => {
                if (!window.confirm(deleteWarning ?? 'Delete this record? It is removed from the file. Use git or the import snapshots to recover it.')) return;
                try {
                  await onDelete();
                  onClose();
                } catch (e) {
                  setErrors([(e as Error).message]);
                }
              }}
            >
              <Trash2 size={14} /> Delete
            </button>
          ) : (
            <span />
          )}
          <div className="row">
            <button type="button" className="btn" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={busy}>
              <Save size={14} /> Save
            </button>
          </div>
        </div>
      </form>
    </Drawer>
  );
}

/* ───────────── Field sets reused across pages ───────────── */

export const STATUS_OPTIONS = ['in-delivery', 'decision-needed', 'at-risk', 'blocked', 'planning', 'bau', 'not-started', 'done'];
export const CLASS_OPTIONS = ['confirmed', 'inferred', 'proposed', 'unverified', 'undocumented'];

export const INITIATIVE_FIELDS = (workstreams: string[]): FieldSpec[] => [
  { key: 'id', label: 'Initiative ID', hint: 'e.g. USFF-GENAI. Cannot change after creation', readOnlyOnEdit: true },
  { key: 'title', label: 'Title' },
  { key: 'status', label: 'Status', type: 'select', options: STATUS_OPTIONS },
  { key: 'workstream', label: 'Workstream', type: 'select', options: workstreams },
  { key: 'priority', label: 'Priority', type: 'select', options: ['P1', 'P2', 'P3'] },
  { key: 'phase', label: 'Phase' },
  { key: 'target.label', label: 'Target (text)', hint: 'e.g. F27 Q2 (proposed)' },
  { key: 'target.date', label: 'Target date', hint: 'YYYY-MM-DD, only if a hard date exists' },
  { key: 'leadershipFocus', label: 'Leadership focus', type: 'bool' },
  { key: 'aiEnabled', label: 'AI-enabled', type: 'bool' },
  { key: 'appIds', label: 'Applications', type: 'apps' },
  { key: 'summary', label: 'Summary', type: 'textarea' },
  { key: 'problem', label: 'Problem', type: 'textarea' },
  { key: 'decision', label: 'Open decision (as a question)', type: 'textarea' },
  { key: 'progress', label: 'Progress', type: 'lines' },
  { key: 'nextSteps', label: 'Next steps', type: 'lines' },
  { key: 'dependencies', label: 'Dependencies', type: 'lines' },
  { key: 'tags', label: 'Tags', type: 'lines', hint: 'bundle:7 changes shows a count badge; conflict:… shows a warning' },
];

export const INTEGRATION_FIELDS: FieldSpec[] = [
  { key: 'id', label: 'Integration ID', readOnlyOnEdit: true },
  { key: 'status', label: 'Status', type: 'select', options: ['live', 'degraded', 'manual', 'in-delivery', 'planned', 'retiring'] },
  { key: 'source', label: 'From application', type: 'app' },
  { key: 'target', label: 'To application', type: 'app' },
  { key: 'purpose', label: 'Purpose', wide: true },
  { key: 'method', label: 'Integration method', hint: 'API, ADF, email, RPA, file…' },
  { key: 'frequency', label: 'Frequency' },
  { key: 'direction', label: 'Direction', type: 'select', options: ['one-way', 'two-way'] },
  { key: 'classification', label: 'Classification', type: 'select', options: CLASS_OPTIONS },
  { key: 'process', label: 'Business process', wide: true },
  { key: 'data', label: 'Data exchanged', type: 'lines', hint: 'Use the same entity names as on the Data flows page' },
  { key: 'dependencies', label: 'Technical dependencies', type: 'lines' },
  { key: 'limitations', label: 'Known limitations', type: 'lines' },
  { key: 'evidence', label: 'Evidence', type: 'evidence', hint: 'One per line: Source | page or sheet | YYYY-MM-DD | high/medium/low' },
];
