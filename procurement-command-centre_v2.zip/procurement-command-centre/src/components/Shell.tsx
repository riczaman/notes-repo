import { useEffect, useState, type ReactNode } from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, KanbanSquare, Boxes, Network, FileInput, Moon, Sun, FileText, Route, Blocks, GitCompare, Grid3x3, Database, GitBranch, Lightbulb, ShieldCheck, Presentation } from 'lucide-react';
import { useData, useModel } from '../store/DataProvider';
import { HEALTH } from '../domain/meta';
import { appContext, portfolioContext } from '../domain/context';
import { todayIso, isMine } from '../domain/model';

function readTheme(): 'dark' | 'light' {
  try {
    const t = localStorage.getItem('pcc-theme');
    if (t === 'light' || t === 'dark') return t;
  } catch {
    /* storage unavailable */
  }
  return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
}

export function useTheme() {
  const [theme, setTheme] = useState<'dark' | 'light'>(readTheme);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try {
      localStorage.setItem('pcc-theme', theme);
    } catch {
      /* storage unavailable */
    }
  }, [theme]);
  return [theme, () => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))] as const;
}

export function useExportContext() {
  const m = useModel();
  const { save, toast } = useData();
  return async (ids?: string[]) => {
    const stamp = todayIso();
    const targets = ids ?? m.appList.filter(isMine).map((a) => a.id);
    const writes = targets.map((id) => ({ path: `context/${id}.md`, content: appContext(m, id, stamp) }));
    if (!ids) writes.push({ path: 'context/PORTFOLIO.md', content: portfolioContext(m, stamp) });
    try {
      await save(writes);
      toast(`Copilot context written: ${writes.length} file${writes.length > 1 ? 's' : ''} in context/`);
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };
}

export function Shell({ children }: { children: ReactNode }) {
  const m = useModel();
  const { readAt } = useData();
  const [theme, toggle] = useTheme();
  const exportContext = useExportContext();
  const owned = m.appList.filter(isMine);
  const active = m.initiatives.filter((i) => i.status !== 'done').length;

  return (
    <div className="shell">
      <nav className="rail" aria-label="Main">
        <div className="brand">
          <span className="brand-mark">
            <svg width="20" height="20" viewBox="0 0 32 32" aria-hidden>
              <circle cx="9" cy="16" r="4" fill="var(--accent)" />
              <circle cx="23" cy="8.5" r="3.4" fill="var(--st-amber)" />
              <circle cx="23" cy="23.5" r="3.4" fill="var(--st-grey)" />
              <path d="M12.5 14.5l7-4.2M12.5 17.5l7 4.2" stroke="var(--accent)" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </span>
          <div>
            <div className="brand-name">Command Centre</div>
            <div className="brand-sub">Procurement Technology</div>
          </div>
        </div>

        <div className="nav-group">
          <div className="nav-label">Portfolio</div>
          <NavLink to="/" end className="nav-link">
            <LayoutDashboard size={16} /> Overview
          </NavLink>
          <NavLink to="/workboard" className="nav-link">
            <KanbanSquare size={16} /> Workboard <span className="count">{active}</span>
          </NavLink>
          <NavLink to="/apps" end className="nav-link">
            <Boxes size={16} /> Applications <span className="count">{owned.length}</span>
          </NavLink>
        </div>

        <div className="nav-group">
          <div className="nav-label">Landscape</div>
          <NavLink to="/landscape/lifecycle" className="nav-link">
            <Route size={16} /> Lifecycle <span className="count">{m.lifecycle.length || ''}</span>
          </NavLink>
          <NavLink to="/landscape/map" className="nav-link">
            <Network size={16} /> Ecosystem map <span className="count">{m.integrations.length}</span>
          </NavLink>
          <NavLink to="/landscape/capabilities" className="nav-link">
            <Blocks size={16} /> Capabilities <span className="count">{m.capabilities.length}</span>
          </NavLink>
          <NavLink to="/landscape/overlaps" className="nav-link">
            <GitCompare size={16} /> Overlaps <span className="count">{m.overlaps.length}</span>
          </NavLink>
          <NavLink to="/landscape/gaps" className="nav-link">
            <Grid3x3 size={16} /> Gaps <span className="count">{m.gaps.filter((g) => g.status !== 'closed').length}</span>
          </NavLink>
          <NavLink to="/landscape/data" className="nav-link">
            <Database size={16} /> Data flows
          </NavLink>
        </div>

        <div className="nav-group">
          <div className="nav-label">Strategy and governance</div>
          <NavLink to="/strategy/future" className="nav-link">
            <GitBranch size={16} /> Current vs future <span className="count">{m.futureState.length}</span>
          </NavLink>
          <NavLink to="/strategy/opportunities" className="nav-link">
            <Lightbulb size={16} /> Opportunities <span className="count">{m.opportunities.length}</span>
          </NavLink>
          <NavLink to="/governance" className="nav-link">
            <ShieldCheck size={16} /> Model governance <span className="count">{m.governance.filter((g) => g.status !== 'done').length}</span>
          </NavLink>
          <NavLink to="/executive" className="nav-link">
            <Presentation size={16} /> Executive view
          </NavLink>
          <NavLink to="/ingest" className="nav-link">
            <FileInput size={16} /> Data ingestion
          </NavLink>
        </div>

        <div className="nav-group">
          <div className="nav-label">My applications</div>
          {owned.map((a) => (
            <NavLink key={a.id} to={`/apps/${a.id}`} className="nav-link" style={{ fontSize: 13, padding: '5px 10px' }}>
              <span className="nav-app-dot" style={{ background: HEALTH[a.profile.health]?.color }} />
              <span className="grow" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.profile.name}</span>
              <span className="count">{a.id}</span>
            </NavLink>
          ))}
        </div>

        <div className="rail-foot">
          <button className="btn btn-sm" onClick={() => exportContext()} title="Write one Markdown context pack per app to context/">
            <FileText size={14} /> Build Copilot context
          </button>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <span className="sync">
              <span className="live" /> Synced {readAt ? new Date(readAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
            </span>
            <button className="btn btn-ghost icon-btn btn-sm" onClick={toggle} aria-label="Toggle theme" title="Toggle light and dark">
              {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
            </button>
          </div>
        </div>
      </nav>
      <main className="main">{children}</main>
    </div>
  );
}
