import { useEffect, useLayoutEffect, useRef, type CSSProperties, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import gsap from 'gsap';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import {
  AppWindow, Bot, Workflow, Cloud, BrainCircuit, Server, BarChart3, Archive, X, Inbox, Sparkles,
  type LucideIcon,
} from 'lucide-react';
import { STATUS, CLASSIFICATION, HEALTH, noteTone } from '../domain/meta';
import type { InitiativeStatus, Classification, Application } from '../domain/schemas';
import { useModel } from '../store/DataProvider';

const tone = (color: string) => ({ '--tone': color }) as CSSProperties;

export function Pill({ color, children, dot = true, title }: { color: string; children: ReactNode; dot?: boolean; title?: string }) {
  return (
    <span className="pill" style={tone(color)} title={title}>
      {dot && <span className="pill-dot" />}
      {children}
    </span>
  );
}

export function StatusPill({ status }: { status: InitiativeStatus }) {
  const s = STATUS[status] ?? { label: status, color: 'var(--st-grey)' };
  return <Pill color={s.color}>{s.label}</Pill>;
}

/** Renders free-text table values (Status, Impact, Type) as pills when they match a known tone. */
export function NoteValue({ value, column }: { value: string; column: string }) {
  if (/status|impact|likelihood|type|decision$/i.test(column)) {
    const t = noteTone(value);
    if (t) return <Pill color={t.color}>{value}</Pill>;
  }
  return <>{value}</>;
}

export function ClassBadge({ k }: { k: Classification }) {
  const c = CLASSIFICATION[k] ?? CLASSIFICATION.undocumented;
  return (
    <span className="badge-class" data-k={k} style={tone(c.color)} title={c.hint}>
      {c.label}
    </span>
  );
}

export function HealthDot({ health }: { health: string }) {
  const h = HEALTH[health] ?? HEALTH.unknown;
  return <span className="health-dot" style={tone(h.color)} title={`Health: ${h.label}`} />;
}

export const CATEGORY: Record<string, { icon: LucideIcon; color: string; label: string }> = {
  'web-app': { icon: AppWindow, color: 'var(--st-teal)', label: 'Web app' },
  automation: { icon: Bot, color: 'var(--st-orange)', label: 'Automation' },
  'data-pipeline': { icon: Workflow, color: 'var(--st-sky)', label: 'Data pipeline' },
  saas: { icon: Cloud, color: 'var(--st-amber)', label: 'SaaS' },
  'ai-model': { icon: BrainCircuit, color: 'var(--st-green)', label: 'AI model' },
  platform: { icon: Server, color: 'var(--st-grey)', label: 'Platform' },
  reporting: { icon: BarChart3, color: 'var(--st-sage)', label: 'Reporting' },
  'legacy-app': { icon: Archive, color: 'var(--st-red)', label: 'Legacy app' },
};

export function AppTile({ app, size = 40 }: { app: Pick<Application, 'category'>; size?: number }) {
  const c = CATEGORY[app.category] ?? CATEGORY.platform;
  const Icon = c.icon;
  return (
    <span className="tile" style={{ ...tone(c.color), '--s': `${size}px` } as CSSProperties}>
      <Icon size={Math.round(size * 0.48)} strokeWidth={1.8} />
    </span>
  );
}

export function AppChip({ id }: { id: string }) {
  const m = useModel();
  const a = m.apps[id];
  return (
    <Link to={`/apps/${id}`} className="chip chip-mono" title={a?.profile.name ?? id} onClick={(e) => e.stopPropagation()}>
      {id}
    </Link>
  );
}

export function AiTag() {
  return (
    <span className="pill tag-ai" style={tone('var(--st-teal)')} title="Initiative uses AI">
      <Sparkles size={11} /> AI
    </span>
  );
}

export function Empty({ icon: Icon = Inbox, title, children }: { icon?: LucideIcon; title: string; children?: ReactNode }) {
  return (
    <div className="empty">
      <Icon size={26} strokeWidth={1.5} />
      <div style={{ color: 'var(--text-2)', fontWeight: 600 }}>{title}</div>
      {children && <div>{children}</div>}
    </div>
  );
}

export function Md({ children }: { children: string }) {
  return (
    <div className="md">
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{children}</ReactMarkdown>
    </div>
  );
}

export function Drawer({ onClose, head, children }: { onClose: () => void; head: ReactNode; children: ReactNode }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [onClose]);
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <aside className="drawer" role="dialog" aria-modal="true">
        <div className="drawer-head">
          <div className="row" style={{ alignItems: 'flex-start' }}>
            <div className="grow">{head}</div>
            <button className="btn btn-ghost icon-btn" onClick={onClose} aria-label="Close">
              <X size={18} />
            </button>
          </div>
        </div>
        <div className="drawer-body">{children}</div>
      </aside>
    </>
  );
}

export function PageHead({ eyebrow, title, sub, actions }: { eyebrow?: ReactNode; title: ReactNode; sub?: ReactNode; actions?: ReactNode }) {
  return (
    <header className="page-head reveal">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1 className="page-title">{title}</h1>
        {sub && <div className="page-sub">{sub}</div>}
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </header>
  );
}

const reduced = () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/** Staggered entrance for every .reveal element inside the returned ref. Runs once per mount. */
export function useReveal<T extends HTMLElement>(deps: unknown[] = []) {
  const ref = useRef<T>(null);
  useLayoutEffect(() => {
    // Background tabs pause requestAnimationFrame; skip the entrance so content is never stuck half-faded.
    if (!ref.current || reduced() || document.hidden) return;
    const ctx = gsap.context(() => {
      gsap.from('.reveal', { opacity: 0, y: 14, duration: 0.55, ease: 'power3.out', stagger: 0.045, clearProps: 'transform,opacity' });
    }, ref);
    return () => ctx.revert();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return ref;
}

export function CountUp({ value }: { value: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const prev = useRef(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (reduced() || document.hidden) {
      el.textContent = String(value);
      prev.current = value;
      return;
    }
    const obj = { v: prev.current };
    const tw = gsap.to(obj, { v: value, duration: 1.1, ease: 'power2.out', onUpdate: () => (el.textContent = String(Math.round(obj.v))) });
    prev.current = value;
    return () => {
      tw.kill();
    };
  }, [value]);
  return <span ref={ref}>0</span>;
}

export function Kpi({ icon: Icon, label, value, foot, color }: { icon: LucideIcon; label: string; value: number; foot?: ReactNode; color: string }) {
  return (
    <div className="card kpi reveal" style={tone(color)}>
      <div className="kpi-top">
        <span className="kpi-icon">
          <Icon size={15} />
        </span>
        {label}
      </div>
      <div className="kpi-value">
        <CountUp value={value} />
      </div>
      {foot && <div className="kpi-foot">{foot}</div>}
    </div>
  );
}

export { tone };
