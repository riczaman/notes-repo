---
app: CBUD
updated: 2026-11-08
author: Claude (proposed ideas, not commitments)
---

# AI opportunities: Contract Buddy

## Automated quarterly test harness
- **Status:** Idea
- **Type:** Evaluation pipeline
- **Impact:** High
- **Effort:** M
- **Value:** Runs the quarterly accuracy test against a fixed labelled set and produces the MRM report automatically, since testing continues in perpetuity
- **MRM:** Supports existing MRM obligations
- **Depends on:** Labelled test set from business

## Drift monitoring dashboard
- **Status:** Idea
- **Type:** Monitoring
- **Impact:** Medium
- **Effort:** S
- **Value:** Tracks extraction confidence and deviation-score distribution month over month
- **MRM:** Supports monitoring plan
- **Depends on:** Prediction logging

## Agiloft capability comparison
- **Status:** Idea
- **Type:** Analysis
- **Impact:** High
- **Effort:** S
- **Value:** Side-by-side test of Contract Buddy and Agiloft AI on the same contracts to support the keep or decommission decision
- **MRM:** None
- **Depends on:** Agiloft sandbox access
