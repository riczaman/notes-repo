---
app: CBUD
title: Contract Buddy
tagline: AI contract extraction and deviation scoring for lower-risk contracting
status: In progress
phase: BAU after MLP2
sponsor: TBC
role: Technology Lead
nextMilestone: Task review call
goLive: MLP2 deployed late Oct 2026
updated: 2026-11-08
thisWeek:
  - Run the CBUD task review and commit dates
  - Confirm 2027 funding model for BAU
  - Confirm MLP2 pen test date (Nov 22 is a Sunday)
---

## 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2026-11-22 | Archer: MLP2 pen test | TBC | In progress | Sunday; confirm the working date and whether it covers fixes |
| 2027-01 | Agiloft fully onboarded (decision point for Contract Buddy) | Partner team | Not started | Deck says January; exact date TBC |

## 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| FUND | Confirm how 2027 BAU funding works | Me |  | Not started | 2026-11-08 notes |
| A1 | Archer: remove prod data from lower environments | TBC |  | Not yet discussed | CBUD task review |
| A2 | Archer: pen testing for MLP2 | TBC | 2026-11-22 | Not yet discussed | CBUD task review |
| B | Annual business quarterly testing (next report MLP1 only, then MLP1 + MLP2) | TBC |  | Not yet discussed | CBUD task review |
| C | Accessibility: 3 star to 4 star (decide together with TPCAI F) | TBC |  | Not yet discussed | CBUD task review |
| D | Snyk and Veracode vulnerabilities | TBC |  | Not yet discussed | CBUD task review |
| D.2 | Snyk onboarding (same as TPCAI K2) | TBC |  | Not yet discussed | CBUD task review |
| E | Provisioning users to the app (need unconfirmed) | TBC |  | Not yet discussed | CBUD task review |
| F | AMH onboarding (same as TPCAI K1) | TBC |  | Not yet discussed | CBUD task review |

## 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

## 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Issue | CBUD-BAU | Two open Archer findings (prod data in lower env, MLP2 pen test) | High | High | Me | Commit dates at task review | Open |
| R2 | Issue | CBUD-BAU | Accessibility at 3 star; 4 star is the minimum | Medium | High | Me | Decide approach with TPCAI F | Open |
| R3 | Risk | CBUD-BAU | 2027 BAU funding not confirmed | High | Medium | Me | Raise with leadership | Open |
| R4 | Risk | CAMEO-INT | Agiloft may replace Contract Buddy, putting further investment at risk | Medium | Medium | Me | Compare capabilities before any new spend | Open |

## 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-10-20 | After Agiloft onboarding: decommission Contract Buddy or keep for specific use cases? | Pending | Leadership | Avoid two contract AI tools |
| 2026-11-08 | No new development in 2027; BAU and maintenance only | Decided | Leadership | Scope defined after MLP2 |
| 2026-11-08 | No new model MRM work; quarterly model testing continues | Decided | MRM | Model scope is defined |

## 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| Confirm items on TPCAI list: retention cadence, CRA for MLP2, MLP2 model artifacts, performance testing | Closes compliance unknowns | Task review | TBC |

## 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| TAPS developers | Build team | TAPS |  | Model and app code |
| MRM team | Model risk | MRM |  | Quarterly testing |

## 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

## 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- MLP2 deployed with feature enhancements; no new dev work into next year
- Quarterly model testing in progress and continues in perpetuity
- Funding model for BAU to be confirmed
