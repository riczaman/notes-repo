---
app: S2P
updated: 2026-11-08
author: Claude (proposed ideas, not commitments)
---

# AI opportunities: Ariba

## Ariba release note impact analyser
- **Status:** Idea
- **Type:** Generative AI
- **Impact:** High
- **Effort:** S
- **Value:** Reads each Ariba release note and flags screens and fields iATLK and the Coupa scripts touch
- **MRM:** Internal productivity use
- **Depends on:** List of screens and fields used by automations

## Vulnerability and certificate expiry forecaster
- **Status:** Idea
- **Type:** Automation
- **Impact:** Medium
- **Effort:** S
- **Value:** Alerts weeks ahead of certificate and Java expirations instead of reacting to findings
- **MRM:** None
- **Depends on:** Server inventory
