---
app: S2P
title: SAP Ariba (Source to Pay)
tagline: Procurement book of record where sourcing requests are created
status: In progress
phase: BAU + Coupa MLP3 planning
sponsor: TBC
role: Technology support
nextMilestone: Coupa MLP3 requirements
goLive: Live
updated: 2026-11-08
thisWeek:
  - Start Ariba release impact analysis for iATLK
  - Request Ariba access for the UiPath developer
  - Confirm MLP3 object (contract workspace vs sourcing project)
---

## 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|

## 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Analyse upcoming Ariba changes and their impact on iATLK | Me |  | Not started | 2026-11-08 notes |
| A2 | Get UiPath developer access to Ariba | Me |  | Not started | 2026-11-08 notes |
| A3 | Write requirements for Coupa MLP3 (contract workspace table) | Me |  | Not started | 2026-11-08 notes |
| A4 | Track certificate renewals and Java expirations on Ariba servers | Me |  | In progress | 2026-11-08 notes |

## 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

## 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | S2P-CHANGE | Every Ariba update can require iATLK changes | High | Medium | Me | Release impact analysis before each Ariba update | Open |
| R2 | Risk | S2P-COUPA-MLP3 | ITK server decommission (Archer findings) would strand the Coupa scripts | High | Medium | Me | Decide: one-year exception or new hosting | Open |
| R3 | Issue | S2P-COUPA-MLP3 | Finding requires MLP3 on the contract workspace table | High | High | Me | Scope MLP3 using MLP1 and MLP2 mechanism | Open |

## 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-10-20 | Keep Coupa scripts on the ITK server for another year, or move now? | Pending | Leadership | Deck recommendation: extend one year under documented exception, plan move in parallel |

## 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| Coupa MLP3 contract workspace | Closes finding | Requirements | F27 Q1 to Q2 |

## 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| Ariba team | Platform | Procurement Technology |  | Manual SR creation, Ariba releases |

## 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

## 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- Team maintains Ariba server vulnerabilities: certificates, Java expirations
- Creating SRs manually with the Ariba team while iATLK is failing
- Coupa automation MLP1 and MLP2 deployed; MLP3 needed for a finding (contract workspace table)
- Note: the Oct 20 deck described MLP3 as the sourcing project object. Confirm which is correct
