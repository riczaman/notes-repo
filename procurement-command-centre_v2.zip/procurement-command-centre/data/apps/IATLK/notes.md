---
app: IATLK
title: iATLK Sourcing Request Bot
tagline: UiPath RPA that creates Ariba sourcing requests from USFF, updates funding confirmation and attaches files
status: At risk
phase: Stabilisation
sponsor: TBC
role: Technology Lead
nextMilestone: UiPath developer onboarded
goLive: Live (degraded)
updated: 2026-11-08
thisWeek:
  - Confirm start date for the funded UiPath developer
  - Keep manual SR creation queue under control
  - List top business exception categories for the developer
---

## 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|

## 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Onboard the funded UiPath developer and grant Ariba access | Me |  | In progress | 2026-11-08 notes |
| A2 | Hand over defect list: Outlook file pickup, duplicate check, business exceptions | Me |  | Not started | 2026-11-08 notes |
| A3 | Track manual SR creation backlog and missed attachments | Ops |  | In progress | 2026-11-08 notes |

## 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

## 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Issue | IATLK-STAB | Failure rate above 70%: files not picked up from Outlook, duplicates despite the check, many business exceptions | Critical | High | Me | Developer funded; fixes expected 2 to 4 weeks after start | Open |
| R2 | Issue | IATLK-STAB | Manual SR creation causes delays at volume and sometimes misses attachments | High | High | Me | Daily manual queue review until bot is fixed | Open |
| R3 | Risk | IATLK-PATH | Any Ariba change can break the bot; fixes depend on UiPath pod priorities | High | Medium | Me | Ariba release impact analysis; long-term path decision | Open |
| R4 | Risk | IATLK-PATH | Bot runs on VDI and must move to cloud; not yet planned | Medium | Medium | Me | Include in long-term path decision | Open |

## 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-10-20 | Long-term SR creation path: UiPath Day 2, API (Globality / Ariba BTP), or Technology-owned tool? | Pending | Leadership | Deck recommendation: Day 2 as a bridge only, API as target |
| 2026-11-08 | Fund a UiPath developer to fix the bot | Decided | Leadership | 70%+ failure rate, manual workaround not sustainable |

## 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| API-based SR creation | Retire RPA fragility | Globality or Ariba BTP APIs | Not set |
| VDI to cloud migration | Supported hosting | Path decision | Not set |

## 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| UiPath pod | RPA | Technology |  | Bot code, Day 2 support |

## 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|
| How the bot runs | 1. USFF submit triggers Power Automate email  2. Retriever reads Outlook, adds to transaction queue  3. Processor creates Ariba SRs at 7 pm daily | UiPath Orchestrator | 2026-11-08 |

## 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- Bot not working reliably; someone is creating SRs manually
- Developer funding approved; fixes expected within 2 to 4 weeks once started
