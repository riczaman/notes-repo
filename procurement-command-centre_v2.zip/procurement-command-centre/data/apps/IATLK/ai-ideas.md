---
app: IATLK
updated: 2026-11-08
author: Claude (proposed ideas, not commitments)
---

# AI opportunities: iATLK

## Business exception classifier
- **Status:** Idea
- **Type:** LLM classification
- **Impact:** High
- **Effort:** S
- **Value:** Groups the 70%+ failures by root cause so the new developer fixes the biggest buckets first
- **MRM:** None if used offline for analysis only
- **Depends on:** Exception logs from UiPath Orchestrator

## Intelligent email and attachment extraction
- **Status:** Idea
- **Type:** UiPath Document Understanding / IXP
- **Impact:** High
- **Effort:** M
- **Value:** Replaces brittle Outlook parsing, the main failure point
- **MRM:** Check with MRM if extraction uses ML models
- **Depends on:** UiPath developer

## Duplicate detection with fuzzy matching
- **Status:** Idea
- **Type:** Deterministic + similarity scoring
- **Impact:** Medium
- **Effort:** S
- **Value:** Stops duplicate SRs that the current exact-match check misses
- **MRM:** None
- **Depends on:** Access to existing SR list

## Agentic SR creation via API
- **Status:** Idea
- **Type:** Agent + API
- **Impact:** High
- **Effort:** L
- **Value:** Retires screen automation entirely once Globality or Ariba BTP exposes SR APIs
- **MRM:** Full model review for agentic actions
- **Depends on:** Platform API decision
