---
app: CAMEO
title: Agiloft (Cameo)
tagline: New contract lifecycle SaaS; partner team owns MRM and setup, we own integrations and requirements later
status: Not started
phase: Partner onboarding
sponsor: TBC
role: Integration lead (later phase)
nextMilestone: Agiloft fully onboarded
goLive: Jan 2027 (expected)
updated: 2026-11-08
thisWeek:
  - Line up BSA for requirements
  - Map Contract Buddy capabilities against Agiloft
---

## 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2027-01 | Agiloft fully onboarded | Partner team | Not started | Deck says January |

## 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | BSA to start requirements for Agiloft integrations | BSA |  | Not started | 2026-11-08 notes |
| A2 | Compare Contract Buddy extraction and deviation scoring with Agiloft | Me |  | Not started | Deck decision 7 |
| A3 | Inventory overlapping integrations to switch off at cutover | Me |  | Not started | 2026-11-08 notes |

## 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

## 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | CAMEO-INT | Overlapping integrations stay on after go-live | High | Medium | Me | Cutover checklist | Open |
| R2 | Risk | CAMEO-INT | BSA capacity for requirements | Medium | Medium | Me | Book BSA time early | Open |

## 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|

## 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|

## 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|

## 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

## 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Context

- Similar to Globality: partner team does MRM and setup, we integrate later
- BSA needs to help with requirements
- Prompt engineering needed
- May replace Contract Buddy
