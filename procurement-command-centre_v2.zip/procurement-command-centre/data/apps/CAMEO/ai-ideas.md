---
app: CAMEO
updated: 2026-11-08
author: Claude (proposed ideas, not commitments)
---

# AI opportunities: Agiloft

## Clause deviation prompts tuned on Contract Buddy learnings
- **Status:** Idea
- **Type:** Prompt engineering
- **Impact:** High
- **Effort:** M
- **Value:** Reuses Contract Buddy deviation rules and test sets so Agiloft starts at known accuracy
- **MRM:** Partner team MRM
- **Depends on:** Contract Buddy test set

## Contract obligation tracker
- **Status:** Idea
- **Type:** Extraction + reminders
- **Impact:** Medium
- **Effort:** M
- **Value:** Extracts renewal and notice dates and pushes reminders to owners
- **MRM:** Model review if extraction is AI-based
- **Depends on:** Agiloft data model
