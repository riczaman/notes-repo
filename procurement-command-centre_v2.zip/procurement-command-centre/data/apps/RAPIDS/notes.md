---
app: RAPIDS
title: Rapids
tagline: AI model where I am the named model developer and own ongoing governance
status: In progress
phase: Ongoing governance
sponsor: TBC
role: Model developer
nextMilestone: Next business test cycle
goLive: Live
updated: 2026-11-08
thisWeek:
  - Confirm next business testing date
  - Check drift and hallucination monitoring evidence
---

## 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|


## 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Confirm business testing cadence and next test date | Me |  | Not started | 2026-11-08 notes |
| A2 | Define drift and hallucination checks and evidence location | Me |  | Not started | 2026-11-08 notes |

## 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

## 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | RAPIDS-GOV | Business does not provide testing evidence on time, leaving model governance gaps | High | Medium | Me | Set a testing calendar with named business testers | Open |

## 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|

## 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|

## 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|

## 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

## 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Context

- I am the model developer: ensure no drift or hallucinations
- Enforce business testing going forward; overall governance
