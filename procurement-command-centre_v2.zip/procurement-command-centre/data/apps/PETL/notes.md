---
app: PETL
title: Procurement ETL (Azure Data Pipeline)
tagline: Ariba data through ADF and ADLS into Rahona for the Procurement Tracker dashboard
status: In progress
phase: MLP3 and MLP4 delivery
sponsor: TBC
role: Technology Lead
nextMilestone: MLP3 + MLP4, 2026-11-22
goLive: Live
updated: 2026-11-08
thisWeek:
  - Confirm MLP4 downtime window for schema replacement
  - Book the Ariba data review with business and developers
  - Confirm DAST rescan date
---

## 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2026-11-22 | MLP3 (11 new tables) and MLP4 (4 new fields) | Dev team | In progress | MLP4 needs downtime: schema dropped and replaced |

## 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Run review of all ingested Ariba data with business and devs: what can refresh less often or be descoped | Me |  | Not started | 2026-11-08 notes |
| A2 | Plan and communicate MLP4 downtime | Dev team | 2026-11-22 | In progress | 2026-11-08 notes |
| A3 | Schedule annual DAST rescan | Me |  | Not started | 2026-11-08 notes |
| A4 | Keep Veracode and Snyk findings remediated | Dev team |  | In progress | 2026-11-08 notes |
| A5 | Confirm AMH onboarding scope for PETL | Me |  | Not started | 2026-11-08 notes (to confirm) |
| A6 | Size ADLS-to-ADLS copy for all environments | Dev team |  | Not started | 2026-11-08 notes |

## 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|
| 2026-11-08 | Procurement business | USFF fields in the Procurement Tracker |  | Open | See USFF-PETL-FEED |

## 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | PETL-API-REVIEW | Ariba API daily limit of 60. More data needs more capacity at extra cost, and Ariba is not the long-term platform | High | High | Me | Review and retire unused tables and fields first | Open |
| R2 | Issue | PETL-MLP3-4 | Rahona ingestion takes about a month per change (IDC file, review, configuration) | Medium | High | Me | Ask for self-serve onboarding | Open |
| R3 | Risk | PETL-MLP3-4 | Adding fields to existing tables needs downtime | Medium | High | Dev team | Schedule and communicate windows | Open |
| R4 | Risk | PETL-MLP5 | Fieldglass data not yet available; timelines move until data and scope are agreed | Medium | High | Me | Hold MLP5 dates until data is testable | Open |
| R5 | Risk | PETL-ADLS | ADLS-to-ADLS copy is the new practice but proven only in sandbox; may be substantial work | Medium | Medium | Me | Size it before it becomes mandatory | Open |

## 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-10-20 | Can the business retire unused tables and fields to free Ariba API capacity? | Pending | Business | Ariba Coupa automation shares the same limits |
| 2026-10-20 | Can Rahona ingestion be fully self-serve for our dev team? | Pending | Rahona | Cuts about a month per change |

## 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| MLP5 Fieldglass source | Contingent workforce data in reporting | Data availability, API access | Not set |
| ADLS-to-ADLS copy | Retire TIBCO hop | Effort sizing | Not planned |

## 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| Rahona ingestion team | Data platform | Rahona |  | IDC review, configuration |

## 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|
| Give an end user access to PETL data in Rahona | 1. Rahona onboarding (IDC) complete  2. User submits a DAC request in Data Compass  3. BSA and end user are contributors, so they can raise it directly | Data Compass | 2026-11-08 |

## 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- MLP3 and MLP4 expected to finish by Nov 22
- New practice: direct ADLS-to-ADLS copy instead of TIBCO; sandbox only so far
