---
app: PETL
updated: 2026-11-08
author: Claude (proposed ideas, not commitments)
---

# AI opportunities: PETL

## API usage optimiser
- **Status:** Idea
- **Type:** Analytics
- **Impact:** High
- **Effort:** S
- **Value:** Shows which tables and fields are actually used in the Procurement Tracker so the business can retire the rest and free Ariba API calls
- **MRM:** None
- **Depends on:** Power BI usage metrics

## Natural language Q&A over procurement data
- **Status:** Idea
- **Type:** Text-to-SQL / Copilot for Power BI
- **Impact:** Medium
- **Effort:** M
- **Value:** Business users ask questions without waiting for new dashboard pages
- **MRM:** Enterprise AI intake and model review
- **Depends on:** Curated zone semantic model

## Data quality anomaly detection
- **Status:** Idea
- **Type:** Statistical / ML anomaly detection
- **Impact:** Medium
- **Effort:** M
- **Value:** Catches schema drift and volume drops after each load, before the business sees a broken dashboard
- **MRM:** Light if statistical thresholds only
- **Depends on:** Load metadata logging

## IDC file and onboarding drafter
- **Status:** Idea
- **Type:** Generative AI
- **Impact:** Medium
- **Effort:** S
- **Value:** Drafts the Rahona IDC file from table metadata to shorten the month-long onboarding loop
- **MRM:** Internal productivity use; confirm with MRM
- **Depends on:** IDC template
