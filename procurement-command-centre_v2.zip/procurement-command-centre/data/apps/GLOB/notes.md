---
app: GLOB
title: Globality
tagline: New SaaS sourcing platform; partner team owns MRM and setup, we own integrations later
status: Not started
phase: Partner onboarding
sponsor: TBC
role: Integration lead (later phase)
nextMilestone: Handover from partner team
goLive: TBC
updated: 2026-11-08
thisWeek:
  - Ask partner team for onboarding timeline and MRM status
  - List current integrations Globality could replace
---

## 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|


## 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Inventory existing integrations that overlap with Globality and must switch off at cutover | Me |  | Not started | 2026-11-08 notes |
| A2 | Get onboarding timeline and handover date from partner team | Me |  | Not started | 2026-11-08 notes |
| A3 | Plan prompt engineering scope | Me |  | Not started | 2026-11-08 notes |

## 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

## 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | GLOB-INT | Overlapping integrations stay on after Globality goes live, creating duplicate data paths | High | Medium | Me | Cutover checklist: switch off old integrations as new ones switch on | Open |
| R2 | Risk | IATLK-PATH | Globality API decision also sets the long-term SR creation path | High | Medium | Me | Track platform decision | Open |

## 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|

## 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|

## 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|

## 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

## 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Context

- Another team runs model MRM and basic setup
- My team joins later for integrations to other apps
- As Globality turns on, overlapping integrations must turn off
- Prompt engineering needed
