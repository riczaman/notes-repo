---
app: GLOB
updated: 2026-11-08
author: Claude (proposed ideas, not commitments)
---

# AI opportunities: Globality

## Prompt library and evaluation set
- **Status:** Idea
- **Type:** Prompt engineering
- **Impact:** High
- **Effort:** M
- **Value:** Versioned prompts with a test set so prompt changes are measured, not guessed
- **MRM:** Supports partner team MRM evidence
- **Depends on:** Access to Globality configuration

## USFF to Globality intake hand-off
- **Status:** Idea
- **Type:** Integration + LLM mapping
- **Impact:** High
- **Effort:** L
- **Value:** Approved USFF intakes create Globality projects without re-keying
- **MRM:** Depends on whether mapping uses an LLM
- **Depends on:** Globality APIs
