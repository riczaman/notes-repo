---
app: USFF
updated: 2026-11-08
author: Claude (proposed ideas, not commitments)
---

# AI opportunities: USFF

Ideas to reduce vendor manager load and requestor rework. Every idea is classified as proposed until you validate it.

## Gen AI intake assistant (Autointake)
- **Status:** POC built
- **Type:** Generative AI assistant (RAG)
- **Impact:** High
- **Effort:** L
- **Value:** Requestors get answers from vendor manager knowledge while filling the form; vendor managers review after submission instead of answering every question
- **MRM:** AI CGA update, enterprise AI intake, new CRA
- **Depends on:** Vendor manager knowledge sources and SMEs

Ground the assistant in the vendor manager playbook, policy and past approved intakes. Start with field-level help ("what goes in management consulting scope?") before letting it draft whole sections.

## Intake completeness and quality checker
- **Status:** Idea
- **Type:** LLM classification + rules
- **Impact:** High
- **Effort:** M
- **Value:** Flags vague descriptions, missing SOW details and wrong expense type before submission, cutting back-and-forth
- **MRM:** Likely lighter than a chatbot if it only flags, never decides
- **Depends on:** Examples of good and rejected intakes

## Smart Triage routing (ARP)
- **Status:** Idea
- **Type:** Rules engine first, ML later
- **Impact:** High
- **Effort:** M
- **Value:** Routes requests to the right team and skips unneeded ARP reviews
- **MRM:** None if pure rules; model review if ML scoring is added
- **Depends on:** Documented ARP triage rules

Build the deterministic rules first. Add a model only where rules cannot decide.

## Approval matrix maintenance assistant
- **Status:** Idea
- **Type:** Automation + HR data sync
- **Impact:** Medium
- **Effort:** M
- **Value:** Detects approvers who moved roles or left and proposes matrix updates for admin approval, closing the support model gap
- **MRM:** None (no model)
- **Depends on:** HR or directory feed

## SPID document matching
- **Status:** Idea
- **Type:** Document AI
- **Impact:** Medium
- **Effort:** M
- **Value:** Matches contract signed IDs to intakes automatically once the SPID ETL lands, flagging mismatches
- **MRM:** Model review if extraction is AI-based
- **Depends on:** SPID validation ETL
