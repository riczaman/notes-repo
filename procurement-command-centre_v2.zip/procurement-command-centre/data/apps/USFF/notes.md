---
app: USFF
title: Unified Storefront (USFF)
tagline: One front door for procurement vendor expense, from intake through approvals to the Ariba sourcing request
status: At risk
phase: Greenlight BAT
sponsor: TBC
role: Technology Lead
nextMilestone: Greenlight BAT go / no-go
goLive: Nov or Dec 2026 (Greenlight)
updated: 2026-11-08
links:
  - label: SharePoint
  - label: Jira
  - label: Teams channel
thisWeek:
  - Lock the BAT plan and go / no-go criteria for Greenlight
  - Confirm date for the isolated business enhancements release
  - Chase TAPS PID update and NSG rules for the USFF to PETL feed
---

## 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2026-11-30 | Greenlight deployment window (November option) | Me | At risk | Depends on BAT outcome |
| 2026-12-15 | Greenlight deployment window (December option) | Me | Not started | Check against December change freeze |

## 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Get BAT scheduled and agree go / no-go criteria | Me |  | In progress | 2026-11-08 notes |
| A2 | Discuss Archer / finding exception for in-app permissions (5 AD groups + in-app scopes) | Me + Geetha |  | Not started | 2026-11-08 notes |
| A3 | Set up prioritisation exercise: EMS flows vs Gen AI Autointake vs Smart Triage | Me |  | Not started | 2026-11-08 notes |
| A4 | Chase TAPS to update PID and Azure team for NSG rules + service principal mapping | Me |  | In progress | 2026-11-08 notes |
| A5 | Chase solution architect for architecture blueprint update (USFF to PETL) | Me |  | In progress | 2026-11-08 notes |
| A6 | Draft support model for approval-matrix maintenance | Me |  | Not started | 2026-11-08 notes |
| A7 | Update AI CGA, enterprise AI intake and create new CRA for Gen AI Autointake | Me |  | Not started | 2026-11-08 notes |
| A8 | Size legacy EMS data migration (SharePoint schema vs USFF tables) in case it becomes a requirement | Dev team |  | Not started | 2026-11-08 notes |

## 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|
| 2026-10-20 | David Parry | Historical EMS and Signing Party data in USFF before launch |  | Open | Descoped for MLP1: new requests only. Migration can be a separate release |
| 2026-11-08 | USFF business owner | Super user role: view-only access to all requests for their support team |  | Open | Built inside Greenlight; rework if Greenlight slips |

## 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | USFF-EMS-MLP1 | Vendor expense is the heartbeat of all other EMS flows. Pulling it into USFF may have downstream impact we have not been told about | High | Medium | Me | Ask EMS team for a downstream impact walkthrough before go-live | Open |
| R2 | Risk | USFF-EMS-MLP1 | No legacy data migration: data discrepancies, and current users add USFF to their tool stack while other flows stay in EMS | High | High | Me | Communicate "new requests only"; scope migration as a separate release | Open |
| R3 | Issue | USFF-SPID-ETL | SPID validation is fully manual (Ariba report saved to SharePoint). No true validation check | High | High | Me | Build SPID ETL as a fast follow | Open |
| R4 | Risk | USFF-EMS-MLP1 | Requestors may not know every answer up front; business wants a segmented form | Medium | High | Me | Interim: make non-critical fields optional rather than redesigning the form | Open |
| R5 | Issue | USFF-EMS-MLP1 | Support model gap: approval tables mapped manually per LOB and segment and must be maintained as approvers move | High | High | Me | Define owner, cadence and admin tooling | Open |
| R6 | Risk | USFF-EMS-NEXT | Vendor expense was reverse engineered. Future EMS flows need named business partners and requirements up front | High | High | Me | Name one SME per flow; written requirements before backlog entry | Open |
| R7 | Risk | USFF-GENAI | All capacity is tied to EMS, so business-requested USFF work (Gen AI Autointake, Smart Triage) keeps slipping | High | High | Me | Prioritisation exercise; ask for added capacity | Open |
| R8 | Risk | USFF-REL-BIZ | Super user role was built for Greenlight. A long Greenlight delay means rebuilding it in isolation (duplicate work) | Medium | Medium | Me | Decide rebuild trigger date | Open |
| R9 | Risk | USFF-EMS-MLP1 | In-app permissions instead of AD groups (EMS matrix would need about 850 AD groups) may need an Archer or finding exception, or a Diamond feed | High | Medium | Me + Geetha | Discuss with Geetha; document the rationale | Open |
| R10 | Issue | USFF-PETL-FEED | PAT and Prod blocked on TAPS PID update, NSG rules and service principal mapping | Medium | High | Me | Escalate if no movement by next sync | Open |

## 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-11-08 | Greenlight: deploy in November or December once BAT passes? | Pending | Leadership | BAT outcome is the go / no-go gate |
| 2026-11-08 | Next pod priority: EMS MLP2 to MLP4, Gen AI Autointake, or Smart Triage? | Pending | Leadership | Pod runs one track at a time |
| 2026-11-08 | Form segmentation: optional fields as interim, or staged form? | Pending | Business + Me | My view: optional fields first |
| 2026-10-20 | Data migration descoped from MLP1; new requests only | Decided | Technology | Mapping not feasible before launch; including it moves launch to Jan to Feb 2027 |
| 2026-11-08 | Build own ETL for attachment migration instead of PETL / ADF | Decided | Technology | Simpler, team-owned |

## 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| EMS MLP2 Approval to Hire | Users stop using EMS for ATH | Named SMEs, requirements | Not committed |
| EMS MLP3 Invoices | Users stop using EMS for invoices | Named SMEs, requirements | Not committed |
| EMS MLP4 Project Requests and Business Cases | EMS can retire | All flows and data migrated | Not committed |
| Gen AI Autointake | Fewer incorrect intakes, less vendor manager load | MRM approvals, knowledge base | F27 Q2 (proposed) |
| Smart Triage (ARP) | Skip unneeded ARP reviews | Documented triage rules | Not set |
| Legacy EMS data migration | One source for all requests | Schema mapping effort | Only if required |

## 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| Geetha | TBC | TBC |  | Access model exception (AD groups vs in-app permissions) |
| David Parry | TBC | EMS / GTS |  | Historical data migration ask |
| TAPS infrastructure | Infrastructure | TAPS |  | PID document |
| Azure team | Cloud | Technology |  | NSG rules, service principals |

## 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|
| Tell a legacy request from a new one | Backend flag on each request: legacy (old non-unified form) or new (unified form) | USFF DB | 2026-11-08 |

## 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Portfolio context dump

- Greenlight (EMS vendor expense) fully developed; waiting on business acceptance testing for go / no-go
- MLP1 unified intake: vendor expense fields, GTS pipeline questions, additional vendor expense questions, management consulting questions, SPID questions
- Old non-unified form continues for existing users; backend flag marks legacy vs new
- Isolated release in flight: alphanumeric cost center, currency and conversion rates, reassign intakes, homepage note, admin bulk upload table, admin data export, remove old emails from UiPath automation
- USFF to PETL feed tested in Dev; PAT and Prod need TAPS PID update, NSG rules and service principal mapping
