---
app: TPCAI
title: 3PCRM AI Tool
tagline: AI review of SOC 2 and attestation documents for third-party cyber control assessments
status: At risk
phase: MLP2 planning
sponsor: TBC
role: Technology Lead
nextMilestone: MLP2 scope and date
goLive: MLP1.5 deployed week of 2026-11-02
updated: 2026-11-08
thisWeek:
  - Run the TPCAI task review and commit dates
  - Confirm MLP2 date vs model testing window
  - Agree latency target before removing prod data from SIT
---

## 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2026-11-02 | MLP1.5 deployment (clickable attestations, 2026 questionnaire) | Dev team | Done | Week of Nov 2 |
| 2027-02 | MLP2 feature enhancements | Dev team | Not started | February 2027; exact date TBC |
| 2027-03-31 | MLP2 model artifacts: model plan, test plan, testing | Me | Not started | Q1 end; check sequence vs MLP2 |

## 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| B | MLP2 feature enhancements: confirm scope and exact date | Me |  | Not yet discussed | TPCAI task review |
| C | MLP2 model artifacts: model plan, test plan, testing | Me |  | Not yet discussed | TPCAI task review |
| D | Business quarterly testing (share MRM kickoff with CBUD B) | TBC |  | Not yet discussed | TPCAI task review |
| E | MLP2 artifact updates: AI intake, CPOP, AI CGA | Me |  | Not yet discussed | TPCAI task review |
| F | Accessibility 3 star to 4 star | TBC |  | Not yet discussed | TPCAI task review |
| G1 | Data retention removal cadence (2-year retention) | TBC |  | Not yet discussed | TPCAI task review |
| G2 | CRA updates for MLP2 | Me |  | Not yet discussed | TPCAI task review |
| H | Remediate Snyk and Veracode findings | Dev team |  | Not yet discussed | TPCAI task review |
| I | Performance testing and latency fixes (blocks J) | Dev team |  | Not yet discussed | TPCAI task review |
| J | Archer: remove prod data from lower environments (depends on I) | TBC |  | Not yet discussed | TPCAI task review |
| K1 | AMH onboarding (same as CBUD F) | TBC |  | Not yet discussed | TPCAI task review |
| K2 | Snyk onboarding (needed for H; same as CBUD D.2) | TBC |  | Not yet discussed | TPCAI task review |

## 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

## 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Issue | TPCAI-BAU | Latency pushed users to SIT, putting prod data in lower environments (Archer finding) | Critical | High | Me | Fix latency first, then remove data; agree interim plan | Open |
| R2 | Risk | TPCAI-MLP2 | Model testing window (to Mar 31) may end after the February feature date | High | Medium | Me | Set separate dates for model plan, test plan, testing | Open |
| R3 | Risk | TPCAI-MLP2 | AI intake, CPOP, AI CGA and CRA may gate MLP2 deployment | High | Medium | Me | Confirm which approvals gate MLP2 | Open |
| R4 | Issue | TPCAI-BAU | Accessibility at 3 star; 4 star required | Medium | High | Me | Apply one answer for TPCAI and CBUD | Open |

## 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-11-08 | Can prod data removal wait for latency fixes, or do SIT users need a plan sooner? | Pending | Me + Archer | Removal first strands SIT users |
| 2026-11-08 | 2027 focus is MLP2: MRM refresh plus development | Decided | Leadership | Main investment area for next year |

## 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| MLP2: attestation documents beyond SOC 2 | Broader assessment coverage | Requirements, MRM approvals | Feb 2027 |
| Confirm CBUD-only items apply: user provisioning, MLP2 pen test | Close compliance unknowns | Task review | TBC |

## 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| MRM team | Model risk | MRM |  | Quarterly testing, model artifacts |

## 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

## 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- MLP1 enhancement deployment complete (MLP1.5)
- 2027 focus: MLP2 with new MRM work (CGA, MRM documents, approvals, new forms) and development
