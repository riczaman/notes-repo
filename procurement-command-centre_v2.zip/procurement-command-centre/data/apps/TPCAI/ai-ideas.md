---
app: TPCAI
updated: 2026-11-08
author: Claude (proposed ideas, not commitments)
---

# AI opportunities: 3PCRM

## Multi-document attestation review (MLP2)
- **Status:** Planned
- **Type:** Document AI + LLM
- **Impact:** High
- **Effort:** L
- **Value:** Extends review beyond SOC 2 to other attestation types
- **MRM:** Model plan, test plan, testing, CRA, AI intake, CPOP, AI CGA
- **Depends on:** MLP2 requirements

## Latency fix through chunked and cached processing
- **Status:** Idea
- **Type:** Engineering
- **Impact:** High
- **Effort:** M
- **Value:** Precompute document embeddings and cache control mappings so users stop working in SIT
- **MRM:** None (performance change); retest accuracy after
- **Depends on:** Latency target

## Control gap explainer
- **Status:** Idea
- **Type:** Generative AI
- **Impact:** Medium
- **Effort:** M
- **Value:** Explains each flagged control gap with page citations so assessors trust and verify faster
- **MRM:** Model review for new output type
- **Depends on:** Citation support in pipeline

## Automated retention purge
- **Status:** Idea
- **Type:** Automation
- **Impact:** Medium
- **Effort:** S
- **Value:** Scheduled job deletes records past 2-year retention and logs evidence, closing G1
- **MRM:** None
- **Depends on:** Agreed cadence
