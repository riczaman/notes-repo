# Context pack: 3PCRM AI Tool (TPCAI)

> Generated 2026-11-08 from the Procurement Command Centre. Source of truth: data/apps/TPCAI/. Treat "proposed" and "unverified" items as unconfirmed.

## Application

| Field | Value |
|---|---|
| ID | TPCAI |
| Name | 3PCRM AI Tool |
| Aliases | 3PCRM Automation, TPCAI |
| Category | ai-model |
| Portfolio | owned |
| Status | live |
| Health | amber |
| My role | Technology Lead |
| Classification | confirmed |

**Summary:** AI tool that reviews SOC 2 and other attestation documents for third-party cyber control assessments.

**Purpose:** Cut long manual review of attestation documents in cyber control assessments.

### Features
- SOC 2 review with clickable attestations (MLP1.5)
- 2026 questionnaire (MLP1.5)
- Attestation documents beyond SOC 2 (MLP2, planned)

### Processes
- None recorded

### User groups
- None recorded

### Technical
- Stack: Not recorded
- Hosting: Not recorded
- Pattern: Not recorded
- Auth: Not recorded
- APIs: None recorded
- Data sources: None recorded
- Data destinations: None recorded
- Dependencies: None recorded

### Operations
- Support model: Not recorded

**Known issues**
- None recorded

**Limitations**
- Latency issues pushed users to SIT
- Accessibility rating 3 star; 4 star required
- No data retention removal cadence (retention period is 2 years)

**Technical debt**
- None recorded

**Compliance**
- Archer: production data in lower environments
- Quarterly business testing
- CRA update for MLP2
- AI intake, CPOP, AI CGA updates for MLP2
- Snyk and Veracode
- AMH and Snyk onboarding

## Initiatives (3)

### TPCAI-MLP15: 3PCRM MLP1.5: clickable attestations and 2026 questionnaire
- Status: Done · Priority P2 · AI-enabled
- Target: Deployed week of Nov 2, 2026
- Summary: MLP1 enhancement deployment.

### TPCAI-MLP2: 3PCRM MLP2: model work and development
- Status: Planning · Priority P1 · AI-enabled
- Target: Feb 2027 (features), Q1 2027 (model artifacts)
- Summary: Main 2027 focus. New MRM work (CGA, MRM documents, approvals, new forms) plus development for attestation documents beyond SOC 2.
- Open decision: Does the model testing window (to Mar 31) fit a February feature date?
- Next steps:
  - Confirm scope and exact date
  - Model plan, test plan and testing
  - AI intake, CPOP, AI CGA updates
  - CRA update

### TPCAI-BAU: 3PCRM compliance backlog
- Status: At risk · Priority P1 · AI-enabled
- Target: Dates to commit at review call
- Summary: Performance and latency fixes, prod data out of lower environments, accessibility to 4 star, retention cadence, Snyk and Veracode, AMH and Snyk onboarding, quarterly testing.
- Problem: Latency pushed users to SIT, which put production data in lower environments (Archer finding). Removing the data before the latency fix strands those users.
- Progress:
  - 13 review tasks, none discussed yet

## Integrations (0)

| ID | From | To | Purpose | Method | Frequency | Status | Classification |
|---|---|---|---|---|---|---|---|


## Gaps
- GAP-005 (confirmed, medium): Data retention removal cadence. Retention period is 2 years but no removal cadence exists.

## Business capabilities
- CAP-007: Third-party cyber control assessment. Limitations: Latency issues
- CAP-010: AI model governance and monitoring

## Model governance obligations
- GOV-002 [not-started] Quarterly business testing (testing, Quarterly). Share the MRM kickoff with Contract Buddy.
- GOV-003 [not-started] MLP2 model plan, test plan and testing (artifact, One-off, due 2027-03)
- GOV-004 [needs-info] MLP2 AI intake, CPOP and AI CGA updates (artifact, One-off). Confirm which must be approved before MLP2 deploys.
- GOV-005 [needs-info] CRA update for MLP2 (approval, One-off)
- GOV-006 [not-started] Data retention removal cadence (2-year retention) (monitoring, To agree)

## Opportunities (not commitments)
- OPP-009 [idea, medium] Shared MRM testing harness for all models: One labelled test set and report pipeline per model, run every quarter.

## Working notes


### 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2026-11-02 | MLP1.5 deployment (clickable attestations, 2026 questionnaire) | Dev team | Done | Week of Nov 2 |
| 2027-02 | MLP2 feature enhancements | Dev team | Not started | February 2027; exact date TBC |
| 2027-03-31 | MLP2 model artifacts: model plan, test plan, testing | Me | Not started | Q1 end; check sequence vs MLP2 |

### 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| B | MLP2 feature enhancements: confirm scope and exact date | Me |  | Not yet discussed | TPCAI task review |
| C | MLP2 model artifacts: model plan, test plan, testing | Me |  | Not yet discussed | TPCAI task review |
| D | Business quarterly testing (share MRM kickoff with CBUD B) | TBC |  | Not yet discussed | TPCAI task review |
| E | MLP2 artifact updates: AI intake, CPOP, AI CGA | Me |  | Not yet discussed | TPCAI task review |
| F | Accessibility 3 star to 4 star | TBC |  | Not yet discussed | TPCAI task review |
| G1 | Data retention removal cadence (2-year retention) | TBC |  | Not yet discussed | TPCAI task review |
| G2 | CRA updates for MLP2 | Me |  | Not yet discussed | TPCAI task review |
| H | Remediate Snyk and Veracode findings | Dev team |  | Not yet discussed | TPCAI task review |
| I | Performance testing and latency fixes (blocks J) | Dev team |  | Not yet discussed | TPCAI task review |
| J | Archer: remove prod data from lower environments (depends on I) | TBC |  | Not yet discussed | TPCAI task review |
| K1 | AMH onboarding (same as CBUD F) | TBC |  | Not yet discussed | TPCAI task review |
| K2 | Snyk onboarding (needed for H; same as CBUD D.2) | TBC |  | Not yet discussed | TPCAI task review |

### 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

### 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Issue | TPCAI-BAU | Latency pushed users to SIT, putting prod data in lower environments (Archer finding) | Critical | High | Me | Fix latency first, then remove data; agree interim plan | Open |
| R2 | Risk | TPCAI-MLP2 | Model testing window (to Mar 31) may end after the February feature date | High | Medium | Me | Set separate dates for model plan, test plan, testing | Open |
| R3 | Risk | TPCAI-MLP2 | AI intake, CPOP, AI CGA and CRA may gate MLP2 deployment | High | Medium | Me | Confirm which approvals gate MLP2 | Open |
| R4 | Issue | TPCAI-BAU | Accessibility at 3 star; 4 star required | Medium | High | Me | Apply one answer for TPCAI and CBUD | Open |

### 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-11-08 | Can prod data removal wait for latency fixes, or do SIT users need a plan sooner? | Pending | Me + Archer | Removal first strands SIT users |
| 2026-11-08 | 2027 focus is MLP2: MRM refresh plus development | Decided | Leadership | Main investment area for next year |

### 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| MLP2: attestation documents beyond SOC 2 | Broader assessment coverage | Requirements, MRM approvals | Feb 2027 |
| Confirm CBUD-only items apply: user provisioning, MLP2 pen test | Close compliance unknowns | Task review | TBC |

### 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| MRM team | Model risk | MRM |  | Quarterly testing, model artifacts |

### 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

### 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- MLP1 enhancement deployment complete (MLP1.5)
- 2027 focus: MLP2 with new MRM work (CGA, MRM documents, approvals, new forms) and development


## AI opportunity ideas (proposed)




### Multi-document attestation review (MLP2)
- **Status:** Planned
- **Type:** Document AI + LLM
- **Impact:** High
- **Effort:** L
- **Value:** Extends review beyond SOC 2 to other attestation types
- **MRM:** Model plan, test plan, testing, CRA, AI intake, CPOP, AI CGA
- **Depends on:** MLP2 requirements

### Latency fix through chunked and cached processing
- **Status:** Idea
- **Type:** Engineering
- **Impact:** High
- **Effort:** M
- **Value:** Precompute document embeddings and cache control mappings so users stop working in SIT
- **MRM:** None (performance change); retest accuracy after
- **Depends on:** Latency target

### Control gap explainer
- **Status:** Idea
- **Type:** Generative AI
- **Impact:** Medium
- **Effort:** M
- **Value:** Explains each flagged control gap with page citations so assessors trust and verify faster
- **MRM:** Model review for new output type
- **Depends on:** Citation support in pipeline

### Automated retention purge
- **Status:** Idea
- **Type:** Automation
- **Impact:** Medium
- **Effort:** S
- **Value:** Scheduled job deletes records past 2-year retention and logs evidence, closing G1
- **MRM:** None
- **Depends on:** Agreed cadence

