# Context pack: iATLK Sourcing Request Bot (IATLK)

> Generated 2026-11-08 from the Procurement Command Centre. Source of truth: data/apps/IATLK/. Treat "proposed" and "unverified" items as unconfirmed.

## Application

| Field | Value |
|---|---|
| ID | IATLK |
| Name | iATLK Sourcing Request Bot |
| Aliases | iATLK, UiPath automation |
| Category | automation |
| Portfolio | owned |
| Status | live |
| Health | red |
| My role | Technology Lead |
| Classification | confirmed |

**Summary:** UiPath RPA that turns USFF requests into Ariba sourcing requests, updates funding confirmation and attaches files.

**Purpose:** Remove manual re-keying of approved USFF requests into Ariba, the book of record.

### Features
- Retriever: reads USFF request emails from Outlook and queues them
- Processor: creates Ariba sourcing requests daily at 7 pm
- Funding confirmation approval updates
- Attachment upload

### Processes
- Sourcing request creation
- Funding confirmation

### User groups
- None recorded

### Technical
- Stack: UiPath (retriever and processor), Outlook mailbox, Transaction queue
- Hosting: VDI (must migrate to cloud)
- Pattern: Email-triggered RPA with a daily batch
- Auth: Not recorded
- APIs: None recorded
- Data sources: Power Automate email per USFF submission
- Data destinations: Ariba sourcing requests
- Dependencies: Ariba UI (any Ariba change can break the bot); Power Automate flow; UiPath pod

### Operations
- Support model: No UiPath developer on the team. A developer has now been funded. Manual SR creation covers the gap.

**Known issues**
- Failure rate above 70%
- Cannot reliably pick up files from Outlook
- Creates duplicate entries despite the duplicate check
- High volume of business exceptions

**Limitations**
- Fixes depend on another pod (UiPath) priorities
- Any Ariba UI change needs bot changes

**Technical debt**
- None recorded

**Compliance**
- None recorded

## Initiatives (4)

### USFF-REL-BIZ: USFF business enhancements release (isolated)
- Status: In delivery · Priority P1
- Target: Isolated release ahead of Greenlight (date TBC)
- Summary: Business-owner fixes shipped separately while Greenlight waits on BAT.
- Open decision: If Greenlight slips significantly, rebuild the super user role in isolation (rework) or wait?
- Progress:
  - Cost center accepts alphanumeric values
  - Currency fields and conversion rates updated
  - Reassign intakes to other users
  - New homepage note
  - Admin table for bulk upload of field values without a deployment
  - Export of admin data fields
  - Remove old emails from the UiPath automation
- Next steps:
  - Confirm release date
  - Decide on super user (view-only) role: wait for Greenlight or rebuild in isolation

### IATLK-STAB: iATLK bot stabilisation
- Status: At risk · Priority P1
- Target: 2 to 4 weeks after the funded developer starts
- Summary: Fix the retriever, duplicate check and business exceptions so the bot creates Ariba SRs reliably again.
- Problem: Failure rate above 70%: files not picked up from Outlook, duplicate entries, frequent business exceptions. SRs are created manually, with delays and missed attachments.
- Progress:
  - Developer funding approved
- Next steps:
  - Onboard UiPath developer
  - Fix Outlook retrieval and duplicate check
  - Review business exception categories

### IATLK-PATH: Long-term SR creation path and VDI to cloud
- Status: Decision needed · Priority P2
- Target: Before UiPath Day 2 handover
- Summary: Choose the target for Ariba SR creation and plan the bot move off VDI.
- Open decision: UiPath Day 2 as a bridge, API-based SR creation (Globality or Ariba BTP), or a Technology-owned tool?

### S2P-CHANGE: Ariba release impact analysis for iATLK
- Status: Not started · Priority P2
- Target: Not set
- Summary: Analyse upcoming Ariba changes and get the UiPath developer access to Ariba.

## Integrations (2)

| ID | From | To | Purpose | Method | Frequency | Status | Classification |
|---|---|---|---|---|---|---|---|
| INT-002 | USFF Power Automate Flow | iATLK Sourcing Request Bot | Deliver request details to the bot mailbox | Email (Outlook) | Per submission | degraded | confirmed |
| INT-003 | iATLK Sourcing Request Bot | SAP Ariba (Source to Pay) | Create Ariba sourcing requests, update funding confirmation, attach files | RPA (UiPath UI automation) | Daily batch, 7 pm | degraded | confirmed |

## Overlaps
- OVL-003 (investigate, medium confidence): SR creation: iATLK vs Globality / Ariba BTP APIs. If Globality or Ariba BTP exposes SR creation APIs, the iATLK bot becomes redundant.

## Gaps
- GAP-003 (confirmed, high): No API for sourcing request creation. Ariba exposes no SR creation APIs to us, so SR creation depends on RPA or manual entry.

## Business capabilities
- CAP-003: Sourcing request creation. Limitations: RPA failure rate above 70%; Manual fallback

## Opportunities (not commitments)
- OPP-002 [idea, high] API-based sourcing request creation: Create SRs through Globality or Ariba BTP APIs.

## Future-state proposals (not approved unless stated)
- FUT-002 [proposed] Replace iATLK RPA with API-based sourcing request creation

## Working notes


### 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|

### 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Onboard the funded UiPath developer and grant Ariba access | Me |  | In progress | 2026-11-08 notes |
| A2 | Hand over defect list: Outlook file pickup, duplicate check, business exceptions | Me |  | Not started | 2026-11-08 notes |
| A3 | Track manual SR creation backlog and missed attachments | Ops |  | In progress | 2026-11-08 notes |

### 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

### 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Issue | IATLK-STAB | Failure rate above 70%: files not picked up from Outlook, duplicates despite the check, many business exceptions | Critical | High | Me | Developer funded; fixes expected 2 to 4 weeks after start | Open |
| R2 | Issue | IATLK-STAB | Manual SR creation causes delays at volume and sometimes misses attachments | High | High | Me | Daily manual queue review until bot is fixed | Open |
| R3 | Risk | IATLK-PATH | Any Ariba change can break the bot; fixes depend on UiPath pod priorities | High | Medium | Me | Ariba release impact analysis; long-term path decision | Open |
| R4 | Risk | IATLK-PATH | Bot runs on VDI and must move to cloud; not yet planned | Medium | Medium | Me | Include in long-term path decision | Open |

### 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-10-20 | Long-term SR creation path: UiPath Day 2, API (Globality / Ariba BTP), or Technology-owned tool? | Pending | Leadership | Deck recommendation: Day 2 as a bridge only, API as target |
| 2026-11-08 | Fund a UiPath developer to fix the bot | Decided | Leadership | 70%+ failure rate, manual workaround not sustainable |

### 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| API-based SR creation | Retire RPA fragility | Globality or Ariba BTP APIs | Not set |
| VDI to cloud migration | Supported hosting | Path decision | Not set |

### 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| UiPath pod | RPA | Technology |  | Bot code, Day 2 support |

### 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|
| How the bot runs | 1. USFF submit triggers Power Automate email  2. Retriever reads Outlook, adds to transaction queue  3. Processor creates Ariba SRs at 7 pm daily | UiPath Orchestrator | 2026-11-08 |

### 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- Bot not working reliably; someone is creating SRs manually
- Developer funding approved; fixes expected within 2 to 4 weeks once started


## AI opportunity ideas (proposed)




### Business exception classifier
- **Status:** Idea
- **Type:** LLM classification
- **Impact:** High
- **Effort:** S
- **Value:** Groups the 70%+ failures by root cause so the new developer fixes the biggest buckets first
- **MRM:** None if used offline for analysis only
- **Depends on:** Exception logs from UiPath Orchestrator

### Intelligent email and attachment extraction
- **Status:** Idea
- **Type:** UiPath Document Understanding / IXP
- **Impact:** High
- **Effort:** M
- **Value:** Replaces brittle Outlook parsing, the main failure point
- **MRM:** Check with MRM if extraction uses ML models
- **Depends on:** UiPath developer

### Duplicate detection with fuzzy matching
- **Status:** Idea
- **Type:** Deterministic + similarity scoring
- **Impact:** Medium
- **Effort:** S
- **Value:** Stops duplicate SRs that the current exact-match check misses
- **MRM:** None
- **Depends on:** Access to existing SR list

### Agentic SR creation via API
- **Status:** Idea
- **Type:** Agent + API
- **Impact:** High
- **Effort:** L
- **Value:** Retires screen automation entirely once Globality or Ariba BTP exposes SR APIs
- **MRM:** Full model review for agentic actions
- **Depends on:** Platform API decision

