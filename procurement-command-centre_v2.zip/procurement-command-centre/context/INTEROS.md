# Context pack: Interos (INTEROS)

> Generated 2026-11-08 from the Procurement Command Centre. Source of truth: data/apps/INTEROS/. Treat "proposed" and "unverified" items as unconfirmed.

## Application

| Field | Value |
|---|---|
| ID | INTEROS |
| Name | Interos |
| Aliases | None |
| Category | ai-model |
| Portfolio | supported |
| Status | live |
| Health | unknown |
| My role | Model developer (governance) |
| Classification | confirmed |

**Summary:** AI model where Ricky is the named model developer, accountable for ongoing model governance.

### Features
- None recorded

### Processes
- None recorded

### User groups
- None recorded

### Technical
- Stack: Not recorded
- Hosting: Not recorded
- Pattern: Not recorded
- Auth: Not recorded
- APIs: None recorded
- Data sources: None recorded
- Data destinations: None recorded
- Dependencies: None recorded

### Operations
- Support model: Model developer governance: drift and hallucination monitoring, enforce business testing.

**Known issues**
- None recorded

**Limitations**
- None recorded

**Technical debt**
- None recorded

**Compliance**
- Ongoing model monitoring
- Business testing evidence

## Initiatives (1)

### INTEROS-GOV: Interos model governance
- Status: BAU · Priority P2 · AI-enabled
- Target: Ongoing
- Summary: Monitor drift and hallucination, and hold the business to regular testing.

## Integrations (0)

| ID | From | To | Purpose | Method | Frequency | Status | Classification |
|---|---|---|---|---|---|---|---|


## Business capabilities
- CAP-010: AI model governance and monitoring

## Model governance obligations
- GOV-010 [ongoing] Drift and hallucination monitoring (monitoring, Ongoing)
- GOV-011 [needs-info] Business testing cycle (testing). Cadence and testers not yet confirmed.

## Opportunities (not commitments)
- OPP-009 [idea, medium] Shared MRM testing harness for all models: One labelled test set and report pipeline per model, run every quarter.

## Working notes


### 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|


### 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Confirm business testing cadence and next test date | Me |  | Not started | 2026-11-08 notes |
| A2 | Define drift and hallucination checks and evidence location | Me |  | Not started | 2026-11-08 notes |

### 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

### 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | INTEROS-GOV | Business does not provide testing evidence on time, leaving model governance gaps | High | Medium | Me | Set a testing calendar with named business testers | Open |

### 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|

### 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|

### 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|

### 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

### 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Context

- I am the model developer: ensure no drift or hallucinations
- Enforce business testing going forward; overall governance


## AI opportunity ideas (proposed)




### Automated drift and hallucination monitor
- **Status:** Idea
- **Type:** Monitoring + LLM-as-judge
- **Impact:** High
- **Effort:** M
- **Value:** Samples outputs weekly, scores them against references and alerts on drift, giving you evidence as model developer
- **MRM:** Supports monitoring plan
- **Depends on:** Output logs and a reference set

### Business testing tracker with reminders
- **Status:** Idea
- **Type:** Automation
- **Impact:** Medium
- **Effort:** S
- **Value:** Schedules business test cycles, chases testers and stores evidence in one place
- **MRM:** None
- **Depends on:** Named business testers

