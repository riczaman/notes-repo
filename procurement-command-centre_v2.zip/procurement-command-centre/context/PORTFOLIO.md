# Context pack: Procurement technology portfolio

> Generated 2026-11-08. 10 owned or supported applications, 28 initiatives.

## Applications

| ID | Name | Status | My role | Summary |
|---|---|---|---|---|
| TPCAI | 3PCRM AI Tool | live | Technology Lead | AI tool that reviews SOC 2 and other attestation documents for third-party cyber control assessments. |
| CBUD | Contract Buddy | live | Technology Lead | AI model built by TAPS developers that extracts key contract information and scores deviations for lower-risk contracting. |
| IATLK | iATLK Sourcing Request Bot | live | Technology Lead | UiPath RPA that turns USFF requests into Ariba sourcing requests, updates funding confirmation and attaches files. |
| PETL | Procurement ETL (Azure Data Pipeline) | live | Technology Lead | Azure Data Factory pipeline that pulls Ariba data and lands it in Rahona for the Procurement Tracker Power BI dashboard. |
| USFF | Unified Storefront | live | Technology Lead | Single front door for procurement vendor expense requests, from intake through approvals to Ariba sourcing request. |
| CAMEO | Agiloft (Cameo) | onboarding | Integration lead (later phase) | New contract lifecycle management SaaS. A partner team runs MRM and base setup; our team integrates it later. |
| GLOB | Globality | onboarding | Integration lead (later phase) | New SaaS sourcing platform. A partner team runs MRM and base setup; our team integrates it with the ecosystem later. |
| INTEROS | Interos | live | Model developer (governance) | AI model where Ricky is the named model developer, accountable for ongoing model governance. |
| RAPIDS | Rapids | live | Model developer (governance) | AI model where Ricky is the named model developer, accountable for ongoing model governance. |
| S2P | SAP Ariba (Source to Pay) | live | Technology support (servers and vulnerabilities) | Procurement book of record where sourcing requests are created. USFF is linked from Ariba. |

## Initiatives

| ID | Title | Apps | Status | Target |
|---|---|---|---|---|
| USFF-EMS-MLP1 | Project Greenlight: EMS vendor expense into USFF | USFF, EMS | At risk | Nov or Dec 2026, pending business acceptance testing |
| USFF-EMS-NEXT | EMS MLP2 to MLP4: remaining EMS flows | USFF, EMS | Decision needed | Not committed (about one quarter per flow once prioritised) |
| USFF-REL-BIZ | USFF business enhancements release (isolated) | USFF, IATLK | In delivery | Isolated release ahead of Greenlight (date TBC) |
| USFF-GENAI | Gen AI Autointake assistant | USFF | Decision needed | F27 Q2 (proposed) |
| USFF-TRIAGE | Smart Triage (ARP) | USFF | Decision needed | Not set (business expects F27 Q1) |
| USFF-ATTACH | Historical attachment migration | USFF, SPO | Planning | Not set |
| USFF-PETL-FEED | USFF data feed to Procurement Tracker | USFF, PETL, PROCTRK | Blocked | PAT and Prod once network access is approved |
| USFF-SPID-ETL | SPID validation ETL | USFF, S2P, SPO | Planning | Fast follow after Greenlight |
| USFF-ARIBA-INT | Two-way SR validation (Ariba / Globality APIs) | USFF, S2P, GLOB | Blocked | Not set (depends on Globality or Ariba BTP decision) |
| IATLK-STAB | iATLK bot stabilisation | IATLK, S2P, PAUT | At risk | 2 to 4 weeks after the funded developer starts |
| IATLK-PATH | Long-term SR creation path and VDI to cloud | IATLK, GLOB, S2P | Decision needed | Before UiPath Day 2 handover |
| PETL-MLP3-4 | PETL MLP3 and MLP4 | PETL, S2P, RAHONA | In delivery | Nov 22, 2026 |
| PETL-API-REVIEW | Ariba data review to free API capacity | PETL, S2P | Not started | Before the next PETL MLP |
| PETL-MLP5 | PETL MLP5: Fieldglass source | PETL, FGLASS | Planning | Not set (waiting on data availability) |
| PETL-ADLS | Direct ADLS-to-ADLS copy to Rahona | PETL, RAHONA | Not started | Not planned |
| PETL-COMPLY | PETL compliance: DAST rescan, Veracode, Snyk | PETL | BAU | DAST rescan due next (annual) |
| S2P-COUPA-MLP3 | Ariba Coupa automation MLP3 (contract workspace) | S2P, COUPA | Planning | F27 Q1 to Q2 |
| S2P-CHANGE | Ariba release impact analysis for iATLK | S2P, IATLK | Not started | Not set |
| S2P-BAU | Ariba server vulnerabilities and manual SR support | S2P | BAU | Ongoing |
| CBUD-MLP2 | Contract Buddy MLP2 feature enhancements | CBUD | Done | Deployed late Oct 2026 |
| CBUD-BAU | Contract Buddy BAU and compliance | CBUD | Decision needed | Ongoing through 2027 |
| TPCAI-MLP15 | 3PCRM MLP1.5: clickable attestations and 2026 questionnaire | TPCAI | Done | Deployed week of Nov 2, 2026 |
| TPCAI-MLP2 | 3PCRM MLP2: model work and development | TPCAI | Planning | Feb 2027 (features), Q1 2027 (model artifacts) |
| TPCAI-BAU | 3PCRM compliance backlog | TPCAI | At risk | Dates to commit at review call |
| GLOB-INT | Globality integrations and prompt engineering | GLOB | Not started | After partner team completes MRM and setup |
| CAMEO-INT | Agiloft integrations, requirements and prompt engineering | CAMEO, CBUD | Not started | Agiloft onboarding expected Jan 2027 |
| INTEROS-GOV | Interos model governance | INTEROS | BAU | Ongoing |
| RAPIDS-GOV | Rapids model governance | RAPIDS | BAU | Ongoing |

## Pending decisions
- [TPCAI] Can prod data removal wait for latency fixes, or do SIT users need a plan sooner? (raised 2026-11-08, owner Me + Archer)
- [CBUD] After Agiloft onboarding: decommission Contract Buddy or keep for specific use cases? (raised 2026-10-20, owner Leadership)
- [IATLK] Long-term SR creation path: UiPath Day 2, API (Globality / Ariba BTP), or Technology-owned tool? (raised 2026-10-20, owner Leadership)
- [PETL] Can the business retire unused tables and fields to free Ariba API capacity? (raised 2026-10-20, owner Business)
- [PETL] Can Rahona ingestion be fully self-serve for our dev team? (raised 2026-10-20, owner Rahona)
- [USFF] Greenlight: deploy in November or December once BAT passes? (raised 2026-11-08, owner Leadership)
- [USFF] Next pod priority: EMS MLP2 to MLP4, Gen AI Autointake, or Smart Triage? (raised 2026-11-08, owner Leadership)
- [USFF] Form segmentation: optional fields as interim, or staged form? (raised 2026-11-08, owner Business + Me)
- [S2P] Keep Coupa scripts on the ITK server for another year, or move now? (raised 2026-10-20, owner Leadership)

## High and critical risks
- [TPCAI R1] Latency pushed users to SIT, putting prod data in lower environments (Archer finding) · Impact Critical · Mitigation: Fix latency first, then remove data; agree interim plan
- [IATLK R1] Failure rate above 70%: files not picked up from Outlook, duplicates despite the check, many business exceptions · Impact Critical · Mitigation: Developer funded; fixes expected 2 to 4 weeks after start
- [CBUD R1] Two open Archer findings (prod data in lower env, MLP2 pen test) · Impact High · Mitigation: Commit dates at task review
- [IATLK R2] Manual SR creation causes delays at volume and sometimes misses attachments · Impact High · Mitigation: Daily manual queue review until bot is fixed
- [PETL R1] Ariba API daily limit of 60. More data needs more capacity at extra cost, and Ariba is not the long-term platform · Impact High · Mitigation: Review and retire unused tables and fields first
- [USFF R2] No legacy data migration: data discrepancies, and current users add USFF to their tool stack while other flows stay in EMS · Impact High · Mitigation: Communicate "new requests only"; scope migration as a separate release
- [USFF R3] SPID validation is fully manual (Ariba report saved to SharePoint). No true validation check · Impact High · Mitigation: Build SPID ETL as a fast follow
- [USFF R5] Support model gap: approval tables mapped manually per LOB and segment and must be maintained as approvers move · Impact High · Mitigation: Define owner, cadence and admin tooling
- [USFF R6] Vendor expense was reverse engineered. Future EMS flows need named business partners and requirements up front · Impact High · Mitigation: Name one SME per flow; written requirements before backlog entry
- [USFF R7] All capacity is tied to EMS, so business-requested USFF work (Gen AI Autointake, Smart Triage) keeps slipping · Impact High · Mitigation: Prioritisation exercise; ask for added capacity
- [S2P R3] Finding requires MLP3 on the contract workspace table · Impact High · Mitigation: Scope MLP3 using MLP1 and MLP2 mechanism
- [TPCAI R2] Model testing window (to Mar 31) may end after the February feature date · Impact High · Mitigation: Set separate dates for model plan, test plan, testing
- [TPCAI R3] AI intake, CPOP, AI CGA and CRA may gate MLP2 deployment · Impact High · Mitigation: Confirm which approvals gate MLP2
- [CBUD R3] 2027 BAU funding not confirmed · Impact High · Mitigation: Raise with leadership
- [IATLK R3] Any Ariba change can break the bot; fixes depend on UiPath pod priorities · Impact High · Mitigation: Ariba release impact analysis; long-term path decision
- [USFF R1] Vendor expense is the heartbeat of all other EMS flows. Pulling it into USFF may have downstream impact we have not been told about · Impact High · Mitigation: Ask EMS team for a downstream impact walkthrough before go-live
- [USFF R9] In-app permissions instead of AD groups (EMS matrix would need about 850 AD groups) may need an Archer or finding exception, or a Diamond feed · Impact High · Mitigation: Discuss with Geetha; document the rationale
- [CAMEO R1] Overlapping integrations stay on after go-live · Impact High · Mitigation: Cutover checklist
- [GLOB R1] Overlapping integrations stay on after Globality goes live, creating duplicate data paths · Impact High · Mitigation: Cutover checklist: switch off old integrations as new ones switch on
- [GLOB R2] Globality API decision also sets the long-term SR creation path · Impact High · Mitigation: Track platform decision
- [INTEROS R1] Business does not provide testing evidence on time, leaving model governance gaps · Impact High · Mitigation: Set a testing calendar with named business testers
- [RAPIDS R1] Business does not provide testing evidence on time, leaving model governance gaps · Impact High · Mitigation: Set a testing calendar with named business testers
- [S2P R1] Every Ariba update can require iATLK changes · Impact High · Mitigation: Release impact analysis before each Ariba update
- [S2P R2] ITK server decommission (Archer findings) would strand the Coupa scripts · Impact High · Mitigation: Decide: one-year exception or new hosting
