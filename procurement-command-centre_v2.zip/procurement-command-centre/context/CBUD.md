# Context pack: Contract Buddy (CBUD)

> Generated 2026-11-08 from the Procurement Command Centre. Source of truth: data/apps/CBUD/. Treat "proposed" and "unverified" items as unconfirmed.

## Application

| Field | Value |
|---|---|
| ID | CBUD |
| Name | Contract Buddy |
| Aliases | CBUD |
| Category | ai-model |
| Portfolio | owned |
| Status | live |
| Health | amber |
| My role | Technology Lead |
| Classification | confirmed |

**Summary:** AI model built by TAPS developers that extracts key contract information and scores deviations for lower-risk contracting.

**Purpose:** Speed up contracting for lower-risk transactions with AI deviation detection and scoring.

### Features
- Contract data extraction
- AI deviation detection and scoring

### Processes
- None recorded

### User groups
- None recorded

### Technical
- Stack: Not recorded
- Hosting: Not recorded
- Pattern: Not recorded
- Auth: Not recorded
- APIs: None recorded
- Data sources: None recorded
- Data destinations: None recorded
- Dependencies: None recorded

### Operations
- Support model: BAU only from 2027. No new development planned. Funding model to confirm.

**Known issues**
- None recorded

**Limitations**
- Accessibility rating 3 star; 4 star is the minimum

**Technical debt**
- None recorded

**Compliance**
- Archer: production data in lower environments
- Archer: MLP2 pen test (date on file Nov 22, 2026)
- Quarterly model testing (in perpetuity)
- Snyk and Veracode
- AMH onboarding

## Initiatives (3)

### CBUD-MLP2: Contract Buddy MLP2 feature enhancements
- Status: Done · Priority P2 · AI-enabled
- Target: Deployed late Oct 2026
- Summary: Second deployment with feature enhancements. No new development planned for 2027.

### CBUD-BAU: Contract Buddy BAU and compliance
- Status: Decision needed · Priority P2 · AI-enabled
- Target: Ongoing through 2027
- Summary: Maintenance only: vulnerability fixes, quarterly model testing (in progress, in perpetuity), Archer findings, accessibility, onboarding.
- Open decision: How is BAU funded in 2027, and do we keep Contract Buddy once Agiloft is onboarded?
- Progress:
  - 8 review tasks, none discussed yet
- Next steps:
  - Confirm 2027 funding model
  - Run the task review call and commit dates

### CAMEO-INT: Agiloft integrations, requirements and prompt engineering
- Status: Not started · Priority P2 · AI-enabled
- Target: Agiloft onboarding expected Jan 2027
- Summary: BSA-led requirements, integrations to existing apps, retiring overlapping integrations, and prompt engineering.

## Integrations (0)

| ID | From | To | Purpose | Method | Frequency | Status | Classification |
|---|---|---|---|---|---|---|---|


## Overlaps
- OVL-002 (potential, medium confidence): Contract Buddy vs Agiloft contract AI. Agiloft may cover Contract Buddy extraction and deviation scoring once fully onboarded.

## Business capabilities
- CAP-006: Contract data extraction and deviation scoring
- CAP-010: AI model governance and monitoring

## Model governance obligations
- GOV-001 [in-progress] Quarterly model accuracy testing (testing, Quarterly (in perpetuity)). Next report covers MLP1 only; the following quarter covers MLP1 and MLP2.

## Opportunities (not commitments)
- OPP-006 [idea, medium] Contract AI consolidation (Contract Buddy and Agiloft): Keep Contract Buddy only for use cases Agiloft does not cover.
- OPP-009 [idea, medium] Shared MRM testing harness for all models: One labelled test set and report pipeline per model, run every quarter.

## Future-state proposals (not approved unless stated)
- FUT-005 [proposed] Decommission Contract Buddy if Agiloft covers its use cases. Depends on the capability comparison after Agiloft onboarding.

## Working notes


### 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2026-11-22 | Archer: MLP2 pen test | TBC | In progress | Sunday; confirm the working date and whether it covers fixes |
| 2027-01 | Agiloft fully onboarded (decision point for Contract Buddy) | Partner team | Not started | Deck says January; exact date TBC |

### 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| FUND | Confirm how 2027 BAU funding works | Me |  | Not started | 2026-11-08 notes |
| A1 | Archer: remove prod data from lower environments | TBC |  | Not yet discussed | CBUD task review |
| A2 | Archer: pen testing for MLP2 | TBC | 2026-11-22 | Not yet discussed | CBUD task review |
| B | Annual business quarterly testing (next report MLP1 only, then MLP1 + MLP2) | TBC |  | Not yet discussed | CBUD task review |
| C | Accessibility: 3 star to 4 star (decide together with TPCAI F) | TBC |  | Not yet discussed | CBUD task review |
| D | Snyk and Veracode vulnerabilities | TBC |  | Not yet discussed | CBUD task review |
| D.2 | Snyk onboarding (same as TPCAI K2) | TBC |  | Not yet discussed | CBUD task review |
| E | Provisioning users to the app (need unconfirmed) | TBC |  | Not yet discussed | CBUD task review |
| F | AMH onboarding (same as TPCAI K1) | TBC |  | Not yet discussed | CBUD task review |

### 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

### 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Issue | CBUD-BAU | Two open Archer findings (prod data in lower env, MLP2 pen test) | High | High | Me | Commit dates at task review | Open |
| R2 | Issue | CBUD-BAU | Accessibility at 3 star; 4 star is the minimum | Medium | High | Me | Decide approach with TPCAI F | Open |
| R3 | Risk | CBUD-BAU | 2027 BAU funding not confirmed | High | Medium | Me | Raise with leadership | Open |
| R4 | Risk | CAMEO-INT | Agiloft may replace Contract Buddy, putting further investment at risk | Medium | Medium | Me | Compare capabilities before any new spend | Open |

### 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-10-20 | After Agiloft onboarding: decommission Contract Buddy or keep for specific use cases? | Pending | Leadership | Avoid two contract AI tools |
| 2026-11-08 | No new development in 2027; BAU and maintenance only | Decided | Leadership | Scope defined after MLP2 |
| 2026-11-08 | No new model MRM work; quarterly model testing continues | Decided | MRM | Model scope is defined |

### 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| Confirm items on TPCAI list: retention cadence, CRA for MLP2, MLP2 model artifacts, performance testing | Closes compliance unknowns | Task review | TBC |

### 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| TAPS developers | Build team | TAPS |  | Model and app code |
| MRM team | Model risk | MRM |  | Quarterly testing |

### 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

### 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- MLP2 deployed with feature enhancements; no new dev work into next year
- Quarterly model testing in progress and continues in perpetuity
- Funding model for BAU to be confirmed


## AI opportunity ideas (proposed)




### Automated quarterly test harness
- **Status:** Idea
- **Type:** Evaluation pipeline
- **Impact:** High
- **Effort:** M
- **Value:** Runs the quarterly accuracy test against a fixed labelled set and produces the MRM report automatically, since testing continues in perpetuity
- **MRM:** Supports existing MRM obligations
- **Depends on:** Labelled test set from business

### Drift monitoring dashboard
- **Status:** Idea
- **Type:** Monitoring
- **Impact:** Medium
- **Effort:** S
- **Value:** Tracks extraction confidence and deviation-score distribution month over month
- **MRM:** Supports monitoring plan
- **Depends on:** Prediction logging

### Agiloft capability comparison
- **Status:** Idea
- **Type:** Analysis
- **Impact:** High
- **Effort:** S
- **Value:** Side-by-side test of Contract Buddy and Agiloft AI on the same contracts to support the keep or decommission decision
- **MRM:** None
- **Depends on:** Agiloft sandbox access

