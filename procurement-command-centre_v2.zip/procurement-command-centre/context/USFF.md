# Context pack: Unified Storefront (USFF)

> Generated 2026-11-08 from the Procurement Command Centre. Source of truth: data/apps/USFF/. Treat "proposed" and "unverified" items as unconfirmed.

## Application

| Field | Value |
|---|---|
| ID | USFF |
| Name | Unified Storefront |
| Aliases | USF, Unified Storefront (USFF) |
| Category | web-app |
| Portfolio | owned |
| Status | live |
| Health | amber |
| My role | Technology Lead |
| Classification | confirmed |

**Summary:** Single front door for procurement vendor expense requests, from intake through approvals to Ariba sourcing request.

**Purpose:** Streamline how colleagues submit and approve procurement vendor expense requests, and remove duplicate data entry across USFF, EMS and Signing Party (SPID). Target state: every procurement-related vendor expense flows through USFF.

### Features
- Unified intake form (vendor expense, GTS pipeline, additional vendor expense, management consulting and SPID questions)
- Pipeline, management and funding approvals
- Legacy vs new request flag (old non-unified form continues for existing users)
- Admin reference tables
- In-app scopes and permissions for the EMS segment approval matrix

### Processes
- Vendor expense intake
- Pipeline approval
- Funding confirmation
- Sourcing request creation (via iATLK)
- SPID (signing party) validation

### User groups
- Line of business requestors
- GTS users (EMS flows)
- Vendor managers
- BOM leads
- EMS team
- Procurement admins

### Technical
- Stack: React web app (migrated from Power Apps), Application database (USFF DB)
- Hosting: Not recorded
- Pattern: Not recorded
- Auth: 5 AD groups plus in-app scopes and permissions. The EMS segment approval matrix would need about 850 AD groups, so permissions are scoped in-app. May need an Archer or finding exception (discuss with Geetha).
- APIs: None recorded
- Data sources: EMS SharePoint (legacy attachments, planned migration); Ariba report on SharePoint for SPID (manual)
- Data destinations: Power Automate email to iATLK mailbox; PETL / Azure Data Factory (planned)
- Dependencies: iATLK (UiPath) for Ariba SR creation; Power Automate flow; Ariba

### Operations
- Support model: Needs a better support model: approval tables are maintained manually per line of business and segment.

**Known issues**
- None recorded

**Limitations**
- SPID validation is fully manual (Ariba report saved to SharePoint by the EMS team)
- Vendor expense was built by reverse engineering EMS, not from written requirements
- Unified form expects requestors to know all answers up front

**Technical debt**
- Historical attachment files not migrated from the Power Apps version
- Super user (view-only) role built inside the EMS release; may need rework if EMS slips

**Compliance**
- Possible Archer or finding exception for in-app permissions

## Initiatives (9)

### USFF-EMS-MLP1: Project Greenlight: EMS vendor expense into USFF
- Status: At risk · Priority P1 · Leadership focus
- Target: Nov or Dec 2026, pending business acceptance testing
- Summary: Move every procurement-related vendor expense from EMS into USFF with one unified intake form, so requestors stop entering the same data in three tools.
- Problem: Vendor expense requests move through USFF intake, EMS pipeline and Signing Party (SPID). Duplicate fields and hand-offs slow approvals and signing.
- Open decision: Deploy in November or December once BAT passes? Data migration stays descoped (new requests only)?
- Progress:
  - Built: unified intake (vendor expense, GTS pipeline, additional vendor expense, management consulting, SPID questions)
  - Pipeline, management and funding approvals in one application
  - QE system testing complete
  - Waiting on business acceptance testing (BAT) for go / no-go
- Next steps:
  - Run BAT and get go / no-go
  - Confirm November or December deployment window
  - Agree interim answer on form segmentation (optional fields vs staged form)
  - Define support model for approval-matrix maintenance
- Dependencies: EMS business SMEs for BAT; Manual SPID report from Ariba (until SPID ETL)

### USFF-EMS-NEXT: EMS MLP2 to MLP4: remaining EMS flows
- Status: Decision needed · Priority P2
- Target: Not committed (about one quarter per flow once prioritised)
- Summary: Bring the remaining EMS flows into USFF so EMS can retire: Approval to Hire (MLP2), Invoices (MLP3), Project Requests and Business Cases (MLP4).
- Problem: MLP1 covers vendor expense only. Users keep EMS for every other flow and run two tools until all flows and their data move.
- Open decision: Who are the accountable SMEs, and does the pod take EMS flows next or business-requested USFF work?
- Next steps:
  - Name one accountable business SME per flow
  - Get written requirements before any flow enters the backlog
- Dependencies: Business SMEs; Pod capacity (2 developers, 0.5 BSA)

### USFF-REL-BIZ: USFF business enhancements release (isolated)
- Status: In delivery · Priority P1
- Target: Isolated release ahead of Greenlight (date TBC)
- Summary: Business-owner fixes shipped separately while Greenlight waits on BAT.
- Open decision: If Greenlight slips significantly, rebuild the super user role in isolation (rework) or wait?
- Progress:
  - Cost center accepts alphanumeric values
  - Currency fields and conversion rates updated
  - Reassign intakes to other users
  - New homepage note
  - Admin table for bulk upload of field values without a deployment
  - Export of admin data fields
  - Remove old emails from the UiPath automation
- Next steps:
  - Confirm release date
  - Decide on super user (view-only) role: wait for Greenlight or rebuild in isolation

### USFF-GENAI: Gen AI Autointake assistant
- Status: Decision needed · Priority P2 · AI-enabled
- Target: F27 Q2 (proposed)
- Summary: Chatbot grounded in vendor manager knowledge that helps requestors fill the intake correctly, so vendor managers review after submission instead of answering every question.
- Problem: The process depends on vendor manager knowledge. Vendor managers lack time to review and answer everything, so incorrect entries create rework.
- Open decision: Run Gen AI Autointake next, or hold until EMS flows land?
- Progress:
  - POC built
  - Some upfront MRM work complete
- Next steps:
  - Prioritisation exercise against EMS work
  - Update AI CGA
  - Complete enterprise AI intake
  - Create a new CRA
  - Identify vendor manager SMEs and knowledge sources
- Dependencies: MRM approvals; Vendor manager knowledge base

### USFF-TRIAGE: Smart Triage (ARP)
- Status: Decision needed · Priority P3
- Target: Not set (business expects F27 Q1)
- Summary: Automate ARP triage logic so requests route to the right team and skip unneeded ARP reviews.
- Problem: ARP manually triages each sourcing request, which adds effort and delays sourcing lead assignment.
- Open decision: When to prioritise behind EMS and Gen AI Autointake?
- Next steps:
  - Document ARP triage rules

### USFF-ATTACH: Historical attachment migration
- Status: Planning · Priority P2
- Target: Not set
- Summary: Move legacy attachment files left behind when USFF moved from Power Apps to React.
- Progress:
  - All other data migrated during the React rebuild
- Next steps:
  - Build a team-owned ETL that reads SharePoint (preferred over PETL / ADF)

### USFF-PETL-FEED: USFF data feed to Procurement Tracker
- Status: Blocked · Priority P1
- Target: PAT and Prod once network access is approved
- Summary: Open a connection from the USFF DB to ADF, then push USFF-specific fields through Rahona to the Procurement Tracker dashboard.
- Progress:
  - Dev test complete
- Next steps:
  - TAPS infrastructure team updates the PID document
  - Azure team opens NSG rules and maps the service principal
  - Solution architect updates the architecture blueprint
- Dependencies: TAPS infrastructure; Azure team; Solution architect

### USFF-SPID-ETL: SPID validation ETL
- Status: Planning · Priority P2
- Target: Fast follow after Greenlight
- Summary: Replace the manual Ariba SPID report (saved to SharePoint by the EMS team) with a team-built ETL so contract signed IDs are validated automatically.
- Problem: No true validation check today: SPID validation is fully manual.

### USFF-ARIBA-INT: Two-way SR validation (Ariba / Globality APIs)
- Status: Blocked · Priority P3
- Target: Not set (depends on Globality or Ariba BTP decision)
- Summary: Integrate USFF with Globality or Ariba BTP APIs for two-way sourcing request validation.
- Problem: Ariba has no APIs available to us, so staff validate SRs by manual swivel chair.
- Dependencies: Target sourcing platform decision

## Integrations (6)

| ID | From | To | Purpose | Method | Frequency | Status | Classification |
|---|---|---|---|---|---|---|---|
| INT-001 | Unified Storefront | USFF Power Automate Flow | Trigger SR creation for each submitted request | Event (on submit) | Per submission | live | confirmed |
| INT-007 | Unified Storefront | Procurement ETL (Azure Data Pipeline) | Send USFF-specific fields to the Procurement Tracker | ADF connection to USFF DB | TBC | in-delivery | confirmed |
| INT-009 | EMS (GTS Expense Management) | Unified Storefront | Move vendor expense intake, pipeline and SPID into USFF (new requests only) | Process migration (no data migration) |  | in-delivery | confirmed |
| INT-012 | SharePoint (EMS sites) | Unified Storefront | SPID validation data into USFF | Team-built ETL |  | planned | proposed |
| INT-013 | SharePoint (EMS sites) | Unified Storefront | Migrate historical attachment files | Team-built ETL (one-time) |  | planned | proposed |
| INT-015 | SAP Ariba (Source to Pay) | Unified Storefront | USFF is linked from the Ariba site | UI link |  | live | confirmed |

## Overlaps
- OVL-001 (confirmed, high confidence): Vendor expense intake duplicated across USFF, EMS and SPID. Requestors enter the same vendor expense data in USFF, the EMS pipeline and Signing Party.

## Gaps
- GAP-001 (confirmed, high): No automated SPID validation. Contract signed IDs are validated from a manual Ariba report saved to SharePoint.
- GAP-002 (confirmed, high): Approval matrix maintenance has no support model. Approvers per line of business and segment are mapped manually and change as people move.
- GAP-004 (needs-validation, high): Requirements for remaining EMS flows. No named SMEs or written requirements; vendor expense was reverse engineered.

## Business capabilities
- CAP-001: Vendor expense intake. Limitations: Legacy EMS data not migrated
- CAP-002: Pipeline, management and funding approval routing. Limitations: Approver matrix maintained manually
- CAP-004: Contract signing validation (SPID) (maturity initial). Limitations: Fully manual Ariba report on SharePoint

## Model governance obligations
- GOV-007 [not-started] Gen AI Autointake: update AI CGA (artifact, One-off)
- GOV-008 [not-started] Gen AI Autointake: enterprise AI intake (approval, One-off)
- GOV-009 [not-started] Gen AI Autointake: new CRA (approval, One-off)

## Opportunities (not commitments)
- OPP-001 [assessing, high] One front door for every EMS flow: Move remaining flows into USFF with written requirements and named SMEs.
- OPP-003 [planned, high] Automated SPID validation: Team-built ETL feeding signed IDs into USFF.
- OPP-004 [assessing, high] Gen AI intake assistant: Assistant grounded in vendor manager knowledge.
- OPP-007 [idea, medium] Approval matrix maintenance automation: Sync from an HR or directory feed with admin approval.
- OPP-010 [idea, medium] Smart Triage for ARP: Automate ARP triage rules in USFF.

## Future-state proposals (not approved unless stated)
- FUT-003 [proposed] USFF creates sourcing requests through Globality or Ariba BTP APIs. Target platform not decided; Ariba BTP is the alternative.
- FUT-006 [proposed] Gen AI intake assistant in USFF
- FUT-007 [proposed] Smart Triage routing for ARP in USFF

## Working notes


### 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2026-11-30 | Greenlight deployment window (November option) | Me | At risk | Depends on BAT outcome |
| 2026-12-15 | Greenlight deployment window (December option) | Me | Not started | Check against December change freeze |

### 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Get BAT scheduled and agree go / no-go criteria | Me |  | In progress | 2026-11-08 notes |
| A2 | Discuss Archer / finding exception for in-app permissions (5 AD groups + in-app scopes) | Me + Geetha |  | Not started | 2026-11-08 notes |
| A3 | Set up prioritisation exercise: EMS flows vs Gen AI Autointake vs Smart Triage | Me |  | Not started | 2026-11-08 notes |
| A4 | Chase TAPS to update PID and Azure team for NSG rules + service principal mapping | Me |  | In progress | 2026-11-08 notes |
| A5 | Chase solution architect for architecture blueprint update (USFF to PETL) | Me |  | In progress | 2026-11-08 notes |
| A6 | Draft support model for approval-matrix maintenance | Me |  | Not started | 2026-11-08 notes |
| A7 | Update AI CGA, enterprise AI intake and create new CRA for Gen AI Autointake | Me |  | Not started | 2026-11-08 notes |
| A8 | Size legacy EMS data migration (SharePoint schema vs USFF tables) in case it becomes a requirement | Dev team |  | Not started | 2026-11-08 notes |

### 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|
| 2026-10-20 | David Parry | Historical EMS and Signing Party data in USFF before launch |  | Open | Descoped for MLP1: new requests only. Migration can be a separate release |
| 2026-11-08 | USFF business owner | Super user role: view-only access to all requests for their support team |  | Open | Built inside Greenlight; rework if Greenlight slips |

### 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | USFF-EMS-MLP1 | Vendor expense is the heartbeat of all other EMS flows. Pulling it into USFF may have downstream impact we have not been told about | High | Medium | Me | Ask EMS team for a downstream impact walkthrough before go-live | Open |
| R2 | Risk | USFF-EMS-MLP1 | No legacy data migration: data discrepancies, and current users add USFF to their tool stack while other flows stay in EMS | High | High | Me | Communicate "new requests only"; scope migration as a separate release | Open |
| R3 | Issue | USFF-SPID-ETL | SPID validation is fully manual (Ariba report saved to SharePoint). No true validation check | High | High | Me | Build SPID ETL as a fast follow | Open |
| R4 | Risk | USFF-EMS-MLP1 | Requestors may not know every answer up front; business wants a segmented form | Medium | High | Me | Interim: make non-critical fields optional rather than redesigning the form | Open |
| R5 | Issue | USFF-EMS-MLP1 | Support model gap: approval tables mapped manually per LOB and segment and must be maintained as approvers move | High | High | Me | Define owner, cadence and admin tooling | Open |
| R6 | Risk | USFF-EMS-NEXT | Vendor expense was reverse engineered. Future EMS flows need named business partners and requirements up front | High | High | Me | Name one SME per flow; written requirements before backlog entry | Open |
| R7 | Risk | USFF-GENAI | All capacity is tied to EMS, so business-requested USFF work (Gen AI Autointake, Smart Triage) keeps slipping | High | High | Me | Prioritisation exercise; ask for added capacity | Open |
| R8 | Risk | USFF-REL-BIZ | Super user role was built for Greenlight. A long Greenlight delay means rebuilding it in isolation (duplicate work) | Medium | Medium | Me | Decide rebuild trigger date | Open |
| R9 | Risk | USFF-EMS-MLP1 | In-app permissions instead of AD groups (EMS matrix would need about 850 AD groups) may need an Archer or finding exception, or a Diamond feed | High | Medium | Me + Geetha | Discuss with Geetha; document the rationale | Open |
| R10 | Issue | USFF-PETL-FEED | PAT and Prod blocked on TAPS PID update, NSG rules and service principal mapping | Medium | High | Me | Escalate if no movement by next sync | Open |

### 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-11-08 | Greenlight: deploy in November or December once BAT passes? | Pending | Leadership | BAT outcome is the go / no-go gate |
| 2026-11-08 | Next pod priority: EMS MLP2 to MLP4, Gen AI Autointake, or Smart Triage? | Pending | Leadership | Pod runs one track at a time |
| 2026-11-08 | Form segmentation: optional fields as interim, or staged form? | Pending | Business + Me | My view: optional fields first |
| 2026-10-20 | Data migration descoped from MLP1; new requests only | Decided | Technology | Mapping not feasible before launch; including it moves launch to Jan to Feb 2027 |
| 2026-11-08 | Build own ETL for attachment migration instead of PETL / ADF | Decided | Technology | Simpler, team-owned |

### 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| EMS MLP2 Approval to Hire | Users stop using EMS for ATH | Named SMEs, requirements | Not committed |
| EMS MLP3 Invoices | Users stop using EMS for invoices | Named SMEs, requirements | Not committed |
| EMS MLP4 Project Requests and Business Cases | EMS can retire | All flows and data migrated | Not committed |
| Gen AI Autointake | Fewer incorrect intakes, less vendor manager load | MRM approvals, knowledge base | F27 Q2 (proposed) |
| Smart Triage (ARP) | Skip unneeded ARP reviews | Documented triage rules | Not set |
| Legacy EMS data migration | One source for all requests | Schema mapping effort | Only if required |

### 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| Geetha | TBC | TBC |  | Access model exception (AD groups vs in-app permissions) |
| David Parry | TBC | EMS / GTS |  | Historical data migration ask |
| TAPS infrastructure | Infrastructure | TAPS |  | PID document |
| Azure team | Cloud | Technology |  | NSG rules, service principals |

### 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|
| Tell a legacy request from a new one | Backend flag on each request: legacy (old non-unified form) or new (unified form) | USFF DB | 2026-11-08 |

### 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Portfolio context dump

- Greenlight (EMS vendor expense) fully developed; waiting on business acceptance testing for go / no-go
- MLP1 unified intake: vendor expense fields, GTS pipeline questions, additional vendor expense questions, management consulting questions, SPID questions
- Old non-unified form continues for existing users; backend flag marks legacy vs new
- Isolated release in flight: alphanumeric cost center, currency and conversion rates, reassign intakes, homepage note, admin bulk upload table, admin data export, remove old emails from UiPath automation
- USFF to PETL feed tested in Dev; PAT and Prod need TAPS PID update, NSG rules and service principal mapping


## AI opportunity ideas (proposed)




Ideas to reduce vendor manager load and requestor rework. Every idea is classified as proposed until you validate it.

### Gen AI intake assistant (Autointake)
- **Status:** POC built
- **Type:** Generative AI assistant (RAG)
- **Impact:** High
- **Effort:** L
- **Value:** Requestors get answers from vendor manager knowledge while filling the form; vendor managers review after submission instead of answering every question
- **MRM:** AI CGA update, enterprise AI intake, new CRA
- **Depends on:** Vendor manager knowledge sources and SMEs

Ground the assistant in the vendor manager playbook, policy and past approved intakes. Start with field-level help ("what goes in management consulting scope?") before letting it draft whole sections.

### Intake completeness and quality checker
- **Status:** Idea
- **Type:** LLM classification + rules
- **Impact:** High
- **Effort:** M
- **Value:** Flags vague descriptions, missing SOW details and wrong expense type before submission, cutting back-and-forth
- **MRM:** Likely lighter than a chatbot if it only flags, never decides
- **Depends on:** Examples of good and rejected intakes

### Smart Triage routing (ARP)
- **Status:** Idea
- **Type:** Rules engine first, ML later
- **Impact:** High
- **Effort:** M
- **Value:** Routes requests to the right team and skips unneeded ARP reviews
- **MRM:** None if pure rules; model review if ML scoring is added
- **Depends on:** Documented ARP triage rules

Build the deterministic rules first. Add a model only where rules cannot decide.

### Approval matrix maintenance assistant
- **Status:** Idea
- **Type:** Automation + HR data sync
- **Impact:** Medium
- **Effort:** M
- **Value:** Detects approvers who moved roles or left and proposes matrix updates for admin approval, closing the support model gap
- **MRM:** None (no model)
- **Depends on:** HR or directory feed

### SPID document matching
- **Status:** Idea
- **Type:** Document AI
- **Impact:** Medium
- **Effort:** M
- **Value:** Matches contract signed IDs to intakes automatically once the SPID ETL lands, flagging mismatches
- **MRM:** Model review if extraction is AI-based
- **Depends on:** SPID validation ETL

