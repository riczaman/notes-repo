# Context pack: SAP Ariba (Source to Pay) (S2P)

> Generated 2026-11-08 from the Procurement Command Centre. Source of truth: data/apps/S2P/. Treat "proposed" and "unverified" items as unconfirmed.

## Application

| Field | Value |
|---|---|
| ID | S2P |
| Name | SAP Ariba (Source to Pay) |
| Aliases | Ariba, S2P, SAP Ariba |
| Category | saas |
| Portfolio | supported |
| Status | live |
| Health | amber |
| My role | Technology support (servers and vulnerabilities) |
| Classification | confirmed |

**Summary:** Procurement book of record where sourcing requests are created. USFF is linked from Ariba.

**Purpose:** System of record for sourcing requests and contracts.

### Features
- Sourcing requests
- Contract workspaces
- Reports (used for SPID validation)

### Processes
- None recorded

### User groups
- None recorded

### Technical
- Stack: SAP Ariba (SaaS), Supporting servers (certificates, Java)
- Hosting: Not recorded
- Pattern: Not recorded
- Auth: Not recorded
- APIs: Ariba APIs (limited; no APIs available for SR creation)
- Data sources: None recorded
- Data destinations: PETL via API; Coupa via ITK server scripts
- Dependencies: None recorded

### Operations
- Support model: Team maintains server vulnerabilities: certificate renewals, Java expirations. Works with the Ariba team to create SRs manually while iATLK is failing.

**Known issues**
- None recorded

**Limitations**
- Ariba changes require iATLK updates
- No APIs available to us for SR creation

**Technical debt**
- None recorded

**Compliance**
- Server vulnerability remediation

## Initiatives (9)

### USFF-SPID-ETL: SPID validation ETL
- Status: Planning · Priority P2
- Target: Fast follow after Greenlight
- Summary: Replace the manual Ariba SPID report (saved to SharePoint by the EMS team) with a team-built ETL so contract signed IDs are validated automatically.
- Problem: No true validation check today: SPID validation is fully manual.

### USFF-ARIBA-INT: Two-way SR validation (Ariba / Globality APIs)
- Status: Blocked · Priority P3
- Target: Not set (depends on Globality or Ariba BTP decision)
- Summary: Integrate USFF with Globality or Ariba BTP APIs for two-way sourcing request validation.
- Problem: Ariba has no APIs available to us, so staff validate SRs by manual swivel chair.
- Dependencies: Target sourcing platform decision

### IATLK-STAB: iATLK bot stabilisation
- Status: At risk · Priority P1
- Target: 2 to 4 weeks after the funded developer starts
- Summary: Fix the retriever, duplicate check and business exceptions so the bot creates Ariba SRs reliably again.
- Problem: Failure rate above 70%: files not picked up from Outlook, duplicate entries, frequent business exceptions. SRs are created manually, with delays and missed attachments.
- Progress:
  - Developer funding approved
- Next steps:
  - Onboard UiPath developer
  - Fix Outlook retrieval and duplicate check
  - Review business exception categories

### IATLK-PATH: Long-term SR creation path and VDI to cloud
- Status: Decision needed · Priority P2
- Target: Before UiPath Day 2 handover
- Summary: Choose the target for Ariba SR creation and plan the bot move off VDI.
- Open decision: UiPath Day 2 as a bridge, API-based SR creation (Globality or Ariba BTP), or a Technology-owned tool?

### PETL-MLP3-4: PETL MLP3 and MLP4
- Status: In delivery · Priority P1
- Target: Nov 22, 2026
- Summary: MLP3 adds 11 new Ariba tables. MLP4 adds 4 new fields to existing tables.
- Progress:
  - In delivery
- Next steps:
  - Plan downtime: adding fields drops and replaces the existing schema

### PETL-API-REVIEW: Ariba data review to free API capacity
- Status: Not started · Priority P2
- Target: Before the next PETL MLP
- Summary: Review all ingested Ariba data with the business and developers; cut or reduce refresh where possible instead of buying more API capacity.
- Problem: Daily Ariba API limit of 60 calls. More capacity costs money and Ariba is not the long-term platform.
- Open decision: Which tables and fields can the business retire or refresh less often?

### S2P-COUPA-MLP3: Ariba Coupa automation MLP3 (contract workspace)
- Status: Planning · Priority P2
- Target: F27 Q1 to Q2
- Summary: Required by a finding: extend the MLP1 and MLP2 mechanism to the contract workspace table.
- Open decision: Keep the scripts on the ITK server for another year under an exception, or move hosting now?
- Progress:
  - MLP1 and MLP2 deployed and working with Coupa

### S2P-CHANGE: Ariba release impact analysis for iATLK
- Status: Not started · Priority P2
- Target: Not set
- Summary: Analyse upcoming Ariba changes and get the UiPath developer access to Ariba.

### S2P-BAU: Ariba server vulnerabilities and manual SR support
- Status: BAU · Priority P2
- Target: Ongoing
- Summary: Certificate renewals, Java expirations and other server vulnerabilities, plus manual SR creation with the Ariba team while iATLK is down.

## Integrations (5)

| ID | From | To | Purpose | Method | Frequency | Status | Classification |
|---|---|---|---|---|---|---|---|
| INT-003 | iATLK Sourcing Request Bot | SAP Ariba (Source to Pay) | Create Ariba sourcing requests, update funding confirmation, attach files | RPA (UiPath UI automation) | Daily batch, 7 pm | degraded | confirmed |
| INT-004 | SAP Ariba (Source to Pay) | Procurement ETL (Azure Data Pipeline) | Extract Ariba data for reporting | Ariba REST APIs | Daily | live | confirmed |
| INT-010 | SAP Ariba (Source to Pay) | Coupa | Push Ariba data to Coupa for audit (replaces failing ITK integrations) | Scripts on ITK servers | TBC | live | confirmed |
| INT-011 | SAP Ariba (Source to Pay) | SharePoint (EMS sites) | SPID validation report saved to SharePoint by EMS team | Manual report export | Manual | manual | confirmed |
| INT-015 | SAP Ariba (Source to Pay) | Unified Storefront | USFF is linked from the Ariba site | UI link |  | live | confirmed |

## Gaps
- GAP-001 (confirmed, high): No automated SPID validation. Contract signed IDs are validated from a manual Ariba report saved to SharePoint.
- GAP-003 (confirmed, high): No API for sourcing request creation. Ariba exposes no SR creation APIs to us, so SR creation depends on RPA or manual entry.

## Business capabilities
- CAP-003: Sourcing request creation. Limitations: RPA failure rate above 70%; Manual fallback
- CAP-004: Contract signing validation (SPID) (maturity initial). Limitations: Fully manual Ariba report on SharePoint
- CAP-008: Sourcing event management
- CAP-009: Audit data sync from Ariba to Coupa

## Opportunities (not commitments)
- OPP-002 [idea, high] API-based sourcing request creation: Create SRs through Globality or Ariba BTP APIs.
- OPP-003 [planned, high] Automated SPID validation: Team-built ETL feeding signed IDs into USFF.
- OPP-005 [idea, high] Ariba data rationalisation: Retire or refresh less often the tables and fields nobody uses.

## Working notes


### 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|

### 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Analyse upcoming Ariba changes and their impact on iATLK | Me |  | Not started | 2026-11-08 notes |
| A2 | Get UiPath developer access to Ariba | Me |  | Not started | 2026-11-08 notes |
| A3 | Write requirements for Coupa MLP3 (contract workspace table) | Me |  | Not started | 2026-11-08 notes |
| A4 | Track certificate renewals and Java expirations on Ariba servers | Me |  | In progress | 2026-11-08 notes |

### 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

### 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | S2P-CHANGE | Every Ariba update can require iATLK changes | High | Medium | Me | Release impact analysis before each Ariba update | Open |
| R2 | Risk | S2P-COUPA-MLP3 | ITK server decommission (Archer findings) would strand the Coupa scripts | High | Medium | Me | Decide: one-year exception or new hosting | Open |
| R3 | Issue | S2P-COUPA-MLP3 | Finding requires MLP3 on the contract workspace table | High | High | Me | Scope MLP3 using MLP1 and MLP2 mechanism | Open |

### 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-10-20 | Keep Coupa scripts on the ITK server for another year, or move now? | Pending | Leadership | Deck recommendation: extend one year under documented exception, plan move in parallel |

### 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| Coupa MLP3 contract workspace | Closes finding | Requirements | F27 Q1 to Q2 |

### 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| Ariba team | Platform | Procurement Technology |  | Manual SR creation, Ariba releases |

### 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

### 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- Team maintains Ariba server vulnerabilities: certificates, Java expirations
- Creating SRs manually with the Ariba team while iATLK is failing
- Coupa automation MLP1 and MLP2 deployed; MLP3 needed for a finding (contract workspace table)
- Note: the Oct 20 deck described MLP3 as the sourcing project object. Confirm which is correct


## AI opportunity ideas (proposed)




### Ariba release note impact analyser
- **Status:** Idea
- **Type:** Generative AI
- **Impact:** High
- **Effort:** S
- **Value:** Reads each Ariba release note and flags screens and fields iATLK and the Coupa scripts touch
- **MRM:** Internal productivity use
- **Depends on:** List of screens and fields used by automations

### Vulnerability and certificate expiry forecaster
- **Status:** Idea
- **Type:** Automation
- **Impact:** Medium
- **Effort:** S
- **Value:** Alerts weeks ahead of certificate and Java expirations instead of reacting to findings
- **MRM:** None
- **Depends on:** Server inventory

