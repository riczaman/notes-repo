# Context pack: Globality (GLOB)

> Generated 2026-11-08 from the Procurement Command Centre. Source of truth: data/apps/GLOB/. Treat "proposed" and "unverified" items as unconfirmed.

## Application

| Field | Value |
|---|---|
| ID | GLOB |
| Name | Globality |
| Aliases | GLOB |
| Category | saas |
| Portfolio | supported |
| Status | onboarding |
| Health | unknown |
| My role | Integration lead (later phase) |
| Classification | confirmed |

**Summary:** New SaaS sourcing platform. A partner team runs MRM and base setup; our team integrates it with the ecosystem later.

**Purpose:** Modernise sourcing. Possible path to API-based SR creation.

### Features
- None recorded

### Processes
- None recorded

### User groups
- None recorded

### Technical
- Stack: Not recorded
- Hosting: Not recorded
- Pattern: Not recorded
- Auth: Not recorded
- APIs: None recorded
- Data sources: None recorded
- Data destinations: None recorded
- Dependencies: None recorded

### Operations
- Support model: Not recorded

**Known issues**
- None recorded

**Limitations**
- None recorded

**Technical debt**
- None recorded

**Compliance**
- None recorded

## Initiatives (3)

### USFF-ARIBA-INT: Two-way SR validation (Ariba / Globality APIs)
- Status: Blocked · Priority P3
- Target: Not set (depends on Globality or Ariba BTP decision)
- Summary: Integrate USFF with Globality or Ariba BTP APIs for two-way sourcing request validation.
- Problem: Ariba has no APIs available to us, so staff validate SRs by manual swivel chair.
- Dependencies: Target sourcing platform decision

### IATLK-PATH: Long-term SR creation path and VDI to cloud
- Status: Decision needed · Priority P2
- Target: Before UiPath Day 2 handover
- Summary: Choose the target for Ariba SR creation and plan the bot move off VDI.
- Open decision: UiPath Day 2 as a bridge, API-based SR creation (Globality or Ariba BTP), or a Technology-owned tool?

### GLOB-INT: Globality integrations and prompt engineering
- Status: Not started · Priority P2 · AI-enabled
- Target: After partner team completes MRM and setup
- Summary: Integrate Globality with existing apps, turn off overlapping integrations as it switches on, and tune prompts.

## Integrations (0)

| ID | From | To | Purpose | Method | Frequency | Status | Classification |
|---|---|---|---|---|---|---|---|


## Overlaps
- OVL-003 (investigate, medium confidence): SR creation: iATLK vs Globality / Ariba BTP APIs. If Globality or Ariba BTP exposes SR creation APIs, the iATLK bot becomes redundant.

## Business capabilities
- CAP-008: Sourcing event management

## Model governance obligations
- GOV-014 [in-progress] Model risk process for Globality (approval)

## Opportunities (not commitments)
- OPP-002 [idea, high] API-based sourcing request creation: Create SRs through Globality or Ariba BTP APIs.

## Future-state proposals (not approved unless stated)
- FUT-003 [proposed] USFF creates sourcing requests through Globality or Ariba BTP APIs. Target platform not decided; Ariba BTP is the alternative.

## Working notes


### 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|


### 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Inventory existing integrations that overlap with Globality and must switch off at cutover | Me |  | Not started | 2026-11-08 notes |
| A2 | Get onboarding timeline and handover date from partner team | Me |  | Not started | 2026-11-08 notes |
| A3 | Plan prompt engineering scope | Me |  | Not started | 2026-11-08 notes |

### 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

### 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | GLOB-INT | Overlapping integrations stay on after Globality goes live, creating duplicate data paths | High | Medium | Me | Cutover checklist: switch off old integrations as new ones switch on | Open |
| R2 | Risk | IATLK-PATH | Globality API decision also sets the long-term SR creation path | High | Medium | Me | Track platform decision | Open |

### 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|

### 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|

### 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|

### 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

### 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Context

- Another team runs model MRM and basic setup
- My team joins later for integrations to other apps
- As Globality turns on, overlapping integrations must turn off
- Prompt engineering needed


## AI opportunity ideas (proposed)




### Prompt library and evaluation set
- **Status:** Idea
- **Type:** Prompt engineering
- **Impact:** High
- **Effort:** M
- **Value:** Versioned prompts with a test set so prompt changes are measured, not guessed
- **MRM:** Supports partner team MRM evidence
- **Depends on:** Access to Globality configuration

### USFF to Globality intake hand-off
- **Status:** Idea
- **Type:** Integration + LLM mapping
- **Impact:** High
- **Effort:** L
- **Value:** Approved USFF intakes create Globality projects without re-keying
- **MRM:** Depends on whether mapping uses an LLM
- **Depends on:** Globality APIs

