# Context pack: Procurement ETL (Azure Data Pipeline) (PETL)

> Generated 2026-11-08 from the Procurement Command Centre. Source of truth: data/apps/PETL/. Treat "proposed" and "unverified" items as unconfirmed.

## Application

| Field | Value |
|---|---|
| ID | PETL |
| Name | Procurement ETL (Azure Data Pipeline) |
| Aliases | Azure Data Pipeline, PETL |
| Category | data-pipeline |
| Portfolio | owned |
| Status | live |
| Health | amber |
| My role | Technology Lead |
| Classification | confirmed |

**Summary:** Azure Data Factory pipeline that pulls Ariba data and lands it in Rahona for the Procurement Tracker Power BI dashboard.

**Purpose:** Give the procurement business custom Ariba data for reporting without manual extracts.

### Features
- Ariba API extraction
- ADLS landing
- TIBCO mailbox delivery to Rahona
- MLP3: 11 new Ariba tables
- MLP4: 4 new fields on existing tables

### Processes
- Procurement reporting

### User groups
- None recorded

### Technical
- Stack: Azure Data Factory, Azure Data Lake Storage (ADLS), TIBCO
- Hosting: Azure
- Pattern: Batch ELT
- Auth: Not recorded
- APIs: SAP Ariba APIs (daily limit 60; other hard limits not yet recorded here)
- Data sources: Ariba APIs; USFF DB (planned); Fieldglass (MLP5, proposed)
- Data destinations: Rahona TIBCO mailbox → curated zone; Procurement Tracker (Power BI) via Rahona
- Dependencies: Rahona ingestion team (IDC file, configuration); Data Compass access (DAC) for end users

### Operations
- Support model: Team-owned. Ingestion depends on the Rahona team.

**Known issues**
- None recorded

**Limitations**
- Near the Ariba API daily limit of 60 calls
- Adding fields to existing tables needs downtime (schema dropped and replaced)
- Rahona onboarding takes about a month per change (IDC review and configuration)

**Technical debt**
- None recorded

**Compliance**
- Veracode and Snyk vulnerability maintenance
- Annual DAST rescan
- AMH onboarding (to confirm)

## Initiatives (6)

### USFF-PETL-FEED: USFF data feed to Procurement Tracker
- Status: Blocked · Priority P1
- Target: PAT and Prod once network access is approved
- Summary: Open a connection from the USFF DB to ADF, then push USFF-specific fields through Rahona to the Procurement Tracker dashboard.
- Progress:
  - Dev test complete
- Next steps:
  - TAPS infrastructure team updates the PID document
  - Azure team opens NSG rules and maps the service principal
  - Solution architect updates the architecture blueprint
- Dependencies: TAPS infrastructure; Azure team; Solution architect

### PETL-MLP3-4: PETL MLP3 and MLP4
- Status: In delivery · Priority P1
- Target: Nov 22, 2026
- Summary: MLP3 adds 11 new Ariba tables. MLP4 adds 4 new fields to existing tables.
- Progress:
  - In delivery
- Next steps:
  - Plan downtime: adding fields drops and replaces the existing schema

### PETL-API-REVIEW: Ariba data review to free API capacity
- Status: Not started · Priority P2
- Target: Before the next PETL MLP
- Summary: Review all ingested Ariba data with the business and developers; cut or reduce refresh where possible instead of buying more API capacity.
- Problem: Daily Ariba API limit of 60 calls. More capacity costs money and Ariba is not the long-term platform.
- Open decision: Which tables and fields can the business retire or refresh less often?

### PETL-MLP5: PETL MLP5: Fieldglass source
- Status: Planning · Priority P3
- Target: Not set (waiting on data availability)
- Summary: Add SAP Fieldglass as a new source once its data and API are available.
- Dependencies: Fieldglass data availability; Scope agreement

### PETL-ADLS: Direct ADLS-to-ADLS copy to Rahona
- Status: Not started · Priority P3
- Target: Not planned
- Summary: New practice replacing the TIBCO mailbox. Proven in sandbox only; rolling to all environments may be substantial work.

### PETL-COMPLY: PETL compliance: DAST rescan, Veracode, Snyk
- Status: BAU · Priority P2
- Target: DAST rescan due next (annual)
- Summary: Annual DAST rescan, ongoing Veracode and Snyk remediation, and AMH onboarding (to confirm).

## Integrations (5)

| ID | From | To | Purpose | Method | Frequency | Status | Classification |
|---|---|---|---|---|---|---|---|
| INT-004 | SAP Ariba (Source to Pay) | Procurement ETL (Azure Data Pipeline) | Extract Ariba data for reporting | Ariba REST APIs | Daily | live | confirmed |
| INT-005 | Procurement ETL (Azure Data Pipeline) | Rahona Data Platform | Land curated procurement data | TIBCO mailbox from ADLS | Daily | live | confirmed |
| INT-007 | Unified Storefront | Procurement ETL (Azure Data Pipeline) | Send USFF-specific fields to the Procurement Tracker | ADF connection to USFF DB | TBC | in-delivery | confirmed |
| INT-008 | Procurement ETL (Azure Data Pipeline) | Rahona Data Platform | Replace TIBCO with direct copy | ADLS-to-ADLS copy |  | planned | proposed |
| INT-014 | SAP Fieldglass | Procurement ETL (Azure Data Pipeline) | New reporting source (MLP5) | API (TBC) |  | planned | proposed |

## Business capabilities
- CAP-005: Procurement reporting. Limitations: Ariba API daily limit of 60; Rahona onboarding about one month per change

## Opportunities (not commitments)
- OPP-005 [idea, high] Ariba data rationalisation: Retire or refresh less often the tables and fields nobody uses.
- OPP-008 [idea, low] Replace TIBCO with ADLS-to-ADLS copy: Roll the sandbox-proven direct copy to all environments.

## Future-state proposals (not approved unless stated)
- FUT-004 [proposed] Retire the TIBCO hop into Rahona. Replaced by the direct ADLS-to-ADLS copy (INT-008), proven in sandbox only.
- FUT-008 [proposed] Retire unused Ariba tables and fields to free API capacity

## Working notes


### 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2026-11-22 | MLP3 (11 new tables) and MLP4 (4 new fields) | Dev team | In progress | MLP4 needs downtime: schema dropped and replaced |

### 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | Run review of all ingested Ariba data with business and devs: what can refresh less often or be descoped | Me |  | Not started | 2026-11-08 notes |
| A2 | Plan and communicate MLP4 downtime | Dev team | 2026-11-22 | In progress | 2026-11-08 notes |
| A3 | Schedule annual DAST rescan | Me |  | Not started | 2026-11-08 notes |
| A4 | Keep Veracode and Snyk findings remediated | Dev team |  | In progress | 2026-11-08 notes |
| A5 | Confirm AMH onboarding scope for PETL | Me |  | Not started | 2026-11-08 notes (to confirm) |
| A6 | Size ADLS-to-ADLS copy for all environments | Dev team |  | Not started | 2026-11-08 notes |

### 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|
| 2026-11-08 | Procurement business | USFF fields in the Procurement Tracker |  | Open | See USFF-PETL-FEED |

### 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | PETL-API-REVIEW | Ariba API daily limit of 60. More data needs more capacity at extra cost, and Ariba is not the long-term platform | High | High | Me | Review and retire unused tables and fields first | Open |
| R2 | Issue | PETL-MLP3-4 | Rahona ingestion takes about a month per change (IDC file, review, configuration) | Medium | High | Me | Ask for self-serve onboarding | Open |
| R3 | Risk | PETL-MLP3-4 | Adding fields to existing tables needs downtime | Medium | High | Dev team | Schedule and communicate windows | Open |
| R4 | Risk | PETL-MLP5 | Fieldglass data not yet available; timelines move until data and scope are agreed | Medium | High | Me | Hold MLP5 dates until data is testable | Open |
| R5 | Risk | PETL-ADLS | ADLS-to-ADLS copy is the new practice but proven only in sandbox; may be substantial work | Medium | Medium | Me | Size it before it becomes mandatory | Open |

### 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|
| 2026-10-20 | Can the business retire unused tables and fields to free Ariba API capacity? | Pending | Business | Ariba Coupa automation shares the same limits |
| 2026-10-20 | Can Rahona ingestion be fully self-serve for our dev team? | Pending | Rahona | Cuts about a month per change |

### 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|
| MLP5 Fieldglass source | Contingent workforce data in reporting | Data availability, API access | Not set |
| ADLS-to-ADLS copy | Retire TIBCO hop | Effort sizing | Not planned |

### 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|
| Rahona ingestion team | Data platform | Rahona |  | IDC review, configuration |

### 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|
| Give an end user access to PETL data in Rahona | 1. Rahona onboarding (IDC) complete  2. User submits a DAC request in Data Compass  3. BSA and end user are contributors, so they can raise it directly | Data Compass | 2026-11-08 |

### 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Status

- MLP3 and MLP4 expected to finish by Nov 22
- New practice: direct ADLS-to-ADLS copy instead of TIBCO; sandbox only so far


## AI opportunity ideas (proposed)




### API usage optimiser
- **Status:** Idea
- **Type:** Analytics
- **Impact:** High
- **Effort:** S
- **Value:** Shows which tables and fields are actually used in the Procurement Tracker so the business can retire the rest and free Ariba API calls
- **MRM:** None
- **Depends on:** Power BI usage metrics

### Natural language Q&A over procurement data
- **Status:** Idea
- **Type:** Text-to-SQL / Copilot for Power BI
- **Impact:** Medium
- **Effort:** M
- **Value:** Business users ask questions without waiting for new dashboard pages
- **MRM:** Enterprise AI intake and model review
- **Depends on:** Curated zone semantic model

### Data quality anomaly detection
- **Status:** Idea
- **Type:** Statistical / ML anomaly detection
- **Impact:** Medium
- **Effort:** M
- **Value:** Catches schema drift and volume drops after each load, before the business sees a broken dashboard
- **MRM:** Light if statistical thresholds only
- **Depends on:** Load metadata logging

### IDC file and onboarding drafter
- **Status:** Idea
- **Type:** Generative AI
- **Impact:** Medium
- **Effort:** S
- **Value:** Drafts the Rahona IDC file from table metadata to shorten the month-long onboarding loop
- **MRM:** Internal productivity use; confirm with MRM
- **Depends on:** IDC template

