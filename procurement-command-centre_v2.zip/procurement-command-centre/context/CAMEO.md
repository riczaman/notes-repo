# Context pack: Agiloft (Cameo) (CAMEO)

> Generated 2026-11-08 from the Procurement Command Centre. Source of truth: data/apps/CAMEO/. Treat "proposed" and "unverified" items as unconfirmed.

## Application

| Field | Value |
|---|---|
| ID | CAMEO |
| Name | Agiloft (Cameo) |
| Aliases | Agiloft, Cameo |
| Category | saas |
| Portfolio | supported |
| Status | onboarding |
| Health | unknown |
| My role | Integration lead (later phase) |
| Classification | confirmed |

**Summary:** New contract lifecycle management SaaS. A partner team runs MRM and base setup; our team integrates it later.

**Purpose:** Contract lifecycle management. May replace Contract Buddy.

### Features
- None recorded

### Processes
- None recorded

### User groups
- None recorded

### Technical
- Stack: Not recorded
- Hosting: Not recorded
- Pattern: Not recorded
- Auth: Not recorded
- APIs: None recorded
- Data sources: None recorded
- Data destinations: None recorded
- Dependencies: None recorded

### Operations
- Support model: Not recorded

**Known issues**
- None recorded

**Limitations**
- None recorded

**Technical debt**
- None recorded

**Compliance**
- None recorded

## Initiatives (1)

### CAMEO-INT: Agiloft integrations, requirements and prompt engineering
- Status: Not started · Priority P2 · AI-enabled
- Target: Agiloft onboarding expected Jan 2027
- Summary: BSA-led requirements, integrations to existing apps, retiring overlapping integrations, and prompt engineering.

## Integrations (0)

| ID | From | To | Purpose | Method | Frequency | Status | Classification |
|---|---|---|---|---|---|---|---|


## Overlaps
- OVL-002 (potential, medium confidence): Contract Buddy vs Agiloft contract AI. Agiloft may cover Contract Buddy extraction and deviation scoring once fully onboarded.

## Model governance obligations
- GOV-015 [in-progress] Model risk process for Agiloft (approval)

## Opportunities (not commitments)
- OPP-006 [idea, medium] Contract AI consolidation (Contract Buddy and Agiloft): Keep Contract Buddy only for use cases Agiloft does not cover.

## Working notes


### 01 Key Dates & Deadlines

> Hard dates only. Use YYYY-MM-DD so Copilot can sort them.

| Date | Milestone / deadline | Owner | Status | Notes |
|---|---|---|---|---|
| 2027-01 | Agiloft fully onboarded | Partner team | Not started | Deck says January |

### 02 Action Items

> Things I own or am chasing. Move done items to the bottom.

| ID | Action | Owner | Due | Status | Source |
|---|---|---|---|---|---|
| A1 | BSA to start requirements for Agiloft integrations | BSA |  | Not started | 2026-11-08 notes |
| A2 | Compare Contract Buddy extraction and deviation scoring with Agiloft | Me |  | Not started | Deck decision 7 |
| A3 | Inventory overlapping integrations to switch off at cutover | Me |  | Not started | 2026-11-08 notes |

### 03 Requests Log

> Asks from leadership and stakeholders, so nothing gets lost.

| Received | From | Request | Due | Status | Outcome |
|---|---|---|---|---|---|

### 04 Risks & Issues

> Risk = might happen. Issue = happening now.

| ID | Type | Initiative | Description | Impact | Likelihood | Owner | Mitigation / next step | Status |
|---|---|---|---|---|---|---|---|---|
| R1 | Risk | CAMEO-INT | Overlapping integrations stay on after go-live | High | Medium | Me | Cutover checklist | Open |
| R2 | Risk | CAMEO-INT | BSA capacity for requirements | Medium | Medium | Me | Book BSA time early | Open |

### 05 Decisions

> What was decided, by whom, and why. Pending decisions stay at the top.

| Date | Decision | Status | Decided by | Why |
|---|---|---|---|---|

### 06 Future State & Backlog

> Ideas and next-phase work. Not committed yet.

| Item | Value | Depends on | Target |
|---|---|---|---|

### 07 Contacts

> Who owns what. Note how they prefer to be reached.

| Name | Role | Team / company | Email / Teams | Owns / go to for |
|---|---|---|---|---|

### 08 How-To & Knowledge

> Steps you will forget in 3 months. Write it once here.

| Task | Steps | Where / link | Last used |
|---|---|---|---|

### 09 Meeting Notes

> Newest on top. Copy actions into section 02.

### 2026-11-08 · Context

- Similar to Globality: partner team does MRM and setup, we integrate later
- BSA needs to help with requirements
- Prompt engineering needed
- May replace Contract Buddy


## AI opportunity ideas (proposed)




### Clause deviation prompts tuned on Contract Buddy learnings
- **Status:** Idea
- **Type:** Prompt engineering
- **Impact:** High
- **Effort:** M
- **Value:** Reuses Contract Buddy deviation rules and test sets so Agiloft starts at known accuracy
- **MRM:** Partner team MRM
- **Depends on:** Contract Buddy test set

### Contract obligation tracker
- **Status:** Idea
- **Type:** Extraction + reminders
- **Impact:** Medium
- **Effort:** M
- **Value:** Extracts renewal and notice dates and pushes reminders to owners
- **MRM:** Model review if extraction is AI-based
- **Depends on:** Agiloft data model

