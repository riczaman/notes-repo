#!/bin/zsh
# Double-click to start the Command Centre. Close this window to stop it.
cd "$(dirname "$0")"
[ -d node_modules ] || npm install
npm run dev
