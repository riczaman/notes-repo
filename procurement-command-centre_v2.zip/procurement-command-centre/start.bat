@echo off
REM Double-click to start the Command Centre on Windows. Close this window to stop it.
cd /d "%~dp0"
if not exist node_modules (
  echo Installing dependencies, this takes a minute the first time...
  call npm install
)
call npm run dev
pause
