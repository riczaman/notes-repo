# Research agent prompt: application summary

Paste this into your research agent together with the source documents for one application. Attach `schemas/application-summary.schema.json`.

---

You are documenting one application in the Procurement TPMM technology landscape. Read the attached source documents and return **one JSON object** that validates against the attached JSON Schema (`application-summary.schema.json`). Return JSON only, no commentary.

## Rules

1. **id is mandatory and stable.** Use the existing application ID if one is given to you: `{{APP_ID}}`. Never invent a new ID for an application that already exists, even if its name differs in the documents. Put other names in `aliases`.
2. **Only include facts the documents support.** If a field is not covered, leave it out. Do not write "N/A", "Unknown" or empty strings. The importer never overwrites existing data with empty values, so omitting a field is always safe.
3. **Do not infer integrations or ownership.** Name a data source, destination, dependency or owner only when a document states it.
4. **Classification:** set `classification` for the record as a whole:
   - `confirmed`: directly stated in the documents
   - `inferred`: implied by several documents, not stated outright
   - `proposed`: a future-state change
   - `unverified`: mentioned but needs confirmation
5. **Evidence:** list every document you used in `sourceDocuments` with `source` (title), `file`, `ref` (sheet, page or slide), `section`, `url` if known, `reviewed` (today, YYYY-MM-DD) and `confidence` (high, medium, low).
6. **summaryVersion:** use `YYYY-MM-DD.N` (N increments if you produce more than one summary on the same day).
7. **Write plainly.** Short, factual sentences. No marketing language.
8. **Lists:** one item per entry, no numbering, no trailing full stops.

## Field guide

| Field | What goes in it |
|---|---|
| `summary` | One line: what it does and for whom |
| `purpose` | The business problem it solves |
| `features` | Key functions users see |
| `processes` | Business processes it supports |
| `userGroups` | Who uses it |
| `tech.stack` | Languages, platforms, products |
| `tech.hosting` | Where it runs |
| `tech.dataSources` / `tech.dataDestinations` | Systems it reads from and writes to, as named in the documents |
| `tech.apis` | APIs exposed or consumed, with limits if stated |
| `tech.auth` | Authentication and authorisation approach |
| `ops.knownIssues` | Problems happening now |
| `ops.limitations` | Constraints by design |
| `ops.techDebt` | Known shortcuts or deferred work |
| `ops.compliance` | Findings, scans, attestations, model risk items |

## Optional: narrative summary

If the documents contain context that does not fit the fields (history, rationale, open questions), also produce a Markdown file:

```markdown
---
app: {{APP_ID}}
title: Short title of this summary
---

# Short title

Plain-language narrative with headings and bullets.
```

The importer stores it under the application's Documents tab.
