# Procurement Portfolio Command Centre: Architecture

Version 2 · 2026-11-08 · Owner: Ricky Zaman

## 1. Decision: code package, not a single HTML file

| Option | Verdict | Why |
|---|---|---|
| One HTML file you edit by hand | Rejected | Every update means editing code. No safe import, no history, and notes are trapped inside markup that Copilot reads badly. |
| HTML + a JSON file you edit by hand | Rejected | This is what killed the last tracker (`product-portfolio-system`): data entry by editing JSON. |
| **Local app + plain files on disk (chosen)** | **Chosen** | You edit in the UI or in VS Code. Both write the same JSON and Markdown files. The files double as Copilot context, live in git, and need no database or cloud. |

The app runs locally with `npm run dev` (or double-click `start.command`). A small Vite server plugin reads and writes the `data/` folder and pushes a live refresh to the browser when any file changes, including edits you make directly in VS Code.

## 2. Technical architecture

```
Browser (React 19 + TypeScript)
  ├─ Pages: Overview · Workboard · Applications · App workspace · Ecosystem map · Ingestion
  ├─ Store (React context): loads one snapshot of all data, derives aggregates
  ├─ Parsers: notes.md → sections/tables · ai-ideas.md → idea cards
  └─ Writers: serialize back to Markdown/JSON, send atomic batch writes
            │  GET /api/data · POST /api/batch · WS event "data:changed"
Vite dev server plugin (Node)
  ├─ Path guard: only data/**/*.json|md, no traversal
  ├─ Atomic writes: temp file + rename, all files in a batch or none
  └─ File watcher on data/ → browser refresh
Disk: data/ (source of truth, git-tracked)
```

Libraries and why:

| Need | Library | Reason |
|---|---|---|
| UI | React 19, React Router 7 (hash routes) | Standard, typed, works offline |
| Network diagrams | `@xyflow/react` + `@dagrejs/dagre` | Zoom, pan, custom nodes, automatic left-to-right layout |
| Charts | Recharts | Declarative, themeable with CSS variables |
| Motion | GSAP + CSS transitions | Your standard stack. No framer-motion |
| Markdown | `react-markdown` + `remark-gfm`, `yaml` | GFM tables render natively; front matter parsed with `yaml` |
| Validation | Zod 4 | One schema drives TypeScript types, import validation and the JSON Schema given to your research agent |
| Icons, fonts | lucide-react, Fontsource (Inter, Space Grotesk, JetBrains Mono) | Bundled locally, no CDN needed at work |

## 3. Folder structure

```
procurement-command-centre/
├─ data/                         ← SOURCE OF TRUTH (edit here or in the UI)
│  ├─ apps/<APP_ID>/
│  │  ├─ profile.json            application record (landscape + directory)
│  │  ├─ notes.md                OneNote-style living notes (9 sections)
│  │  ├─ ai-ideas.md             AI opportunity ideas
│  │  └─ docs/*.md               imported narrative summaries
│  ├─ portfolio/
│  │  ├─ initiatives.json        workboard cards
│  │  └─ workstreams.json
│  ├─ landscape/
│  │  ├─ integrations.json       documented connections only
│  │  ├─ lifecycle.json          stages (empty until you supply them)
│  │  ├─ capabilities.json
│  │  ├─ overlaps.json
│  │  ├─ gaps.json
│  │  └─ data-entities.json      system of record, owners, quality issues
│  ├─ strategy/
│  │  ├─ future-state.json       proposed changes (never approved by default)
│  │  └─ opportunities.json
│  ├─ governance/
│  │  └─ model-governance.json   MRM obligations per model
│  └─ history/
│     ├─ imports.json            import log
│     └─ snapshots/<IMP-ID>.json before/after per import
├─ context/                      generated Copilot context packs (one .md per app)
├─ schemas/                      generated JSON Schema for the research agent
├─ docs/                         this file, research agent prompt
├─ server/dataApi.ts             Vite plugin: read, write, watch
├─ scripts/                      schema export
└─ src/
   ├─ domain/                    schemas.ts, parsers, merge/diff, selectors
   ├─ store/                     DataProvider
   ├─ components/                design-system primitives
   ├─ features/                  overview, workboard, apps, notes, ai, map, ingest
   └─ styles/                    tokens.css, base.css, components.css
```

## 4. Data model

One rule above all: **each fact lives in one place.**

| Entity | File | Key | Owns |
|---|---|---|---|
| Application | `apps/<ID>/profile.json` | `id` (e.g. `USFF`) | Identity, purpose, owners, tech, ops, docs, evidence |
| Notes | `apps/<ID>/notes.md` | app folder | Key dates, actions, requests, risks, decisions, backlog, contacts, how-to, meeting notes |
| AI ideas | `apps/<ID>/ai-ideas.md` | heading | Ideas, value, effort, MRM impact |
| Initiative | `portfolio/initiatives.json` | `id` (e.g. `USFF-EMS-MLP1`) | Status, target, problem, next steps, open decision, `appIds[]` |
| Integration | `landscape/integrations.json` | `id` (`INT-###`) | Source, target, data, method, frequency, status, classification |
| Overlap / Gap | `landscape/*.json` | `OVL-###` / `GAP-###` | Evidence-backed findings |
| Import | `history/` | `IMP-<timestamp>` | Before/after snapshot, source refs |

Relationships are ID references only (`appIds`, `source`, `target`). The landscape and the project workspace read the same `profile.json`, so there are no copies to drift.

Risks and decisions live in each app's `notes.md` tables, not in JSON. The Overview aggregates them across apps. You maintain one table; leadership sees the rollup.

### Information classification (every important record)

`confirmed` (in a source document) · `inferred` (implied by several sources) · `proposed` (future state) · `unverified` (needs confirmation) · `undocumented` (not yet established). Evidence entries carry source, file, page/sheet, section, URL, reviewed date, validated date and confidence. Owner statements from your notes are recorded as source `Owner notes` with the date.

### Import and merge rules

1. Match on `id` only. A name or alias match raises a warning, never an automatic merge.
2. Never overwrite a field with an empty value.
3. Arrays of strings: union. Arrays of objects: merge by `id`.
4. Both values present and different: flagged as a conflict; you choose.
5. Nothing is written until you approve. Each import stores a before/after snapshot.

## 5. Navigation

```
Command Centre
├─ Portfolio
│    ├─ Overview            KPIs, status mix, timeline, decisions, top risks, workload heatmap
│    ├─ Workboard           Kanban by status; create, edit, delete initiatives
│    └─ Applications        Directory → App workspace
│         └─ <App>          Overview · Notes · AI ideas · Architecture profile · Integrations · Documents & history
├─ Landscape
│    ├─ Lifecycle           Stages (you define), four views: business, apps, capabilities, integrations
│    ├─ Ecosystem map       Documented integrations, upstream/downstream tracing
│    ├─ Capabilities        Capability map and app coverage matrix
│    ├─ Overlaps            Compare 2 to 4 apps; overlap register
│    ├─ Gaps                Coverage heatmap; gap register
│    └─ Data flows          Entity lineage, roles, system of record
├─ Strategy and governance
│    ├─ Current vs future   Side-by-side diagrams; change register (proposals)
│    ├─ Opportunities       Roadmap by quarter; register
│    ├─ Model governance    MRM obligations per model
│    └─ Executive view      Nine generated slides, presentation mode, PDF export
└─ Data ingestion           Paste or drop, validate, diff, approve, history
```

The governance register holds recurring model-risk obligations (testing cadence, artifacts, approvals, monitoring). One-off tasks stay in each app's notes section 02.

## 6. Design system

- **Direction:** quiet, dense, high-contrast product UI. Dark graphite default, true light theme. No purple gradients, glass cards, default blue or cream.
- **Accent:** signal teal for interaction; status colours carry meaning only.
- **Type:** Space Grotesk (display, numbers), Inter (UI), JetBrains Mono (IDs, dates).
- **Status scale:** In delivery (teal) · Decision needed (amber) · At risk (orange) · Blocked (red) · Planning (sky) · BAU (slate-green) · Not started (grey) · Done (green). Always a filled pill plus label, never colour alone.
- **Classification scale:** confirmed (solid) · inferred (outline) · proposed (dashed) · unverified (dotted) · undocumented (hatched).
- **Motion:** staggered entrance, count-up KPIs, animated edges for live flows. Respects `prefers-reduced-motion`.
- **Layout:** fixed left rail; page header scrolls away with content (nothing floats over content).

## 7. Milestones

| # | Milestone | Contents | State |
|---|---|---|---|
| M1 | Foundation | Schemas, file API with atomic writes and live reload, seed data, validation | Done |
| M2 | Portfolio | Overview, Workboard, Directory, App workspace with Notes and AI Ideas, Copilot context export | Done |
| M3 | Ingestion + map | JSON/MD/paste import with diff and approval, history, Ecosystem map | Done |
| M4 | Intelligence | Lifecycle (stages entered by you), capabilities, overlap compare, gap heatmap, data flows | Done |
| M5 | Strategy | Current vs future state, opportunities and roadmap, model governance | Done |
| M6 | Executive | Presentation mode and PDF export | Done |
| M7 | Editing | Create, edit and delete for every record type in the UI | Done |
| Next | Optional | Read-only HTML snapshot to share without running the app; search across everything | Not started |

## 8. Key technical risks

| Risk | Impact | Mitigation |
|---|---|---|
| Work laptop blocks `npm install` or local servers | App will not run at work | Read-only HTML snapshot export (M6); data files stay readable either way |
| Markdown tables edited by hand drift from expected columns | Rollups miss rows | Parser matches columns by header name, tolerates extra columns, shows a warning chip |
| Two sources of truth creep in | Conflicting status | One-fact-one-place rule above; risks/decisions only in notes.md |
| Research agent output varies | Bad imports | Zod validation, JSON Schema handed to the agent, preview and diff before commit |
| Map clutter as apps grow | Unreadable diagram | Dagre layout, filters, isolate-network mode, classification filters |
| No backups | Data loss | `git init` in the project; every import also snapshots |
