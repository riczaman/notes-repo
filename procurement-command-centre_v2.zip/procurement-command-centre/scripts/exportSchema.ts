/**
 * Writes the JSON Schema your research agent should follow.
 * Run: npm run schema
 */
import fs from 'node:fs';
import { z } from 'zod';
import { ApplicationSummary } from '../src/domain/schemas';

const schema = z.toJSONSchema(ApplicationSummary, { io: 'input' });
fs.mkdirSync('schemas', { recursive: true });
fs.writeFileSync('schemas/application-summary.schema.json', JSON.stringify({ title: 'Application summary', ...schema }, null, 2) + '\n');
console.log('Wrote schemas/application-summary.schema.json');
